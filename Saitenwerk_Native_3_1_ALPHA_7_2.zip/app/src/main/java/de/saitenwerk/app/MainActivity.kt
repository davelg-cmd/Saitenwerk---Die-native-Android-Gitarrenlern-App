package de.saitenwerk.app

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.card.MaterialCardView
import org.json.JSONArray
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private var micGrantedAction: (() -> Unit)? = null
    private var contentFrameId: Int = View.NO_ID
    private val requestMic = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) micGrantedAction?.invoke()
        else Toast.makeText(this, "Für das Stimmgerät wird Mikrofonzugriff benötigt.", Toast.LENGTH_LONG).show()
        micGrantedAction = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = getColor(R.color.sw_navy)
        window.navigationBarColor = getColor(R.color.sw_navy)
        setContentView(buildRoot())
        if (savedInstanceState == null) show(HomeFragment())
    }

    private fun buildRoot(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.sw_navy))
        }
        val frame = FrameLayout(this).also { contentFrameId = View.generateViewId(); it.id = contentFrameId }
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = BottomNavigationView(this).apply {
            setBackgroundColor(getColor(R.color.sw_surface))
            menu.add(0, 1, 0, "Start").setIcon(android.R.drawable.ic_menu_view)
            menu.add(0, 2, 1, "Stimmen").setIcon(android.R.drawable.ic_btn_speak_now)
            menu.add(0, 3, 2, "Akkorde").setIcon(android.R.drawable.ic_menu_edit)
            menu.add(0, 4, 3, "Lieder").setIcon(android.R.drawable.ic_menu_agenda)
            menu.add(0, 5, 4, "Lernstudio").setIcon(android.R.drawable.ic_media_play)
            // BottomNavigationView unterstützt maximal fünf Einträge.
            // Den Lernpfad erreichen Nutzer über das Lernstudio und die Startseite.
            labelVisibilityMode = BottomNavigationView.LABEL_VISIBILITY_LABELED
            setOnItemSelectedListener { item -> openSection(item.itemId); true }
        }
        root.addView(nav, LinearLayout.LayoutParams(-1, dp(68)))
        return root
    }

    private fun show(fragment: Fragment) {
        supportFragmentManager.beginTransaction().replace(contentFrameId, fragment).commit()
    }

    fun openSection(id: Int) {
        when (id) {
            1 -> show(HomeFragment())
            2 -> show(TunerFragment())
            3 -> show(ChordsFragment())
            4 -> show(SongsFragment())
            5 -> show(LearnFragment())
            6 -> show(PathFragment())
        }
    }

    fun openSong(song: Song) {
        show(SongDetailFragment.newInstance(song))
    }

    fun askMic(onGranted: () -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) onGranted()
        else { micGrantedAction = onGranted; requestMic.launch(Manifest.permission.RECORD_AUDIO) }
    }

    fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()
    fun title(value: String) = TextView(this).apply {
        text = value; setTextColor(getColor(R.color.sw_text)); textSize = 27f
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(dp(20), dp(22), dp(20), dp(12))
    }
    fun body(value: String, size: Float = 15f) = TextView(this).apply {
        text = value; textSize = size; setTextColor(getColor(R.color.sw_muted)); setPadding(dp(20), 0, dp(20), dp(12))
    }
    fun card(): MaterialCardView = MaterialCardView(this).apply {
        setCardBackgroundColor(getColor(R.color.sw_surface)); radius = dp(18).toFloat()
        strokeColor = getColor(R.color.sw_surface2); strokeWidth = dp(1)
    }
    fun button(value: String) = Button(this).apply {
        text = value; isAllCaps = false; setTextColor(getColor(R.color.sw_text))
        setBackgroundColor(getColor(R.color.sw_surface2))
    }
}

class HomeFragment : Fragment() {
    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity
        val root = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        root.addView(a.title("Heute Gitarre spielen."))
        root.addView(a.body("Dein persönlicher Gitarrenbegleiter – stimmen, Akkorde lernen, Songs spielen und Schritt für Schritt besser werden."))
        val card = a.card()
        val inner = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(18), a.dp(18), a.dp(18), a.dp(18)) }
        inner.addView(TextView(a).apply { text = "SAITENWERK"; textSize = 23f; setTextColor(a.getColor(R.color.sw_copper)); setTypeface(typeface, 1) })
        inner.addView(TextView(a).apply { text = "Gitarre · Stimmen · Üben · Akkorde"; setTextColor(a.getColor(R.color.sw_muted)) })
        card.addView(inner)
        root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(14)) })
        val entries = listOf("🎸  Stimmgerät" to 2, "◉  Akkorde lernen" to 3, "♫  Liederbuch" to 4, "◆  Lernstudio" to 5, "↗  Lernpfad" to 6)
        entries.forEach { (label, section) ->
            val b = a.button(label); b.setOnClickListener { a.openSection(section) }
            root.addView(b, LinearLayout.LayoutParams(-1, a.dp(50)).apply { setMargins(a.dp(16), a.dp(4), a.dp(16), a.dp(4)) })
        }
        return ScrollView(a).apply { addView(root) }
    }
}

class TunerFragment : Fragment() {
    @Volatile private var active = false
    private var recorder: AudioRecord? = null
    private var worker: Thread? = null
    private var noteView: TextView? = null
    private var hzView: TextView? = null
    private var centsView: TextView? = null
    private var meter: ProgressBar? = null
    private var startButton: Button? = null

    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity
        val root = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        root.addView(a.title("Stimmgerät"))
        root.addView(a.body("Chromatischer Tuner · Standardstimmung E–A–D–G–B–E"))
        val card = a.card()
        val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(a.dp(20), a.dp(22), a.dp(20), a.dp(22)) }
        noteView = TextView(a).apply { text = "—"; textSize = 60f; gravity = Gravity.CENTER; setTextColor(a.getColor(R.color.sw_copper)); setTypeface(typeface, 1) }
        hzView = TextView(a).apply { text = "Warte auf einen Ton"; textSize = 18f; gravity = Gravity.CENTER; setTextColor(a.getColor(R.color.sw_text)) }
        centsView = TextView(a).apply { text = "0 Cent"; gravity = Gravity.CENTER; setTextColor(a.getColor(R.color.sw_muted)) }
        meter = ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progress = 50 }
        startButton = a.button("Stimmen starten").also { it.setOnClickListener { if (active) stopTuner() else a.askMic { startTuner() } } }
        box.addView(noteView, LinearLayout.LayoutParams(-1, a.dp(82)))
        box.addView(hzView, LinearLayout.LayoutParams(-1, a.dp(34)))
        box.addView(centsView, LinearLayout.LayoutParams(-1, a.dp(32)))
        box.addView(meter, LinearLayout.LayoutParams(-1, a.dp(12)))
        box.addView(startButton, LinearLayout.LayoutParams(-1, a.dp(52)).apply { topMargin = a.dp(22) })
        card.addView(box)
        root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(16)) })
        root.addView(a.body("Tipp: Spiele eine einzelne Saite möglichst gleichmäßig an und dämpfe die übrigen Saiten."))
        return ScrollView(a).apply { addView(root) }
    }

    private fun startTuner() {
        if (active) return
        val rate = 44100
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) { Toast.makeText(requireContext(), "Audioaufnahme wird von diesem Gerät nicht unterstützt.", Toast.LENGTH_LONG).show(); return }
        try {
            val size = maxOf(min, 8192)
            val audio = AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size)
            check(audio.state == AudioRecord.STATE_INITIALIZED) { "AudioRecord konnte nicht initialisiert werden" }
            recorder = audio; audio.startRecording(); active = true; startButton?.text = "Stimmen stoppen"
            worker = Thread {
                val samples = ShortArray(4096)
                while (active) {
                    val n = audio.read(samples, 0, samples.size)
                    if (n > 2048) {
                        val hz = estimatePitch(samples, n, rate)
                        if (hz in 65.0..1100.0) {
                            val midi = (69 + 12 * ln(hz / 440.0) / ln(2.0)).roundToInt()
                            val target = 440.0 * 2.0.pow((midi - 69) / 12.0)
                            val cents = (1200 * ln(hz / target) / ln(2.0)).roundToInt()
                            val names = arrayOf("C", "C♯", "D", "D♯", "E", "F", "F♯", "G", "G♯", "A", "A♯", "B")
                            val note = names[(midi % 12 + 12) % 12] + (midi / 12 - 1)
                            activity?.runOnUiThread {
                                if (active) {
                                    noteView?.text = note; hzView?.text = "%.1f Hz".format(hz)
                                    centsView?.text = when { cents > 2 -> "+$cents Cent · zu hoch"; cents < -2 -> "$cents Cent · zu tief"; else -> "0 Cent · gestimmt" }
                                    meter?.progress = (50 + cents / 2).coerceIn(0, 100)
                                }
                            }
                        }
                    }
                }
            }.apply { name = "Saitenwerk-Tuner"; start() }
        } catch (e: Exception) {
            active = false; releaseRecorder(); startButton?.text = "Erneut versuchen"
            Toast.makeText(requireContext(), "Mikrofonfehler: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun estimatePitch(x: ShortArray, n: Int, sr: Int): Double {
        val minLag = sr / 1100; val maxLag = minOf(sr / 60, n / 2)
        var bestLag = 0; var best = Double.NEGATIVE_INFINITY
        for (lag in minLag..maxLag step 2) {
            var sum = 0.0
            for (i in 0 until n - lag step 3) sum += x[i].toDouble() * x[i + lag].toDouble()
            if (sum > best) { best = sum; bestLag = lag }
        }
        return if (bestLag > 0) sr.toDouble() / bestLag else -1.0
    }

    private fun releaseRecorder() {
        try { recorder?.stop() } catch (_: Exception) { }
        try { recorder?.release() } catch (_: Exception) { }
        recorder = null; worker = null
    }
    private fun stopTuner() { active = false; releaseRecorder(); startButton?.text = "Stimmen starten" }
    override fun onPause() { stopTuner(); super.onPause() }
    override fun onDestroyView() { stopTuner(); noteView = null; hzView = null; centsView = null; meter = null; startButton = null; super.onDestroyView() }
}

data class ChordShape(val name: String, val quality: String, val frets: IntArray, val baseFret: Int = 1, val note: String = "")
object ChordLibrary {
    val all = listOf(
        ChordShape("C", "Dur", intArrayOf(-1,3,2,0,1,0), note="Offener C-Dur-Griff"),
        ChordShape("G", "Dur", intArrayOf(3,2,0,0,0,3), note="Offener G-Dur-Griff"),
        ChordShape("D", "Dur", intArrayOf(-1,-1,0,2,3,2), note="Offener D-Dur-Griff"),
        ChordShape("A", "Dur", intArrayOf(-1,0,2,2,2,0), note="Offener A-Dur-Griff"),
        ChordShape("E", "Dur", intArrayOf(0,2,2,1,0,0), note="Offener E-Dur-Griff"),
        ChordShape("F", "Dur", intArrayOf(1,3,3,2,1,1), note="Barré-Griff im 1. Bund"),
        ChordShape("Am", "Moll", intArrayOf(-1,0,2,2,1,0)),
        ChordShape("Em", "Moll", intArrayOf(0,2,2,0,0,0)),
        ChordShape("Dm", "Moll", intArrayOf(-1,-1,0,2,3,1)),
        ChordShape("Bm", "Moll", intArrayOf(-1,2,4,4,3,2), 2),
        ChordShape("C7", "Septakkord", intArrayOf(-1,3,2,3,1,0)),
        ChordShape("D7", "Septakkord", intArrayOf(-1,-1,0,2,1,2)),
        ChordShape("E7", "Septakkord", intArrayOf(0,2,0,1,0,0)),
        ChordShape("G7", "Septakkord", intArrayOf(3,2,0,0,0,1)),
        ChordShape("Am7", "Septakkord", intArrayOf(-1,0,2,0,1,0)),
        ChordShape("Em7", "Septakkord", intArrayOf(0,2,0,0,0,0)),
        ChordShape("Dsus2", "Sus-Akkord", intArrayOf(-1,-1,0,2,3,0)),
        ChordShape("Dsus4", "Sus-Akkord", intArrayOf(-1,-1,0,2,3,3)),
        ChordShape("Asus2", "Sus-Akkord", intArrayOf(-1,0,2,2,0,0)),
        ChordShape("Asus4", "Sus-Akkord", intArrayOf(-1,0,2,2,3,0))
    )
}

class ChordDiagramView(context: android.content.Context, private val shape: ChordShape) : View(context) {
    private val gridPaint = android.graphics.Paint(3).apply { color = android.graphics.Color.LTGRAY; strokeWidth = 2f }
    private val textPaint = android.graphics.Paint(3).apply { color = android.graphics.Color.WHITE; textSize = 22f; textAlign = android.graphics.Paint.Align.CENTER }
    private val dotPaint = android.graphics.Paint(3).apply { color = android.graphics.Color.rgb(217,154,112); style = android.graphics.Paint.Style.FILL }

    // Standard-Hochkantdarstellung: sechs Saiten verlaufen senkrecht,
    // die Bünde waagerecht. Tiefe E-Saite links, hohe e-Saite rechts.
    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val top = dp(38f)
        val bottom = height - dp(42f)
        val left = width * .17f
        val right = width * .83f
        val dx = (right - left) / 5f
        val dy = (bottom - top) / 4f

        // Saiten
        for (i in 0..5) canvas.drawLine(left + i * dx, top, left + i * dx, bottom, gridPaint)
        // Bünde
        for (i in 0..4) canvas.drawLine(left, top + i * dy, right, top + i * dy, gridPaint)

        // Sattel / Bundnummer
        if (shape.baseFret == 1) {
            canvas.drawRect(left - dp(2f), top - dp(4f), right + dp(2f), top + dp(2f), gridPaint)
        } else {
            canvas.drawText("${shape.baseFret}.", left - dp(27f), top + dy * .55f, textPaint)
        }

        val labels = arrayOf("E", "A", "D", "G", "H", "e")
        for (i in 0..5) {
            val fret = shape.frets[i]
            val x = left + i * dx
            val marker = if (fret < 0) "×" else if (fret == 0) "○" else ""
            if (marker.isNotEmpty()) canvas.drawText(marker, x, top - dp(12f), textPaint)
            if (fret > 0) {
                val y = top + (fret - shape.baseFret + .5f) * dy
                if (y in top..bottom) canvas.drawCircle(x, y, dp(10f), dotPaint)
            }
            canvas.drawText(labels[i], x, height - dp(8f), textPaint)
        }
    }

    private fun dp(v: Float) = v * resources.displayMetrics.density
}

/** Spielt den ausgewählten Griff als kurze, gezupfte Gitarrenprobe. */
object ChordPreviewPlayer {
    @Volatile private var current: android.media.AudioTrack? = null

    fun play(shape: ChordShape) {
        stop()
        Thread {
            val sampleRate = 44100
            val durationMs = 2600
            val samples = sampleRate * durationMs / 1000
            val mix = DoubleArray(samples)
            val tuning = doubleArrayOf(82.4069, 110.0, 146.832, 196.0, 246.942, 329.628)
            val random = java.util.Random(shape.name.hashCode().toLong())
            var activeStrings = 0

            // Karplus-Strong: ein kurzer Rauschimpuls wird durch eine rückgekoppelte
            // Verzögerungsleitung geschickt. Dadurch entsteht ein deutlich natürlicherer
            // gezupfter Saitenklang als mit reinen Sinuswellen.
            shape.frets.forEachIndexed { stringIndex, fret ->
                if (fret >= 0) {
                    activeStrings++
                    val frequency = tuning[stringIndex] * 2.0.pow(fret / 12.0)
                    val delay = (sampleRate / frequency).roundToInt().coerceAtLeast(2)
                    val pluck = DoubleArray(delay)
                    for (i in pluck.indices) {
                        pluck[i] = random.nextDouble() * 2.0 - 1.0
                    }

                    val start = stringIndex * (sampleRate / 95)
                    var previous = 0.0
                    val decay = 0.9965 - stringIndex * 0.00012
                    val stringLength = minOf(samples - start, (durationMs * sampleRate / 1000))
                    if (stringLength <= 0) return@forEachIndexed

                    for (j in 0 until stringLength) {
                        val pos = j % delay
                        val currentSample = pluck[pos]
                        val nextPos = (pos + 1) % delay
                        // leichter Tiefpass in der Rückkopplung = typische Dämpfung hoher Obertöne
                        val filtered = 0.5 * (currentSample + previous)
                        pluck[pos] = filtered * decay
                        previous = currentSample

                        val t = j.toDouble() / sampleRate
                        val envelope = kotlin.math.exp(-1.55 * t)
                        val attack = if (t < 0.004) t / 0.004 else 1.0
                        mix[start + j] += currentSample * envelope * attack * 0.34
                    }
                }
            }

            if (activeStrings == 0) return@Thread

            // Sanfte Sättigung und Normalisierung verhindern harte digitale Spitzen.
            val max = mix.maxOf { kotlin.math.abs(it) }.coerceAtLeast(0.001)
            val pcm = ShortArray(samples) { i ->
                val x = (mix[i] / max * 0.78).coerceIn(-1.0, 1.0)
                val shaped = kotlin.math.tanh(x * 1.08)
                (shaped * Short.MAX_VALUE).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            }

            val track = android.media.AudioTrack.Builder()
                .setAudioAttributes(
                    android.media.AudioAttributes.Builder()
                        .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    android.media.AudioFormat.Builder()
                        .setEncoding(android.media.AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(android.media.AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(pcm.size * 2)
                .setTransferMode(android.media.AudioTrack.MODE_STATIC)
                .build()

            current = track
            track.write(pcm, 0, pcm.size)
            track.play()
            while (track.playState == android.media.AudioTrack.PLAYSTATE_PLAYING) {
                Thread.sleep(30)
            }
            track.release()
            if (current === track) current = null
        }.start()
    }

    fun stop() {
        val track = current
        current = null
        try { track?.stop() } catch (_: Exception) { }
        try { track?.release() } catch (_: Exception) { }
    }
}

class ChordsFragment : Fragment() {
    private var training: ChordTrainingPanel? = null
    override fun onDestroyView() { training?.stop(); training = null; super.onDestroyView() }
    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity
        val root = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        root.addView(a.title("Akkorde")); root.addView(a.body("Griffbilder · Akkordwissen · Wechseltraining"))
        val search = EditText(a).apply { hint = "Akkord suchen (z. B. Am, G7 …)"; setSingleLine(); setTextColor(a.getColor(R.color.sw_text)); setHintTextColor(a.getColor(R.color.sw_muted)); setPadding(a.dp(16), 0, a.dp(16), 0) }
        root.addView(search, LinearLayout.LayoutParams(-1, a.dp(50)).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(8)) })
        val filters = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; setPadding(a.dp(10), 0, a.dp(10), a.dp(8)) }
        val categories = listOf("Alle", "Dur", "Moll", "Septakkord", "Sus-Akkord"); var category = "Alle"
        val scroll = ScrollView(a)
        val content = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        val detailCard = a.card().apply { visibility = View.GONE }
        val detail = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(16), a.dp(14), a.dp(16), a.dp(16)) }
        detailCard.addView(detail)
        val grid = GridLayout(a).apply { columnCount = 3; setPadding(a.dp(10), a.dp(4), a.dp(10), a.dp(12)) }
        fun showChord(ch: ChordShape) {
            detail.removeAllViews()
            detail.addView(TextView(a).apply { text = ch.name; textSize = 29f; setTextColor(a.getColor(R.color.sw_copper)); setTypeface(typeface, 1) })
            detail.addView(TextView(a).apply { text = "${ch.quality} · ${ch.note}"; setTextColor(a.getColor(R.color.sw_muted)) })
            detail.addView(ChordDiagramView(a, ch), LinearLayout.LayoutParams(-1, a.dp(270)))
            detail.addView(TextView(a).apply { text = "Hochkant: tiefe E-Saite links · hohe e-Saite rechts\n× = nicht anschlagen · ○ = leere Saite"; setTextColor(a.getColor(R.color.sw_muted)); textSize = 13f })
            val preview = a.button("▶ Akkord anhören")
            preview.setOnClickListener { ChordPreviewPlayer.play(ch) }
            detail.addView(preview, LinearLayout.LayoutParams(-1, a.dp(48)).apply { topMargin = a.dp(8) })
            val prefs = a.getSharedPreferences("saitenwerk", 0); val key = "fav_chords"
            val saved = prefs.getStringSet(key, emptySet())?.toMutableSet() ?: mutableSetOf()
            val fav = a.button(if (ch.name in saved) "★ Favorit entfernen" else "☆ Als Favorit speichern")
            fav.setOnClickListener { val now = prefs.getStringSet(key, emptySet())?.toMutableSet() ?: mutableSetOf(); if (!now.add(ch.name)) now.remove(ch.name); prefs.edit().putStringSet(key, now).apply(); fav.text = if (ch.name in now) "★ Favorit entfernen" else "☆ Als Favorit speichern" }
            detail.addView(fav, LinearLayout.LayoutParams(-1, a.dp(46)).apply { topMargin = a.dp(8) })
            detailCard.visibility = View.VISIBLE
        }
        fun render() {
            grid.removeAllViews(); val q = search.text.toString().trim().lowercase()
            val matches = ChordLibrary.all.filter { (category == "Alle" || it.quality == category) && it.name.lowercase().contains(q) }
            matches.forEach { chord ->
                val b = a.button(chord.name); b.setOnClickListener { showChord(chord) }
                grid.addView(b, GridLayout.LayoutParams().apply { width = 0; height = a.dp(52); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(a.dp(3), a.dp(3), a.dp(3), a.dp(3)) })
            }
            if (matches.isEmpty()) grid.addView(a.body("Kein passender Akkord gefunden."))
        }
        categories.forEach { cat -> val b = a.button(cat); b.textSize = 11f; b.setOnClickListener { category = cat; render() }; filters.addView(b, LinearLayout.LayoutParams(0, a.dp(42), 1f).apply { setMargins(a.dp(2), 0, a.dp(2), 0) }) }
        search.addTextChangedListener(object : TextWatcher { override fun beforeTextChanged(s: CharSequence?, st: Int, count: Int, after: Int) {}; override fun onTextChanged(s: CharSequence?, st: Int, before: Int, count: Int) { render() }; override fun afterTextChanged(e: Editable?) {} })
        content.addView(detailCard); content.addView(grid)
        training = ChordTrainingPanel(a); content.addView(training, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(12), a.dp(12), a.dp(12), a.dp(20)) })
        scroll.addView(content); root.addView(filters); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f)); render()
        return root
    }
}

class ChordTrainingPanel(private val host: MainActivity) : LinearLayout(host) {
    private val handler = Handler(Looper.getMainLooper())
    private val tone = ToneGenerator(AudioManager.STREAM_MUSIC, 55)
    private val sequence = listOf("C", "G", "Am", "F")
    private var bpm = 72; private var beat = 0; private var changes = 0; private var running = false
    private val current = TextView(host); private val status = TextView(host); private val start = host.button("Training starten")
    private val tempo = SeekBar(host); private val tempoLabel = TextView(host); private val stats = TextView(host)
    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            tone.startTone(if (beat % 4 == 0) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_BEEP, 65)
            if (beat % 4 == 0) { current.text = sequence[changes % sequence.size]; changes++; stats.text = "Akkordwechsel: ${changes - 1} · Tempo: $bpm BPM" }
            beat++; handler.postDelayed(this, (60000L / bpm).coerceAtLeast(100L))
        }
    }
    init {
        orientation = VERTICAL; setPadding(host.dp(16), host.dp(16), host.dp(16), host.dp(16)); setBackgroundColor(host.getColor(R.color.sw_surface))
        addView(TextView(host).apply { text = "Akkordwechsel-Training"; textSize = 20f; setTextColor(host.getColor(R.color.sw_copper)); setTypeface(typeface, 1) })
        addView(TextView(host).apply { text = "Wechsle im Takt: C · G · Am · F"; setTextColor(host.getColor(R.color.sw_muted)); setPadding(0, host.dp(5), 0, host.dp(10)) })
        current.apply { text = "C"; textSize = 40f; gravity = Gravity.CENTER; setTextColor(host.getColor(R.color.sw_text)); setTypeface(typeface, 1) }
        addView(current, LayoutParams(-1, host.dp(76)))
        status.apply { text = "Bereit? Starte das Metronom."; setTextColor(host.getColor(R.color.sw_muted)); textSize = 13f }
        addView(status, LayoutParams(-1, -2))
        tempoLabel.apply { text = "Tempo: 72 BPM"; setTextColor(host.getColor(R.color.sw_text)); setPadding(0, host.dp(10), 0, 0) }
        addView(tempoLabel)
        tempo.max = 110; tempo.progress = 22
        tempo.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(v: SeekBar?, progress: Int, fromUser: Boolean) { bpm = 50 + progress; tempoLabel.text = "Tempo: $bpm BPM" }
            override fun onStartTrackingTouch(v: SeekBar?) {}; override fun onStopTrackingTouch(v: SeekBar?) {}
        })
        addView(tempo, LayoutParams(-1, host.dp(42)))
        start.setOnClickListener { if (running) stop() else begin() }; addView(start, LayoutParams(-1, host.dp(48)))
        stats.apply { text = "Akkordwechsel: 0 · Tempo: 72 BPM"; setTextColor(host.getColor(R.color.sw_muted)); setPadding(0, host.dp(8), 0, host.dp(6)) }; addView(stats)
        val row = LinearLayout(host).apply { orientation = HORIZONTAL }
        val mastered = host.button("✓ Sitzt"); val practice = host.button("↻ Weiter üben")
        mastered.setOnClickListener { saveRating(true) }; practice.setOnClickListener { saveRating(false) }
        row.addView(mastered, LayoutParams(0, host.dp(44), 1f)); row.addView(practice, LayoutParams(0, host.dp(44), 1f).apply { leftMargin = host.dp(6) }); addView(row)
        val p = host.getSharedPreferences("saitenwerk", 0)
        status.text = "Bisher: ${p.getInt("chord_training_mastered", 0)} gemeisterte Bewertungen aus ${p.getInt("chord_training_sessions", 0)} Einträgen."
    }
    private fun begin() { running = true; beat = 0; changes = 0; start.text = "Training stoppen"; status.text = "Läuft · auf den ersten Schlag achten"; handler.removeCallbacks(tick); handler.post(tick) }
    fun stop() { running = false; handler.removeCallbacks(tick); start.text = "Training starten"; try { tone.stopTone() } catch (_: Exception) { } }
    private fun saveRating(mastered: Boolean) {
        val p = host.getSharedPreferences("saitenwerk", 0); val sessions = p.getInt("chord_training_sessions", 0) + 1
        val wins = p.getInt("chord_training_mastered", 0) + if (mastered) 1 else 0
        p.edit().putInt("chord_training_sessions", sessions).putInt("chord_training_mastered", wins).apply()
        status.text = if (mastered) "Als gemeistert markiert · $wins von $sessions" else "Für weitere Übung vorgemerkt · $wins von $sessions"
    }
    override fun onDetachedFromWindow() { stop(); try { tone.release() } catch (_: Exception) { }; super.onDetachedFromWindow() }
}

data class Song(val title: String, val artist: String = "", val genre: String = "")
object SongRepository {
    fun load(a: MainActivity): MutableList<Song> = try {
        val raw = a.assets.open("songs.json").bufferedReader().use { it.readText() }; val array = JSONArray(raw)
        MutableList(array.length()) { index -> val o = array.getJSONObject(index); Song(o.optString("title"), o.optString("artist"), o.optString("genre")) }
    } catch (_: Exception) { mutableListOf() }
    private fun ids(a: MainActivity) = a.getSharedPreferences("saitenwerk", 0).getStringSet("song_favorites", emptySet())?.toMutableSet() ?: mutableSetOf()
    fun isFavorite(a: MainActivity, song: Song) = (song.title + "|" + song.artist) in ids(a)
    fun toggleFavorite(a: MainActivity, song: Song): Boolean {
        val set = ids(a); val key = song.title + "|" + song.artist; val now = if (set.remove(key)) false else { set.add(key); true }
        a.getSharedPreferences("saitenwerk", 0).edit().putStringSet("song_favorites", set).apply(); return now
    }
}

class SongsFragment : Fragment() {
    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity; val root = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        root.addView(a.title("Liederbuch")); val songs = SongRepository.load(a)
        val count = a.body("${songs.size} Songs · offline verfügbar"); root.addView(count)
        val query = EditText(a).apply { hint = "Lied oder Künstler suchen"; setSingleLine(); setTextColor(a.getColor(R.color.sw_text)); setHintTextColor(a.getColor(R.color.sw_muted)); setPadding(a.dp(18), 0, a.dp(18), 0) }
        root.addView(query, LinearLayout.LayoutParams(-1, a.dp(50)).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(8)) })
        var favoritesOnly = false
        val filterRow = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        val allButton = a.button("Alle Songs"); val favButton = a.button("★ Favoriten")
        filterRow.addView(allButton, LinearLayout.LayoutParams(0, a.dp(44), 1f).apply { setMargins(a.dp(16), 0, a.dp(4), a.dp(8)) })
        filterRow.addView(favButton, LinearLayout.LayoutParams(0, a.dp(44), 1f).apply { setMargins(a.dp(4), 0, a.dp(16), a.dp(8)) }); root.addView(filterRow)
        val list = RecyclerView(a).apply { layoutManager = LinearLayoutManager(a) }
        val adapter = SongAdapter(songs, a) { a.openSong(it) }; list.adapter = adapter
        fun update() { adapter.filter(query.text.toString(), favoritesOnly); count.text = "${adapter.itemCount} von ${songs.size} Songs${if (favoritesOnly) " · Favoriten" else " · offline verfügbar"}" }
        allButton.setOnClickListener { favoritesOnly = false; update() }; favButton.setOnClickListener { favoritesOnly = true; update() }
        query.addTextChangedListener(object : TextWatcher { override fun beforeTextChanged(s: CharSequence?, st: Int, count: Int, after: Int) {}; override fun onTextChanged(s: CharSequence?, st: Int, before: Int, count: Int) { update() }; override fun afterTextChanged(e: Editable?) {} })
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f)); update(); return root
    }
}

class SongAdapter(private val all: List<Song>, private val host: MainActivity, private val onClick: (Song) -> Unit) : RecyclerView.Adapter<SongAdapter.Holder>() {
    private var data = all.toList()
    class Holder(v: View) : RecyclerView.ViewHolder(v)
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = Holder(TextView(parent.context).apply { setTextColor(host.getColor(R.color.sw_text)); textSize = 16f; setPadding(host.dp(18), host.dp(14), host.dp(18), host.dp(14)); isClickable = true; isFocusable = true })
    override fun getItemCount() = data.size
    override fun onBindViewHolder(holder: Holder, position: Int) {
        val song = data[position]; val favorite = SongRepository.isFavorite(host, song)
        (holder.itemView as TextView).apply { text = (if (favorite) "★  " else "♫  ") + song.title + "\n" + song.artist + " · " + song.genre; setOnClickListener { onClick(song) } }
    }
    fun filter(q: String, favoritesOnly: Boolean) {
        val term = q.trim().lowercase(); data = all.filter { (term.isEmpty() || it.title.lowercase().contains(term) || it.artist.lowercase().contains(term) || it.genre.lowercase().contains(term)) && (!favoritesOnly || SongRepository.isFavorite(host, it)) }; notifyDataSetChanged()
    }
}

class SongDetailFragment : Fragment() {
    companion object {
        fun newInstance(song: Song) = SongDetailFragment().apply {
            arguments = Bundle().apply {
                putString("title", song.title)
                putString("artist", song.artist)
                putString("genre", song.genre)
            }
        }
    }

    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity
        val song = arguments?.let {
            Song(it.getString("title").orEmpty(), it.getString("artist").orEmpty(), it.getString("genre").orEmpty())
        } ?: Song("Unbekannter Titel")
        val prefs = a.getSharedPreferences("saitenwerk", 0)
        val root = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        val back = a.button("‹  Zurück zum Liederbuch")
        back.setOnClickListener { a.openSection(4) }
        root.addView(back, LinearLayout.LayoutParams(-1, a.dp(50)).apply { setMargins(a.dp(16), a.dp(12), a.dp(16), 0) })
        root.addView(a.title(song.title))
        root.addView(TextView(a).apply {
            text = song.artist
            textSize = 19f
            setTextColor(a.getColor(R.color.sw_copper))
            setPadding(a.dp(20), 0, a.dp(20), a.dp(8))
        })
        root.addView(a.body("Genre: ${song.genre}"))

        val favorite = a.button(if (SongRepository.isFavorite(a, song)) "★ Aus Favoriten entfernen" else "☆ Zu Favoriten hinzufügen")
        favorite.setOnClickListener {
            val now = SongRepository.toggleFavorite(a, song)
            favorite.text = if (now) "★ Aus Favoriten entfernen" else "☆ Zu Favoriten hinzufügen"
            Toast.makeText(a, if (now) "Als Favorit gespeichert" else "Aus Favoriten entfernt", Toast.LENGTH_SHORT).show()
        }
        root.addView(favorite, LinearLayout.LayoutParams(-1, a.dp(48)).apply { setMargins(a.dp(16), a.dp(8), a.dp(16), a.dp(12)) })

        val card = a.card()
        val box = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dp(16), a.dp(16), a.dp(16), a.dp(18))
        }
        box.addView(TextView(a).apply {
            text = "Dein Song-Arrangement"
            textSize = 21f
            setTextColor(a.getColor(R.color.sw_copper))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        box.addView(a.body("Trage deine Akkorde abschnittsweise ein. Deine Arrangements werden lokal auf diesem Gerät gespeichert. Es werden keine Songtexte ergänzt."))

        val storageKey = "song_arrangement_${song.title}|${song.artist}"
        val sections = listOf("Intro", "Strophe 1", "Strophe 2", "Refrain", "Bridge", "Outro")
        val section = Spinner(a).apply {
            adapter = ArrayAdapter(a, android.R.layout.simple_spinner_dropdown_item, sections)
            setSelection(1)
        }
        fun loadSection(name: String): org.json.JSONObject = try {
            org.json.JSONObject(prefs.getString("${storageKey}_$name", "{}") ?: "{}")
        } catch (_: Exception) { org.json.JSONObject() }
        val initialSaved = loadSection("Strophe 1")
        box.addView(TextView(a).apply { text = "Songabschnitt"; setTextColor(a.getColor(R.color.sw_text)); setPadding(0, a.dp(8), 0, a.dp(4)) })
        box.addView(section, LinearLayout.LayoutParams(-1, a.dp(48)))

        val progression = EditText(a).apply {
            hint = "z. B. Am | F | C | G"
            setText(initialSaved.optString("chords", ""))
            setTextColor(a.getColor(R.color.sw_text))
            setHintTextColor(a.getColor(R.color.sw_muted))
            minLines = 2
            gravity = Gravity.TOP
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        }
        box.addView(TextView(a).apply { text = "Akkordfolge (mit | trennen)"; setTextColor(a.getColor(R.color.sw_text)); setPadding(0, a.dp(10), 0, a.dp(4)) })
        box.addView(progression, LinearLayout.LayoutParams(-1, a.dp(84)))

        val capoLabel = TextView(a).apply { setTextColor(a.getColor(R.color.sw_text)); setPadding(0, a.dp(10), 0, 0) }
        val capo = SeekBar(a).apply { max = 12; progress = initialSaved.optInt("capo", 0).coerceIn(0, 12) }
        val transposeLabel = TextView(a).apply { setTextColor(a.getColor(R.color.sw_text)); setPadding(0, a.dp(8), 0, 0) }
        val transpose = SeekBar(a).apply { max = 12; progress = (initialSaved.optInt("transpose", 0) + 6).coerceIn(0, 12) }
        val preview = TextView(a).apply {
            textSize = 18f
            setTextColor(a.getColor(R.color.sw_copper))
            setPadding(0, a.dp(12), 0, a.dp(10))
        }
        fun updatePreview() {
            val semitones = transpose.progress - 6
            capoLabel.text = "Capo: ${capo.progress}. Bund"
            transposeLabel.text = "Transponierung: ${if (semitones > 0) "+" else ""}$semitones Halbtöne"
            val tokens = progression.text.toString().split(Regex("[|\\s,;]+" )).filter { it.isNotBlank() }
            val shifted = tokens.map { transposeChord(it, semitones) }
            preview.text = if (tokens.isEmpty()) "Vorschau deiner Akkorde erscheint hier." else "${shifted.joinToString("   ·   ")}\n\nCapo ${capo.progress} · Anzeige-Transponierung ${semitones}"
        }
        box.addView(capoLabel); box.addView(capo, LinearLayout.LayoutParams(-1, a.dp(42)))
        box.addView(transposeLabel); box.addView(transpose, LinearLayout.LayoutParams(-1, a.dp(42)))
        box.addView(preview)
        progression.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { updatePreview() }
            override fun afterTextChanged(s: Editable?) {}
        })
        capo.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) = updatePreview()
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        transpose.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) = updatePreview()
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        updatePreview()
        section.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                val data = loadSection(sections[position])
                progression.setText(data.optString("chords", ""))
                capo.progress = data.optInt("capo", 0).coerceIn(0, 12)
                transpose.progress = (data.optInt("transpose", 0) + 6).coerceIn(0, 12)
                updatePreview()
            }
        }
        val save = a.button("Arrangement speichern")
        save.setOnClickListener {
            val sectionName = section.selectedItem?.toString() ?: "Strophe 1"
            val data = org.json.JSONObject().apply {
                put("section", sectionName)
                put("chords", progression.text.toString().trim())
                put("capo", capo.progress)
                put("transpose", transpose.progress - 6)
                put("updatedAt", System.currentTimeMillis())
            }
            prefs.edit().putString("${storageKey}_$sectionName", data.toString()).apply()
            Toast.makeText(a, "$sectionName gespeichert", Toast.LENGTH_SHORT).show()
        }
        box.addView(save, LinearLayout.LayoutParams(-1, a.dp(48)).apply { topMargin = a.dp(8) })
        card.addView(box)
        root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(18)) })
        return ScrollView(a).apply { addView(root) }
    }

    private fun transposeChord(token: String, semitones: Int): String {
        if (semitones == 0) return token
        val names = listOf("C", "C♯", "D", "D♯", "E", "F", "F♯", "G", "G♯", "A", "A♯", "B")
        val match = Regex("^([A-G])([#b]?)(.*)$").matchEntire(token) ?: return token
        val root = match.groupValues[1] + match.groupValues[2]
        val rawSuffix = match.groupValues[3]
        val suffixParts = rawSuffix.split("/", limit = 2)
        val suffix = if (suffixParts.size == 2) "/" + transposeChord(suffixParts[1], semitones) else rawSuffix
        val index = when (root) {
            "C" -> 0; "C#", "Db" -> 1; "D" -> 2; "D#", "Eb" -> 3
            "E", "Fb" -> 4; "F", "E#" -> 5; "F#", "Gb" -> 6
            "G" -> 7; "G#", "Ab" -> 8; "A" -> 9; "A#", "Bb" -> 10
            "B", "Cb" -> 11; else -> return token
        }
        val shifted = names[(index + semitones % 12 + 12) % 12]
        return shifted + suffix
    }
}
class LearnFragment : Fragment() {
    private var chordTraining: ChordTrainingPanel? = null
    private var rhythmTone: ToneGenerator? = null
    private var rhythmHandler: Handler? = null
    private var rhythmRunning = false
    private var rhythmBeat = 0
    private var rhythmBpm = 80
    override fun onDestroyView() { chordTraining?.stop(); chordTraining = null; stopRhythm(); super.onDestroyView() }

    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity; val prefs = a.getSharedPreferences("saitenwerk", 0)
        val root = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        root.addView(a.title("Lernstudio")); root.addView(a.body("Kurze, praktische Einheiten für Akkorde, Wechsel und Rhythmus. Dein Fortschritt wird auf diesem Gerät gespeichert."))
        val pathButton = a.button("◆  Deinen Lernpfad öffnen")
        pathButton.setOnClickListener { a.openSection(6) }
        root.addView(pathButton, LinearLayout.LayoutParams(-1, a.dp(48)).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(12)) })
        val summary = a.body("Akkord-Quiz: ${prefs.getInt("learn_quiz_correct", 0)} richtige Antworten · ${prefs.getInt("learn_quiz_total", 0)} Versuche").apply { setTextColor(a.getColor(R.color.sw_copper)) }; root.addView(summary)
        val tabs = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; setPadding(a.dp(8), 0, a.dp(8), a.dp(8)) }
        val content = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(14), a.dp(4), a.dp(14), a.dp(24)) }
        val scroll = ScrollView(a).apply { addView(content) }
        fun panel(heading: String, description: String): Pair<MaterialCardView, LinearLayout> {
            val card = a.card(); val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(16), a.dp(16), a.dp(16), a.dp(16)) }
            box.addView(TextView(a).apply { text = heading; textSize = 20f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_copper)) })
            box.addView(a.body(description, 14f)); card.addView(box); return card to box
        }
        fun showQuiz() {
            chordTraining?.stop(); chordTraining = null; stopRhythm(); content.removeAllViews()
            val (card, box) = panel("Akkord-Blitztrainer", "Erkenne Griffbilder und festige die wichtigsten offenen Akkorde.")
            box.addView(TextView(a).apply { text = "Welcher Akkord ist das?"; textSize = 18f; gravity = Gravity.CENTER; setTextColor(a.getColor(R.color.sw_text)) })
            val diagram = FrameLayout(a); box.addView(diagram, LinearLayout.LayoutParams(-1, a.dp(210)))
            val choices = GridLayout(a).apply { columnCount = 2 }; box.addView(choices)
            val feedback = TextView(a).apply { text = "Wähle den passenden Akkord."; gravity = Gravity.CENTER; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0, a.dp(10), 0, a.dp(8)) }; box.addView(feedback)
            val next = a.button("Nächster Akkord"); box.addView(next, LinearLayout.LayoutParams(-1, a.dp(46)))
            var answer = ""; var locked = false
            fun newQuestion() {
                val pool = ChordLibrary.all.filter { it.name in listOf("C", "G", "D", "A", "E", "F", "Am", "Em", "Dm") }
                val shape = pool.random(); answer = shape.name; locked = false; feedback.text = "Wähle den passenden Akkord."; feedback.setTextColor(a.getColor(R.color.sw_muted))
                diagram.removeAllViews(); diagram.addView(ChordDiagramView(a, shape), FrameLayout.LayoutParams(-1, -1)); choices.removeAllViews()
                val options = (listOf(answer) + pool.filter { it.name != answer }.shuffled().take(3).map { it.name }).shuffled()
                options.forEach { option ->
                    val b = a.button(option); b.setOnClickListener {
                        if (!locked) {
                            locked = true; val correct = option == answer; val total = prefs.getInt("learn_quiz_total", 0) + 1
                            val score = prefs.getInt("learn_quiz_correct", 0) + if (correct) 1 else 0
                            prefs.edit().putInt("learn_quiz_total", total).putInt("learn_quiz_correct", score).apply()
                            summary.text = "Akkord-Quiz: $score richtige Antworten · $total Versuche"
                            feedback.text = if (correct) "Richtig! $answer sauber erkannt." else "Noch nicht ganz – gesucht war $answer.\nSchau dir die Fingerpositionen an."
                            feedback.setTextColor(a.getColor(if (correct) R.color.sw_copper else R.color.sw_muted))
                            for (j in 0 until choices.childCount) choices.getChildAt(j).isEnabled = false
                        }
                    }
                    choices.addView(b, GridLayout.LayoutParams().apply { width = 0; height = a.dp(46); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(a.dp(3), a.dp(3), a.dp(3), a.dp(3)) })
                }
            }
            next.setOnClickListener { newQuestion() }; newQuestion(); content.addView(card)
        }
        fun showChanges() {
            stopRhythm(); content.removeAllViews(); content.addView(a.body("Wechsle C · G · Am · F im gleichmäßigen Puls. Starte langsam und steigere das Tempo erst, wenn jeder Griff sauber klingt."))
            chordTraining = ChordTrainingPanel(a); content.addView(chordTraining, LinearLayout.LayoutParams(-1, -2))
        }
        fun showRhythm() {
            chordTraining?.stop(); chordTraining = null; stopRhythm(); content.removeAllViews()
            val (card, box) = panel("Rhythmus & Timing", "Übe einen gleichmäßigen Viertelpuls. Der erste Schlag jedes Taktes wird stärker markiert.")
            val label = TextView(a).apply { text = "Tempo: 80 BPM"; textSize = 17f; setTextColor(a.getColor(R.color.sw_text)) }; box.addView(label)
            val slider = SeekBar(a).apply { max = 110; progress = 30 }; slider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(v: SeekBar?, p: Int, from: Boolean) { rhythmBpm = 50 + p; label.text = "Tempo: $rhythmBpm BPM" }
                override fun onStartTrackingTouch(v: SeekBar?) {}; override fun onStopTrackingTouch(v: SeekBar?) {}
            }); box.addView(slider)
            val beat = TextView(a).apply { text = "Bereit"; textSize = 32f; gravity = Gravity.CENTER; setTextColor(a.getColor(R.color.sw_copper)); setPadding(0, a.dp(12), 0, a.dp(12)) }; box.addView(beat, LinearLayout.LayoutParams(-1, a.dp(72)))
            val start = a.button("Metronom starten"); box.addView(start, LinearLayout.LayoutParams(-1, a.dp(48)))
            start.setOnClickListener {
                if (rhythmRunning) { stopRhythm(); start.text = "Metronom starten"; beat.text = "Pausiert" }
                else {
                    rhythmRunning = true; rhythmBeat = 0; rhythmTone = ToneGenerator(AudioManager.STREAM_MUSIC, 65); rhythmHandler = Handler(Looper.getMainLooper()); start.text = "Metronom stoppen"
                    val task = object : Runnable { override fun run() {
                        if (!rhythmRunning) return
                        val strong = rhythmBeat % 4 == 0; rhythmTone?.startTone(if (strong) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_BEEP, 70)
                        beat.text = if (strong) "1 · TAKT" else "${rhythmBeat % 4 + 1}"; rhythmBeat++
                        rhythmHandler?.postDelayed(this, (60000L / rhythmBpm).coerceAtLeast(100L))
                    } }
                    rhythmHandler?.post(task)
                }
            }
            content.addView(card)
        }
        fun showRoutine() {
            chordTraining?.stop(); chordTraining = null; stopRhythm(); content.removeAllViews()
            val (card, box) = panel("Deine tägliche 10-Minuten-Routine", "Hake die Einheiten ab, wenn du sie erledigt hast. Der Tagesstand wird lokal gespeichert.")
            val day = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.GERMANY).format(java.util.Date())
            if (prefs.getString("learn_routine_day", "") != day) prefs.edit().putString("learn_routine_day", day).putInt("learn_routine_done", 0).apply()
            val tasks = listOf("2 Min. Akkordgriffe sauber aufsetzen", "3 Min. Wechsel C – G – Am – F", "3 Min. Rhythmus mit Metronom", "2 Min. Lieblingssong spielen")
            val progressLabel = TextView(a).apply { setTextColor(a.getColor(R.color.sw_text)) }; box.addView(progressLabel)
            val progress = ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply { max = tasks.size }; box.addView(progress, LinearLayout.LayoutParams(-1, a.dp(10)))
            fun update(mask: Int) { val n = Integer.bitCount(mask); progress.progress = n; progressLabel.text = "Heute erledigt: $n von ${tasks.size}" }
            tasks.forEachIndexed { index, task ->
                val cb = CheckBox(a).apply { text = task; setTextColor(a.getColor(R.color.sw_text)); isChecked = (prefs.getInt("learn_routine_done", 0) and (1 shl index)) != 0 }
                cb.setOnCheckedChangeListener { _, checked ->
                    var mask = prefs.getInt("learn_routine_done", 0); mask = if (checked) mask or (1 shl index) else mask and (1 shl index).inv()
                    prefs.edit().putInt("learn_routine_done", mask).apply(); update(mask)
                }; box.addView(cb)
            }
            update(prefs.getInt("learn_routine_done", 0)); content.addView(card)
        }
        val modes = listOf("Blitztrainer", "Wechsel", "Rhythmus", "Routine")
        val actions = listOf({ showQuiz() }, { showChanges() }, { showRhythm() }, { showRoutine() })
        modes.forEachIndexed { index, label -> val b = a.button(label); b.textSize = 11f; b.setOnClickListener { actions[index]() }; tabs.addView(b, LinearLayout.LayoutParams(0, a.dp(44), 1f).apply { setMargins(a.dp(2), 0, a.dp(2), 0) }) }
        root.addView(tabs); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f)); showQuiz(); return root
    }
    private fun stopRhythm() {
        rhythmRunning = false; rhythmHandler?.removeCallbacksAndMessages(null); rhythmHandler = null
        try { rhythmTone?.stopTone(); rhythmTone?.release() } catch (_: Exception) { }; rhythmTone = null
    }
}

class PathFragment : Fragment() {
    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity; val prefs = a.getSharedPreferences("saitenwerk", 0)
        val root = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        root.addView(a.title("Dein Lernpfad")); root.addView(a.body("Vom ersten Griff bis zum selbstständigen Spielen ganzer Songs. Du bestimmst dein Tempo – dein Fortschritt bleibt auf diesem Gerät gespeichert."))
        val stages = listOf(
            "Erste Akkorde" to "Lerne C, G, D, A, E sowie Am und Em kennen. Ziel: jeden Griff ruhig und einzeln aufsetzen.",
            "Saubere Griffbilder" to "Achte auf gekrümmte Finger, kurze Fingernägel und darauf, dass jede Saite klar klingt.",
            "Flüssige Wechsel" to "Verbinde zwei Akkorde zunächst langsam. Steigere das Tempo erst, wenn der Wechsel sicher sitzt.",
            "Rhythmus festigen" to "Halte einen gleichmäßigen Viertelpuls und übe den Wechsel ohne den Schlagfluss zu unterbrechen.",
            "Erste Songs begleiten" to "Wähle ein einfaches Lied und spiele die Akkordfolge langsam im passenden Takt.",
            "Selbstständig spielen" to "Spiele einen Song vom Anfang bis zum Ende und finde bei Bedarf selbst zurück in den Ablauf."
        )
        val key = "learning_path_done"
        val progressLabel = TextView(a).apply { setTextColor(a.getColor(R.color.sw_copper)); textSize = 17f; setPadding(a.dp(20), a.dp(8), a.dp(20), a.dp(8)) }
        val progress = ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply { max = stages.size }
        root.addView(progressLabel); root.addView(progress, LinearLayout.LayoutParams(-1, a.dp(10)).apply { setMargins(a.dp(20), 0, a.dp(20), a.dp(14)) })
        fun refresh() { val mask = prefs.getInt(key, 0); val count = Integer.bitCount(mask); progress.progress = count; progressLabel.text = "$count von ${stages.size} Lernstufen abgeschlossen · ${count * 100 / stages.size}%" }
        val goalCard = a.card(); val goalBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(16), a.dp(14), a.dp(16), a.dp(14)) }
        goalBox.addView(TextView(a).apply { text = "Mein persönliches Lernziel"; textSize = 19f; setTextColor(a.getColor(R.color.sw_copper)); setTypeface(typeface, 1) })
        val goal = EditText(a).apply { setText(prefs.getString("learning_path_goal", "")); hint = "z. B. In vier Wochen drei Songs begleiten"; setTextColor(a.getColor(R.color.sw_text)); setHintTextColor(a.getColor(R.color.sw_muted)); minLines = 2 }
        goalBox.addView(goal)
        val save = a.button("Lernziel speichern"); save.setOnClickListener { prefs.edit().putString("learning_path_goal", goal.text.toString().trim()).apply(); Toast.makeText(a, "Lernziel gespeichert", Toast.LENGTH_SHORT).show() }
        goalBox.addView(save); goalCard.addView(goalBox); root.addView(goalCard, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(14)) })
        val next = a.body("").apply { textSize = 16f; setTextColor(a.getColor(R.color.sw_text)) }; root.addView(next)
        val checks = mutableListOf<CheckBox>()
        stages.forEachIndexed { index, stage ->
            val card = a.card(); val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(14), a.dp(12), a.dp(14), a.dp(12)) }
            box.addView(TextView(a).apply { text = "${index + 1}. ${stage.first}"; textSize = 18f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_text)) })
            box.addView(a.body(stage.second, 14f))
            val check = CheckBox(a).apply { text = "Lernstufe abgeschlossen"; setTextColor(a.getColor(R.color.sw_text)); isChecked = (prefs.getInt(key, 0) and (1 shl index)) != 0 }; checks.add(check)
            check.setOnCheckedChangeListener { _, checked ->
                var mask = prefs.getInt(key, 0); mask = if (checked) mask or (1 shl index) else mask and (1 shl index).inv(); prefs.edit().putInt(key, mask).apply(); refresh()
                val first = stages.indices.firstOrNull { (mask and (1 shl it)) == 0 }; next.text = if (first == null) "Geschafft! Alle Lernstufen sind abgeschlossen." else "Dein nächster Schritt: ${stages[first].first}"
            }
            box.addView(check); val practice = a.button("Im Lernstudio üben"); practice.setOnClickListener { a.openSection(5) }; box.addView(practice)
            card.addView(box); root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(16), a.dp(5), a.dp(16), a.dp(5)) })
        }
        val reset = a.button("Lernpfad zurücksetzen"); reset.setOnClickListener { prefs.edit().putInt(key, 0).apply(); checks.forEach { it.isChecked = false }; refresh(); next.text = "Dein nächster Schritt: ${stages.first().first}"; Toast.makeText(a, "Lernpfad zurückgesetzt", Toast.LENGTH_SHORT).show() }
        root.addView(reset, LinearLayout.LayoutParams(-1, a.dp(48)).apply { setMargins(a.dp(16), a.dp(12), a.dp(16), a.dp(24)) })
        refresh(); val mask = prefs.getInt(key, 0); val first = stages.indices.firstOrNull { (mask and (1 shl it)) == 0 }; next.text = if (first == null) "Geschafft! Alle Lernstufen sind abgeschlossen." else "Dein nächster Schritt: ${stages[first].first}"
        return ScrollView(a).apply { addView(root) }
    }
}
