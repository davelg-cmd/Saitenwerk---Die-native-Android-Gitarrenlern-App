package de.saitenwerk.app

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.AudioAttributes
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.card.MaterialCardView
import org.json.JSONArray
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private var bottomNav: BottomNavigationView? = null
    private var suppressNavSelection = false
    private var micGrantedAction: (() -> Unit)? = null
    private var contentFrameId: Int = View.NO_ID
    private val requestMic = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) micGrantedAction?.invoke()
        else Toast.makeText(this, "Für das Stimmgerät wird Mikrofonzugriff benötigt.", Toast.LENGTH_LONG).show()
        micGrantedAction = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = getColor(R.color.sw_navy)
        window.navigationBarColor = getColor(R.color.sw_navy)
        setContentView(buildRoot())
        if (savedInstanceState == null) show(HomeFragment(), addToBackStack = false)
        setupBackNavigation()
    }

    private fun buildRoot(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.sw_navy))
        }
        val frame = FrameLayout(this).also { contentFrameId = View.generateViewId(); it.id = contentFrameId }
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = BottomNavigationView(this).apply {
            // Bewusst dunkler als der Inhaltsbereich: Die Navigation ist klar abgesetzt.
            setBackgroundColor(getColor(R.color.sw_nav_bar))
            elevation = dp(10).toFloat()
            setItemIconSize(dp(27))
            itemPaddingTop = dp(8)
            itemPaddingBottom = dp(8)
            labelVisibilityMode = BottomNavigationView.LABEL_VISIBILITY_LABELED
            setItemIconTintList(android.content.res.ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(getColor(R.color.sw_copper), getColor(R.color.sw_nav_icon))
            ))
            setItemTextColor(android.content.res.ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(getColor(R.color.sw_copper), getColor(R.color.sw_nav_text))
            ))
            setItemTextAppearanceInactive(R.style.SaitenwerkBottomNavLabel)
            setItemTextAppearanceActive(R.style.SaitenwerkBottomNavLabelActive)
            menu.add(0, 1, 0, "Start").setIcon(R.drawable.ic_nav_home)
            menu.add(0, 2, 1, "Stimmen").setIcon(R.drawable.ic_nav_tuner)
            menu.add(0, 3, 2, "Akkorde").setIcon(R.drawable.ic_nav_chords)
            menu.add(0, 4, 3, "Lieder").setIcon(R.drawable.ic_nav_songs)
            menu.add(0, 5, 4, "Lernstudio").setIcon(R.drawable.ic_nav_learn)
            // BottomNavigationView unterstützt maximal fünf Einträge.
            // Den Lernpfad erreichen Nutzer über das Lernstudio und die Startseite.
            setOnItemSelectedListener { item ->
                if (suppressNavSelection) true else { openSection(item.itemId); true }
            }
        }
        bottomNav = nav
        root.addView(nav, LinearLayout.LayoutParams(-1, dp(84)))
        return root
    }

    private fun show(fragment: Fragment, addToBackStack: Boolean = true) {
        val tx = supportFragmentManager.beginTransaction().replace(contentFrameId, fragment)
        if (addToBackStack) tx.addToBackStack(null)
        tx.commit()
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (supportFragmentManager.backStackEntryCount > 0) {
                    supportFragmentManager.popBackStack()
                    syncBottomNavigation()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    private fun syncBottomNavigation() {
        val id = when (supportFragmentManager.findFragmentById(contentFrameId)) {
            is HomeFragment -> 1
            is TunerFragment -> 2
            is ChordsFragment -> 3
            is SongsFragment -> 4
            is LearnFragment -> 5
            is PathFragment -> 5
            else -> 0
        }
        if (id != 0 && bottomNav?.selectedItemId != id) {
            suppressNavSelection = true
            bottomNav?.selectedItemId = id
            suppressNavSelection = false
        }
    }

    fun openSection(id: Int) {
        val current = supportFragmentManager.findFragmentById(contentFrameId)
        val alreadyOpen = when (id) {
            1 -> current is HomeFragment
            2 -> current is TunerFragment
            3 -> current is ChordsFragment
            4 -> current is SongsFragment
            5 -> current is LearnFragment
            6 -> current is PathFragment
            else -> false
        }
        if (alreadyOpen) return
        when (id) {
            1 -> show(HomeFragment())
            2 -> show(TunerFragment())
            3 -> show(ChordsFragment())
            4 -> show(SongsFragment())
            5 -> show(LearnFragment())
            6 -> show(PathFragment())
        }
    }

    fun openSong(song: Song) {
        show(SongDetailFragment.newInstance(song))
    }

    fun askMic(onGranted: () -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) onGranted()
        else { micGrantedAction = onGranted; requestMic.launch(Manifest.permission.RECORD_AUDIO) }
    }

    fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()
    fun title(value: String) = TextView(this).apply {
        text = value; setTextColor(getColor(R.color.sw_text)); textSize = 27f
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(dp(20), dp(22), dp(20), dp(12))
    }
    fun body(value: String, size: Float = 15f) = TextView(this).apply {
        text = value; textSize = size; setTextColor(getColor(R.color.sw_muted)); setPadding(dp(20), 0, dp(20), dp(12))
    }
    fun card(): MaterialCardView = MaterialCardView(this).apply {
        setCardBackgroundColor(getColor(R.color.sw_surface)); radius = dp(18).toFloat()
        strokeColor = getColor(R.color.sw_surface2); strokeWidth = dp(1)
    }
    fun button(value: String) = Button(this).apply {
        text = value; isAllCaps = false; setTextColor(getColor(R.color.sw_text))
        setBackgroundColor(getColor(R.color.sw_surface2))
    }
}

class HomeFragment : Fragment() {
    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity
        val root = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        root.addView(a.title("Heute Gitarre spielen."))
        root.addView(a.body("Dein persönlicher Gitarrenbegleiter – stimmen, Akkorde lernen, Songs spielen und Schritt für Schritt besser werden."))
        val card = a.card()
        val inner = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(18), a.dp(18), a.dp(18), a.dp(18)) }
        inner.addView(TextView(a).apply { text = "SAITENWERK"; textSize = 23f; setTextColor(a.getColor(R.color.sw_copper)); setTypeface(typeface, 1) })
        inner.addView(TextView(a).apply { text = "Gitarre · Stimmen · Üben · Akkorde"; setTextColor(a.getColor(R.color.sw_muted)) })
        card.addView(inner)
        root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(14)) })
        val entries = listOf("🎸  Stimmgerät" to 2, "◉  Akkorde lernen" to 3, "♫  Liederbuch" to 4, "◆  Lernstudio" to 5, "↗  Lernpfad" to 6)
        entries.forEach { (label, section) ->
            val b = a.button(label); b.setOnClickListener { a.openSection(section) }
            root.addView(b, LinearLayout.LayoutParams(-1, a.dp(50)).apply { setMargins(a.dp(16), a.dp(4), a.dp(16), a.dp(4)) })
        }
        return ScrollView(a).apply { addView(root) }
    }
}

class TunerFragment : Fragment() {
    @Volatile private var active = false
    private var recorder: AudioRecord? = null
    private var worker: Thread? = null
    private var noteView: TextView? = null
    private var hzView: TextView? = null
    private var centsView: TextView? = null
    private var targetView: TextView? = null
    private var statusView: TextView? = null
    private var gauge: TunerGaugeView? = null
    private var startButton: Button? = null
    private var instrumentSpinner: Spinner? = null
    private var selectedMode = TuningMode.GUITAR
    private var referenceA4 = 440.0
    private var referenceLabel: TextView? = null
    private var stringPanel: LinearLayout? = null
    private var referenceButton: Button? = null
    private var referenceTrack: AudioTrack? = null

    private enum class TuningMode(val label: String) {
        GUITAR("Gitarre · Standard · E–A–D–G–B–E"),
        CHROMATIC("Chromatisch · alle Töne"),
        BASS("Bass · Standard · E–A–D–G"),
        UKULELE("Ukulele · C-Stimmung · G–C–E–A"),
        VIOLIN("Violine · Standard · G–D–A–E")
    }

    private data class Target(val name: String, val hz: Double)

    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity
        val root = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        root.addView(a.title("Stimmgerät"))
        root.addView(a.body("Schnell und präzise stimmen · A4 = 440 Hz"))

        val selectorCard = a.card()
        val selector = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dp(16), a.dp(14), a.dp(16), a.dp(14))
        }
        selector.addView(TextView(a).apply {
            text = "Instrument & Stimmung"
            textSize = 13f
            setTextColor(a.getColor(R.color.sw_muted))
            setPadding(0, 0, 0, a.dp(6))
        })
        instrumentSpinner = Spinner(a).apply {
            val labels = TuningMode.values().map { it.label }
            adapter = ArrayAdapter(a, android.R.layout.simple_spinner_dropdown_item, labels)
            setSelection(TuningMode.values().indexOf(selectedMode))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) = Unit
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    selectedMode = TuningMode.values()[position]
                    targetView?.text = targetHint()
                    rebuildStringButtons()
                }
            }
        }
        selector.addView(instrumentSpinner, LinearLayout.LayoutParams(-1, a.dp(52)))

        referenceLabel = TextView(a).apply {
            text = "Kammerton A4 · 440 Hz"
            textSize = 13f
            setTextColor(a.getColor(R.color.sw_muted))
            setPadding(0, a.dp(10), 0, a.dp(2))
        }
        selector.addView(referenceLabel)
        val referenceSeek = SeekBar(a).apply {
            max = 10
            progress = 8
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(v: SeekBar?, progress: Int, fromUser: Boolean) {
                    referenceA4 = 432.0 + progress
                    referenceLabel?.text = "Kammerton A4 · ${referenceA4.roundToInt()} Hz"
                    targetView?.text = targetHint()
                }
                override fun onStartTrackingTouch(v: SeekBar?) = Unit
                override fun onStopTrackingTouch(v: SeekBar?) = Unit
            })
        }
        selector.addView(referenceSeek, LinearLayout.LayoutParams(-1, a.dp(42)))

        stringPanel = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, a.dp(6), 0, 0)
        }
        selector.addView(stringPanel, LinearLayout.LayoutParams(-1, a.dp(48)))
        selectorCard.addView(selector)
        root.addView(selectorCard, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(10)) })

        val displayCard = a.card()
        val display = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(a.dp(14), a.dp(10), a.dp(14), a.dp(16))
        }

        targetView = TextView(a).apply {
            text = targetHint()
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(a.getColor(R.color.sw_muted))
        }
        display.addView(targetView, LinearLayout.LayoutParams(-1, a.dp(30)))

        gauge = TunerGaugeView(a)
        display.addView(gauge, LinearLayout.LayoutParams(-1, a.dp(230)))

        noteView = TextView(a).apply {
            text = "—"
            textSize = 64f
            gravity = Gravity.CENTER
            setTextColor(a.getColor(R.color.sw_text))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        display.addView(noteView, LinearLayout.LayoutParams(-1, a.dp(76)))

        centsView = TextView(a).apply {
            text = "0 Cent"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(a.getColor(R.color.sw_muted))
        }
        display.addView(centsView, LinearLayout.LayoutParams(-1, a.dp(32)))

        hzView = TextView(a).apply {
            text = "Warte auf einen Ton"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(a.getColor(R.color.sw_muted))
        }
        display.addView(hzView, LinearLayout.LayoutParams(-1, a.dp(32)))

        statusView = TextView(a).apply {
            text = "BEREIT ZUM STIMMEN"
            textSize = 15f
            gravity = Gravity.CENTER
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(a.getColor(R.color.sw_copper))
        }
        display.addView(statusView, LinearLayout.LayoutParams(-1, a.dp(34)))

        referenceButton = a.button("Referenzton spielen").also {
            it.setOnClickListener { playReferenceTone() }
        }
        display.addView(referenceButton, LinearLayout.LayoutParams(-1, a.dp(48)).apply { topMargin = a.dp(4) })

        startButton = a.button("Stimmen starten").also {
            it.setOnClickListener { if (active) stopTuner() else a.askMic { startTuner() } }
        }
        display.addView(startButton, LinearLayout.LayoutParams(-1, a.dp(52)).apply { topMargin = a.dp(8) })
        displayCard.addView(display)
        root.addView(displayCard, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(14)) })

        rebuildStringButtons()
        root.addView(a.body("Spiele eine einzelne Saite an. Die Anzeige zeigt dir sofort den erkannten Ton, die Abweichung in Cent und die Zielsaite. In der Mitte ist die Saite gestimmt. Tippe eine Zielsaite an, um ihren Referenzton abzuspielen."))
        return ScrollView(a).apply { addView(root) }
    }

    private fun targetHint(): String = when (selectedMode) {
        TuningMode.GUITAR -> "Zielsaiten: 6E · 5A · 4D · 3G · 2B · 1E"
        TuningMode.BASS -> "Zielsaiten: 4E · 3A · 2D · 1G"
        TuningMode.UKULELE -> "Zielsaiten: 4G · 3C · 2E · 1A"
        TuningMode.VIOLIN -> "Zielsaiten: 4G · 3D · 2A · 1E"
        TuningMode.CHROMATIC -> "Chromatisch: jeder Ton wird erkannt"
    }

    private fun targets(): List<Target> {
        val scale = referenceA4 / 440.0
        return when (selectedMode) {
            TuningMode.GUITAR -> listOf(Target("6E", 82.4069 * scale), Target("5A", 110.0 * scale), Target("4D", 146.832 * scale), Target("3G", 195.998 * scale), Target("2B", 246.942 * scale), Target("1E", 329.628 * scale))
            TuningMode.BASS -> listOf(Target("4E", 41.2034 * scale), Target("3A", 55.0 * scale), Target("2D", 73.4162 * scale), Target("1G", 97.9989 * scale))
            TuningMode.UKULELE -> listOf(Target("4G", 392.0 * scale), Target("3C", 261.626 * scale), Target("2E", 329.628 * scale), Target("1A", 440.0 * scale))
            TuningMode.VIOLIN -> listOf(Target("4G", 196.0 * scale), Target("3D", 293.665 * scale), Target("2A", 440.0 * scale), Target("1E", 659.255 * scale))
            TuningMode.CHROMATIC -> emptyList()
        }
    }

    private fun rebuildStringButtons() {
        val panel = stringPanel ?: return
        panel.removeAllViews()
        val list = targets()
        if (list.isEmpty()) {
            panel.addView(TextView(requireContext()).apply {
                text = "Chromatisch · keine Zielsaiten"
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(requireContext().getColor(R.color.sw_muted))
            })
            return
        }
        list.forEach { target ->
            val b = Button(requireContext()).apply {
                text = target.name
                textSize = 12f
                minHeight = 0
                minimumHeight = 0
                setPadding(0, 0, 0, 0)
                setOnClickListener {
                    targetView?.text = "Ziel: ${target.name} · ${"%.1f".format(target.hz)} Hz"
                    playReferenceTone(target.hz)
                }
            }
            panel.addView(b, LinearLayout.LayoutParams(0, -1, 1f).apply {
                setMargins((2f * resources.displayMetrics.density).roundToInt(), 0, (2f * resources.displayMetrics.density).roundToInt(), 0)
            })
        }
    }

    private fun playReferenceTone(frequency: Double = referenceA4) {
        try {
            referenceTrack?.stop()
            referenceTrack?.release()
            val sampleRate = 44100
            val durationMs = 1500
            val count = sampleRate * durationMs / 1000
            val pcm = ShortArray(count)
            for (i in pcm.indices) {
                val t = i.toDouble() / sampleRate
                val envelope = kotlin.math.exp(-3.8 * t)
                val fundamental = kotlin.math.sin(2.0 * Math.PI * frequency * t)
                val second = 0.22 * kotlin.math.sin(2.0 * Math.PI * frequency * 2.0 * t)
                val third = 0.08 * kotlin.math.sin(2.0 * Math.PI * frequency * 3.0 * t)
                pcm[i] = (0.22 * envelope * (fundamental + second + third) * Short.MAX_VALUE).toInt().toShort()
            }
            val min = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val track = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(sampleRate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                .setBufferSizeInBytes(maxOf(min, pcm.size * 2))
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            referenceTrack = track
            track.write(pcm, 0, pcm.size)
            track.play()
        } catch (_: Exception) {
            Toast.makeText(requireContext(), "Referenzton konnte nicht abgespielt werden.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startTuner() {
        if (active) return
        val rate = 44100
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) { Toast.makeText(requireContext(), "Audioaufnahme wird von diesem Gerät nicht unterstützt.", Toast.LENGTH_LONG).show(); return }
        try {
            val size = maxOf(min, 8192)
            val audio = AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size)
            check(audio.state == AudioRecord.STATE_INITIALIZED) { "AudioRecord konnte nicht initialisiert werden" }
            recorder = audio; audio.startRecording(); active = true
            startButton?.text = "Stimmen stoppen"
            statusView?.text = "ICH HÖRE ZU …"
            worker = Thread {
                val samples = ShortArray(4096)
                while (active) {
                    val n = audio.read(samples, 0, samples.size)
                    if (n > 2048) {
                        val hz = estimatePitch(samples, n, rate)
                        if (hz in 35.0..1100.0) updatePitch(hz)
                    }
                }
            }.apply { name = "Saitenwerk-Tuner"; start() }
        } catch (e: Exception) {
            active = false; releaseRecorder(); startButton?.text = "Erneut versuchen"
            Toast.makeText(requireContext(), "Mikrofonfehler: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun updatePitch(hz: Double) {
        val result = if (selectedMode == TuningMode.CHROMATIC) {
            val midi = (69 + 12 * ln(hz / 440.0) / ln(2.0)).roundToInt()
            val target = 440.0 * 2.0.pow((midi - 69) / 12.0)
            val names = arrayOf("C", "C♯", "D", "D♯", "E", "F", "F♯", "G", "G♯", "A", "A♯", "B")
            val note = names[(midi % 12 + 12) % 12] + (midi / 12 - 1)
            note to target
        } else {
            val t = targets().minByOrNull { kotlin.math.abs(1200.0 * ln(hz / it.hz) / ln(2.0)) } ?: Target("—", 440.0)
            t.name to t.hz
        }
        val cents = (1200 * ln(hz / result.second) / ln(2.0)).roundToInt()
        val status = when {
            cents < -5 -> "ZU TIEF"
            cents > 5 -> "ZU HOCH"
            else -> "GESTIMMT"
        }
        activity?.runOnUiThread {
            if (!active) return@runOnUiThread
            noteView?.text = result.first
            hzView?.text = "%.1f Hz".format(hz)
            centsView?.text = when {
                cents > 0 -> "+$cents Cent"
                else -> "$cents Cent"
            }
            statusView?.text = status
            val tone = when {
                cents < -5 -> -1
                cents > 5 -> 1
                else -> 0
            }
            statusView?.setTextColor(requireContext().getColor(when (tone) {
                -1 -> R.color.sw_copper
                1 -> R.color.sw_copper
                else -> R.color.sw_copper
            }))
            gauge?.setCents(cents)
        }
    }

    private fun estimatePitch(x: ShortArray, n: Int, sr: Int): Double {
        val minLag = sr / 1100; val maxLag = minOf(sr / 35, n / 2)
        var bestLag = 0; var best = Double.NEGATIVE_INFINITY
        for (lag in minLag..maxLag step 2) {
            var sum = 0.0
            for (i in 0 until n - lag step 3) sum += x[i].toDouble() * x[i + lag].toDouble()
            if (sum > best) { best = sum; bestLag = lag }
        }
        return if (bestLag > 0) sr.toDouble() / bestLag else -1.0
    }

    private fun releaseRecorder() {
        try { recorder?.stop() } catch (_: Exception) { }
        try { recorder?.release() } catch (_: Exception) { }
        recorder = null; worker = null
    }
    private fun stopTuner() {
        active = false
        releaseRecorder()
        try { referenceTrack?.stop() } catch (_: Exception) { }
        try { referenceTrack?.release() } catch (_: Exception) { }
        referenceTrack = null
        startButton?.text = "Stimmen starten"
        statusView?.text = "BEREIT ZUM STIMMEN"
    }
    override fun onPause() { stopTuner(); super.onPause() }
    override fun onDestroyView() { stopTuner(); noteView = null; hzView = null; centsView = null; targetView = null; statusView = null; gauge = null; startButton = null; instrumentSpinner = null; super.onDestroyView() }
}

class TunerGaugeView(context: android.content.Context) : View(context) {
    private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    private val rect = android.graphics.RectF()
    private var cents = 0

    fun setCents(value: Int) {
        cents = value.coerceIn(-50, 50)
        invalidate()
    }

    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h * 0.78f
        val radius = minOf(w * 0.42f, h * 0.67f)
        rect.set(cx - radius, cy - radius, cx + radius, cy + radius)

        // Große, gut lesbare Halbkreis-Anzeige wie bei einem klassischen Hardware-Tuner.
        val segments = 31
        for (i in 0 until segments) {
            val start = 200f + i * (140f / segments)
            val center = i - (segments - 1) / 2f
            paint.style = android.graphics.Paint.Style.STROKE
            paint.strokeWidth = dp(8f)
            paint.strokeCap = android.graphics.Paint.Cap.BUTT
            paint.color = when {
                kotlin.math.abs(center) <= 2 -> android.graphics.Color.rgb(92, 155, 135)
                center < 0 -> android.graphics.Color.rgb(218, 174, 76)
                else -> android.graphics.Color.rgb(190, 88, 82)
            }
            canvas.drawArc(rect, start, 140f / segments - 2.2f, false, paint)
        }

        val angle = 270f + (cents / 50f) * 70f
        val rad = Math.toRadians(angle.toDouble())
        val x1 = cx + kotlin.math.cos(rad).toFloat() * radius * 0.18f
        val y1 = cy + kotlin.math.sin(rad).toFloat() * radius * 0.18f
        val x2 = cx + kotlin.math.cos(rad).toFloat() * radius * 0.91f
        val y2 = cy + kotlin.math.sin(rad).toFloat() * radius * 0.91f
        paint.color = android.graphics.Color.WHITE
        paint.strokeWidth = dp(4f)
        paint.strokeCap = android.graphics.Paint.Cap.ROUND
        canvas.drawLine(x1, y1, x2, y2, paint)

        paint.style = android.graphics.Paint.Style.FILL
        paint.color = android.graphics.Color.WHITE
        canvas.drawCircle(cx, cy, dp(7f), paint)

        paint.textAlign = android.graphics.Paint.Align.CENTER
        paint.typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
        paint.textSize = dp(13f)
        paint.color = android.graphics.Color.LTGRAY
        canvas.drawText("−50", cx - radius * 0.82f, cy + dp(24f), paint)
        canvas.drawText("0", cx, cy - radius * 0.91f, paint)
        canvas.drawText("+50", cx + radius * 0.82f, cy + dp(24f), paint)
    }

    private fun dp(v: Float) = v * resources.displayMetrics.density
}

data class ChordShape(val name: String, val quality: String, val frets: IntArray, val baseFret: Int = 1, val note: String = "")
object ChordLibrary {
    val all = listOf(
        ChordShape("C", "Dur", intArrayOf(-1,3,2,0,1,0), note="Offener C-Dur-Griff"),
        ChordShape("G", "Dur", intArrayOf(3,2,0,0,0,3), note="Offener G-Dur-Griff"),
        ChordShape("D", "Dur", intArrayOf(-1,-1,0,2,3,2), note="Offener D-Dur-Griff"),
        ChordShape("A", "Dur", intArrayOf(-1,0,2,2,2,0), note="Offener A-Dur-Griff"),
        ChordShape("E", "Dur", intArrayOf(0,2,2,1,0,0), note="Offener E-Dur-Griff"),
        ChordShape("F", "Dur", intArrayOf(1,3,3,2,1,1), note="Barré-Griff im 1. Bund"),
        ChordShape("Am", "Moll", intArrayOf(-1,0,2,2,1,0)),
        ChordShape("Em", "Moll", intArrayOf(0,2,2,0,0,0)),
        ChordShape("Dm", "Moll", intArrayOf(-1,-1,0,2,3,1)),
        ChordShape("Bm", "Moll", intArrayOf(-1,2,4,4,3,2), 2),
        ChordShape("C7", "Septakkord", intArrayOf(-1,3,2,3,1,0)),
        ChordShape("D7", "Septakkord", intArrayOf(-1,-1,0,2,1,2)),
        ChordShape("E7", "Septakkord", intArrayOf(0,2,0,1,0,0)),
        ChordShape("G7", "Septakkord", intArrayOf(3,2,0,0,0,1)),
        ChordShape("Am7", "Septakkord", intArrayOf(-1,0,2,0,1,0)),
        ChordShape("Em7", "Septakkord", intArrayOf(0,2,0,0,0,0)),
        ChordShape("Dsus2", "Sus-Akkord", intArrayOf(-1,-1,0,2,3,0)),
        ChordShape("Dsus4", "Sus-Akkord", intArrayOf(-1,-1,0,2,3,3)),
        ChordShape("Asus2", "Sus-Akkord", intArrayOf(-1,0,2,2,0,0)),
        ChordShape("Asus4", "Sus-Akkord", intArrayOf(-1,0,2,2,3,0))
    )
}

class ChordDiagramView(context: android.content.Context, private val shape: ChordShape) : View(context) {
    private val gridPaint = android.graphics.Paint(3).apply { color = android.graphics.Color.LTGRAY; strokeWidth = 2f }
    private val textPaint = android.graphics.Paint(3).apply { color = android.graphics.Color.WHITE; textSize = 22f; textAlign = android.graphics.Paint.Align.CENTER }
    private val dotPaint = android.graphics.Paint(3).apply { color = android.graphics.Color.rgb(217,154,112); style = android.graphics.Paint.Style.FILL }

    // Standard-Hochkantdarstellung: sechs Saiten verlaufen senkrecht,
    // die Bünde waagerecht. Tiefe E-Saite links, hohe e-Saite rechts.
    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val top = dp(38f)
        val bottom = height - dp(42f)
        val left = width * .17f
        val right = width * .83f
        val dx = (right - left) / 5f
        val dy = (bottom - top) / 4f

        // Saiten
        for (i in 0..5) canvas.drawLine(left + i * dx, top, left + i * dx, bottom, gridPaint)
        // Bünde
        for (i in 0..4) canvas.drawLine(left, top + i * dy, right, top + i * dy, gridPaint)

        // Sattel / Bundnummer
        if (shape.baseFret == 1) {
            canvas.drawRect(left - dp(2f), top - dp(4f), right + dp(2f), top + dp(2f), gridPaint)
        } else {
            canvas.drawText("${shape.baseFret}.", left - dp(27f), top + dy * .55f, textPaint)
        }

        val labels = arrayOf("E", "A", "D", "G", "H", "e")
        for (i in 0..5) {
            val fret = shape.frets[i]
            val x = left + i * dx
            val marker = if (fret < 0) "×" else if (fret == 0) "○" else ""
            if (marker.isNotEmpty()) canvas.drawText(marker, x, top - dp(12f), textPaint)
            if (fret > 0) {
                val y = top + (fret - shape.baseFret + .5f) * dy
                if (y in top..bottom) canvas.drawCircle(x, y, dp(10f), dotPaint)
            }
            canvas.drawText(labels[i], x, height - dp(8f), textPaint)
        }
    }

    private fun dp(v: Float) = v * resources.displayMetrics.density
}

/** Spielt den ausgewählten Griff als kurze, gezupfte Gitarrenprobe. */
object ChordPreviewPlayer {
    @Volatile private var current: android.media.AudioTrack? = null

    fun play(shape: ChordShape) {
        stop()
        Thread {
            val sampleRate = 44100
            val durationMs = 3000
            val samples = sampleRate * durationMs / 1000
            val mix = DoubleArray(samples)
            val tuning = doubleArrayOf(82.4069, 110.0, 146.832, 196.0, 246.942, 329.628)
            val random = java.util.Random(shape.name.hashCode().toLong())
            var activeStrings = 0

            // Karplus-Strong: ein kurzer Rauschimpuls wird durch eine rückgekoppelte
            // Verzögerungsleitung geschickt. Dadurch entsteht ein deutlich natürlicherer
            // gezupfter Saitenklang als mit reinen Sinuswellen.
            shape.frets.forEachIndexed { stringIndex, fret ->
                if (fret >= 0) {
                    activeStrings++
                    val frequency = tuning[stringIndex] * 2.0.pow(fret / 12.0)
                    val delay = (sampleRate / frequency).roundToInt().coerceAtLeast(2)
                    val pluck = DoubleArray(delay)
                    for (i in pluck.indices) {
                        pluck[i] = random.nextDouble() * 2.0 - 1.0
                    }

                    val start = stringIndex * (sampleRate / 95)
                    var previous = 0.0
                    val decay = 0.9968 - stringIndex * 0.00006
                    val stringLength = minOf(samples - start, (durationMs * sampleRate / 1000))
                    if (stringLength <= 0) return@forEachIndexed

                    for (j in 0 until stringLength) {
                        val pos = j % delay
                        val currentSample = pluck[pos]
                        val nextPos = (pos + 1) % delay
                        // leichter Tiefpass in der Rückkopplung = typische Dämpfung hoher Obertöne
                        val filtered = 0.5 * (currentSample + previous)
                        pluck[pos] = filtered * decay
                        previous = currentSample

                        val t = j.toDouble() / sampleRate
                        val envelope = kotlin.math.exp(-0.95 * t)
                        // Weicher Anschlag: kein harter Klick am Anfang der Saite.
                        val attack = if (t < 0.055) {
                            val a = t / 0.055
                            a * a * (3.0 - 2.0 * a)
                        } else 1.0
                        val fadeOut = if (t > 2.35) ((3.0 - t) / 0.65).coerceIn(0.0, 1.0) else 1.0
                        mix[start + j] += currentSample * envelope * attack * fadeOut * 0.12
                    }
                }
            }

            if (activeStrings == 0) return@Thread

            // Sanfte Sättigung und Normalisierung verhindern harte digitale Spitzen.
            val max = mix.maxOf { kotlin.math.abs(it) }.coerceAtLeast(0.001)
            val pcm = ShortArray(samples) { i ->
                val x = (mix[i] / max * 0.26).coerceIn(-1.0, 1.0)
                val shaped = kotlin.math.tanh(x * 0.58)
                (shaped * Short.MAX_VALUE).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            }

            val track = android.media.AudioTrack.Builder()
                .setAudioAttributes(
                    android.media.AudioAttributes.Builder()
                        .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    android.media.AudioFormat.Builder()
                        .setEncoding(android.media.AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(android.media.AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(pcm.size * 2)
                .setTransferMode(android.media.AudioTrack.MODE_STATIC)
                .build()

            current = track
            track.write(pcm, 0, pcm.size)
            track.play()
            while (track.playState == android.media.AudioTrack.PLAYSTATE_PLAYING) {
                Thread.sleep(30)
            }
            track.release()
            if (current === track) current = null
        }.start()
    }

    fun stop() {
        val track = current
        current = null
        try { track?.stop() } catch (_: Exception) { }
        try { track?.release() } catch (_: Exception) { }
    }
}

class ChordsFragment : Fragment() {
    private var training: ChordTrainingPanel? = null
    override fun onDestroyView() { training?.stop(); training = null; super.onDestroyView() }
    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity
        val root = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        root.addView(a.title("Akkorde")); root.addView(a.body("Griffbilder · Akkordwissen · Wechseltraining"))
        val search = EditText(a).apply { hint = "Akkord suchen (z. B. Am, G7 …)"; setSingleLine(); setTextColor(a.getColor(R.color.sw_text)); setHintTextColor(a.getColor(R.color.sw_muted)); setPadding(a.dp(16), 0, a.dp(16), 0) }
        root.addView(search, LinearLayout.LayoutParams(-1, a.dp(50)).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(8)) })
        val filters = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; setPadding(a.dp(10), 0, a.dp(10), a.dp(8)) }
        val categories = listOf("Alle", "Dur", "Moll", "Septakkord", "Sus-Akkord"); var category = "Alle"
        val scroll = ScrollView(a)
        val content = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        val detailCard = a.card().apply { visibility = View.GONE }
        val detail = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(16), a.dp(14), a.dp(16), a.dp(16)) }
        detailCard.addView(detail)
        val grid = GridLayout(a).apply { columnCount = 3; setPadding(a.dp(10), a.dp(4), a.dp(10), a.dp(12)) }
        fun showChord(ch: ChordShape) {
            detail.removeAllViews()
            detail.addView(TextView(a).apply { text = ch.name; textSize = 29f; setTextColor(a.getColor(R.color.sw_copper)); setTypeface(typeface, 1) })
            detail.addView(TextView(a).apply { text = "${ch.quality} · ${ch.note}"; setTextColor(a.getColor(R.color.sw_muted)) })
            detail.addView(ChordDiagramView(a, ch), LinearLayout.LayoutParams(-1, a.dp(270)))
            detail.addView(TextView(a).apply { text = "Hochkant: tiefe E-Saite links · hohe e-Saite rechts\n× = nicht anschlagen · ○ = leere Saite"; setTextColor(a.getColor(R.color.sw_muted)); textSize = 13f })
            val preview = a.button("▶ Akkord anhören")
            preview.setOnClickListener { ChordPreviewPlayer.play(ch) }
            detail.addView(preview, LinearLayout.LayoutParams(-1, a.dp(48)).apply { topMargin = a.dp(8) })
            val prefs = a.getSharedPreferences("saitenwerk", 0); val key = "fav_chords"
            val saved = prefs.getStringSet(key, emptySet())?.toMutableSet() ?: mutableSetOf()
            val fav = a.button(if (ch.name in saved) "★ Favorit entfernen" else "☆ Als Favorit speichern")
            fav.setOnClickListener { val now = prefs.getStringSet(key, emptySet())?.toMutableSet() ?: mutableSetOf(); if (!now.add(ch.name)) now.remove(ch.name); prefs.edit().putStringSet(key, now).apply(); fav.text = if (ch.name in now) "★ Favorit entfernen" else "☆ Als Favorit speichern" }
            detail.addView(fav, LinearLayout.LayoutParams(-1, a.dp(46)).apply { topMargin = a.dp(8) })
            detailCard.visibility = View.VISIBLE
        }
        fun render() {
            grid.removeAllViews(); val q = search.text.toString().trim().lowercase()
            val matches = ChordLibrary.all.filter { (category == "Alle" || it.quality == category) && it.name.lowercase().contains(q) }
            matches.forEach { chord ->
                val b = a.button(chord.name); b.setOnClickListener { showChord(chord) }
                grid.addView(b, GridLayout.LayoutParams().apply { width = 0; height = a.dp(52); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(a.dp(3), a.dp(3), a.dp(3), a.dp(3)) })
            }
            if (matches.isEmpty()) grid.addView(a.body("Kein passender Akkord gefunden."))
        }
        categories.forEach { cat -> val b = a.button(cat); b.textSize = 11f; b.setOnClickListener { category = cat; render() }; filters.addView(b, LinearLayout.LayoutParams(0, a.dp(42), 1f).apply { setMargins(a.dp(2), 0, a.dp(2), 0) }) }
        search.addTextChangedListener(object : TextWatcher { override fun beforeTextChanged(s: CharSequence?, st: Int, count: Int, after: Int) {}; override fun onTextChanged(s: CharSequence?, st: Int, before: Int, count: Int) { render() }; override fun afterTextChanged(e: Editable?) {} })
        content.addView(detailCard); content.addView(grid)
        training = ChordTrainingPanel(a); content.addView(training, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(12), a.dp(12), a.dp(12), a.dp(20)) })
        scroll.addView(content); root.addView(filters); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f)); render()
        return root
    }
}

class ChordTrainingPanel(private val host: MainActivity) : LinearLayout(host) {
    private val handler = Handler(Looper.getMainLooper())
    private val tone = ToneGenerator(AudioManager.STREAM_MUSIC, 55)
    private val sequence = listOf("C", "G", "Am", "F")
    private var bpm = 72; private var beat = 0; private var changes = 0; private var running = false
    private val current = TextView(host); private val status = TextView(host); private val start = host.button("Training starten")
    private val tempo = SeekBar(host); private val tempoLabel = TextView(host); private val stats = TextView(host)
    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            tone.startTone(if (beat % 4 == 0) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_BEEP, 65)
            if (beat % 4 == 0) { current.text = sequence[changes % sequence.size]; changes++; stats.text = "Akkordwechsel: ${changes - 1} · Tempo: $bpm BPM" }
            beat++; handler.postDelayed(this, (60000L / bpm).coerceAtLeast(100L))
        }
    }
    init {
        orientation = VERTICAL; setPadding(host.dp(16), host.dp(16), host.dp(16), host.dp(16)); setBackgroundColor(host.getColor(R.color.sw_surface))
        addView(TextView(host).apply { this.text = "Akkordwechsel-Training"; textSize = 20f; setTextColor(host.getColor(R.color.sw_copper)); setTypeface(typeface, 1) })
        addView(TextView(host).apply { this.text = "Wechsle im Takt: C · G · Am · F"; setTextColor(host.getColor(R.color.sw_muted)); setPadding(0, host.dp(5), 0, host.dp(10)) })
        current.apply { text = "C"; textSize = 40f; gravity = Gravity.CENTER; setTextColor(host.getColor(R.color.sw_text)); setTypeface(typeface, 1) }
        addView(current, LayoutParams(-1, host.dp(76)))
        status.apply { text = "Bereit? Starte das Metronom."; setTextColor(host.getColor(R.color.sw_muted)); textSize = 13f }
        addView(status, LayoutParams(-1, -2))
        tempoLabel.apply { text = "Tempo: 72 BPM"; setTextColor(host.getColor(R.color.sw_text)); setPadding(0, host.dp(10), 0, 0) }
        addView(tempoLabel)
        tempo.max = 110; tempo.progress = 22
        tempo.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(v: SeekBar?, progress: Int, fromUser: Boolean) { bpm = 50 + progress; tempoLabel.text = "Tempo: $bpm BPM" }
            override fun onStartTrackingTouch(v: SeekBar?) {}; override fun onStopTrackingTouch(v: SeekBar?) {}
        })
        addView(tempo, LayoutParams(-1, host.dp(42)))
        start.setOnClickListener { if (running) stop() else begin() }; addView(start, LayoutParams(-1, host.dp(48)))
        stats.apply { text = "Akkordwechsel: 0 · Tempo: 72 BPM"; setTextColor(host.getColor(R.color.sw_muted)); setPadding(0, host.dp(8), 0, host.dp(6)) }; addView(stats)
        val row = LinearLayout(host).apply { orientation = HORIZONTAL }
        val mastered = host.button("✓ Sitzt"); val practice = host.button("↻ Weiter üben")
        mastered.setOnClickListener { saveRating(true) }; practice.setOnClickListener { saveRating(false) }
        row.addView(mastered, LayoutParams(0, host.dp(44), 1f)); row.addView(practice, LayoutParams(0, host.dp(44), 1f).apply { leftMargin = host.dp(6) }); addView(row)
        val p = host.getSharedPreferences("saitenwerk", 0)
        status.text = "Bisher: ${p.getInt("chord_training_mastered", 0)} gemeisterte Bewertungen aus ${p.getInt("chord_training_sessions", 0)} Einträgen."
    }
    private fun begin() { running = true; beat = 0; changes = 0; start.text = "Training stoppen"; status.text = "Läuft · auf den ersten Schlag achten"; handler.removeCallbacks(tick); handler.post(tick) }
    fun stop() { running = false; handler.removeCallbacks(tick); start.text = "Training starten"; try { tone.stopTone() } catch (_: Exception) { } }
    private fun saveRating(mastered: Boolean) {
        val p = host.getSharedPreferences("saitenwerk", 0); val sessions = p.getInt("chord_training_sessions", 0) + 1
        val wins = p.getInt("chord_training_mastered", 0) + if (mastered) 1 else 0
        p.edit().putInt("chord_training_sessions", sessions).putInt("chord_training_mastered", wins).apply()
        status.text = if (mastered) "Als gemeistert markiert · $wins von $sessions" else "Für weitere Übung vorgemerkt · $wins von $sessions"
    }
    override fun onDetachedFromWindow() { stop(); try { tone.release() } catch (_: Exception) { }; super.onDetachedFromWindow() }
}

data class Song(val title: String, val artist: String = "", val genre: String = "", val custom: Boolean = false)
object SongRepository {
    private const val PREFS = "saitenwerk"
    private fun prefs(a: MainActivity) = a.getSharedPreferences(PREFS, 0)
    fun key(song: Song) = (song.title.trim() + "|" + song.artist.trim()).lowercase()

    fun load(a: MainActivity): MutableList<Song> {
        val base = try {
            val raw = a.assets.open("songs.json").bufferedReader().use { it.readText() }
            val array = JSONArray(raw)
            MutableList(array.length()) { index ->
                val o = array.getJSONObject(index)
                Song(o.optString("title"), o.optString("artist"), o.optString("genre"))
            }
        } catch (_: Exception) { mutableListOf() }
        val custom = try {
            val arr = JSONArray(prefs(a).getString("custom_songs", "[]"))
            MutableList(arr.length()) { i -> arr.getJSONObject(i).let { Song(it.optString("title"), it.optString("artist"), it.optString("genre", "Eigene Songs"), true) } }
        } catch (_: Exception) { mutableListOf() }
        val seen = base.map { key(it) }.toMutableSet()
        base.addAll(custom.filter { seen.add(key(it)) })
        return base
    }

    private fun stringSet(a: MainActivity, name: String) = prefs(a).getStringSet(name, emptySet())?.toMutableSet() ?: mutableSetOf()
    fun isFavorite(a: MainActivity, song: Song) = key(song) in stringSet(a, "song_favorites")
    fun toggleFavorite(a: MainActivity, song: Song): Boolean {
        val set = stringSet(a, "song_favorites"); val k = key(song)
        val now = if (set.remove(k)) false else { set.add(k); true }
        prefs(a).edit().putStringSet("song_favorites", set).apply(); return now
    }
    fun inSetlist(a: MainActivity, song: Song) = key(song) in stringSet(a, "song_setlist")
    fun toggleSetlist(a: MainActivity, song: Song): Boolean {
        val set = stringSet(a, "song_setlist"); val k = key(song)
        val now = if (set.remove(k)) false else { set.add(k); true }
        prefs(a).edit().putStringSet("song_setlist", set).apply(); return now
    }
    fun addRecent(a: MainActivity, song: Song) {
        val old = prefs(a).getString("song_recent", "")!!.split("\n").filter { it.isNotBlank() }.toMutableList()
        old.remove(key(song)); old.add(0, key(song))
        prefs(a).edit().putString("song_recent", old.take(30).joinToString("\n")).apply()
    }
    fun isRecent(a: MainActivity, song: Song) = key(song) in prefs(a).getString("song_recent", "")!!.split("\n")
    fun addCustom(a: MainActivity, song: Song) {
        val arr = try { JSONArray(prefs(a).getString("custom_songs", "[]")) } catch (_: Exception) { JSONArray() }
        if (load(a).any { key(it) == key(song) }) return
        arr.put(org.json.JSONObject().put("title", song.title).put("artist", song.artist).put("genre", song.genre.ifBlank { "Eigene Songs" }))
        prefs(a).edit().putString("custom_songs", arr.toString()).apply()
    }
}

class SongsFragment : Fragment() {
    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity
        val root = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        root.addView(a.title("Liederbuch"))
        val songs = SongRepository.load(a)
        val count = a.body("${songs.size} Songs · offline verfügbar")
        root.addView(count)
        val search = EditText(a).apply {
            hint = "Titel, Künstler oder Genre suchen"; setSingleLine()
            setTextColor(a.getColor(R.color.sw_text)); setHintTextColor(a.getColor(R.color.sw_muted))
            setPadding(a.dp(16), 0, a.dp(16), 0)
            background = android.graphics.drawable.GradientDrawable().apply { setColor(a.getColor(R.color.sw_surface)); cornerRadius = a.dp(14).toFloat(); setStroke(a.dp(1), a.getColor(R.color.sw_surface2)) }
        }
        root.addView(search, LinearLayout.LayoutParams(-1, a.dp(50)).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(8)) })

        val genreValues = listOf("Alle Genres") + songs.map { it.genre }.filter { it.isNotBlank() }.distinct().sorted()
        val genre = Spinner(a).apply { adapter = ArrayAdapter(a, android.R.layout.simple_spinner_dropdown_item, genreValues) }
        val sort = Spinner(a).apply { adapter = ArrayAdapter(a, android.R.layout.simple_spinner_dropdown_item, listOf("Titel A–Z", "Künstler A–Z", "Genre")) }
        val controls = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        controls.addView(genre, LinearLayout.LayoutParams(0, a.dp(48), 1f).apply { setMargins(a.dp(12), 0, a.dp(4), 0) })
        controls.addView(sort, LinearLayout.LayoutParams(0, a.dp(48), 1f).apply { setMargins(a.dp(4), 0, a.dp(12), 0) })
        root.addView(controls)

        var filter = "Alle"
        var refreshList: (() -> Unit)? = null
        val filters = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        val buttons = linkedMapOf<String, Button>()
        listOf("Alle", "★ Favoriten", "♫ Setlist", "Zuletzt").forEach { label ->
            val b = a.button(label).apply { textSize = 12f; minWidth = 0; setPadding(a.dp(8), 0, a.dp(8), 0) }
            buttons[label] = b
            filters.addView(b, LinearLayout.LayoutParams(0, a.dp(42), 1f).apply { setMargins(a.dp(3), a.dp(8), a.dp(3), a.dp(8)) })
            b.setOnClickListener { filter = label; refreshList?.invoke() }
        }
        root.addView(filters)

        val list = RecyclerView(a).apply { layoutManager = LinearLayoutManager(a); setPadding(0, 0, 0, a.dp(8)); clipToPadding = false }
        val adapter = SongAdapter(songs, a) { song -> SongRepository.addRecent(a, song); a.openSong(song) }
        list.adapter = adapter
        fun refresh() {
            val term = search.text.toString().trim().lowercase()
            val selectedGenre = genre.selectedItem?.toString() ?: "Alle Genres"
            val filtered = songs.filter { song ->
                (term.isEmpty() || song.title.lowercase().contains(term) || song.artist.lowercase().contains(term) || song.genre.lowercase().contains(term)) &&
                (selectedGenre == "Alle Genres" || song.genre == selectedGenre) && when (filter) {
                    "★ Favoriten" -> SongRepository.isFavorite(a, song)
                    "♫ Setlist" -> SongRepository.inSetlist(a, song)
                    "Zuletzt" -> SongRepository.isRecent(a, song)
                    else -> true
                }
            }.let { result -> when (sort.selectedItemPosition) {
                1 -> result.sortedBy { it.artist.lowercase() + it.title.lowercase() }
                2 -> result.sortedBy { it.genre.lowercase() + it.title.lowercase() }
                else -> result.sortedBy { it.title.lowercase() }
            } }
            adapter.submit(filtered)
            count.text = "${filtered.size} angezeigt · ${songs.size} Songs insgesamt · offline verfügbar"
            buttons.forEach { (name, b) -> b.alpha = if ((name == "★ Favoriten" && filter == name) || (name == "♫ Setlist" && filter == name) || (name == filter)) 1f else .68f }
        }
        refreshList = { refresh() }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, before: Int, count: Int) { refresh() }
            override fun afterTextChanged(e: Editable?) {}
        })
        genre.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { refresh() }
        }
        sort.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { refresh() }
        }
        val add = a.button("＋ Eigenen Song hinzufügen")
        add.setOnClickListener {
            val panel = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(20), a.dp(8), a.dp(20), 0) }
            val title = EditText(a).apply { hint = "Songtitel" }
            val artist = EditText(a).apply { hint = "Künstler (optional)" }
            val category = EditText(a).apply { hint = "Genre (optional)" }
            panel.addView(title); panel.addView(artist); panel.addView(category)
            androidx.appcompat.app.AlertDialog.Builder(a).setTitle("Eigenen Song anlegen").setView(panel)
                .setNegativeButton("Abbrechen", null).setPositiveButton("Speichern") { _, _ ->
                    val name = title.text.toString().trim()
                    if (name.isBlank()) Toast.makeText(a, "Bitte einen Songtitel eingeben.", Toast.LENGTH_SHORT).show()
                    else {
                        val song = Song(name, artist.text.toString().trim(), category.text.toString().trim().ifBlank { "Eigene Songs" }, true)
                        if (songs.any { SongRepository.key(it) == SongRepository.key(song) }) Toast.makeText(a, "Dieser Song ist bereits vorhanden.", Toast.LENGTH_SHORT).show()
                        else { SongRepository.addCustom(a, song); songs.add(song); refresh(); Toast.makeText(a, "Song gespeichert", Toast.LENGTH_SHORT).show() }
                    }
                }.show()
        }
        root.addView(add, LinearLayout.LayoutParams(-1, a.dp(46)).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(6)) })
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        refresh()
        return root
    }
}

class SongAdapter(private val all: List<Song>, private val host: MainActivity, private val onClick: (Song) -> Unit) : RecyclerView.Adapter<SongAdapter.Holder>() {
    private var data = all.toList()
    class Holder(v: View) : RecyclerView.ViewHolder(v)
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val card = MaterialCardView(host).apply {
            setCardBackgroundColor(host.getColor(R.color.sw_surface)); radius = host.dp(14).toFloat()
            strokeColor = host.getColor(R.color.sw_surface2); strokeWidth = host.dp(1)
            val text = LinearLayout(host).apply { orientation = LinearLayout.VERTICAL; setPadding(host.dp(16), host.dp(12), host.dp(16), host.dp(12)) }
            addView(text); tag = text
        }
        return Holder(card)
    }
    override fun getItemCount() = data.size
    override fun onBindViewHolder(holder: Holder, position: Int) {
        val song = data[position]; val card = holder.itemView as MaterialCardView
        val text = card.tag as LinearLayout; text.removeAllViews()
        text.addView(TextView(host).apply { this.text = (if (SongRepository.isFavorite(host, song)) "★  " else "♫  ") + song.title; setTextColor(host.getColor(R.color.sw_text)); textSize = 16f; setTypeface(typeface, android.graphics.Typeface.BOLD) })
        text.addView(TextView(host).apply { this.text = song.artist.ifBlank { "Künstler unbekannt" } + "   ·   " + song.genre + if (SongRepository.inSetlist(host, song)) "   ·   Setlist" else ""; setTextColor(host.getColor(R.color.sw_muted)); textSize = 13f; setPadding(0, host.dp(4), 0, 0) })
        card.setOnClickListener { onClick(song) }
        card.layoutParams = RecyclerView.LayoutParams(-1, -2).apply {
            setMargins(host.dp(12), host.dp(4), host.dp(12), host.dp(4))
        }
    }
    fun submit(items: List<Song>) { data = items; notifyDataSetChanged() }
}

class SongDetailFragment : Fragment() {
    companion object {
        fun newInstance(song: Song) = SongDetailFragment().apply {
            arguments = Bundle().apply {
                putString("title", song.title)
                putString("artist", song.artist)
                putString("genre", song.genre)
            }
        }
    }

    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity
        val song = arguments?.let {
            Song(it.getString("title").orEmpty(), it.getString("artist").orEmpty(), it.getString("genre").orEmpty())
        } ?: Song("Unbekannter Titel")
        val prefs = a.getSharedPreferences("saitenwerk", 0)
        val root = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        val back = a.button("‹  Zurück zum Liederbuch")
        back.setOnClickListener { a.openSection(4) }
        root.addView(back, LinearLayout.LayoutParams(-1, a.dp(50)).apply { setMargins(a.dp(16), a.dp(12), a.dp(16), 0) })
        root.addView(a.title(song.title))
        root.addView(TextView(a).apply {
            text = song.artist
            textSize = 19f
            setTextColor(a.getColor(R.color.sw_copper))
            setPadding(a.dp(20), 0, a.dp(20), a.dp(8))
        })
        root.addView(a.body("Genre: ${song.genre}"))

        val favorite = a.button(if (SongRepository.isFavorite(a, song)) "★ Aus Favoriten entfernen" else "☆ Zu Favoriten hinzufügen")
        favorite.setOnClickListener {
            val now = SongRepository.toggleFavorite(a, song)
            favorite.text = if (now) "★ Aus Favoriten entfernen" else "☆ Zu Favoriten hinzufügen"
            Toast.makeText(a, if (now) "Als Favorit gespeichert" else "Aus Favoriten entfernt", Toast.LENGTH_SHORT).show()
        }
        root.addView(favorite, LinearLayout.LayoutParams(-1, a.dp(48)).apply { setMargins(a.dp(16), a.dp(8), a.dp(16), a.dp(4)) })
        val setlist = a.button(if (SongRepository.inSetlist(a, song)) "✓ Aus meiner Setlist entfernen" else "＋ Zur Setlist hinzufügen")
        setlist.setOnClickListener {
            val added = SongRepository.toggleSetlist(a, song)
            setlist.text = if (added) "✓ Aus meiner Setlist entfernen" else "＋ Zur Setlist hinzufügen"
            Toast.makeText(a, if (added) "Zur Setlist hinzugefügt" else "Aus Setlist entfernt", Toast.LENGTH_SHORT).show()
        }
        root.addView(setlist, LinearLayout.LayoutParams(-1, a.dp(46)).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(12)) })

        val card = a.card()
        val box = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dp(16), a.dp(16), a.dp(16), a.dp(18))
        }
        box.addView(TextView(a).apply {
            text = "Dein Song-Arrangement"
            textSize = 21f
            setTextColor(a.getColor(R.color.sw_copper))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        box.addView(a.body("Trage deine Akkorde abschnittsweise ein. Deine Arrangements werden lokal auf diesem Gerät gespeichert. Es werden keine Songtexte ergänzt."))

        val storageKey = "song_arrangement_${song.title}|${song.artist}"
        val sections = listOf("Intro", "Strophe 1", "Strophe 2", "Refrain", "Bridge", "Outro")
        val section = Spinner(a).apply {
            adapter = ArrayAdapter(a, android.R.layout.simple_spinner_dropdown_item, sections)
            setSelection(1)
        }
        fun loadSection(name: String): org.json.JSONObject = try {
            org.json.JSONObject(prefs.getString("${storageKey}_$name", "{}") ?: "{}")
        } catch (_: Exception) { org.json.JSONObject() }
        val initialSaved = loadSection("Strophe 1")
        box.addView(TextView(a).apply { text = "Songabschnitt"; setTextColor(a.getColor(R.color.sw_text)); setPadding(0, a.dp(8), 0, a.dp(4)) })
        box.addView(section, LinearLayout.LayoutParams(-1, a.dp(48)))

        val progression = EditText(a).apply {
            hint = "z. B. Am | F | C | G"
            setText(initialSaved.optString("chords", ""))
            setTextColor(a.getColor(R.color.sw_text))
            setHintTextColor(a.getColor(R.color.sw_muted))
            minLines = 2
            gravity = Gravity.TOP
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        }
        box.addView(TextView(a).apply { text = "Akkordfolge (mit | trennen)"; setTextColor(a.getColor(R.color.sw_text)); setPadding(0, a.dp(10), 0, a.dp(4)) })
        box.addView(progression, LinearLayout.LayoutParams(-1, a.dp(84)))

        val capoLabel = TextView(a).apply { setTextColor(a.getColor(R.color.sw_text)); setPadding(0, a.dp(10), 0, 0) }
        val capo = SeekBar(a).apply { max = 12; progress = initialSaved.optInt("capo", 0).coerceIn(0, 12) }
        val transposeLabel = TextView(a).apply { setTextColor(a.getColor(R.color.sw_text)); setPadding(0, a.dp(8), 0, 0) }
        val transpose = SeekBar(a).apply { max = 12; progress = (initialSaved.optInt("transpose", 0) + 6).coerceIn(0, 12) }
        val preview = TextView(a).apply {
            textSize = 18f
            setTextColor(a.getColor(R.color.sw_copper))
            setPadding(0, a.dp(12), 0, a.dp(10))
        }
        fun updatePreview() {
            val semitones = transpose.progress - 6
            capoLabel.text = "Capo: ${capo.progress}. Bund"
            transposeLabel.text = "Transponierung: ${if (semitones > 0) "+" else ""}$semitones Halbtöne"
            val tokens = progression.text.toString().split(Regex("[|\\s,;]+" )).filter { it.isNotBlank() }
            val shifted = tokens.map { transposeChord(it, semitones) }
            preview.text = if (tokens.isEmpty()) "Vorschau deiner Akkorde erscheint hier." else "${shifted.joinToString("   ·   ")}\n\nCapo ${capo.progress} · Anzeige-Transponierung ${semitones}"
        }
        box.addView(capoLabel); box.addView(capo, LinearLayout.LayoutParams(-1, a.dp(42)))
        box.addView(transposeLabel); box.addView(transpose, LinearLayout.LayoutParams(-1, a.dp(42)))
        box.addView(preview)
        progression.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { updatePreview() }
            override fun afterTextChanged(s: Editable?) {}
        })
        capo.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) = updatePreview()
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        transpose.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) = updatePreview()
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        updatePreview()
        section.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                val data = loadSection(sections[position])
                progression.setText(data.optString("chords", ""))
                capo.progress = data.optInt("capo", 0).coerceIn(0, 12)
                transpose.progress = (data.optInt("transpose", 0) + 6).coerceIn(0, 12)
                updatePreview()
            }
        }
        val save = a.button("Arrangement speichern")
        save.setOnClickListener {
            val sectionName = section.selectedItem?.toString() ?: "Strophe 1"
            val data = org.json.JSONObject().apply {
                put("section", sectionName)
                put("chords", progression.text.toString().trim())
                put("capo", capo.progress)
                put("transpose", transpose.progress - 6)
                put("updatedAt", System.currentTimeMillis())
            }
            prefs.edit().putString("${storageKey}_$sectionName", data.toString()).apply()
            Toast.makeText(a, "$sectionName gespeichert", Toast.LENGTH_SHORT).show()
        }
        box.addView(save, LinearLayout.LayoutParams(-1, a.dp(48)).apply { topMargin = a.dp(8) })
        card.addView(box)
        root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(18)) })
        return ScrollView(a).apply { addView(root) }
    }

    private fun transposeChord(token: String, semitones: Int): String {
        if (semitones == 0) return token
        val names = listOf("C", "C♯", "D", "D♯", "E", "F", "F♯", "G", "G♯", "A", "A♯", "B")
        val match = Regex("^([A-G])([#b]?)(.*)$").matchEntire(token) ?: return token
        val root = match.groupValues[1] + match.groupValues[2]
        val rawSuffix = match.groupValues[3]
        val suffixParts = rawSuffix.split("/", limit = 2)
        val suffix = if (suffixParts.size == 2) "/" + transposeChord(suffixParts[1], semitones) else rawSuffix
        val index = when (root) {
            "C" -> 0; "C#", "Db" -> 1; "D" -> 2; "D#", "Eb" -> 3
            "E", "Fb" -> 4; "F", "E#" -> 5; "F#", "Gb" -> 6
            "G" -> 7; "G#", "Ab" -> 8; "A" -> 9; "A#", "Bb" -> 10
            "B", "Cb" -> 11; else -> return token
        }
        val shifted = names[(index + semitones % 12 + 12) % 12]
        return shifted + suffix
    }
}
class LearnFragment : Fragment() {
    private var chordTraining: ChordTrainingPanel? = null
    private var rhythmTone: ToneGenerator? = null
    private var rhythmHandler: Handler? = null
    private var rhythmRunning = false
    private var rhythmBeat = 0
    private var rhythmBpm = 80
    override fun onDestroyView() { chordTraining?.stop(); chordTraining = null; stopRhythm(); super.onDestroyView() }

    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity; val prefs = a.getSharedPreferences("saitenwerk", 0)
        val root = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        root.addView(a.title("Lernstudio")); root.addView(a.body("Kurze, praktische Einheiten für Akkorde, Wechsel und Rhythmus. Dein Fortschritt wird auf diesem Gerät gespeichert."))
        val pathButton = a.button("◆  Deinen Lernpfad öffnen")
        pathButton.setOnClickListener { a.openSection(6) }
        root.addView(pathButton, LinearLayout.LayoutParams(-1, a.dp(48)).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(12)) })
        val summary = a.body("Akkord-Quiz: ${prefs.getInt("learn_quiz_correct", 0)} richtige Antworten · ${prefs.getInt("learn_quiz_total", 0)} Versuche").apply { setTextColor(a.getColor(R.color.sw_copper)) }; root.addView(summary)
        val tabs = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; setPadding(a.dp(8), 0, a.dp(8), a.dp(8)) }
        val content = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(14), a.dp(4), a.dp(14), a.dp(24)) }
        val scroll = ScrollView(a).apply { addView(content) }
        fun panel(heading: String, description: String): Pair<MaterialCardView, LinearLayout> {
            val card = a.card(); val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(16), a.dp(16), a.dp(16), a.dp(16)) }
            box.addView(TextView(a).apply { text = heading; textSize = 20f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_copper)) })
            box.addView(a.body(description, 14f)); card.addView(box); return card to box
        }
        fun showQuiz() {
            chordTraining?.stop(); chordTraining = null; stopRhythm(); content.removeAllViews()
            val (card, box) = panel("Akkord-Blitztrainer", "Erkenne Griffbilder und festige die wichtigsten offenen Akkorde.")
            box.addView(TextView(a).apply { text = "Welcher Akkord ist das?"; textSize = 18f; gravity = Gravity.CENTER; setTextColor(a.getColor(R.color.sw_text)) })
            val diagram = FrameLayout(a); box.addView(diagram, LinearLayout.LayoutParams(-1, a.dp(210)))
            val choices = GridLayout(a).apply { columnCount = 2 }; box.addView(choices)
            val feedback = TextView(a).apply { text = "Wähle den passenden Akkord."; gravity = Gravity.CENTER; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0, a.dp(10), 0, a.dp(8)) }; box.addView(feedback)
            val next = a.button("Nächster Akkord"); box.addView(next, LinearLayout.LayoutParams(-1, a.dp(46)))
            var answer = ""; var locked = false
            fun newQuestion() {
                val pool = ChordLibrary.all.filter { it.name in listOf("C", "G", "D", "A", "E", "F", "Am", "Em", "Dm") }
                val shape = pool.random(); answer = shape.name; locked = false; feedback.text = "Wähle den passenden Akkord."; feedback.setTextColor(a.getColor(R.color.sw_muted))
                diagram.removeAllViews(); diagram.addView(ChordDiagramView(a, shape), FrameLayout.LayoutParams(-1, -1)); choices.removeAllViews()
                val options = (listOf(answer) + pool.filter { it.name != answer }.shuffled().take(3).map { it.name }).shuffled()
                options.forEach { option ->
                    val b = a.button(option); b.setOnClickListener {
                        if (!locked) {
                            locked = true; val correct = option == answer; val total = prefs.getInt("learn_quiz_total", 0) + 1
                            val score = prefs.getInt("learn_quiz_correct", 0) + if (correct) 1 else 0
                            prefs.edit().putInt("learn_quiz_total", total).putInt("learn_quiz_correct", score).apply()
                            summary.text = "Akkord-Quiz: $score richtige Antworten · $total Versuche"
                            feedback.text = if (correct) "Richtig! $answer sauber erkannt." else "Noch nicht ganz – gesucht war $answer.\nSchau dir die Fingerpositionen an."
                            feedback.setTextColor(a.getColor(if (correct) R.color.sw_copper else R.color.sw_muted))
                            for (j in 0 until choices.childCount) choices.getChildAt(j).isEnabled = false
                        }
                    }
                    choices.addView(b, GridLayout.LayoutParams().apply { width = 0; height = a.dp(46); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(a.dp(3), a.dp(3), a.dp(3), a.dp(3)) })
                }
            }
            next.setOnClickListener { newQuestion() }; newQuestion(); content.addView(card)
        }
        fun showChanges() {
            stopRhythm(); content.removeAllViews(); content.addView(a.body("Wechsle C · G · Am · F im gleichmäßigen Puls. Starte langsam und steigere das Tempo erst, wenn jeder Griff sauber klingt."))
            chordTraining = ChordTrainingPanel(a); content.addView(chordTraining, LinearLayout.LayoutParams(-1, -2))
        }
        fun showRhythm() {
            chordTraining?.stop(); chordTraining = null; stopRhythm(); content.removeAllViews()
            val (card, box) = panel("Rhythmus & Timing", "Übe einen gleichmäßigen Viertelpuls. Der erste Schlag jedes Taktes wird stärker markiert.")
            val label = TextView(a).apply { text = "Tempo: 80 BPM"; textSize = 17f; setTextColor(a.getColor(R.color.sw_text)) }; box.addView(label)
            val slider = SeekBar(a).apply { max = 110; progress = 30 }; slider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(v: SeekBar?, p: Int, from: Boolean) { rhythmBpm = 50 + p; label.text = "Tempo: $rhythmBpm BPM" }
                override fun onStartTrackingTouch(v: SeekBar?) {}; override fun onStopTrackingTouch(v: SeekBar?) {}
            }); box.addView(slider)
            val beat = TextView(a).apply { text = "Bereit"; textSize = 32f; gravity = Gravity.CENTER; setTextColor(a.getColor(R.color.sw_copper)); setPadding(0, a.dp(12), 0, a.dp(12)) }; box.addView(beat, LinearLayout.LayoutParams(-1, a.dp(72)))
            val start = a.button("Metronom starten"); box.addView(start, LinearLayout.LayoutParams(-1, a.dp(48)))
            start.setOnClickListener {
                if (rhythmRunning) { stopRhythm(); start.text = "Metronom starten"; beat.text = "Pausiert" }
                else {
                    rhythmRunning = true; rhythmBeat = 0; rhythmTone = ToneGenerator(AudioManager.STREAM_MUSIC, 65); rhythmHandler = Handler(Looper.getMainLooper()); start.text = "Metronom stoppen"
                    val task = object : Runnable { override fun run() {
                        if (!rhythmRunning) return
                        val strong = rhythmBeat % 4 == 0; rhythmTone?.startTone(if (strong) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_BEEP, 70)
                        beat.text = if (strong) "1 · TAKT" else "${rhythmBeat % 4 + 1}"; rhythmBeat++
                        rhythmHandler?.postDelayed(this, (60000L / rhythmBpm).coerceAtLeast(100L))
                    } }
                    rhythmHandler?.post(task)
                }
            }
            content.addView(card)
        }
        fun showRoutine() {
            chordTraining?.stop(); chordTraining = null; stopRhythm(); content.removeAllViews()
            val (card, box) = panel("Deine tägliche 10-Minuten-Routine", "Hake die Einheiten ab, wenn du sie erledigt hast. Der Tagesstand wird lokal gespeichert.")
            val day = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.GERMANY).format(java.util.Date())
            if (prefs.getString("learn_routine_day", "") != day) prefs.edit().putString("learn_routine_day", day).putInt("learn_routine_done", 0).apply()
            val tasks = listOf("2 Min. Akkordgriffe sauber aufsetzen", "3 Min. Wechsel C – G – Am – F", "3 Min. Rhythmus mit Metronom", "2 Min. Lieblingssong spielen")
            val progressLabel = TextView(a).apply { setTextColor(a.getColor(R.color.sw_text)) }; box.addView(progressLabel)
            val progress = ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply { max = tasks.size }; box.addView(progress, LinearLayout.LayoutParams(-1, a.dp(10)))
            fun update(mask: Int) { val n = Integer.bitCount(mask); progress.progress = n; progressLabel.text = "Heute erledigt: $n von ${tasks.size}" }
            tasks.forEachIndexed { index, task ->
                val cb = CheckBox(a).apply { text = task; setTextColor(a.getColor(R.color.sw_text)); isChecked = (prefs.getInt("learn_routine_done", 0) and (1 shl index)) != 0 }
                cb.setOnCheckedChangeListener { _, checked ->
                    var mask = prefs.getInt("learn_routine_done", 0); mask = if (checked) mask or (1 shl index) else mask and (1 shl index).inv()
                    prefs.edit().putInt("learn_routine_done", mask).apply(); update(mask)
                }; box.addView(cb)
            }
            update(prefs.getInt("learn_routine_done", 0)); content.addView(card)
        }
        val modes = listOf("Blitztrainer", "Wechsel", "Rhythmus", "Routine")
        val actions = listOf({ showQuiz() }, { showChanges() }, { showRhythm() }, { showRoutine() })
        modes.forEachIndexed { index, label -> val b = a.button(label); b.textSize = 11f; b.setOnClickListener { actions[index]() }; tabs.addView(b, LinearLayout.LayoutParams(0, a.dp(44), 1f).apply { setMargins(a.dp(2), 0, a.dp(2), 0) }) }
        root.addView(tabs); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f)); showQuiz(); return root
    }
    private fun stopRhythm() {
        rhythmRunning = false; rhythmHandler?.removeCallbacksAndMessages(null); rhythmHandler = null
        try { rhythmTone?.stopTone(); rhythmTone?.release() } catch (_: Exception) { }; rhythmTone = null
    }
}

class PathFragment : Fragment() {
    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity; val prefs = a.getSharedPreferences("saitenwerk", 0)
        val root = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        root.addView(a.title("Dein Lernpfad")); root.addView(a.body("Vom ersten Griff bis zum selbstständigen Spielen ganzer Songs. Du bestimmst dein Tempo – dein Fortschritt bleibt auf diesem Gerät gespeichert."))
        val stages = listOf(
            "Erste Akkorde" to "Lerne C, G, D, A, E sowie Am und Em kennen. Ziel: jeden Griff ruhig und einzeln aufsetzen.",
            "Saubere Griffbilder" to "Achte auf gekrümmte Finger, kurze Fingernägel und darauf, dass jede Saite klar klingt.",
            "Flüssige Wechsel" to "Verbinde zwei Akkorde zunächst langsam. Steigere das Tempo erst, wenn der Wechsel sicher sitzt.",
            "Rhythmus festigen" to "Halte einen gleichmäßigen Viertelpuls und übe den Wechsel ohne den Schlagfluss zu unterbrechen.",
            "Erste Songs begleiten" to "Wähle ein einfaches Lied und spiele die Akkordfolge langsam im passenden Takt.",
            "Selbstständig spielen" to "Spiele einen Song vom Anfang bis zum Ende und finde bei Bedarf selbst zurück in den Ablauf."
        )
        val key = "learning_path_done"
        val progressLabel = TextView(a).apply { setTextColor(a.getColor(R.color.sw_copper)); textSize = 17f; setPadding(a.dp(20), a.dp(8), a.dp(20), a.dp(8)) }
        val progress = ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply { max = stages.size }
        root.addView(progressLabel); root.addView(progress, LinearLayout.LayoutParams(-1, a.dp(10)).apply { setMargins(a.dp(20), 0, a.dp(20), a.dp(14)) })
        fun refresh() { val mask = prefs.getInt(key, 0); val count = Integer.bitCount(mask); progress.progress = count; progressLabel.text = "$count von ${stages.size} Lernstufen abgeschlossen · ${count * 100 / stages.size}%" }
        val goalCard = a.card(); val goalBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(16), a.dp(14), a.dp(16), a.dp(14)) }
        goalBox.addView(TextView(a).apply { text = "Mein persönliches Lernziel"; textSize = 19f; setTextColor(a.getColor(R.color.sw_copper)); setTypeface(typeface, 1) })
        val goal = EditText(a).apply { setText(prefs.getString("learning_path_goal", "")); hint = "z. B. In vier Wochen drei Songs begleiten"; setTextColor(a.getColor(R.color.sw_text)); setHintTextColor(a.getColor(R.color.sw_muted)); minLines = 2 }
        goalBox.addView(goal)
        val save = a.button("Lernziel speichern"); save.setOnClickListener { prefs.edit().putString("learning_path_goal", goal.text.toString().trim()).apply(); Toast.makeText(a, "Lernziel gespeichert", Toast.LENGTH_SHORT).show() }
        goalBox.addView(save); goalCard.addView(goalBox); root.addView(goalCard, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(14)) })
        val next = a.body("").apply { textSize = 16f; setTextColor(a.getColor(R.color.sw_text)) }; root.addView(next)
        val checks = mutableListOf<CheckBox>()
        stages.forEachIndexed { index, stage ->
            val card = a.card(); val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(14), a.dp(12), a.dp(14), a.dp(12)) }
            box.addView(TextView(a).apply { text = "${index + 1}. ${stage.first}"; textSize = 18f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_text)) })
            box.addView(a.body(stage.second, 14f))
            val check = CheckBox(a).apply { text = "Lernstufe abgeschlossen"; setTextColor(a.getColor(R.color.sw_text)); isChecked = (prefs.getInt(key, 0) and (1 shl index)) != 0 }; checks.add(check)
            check.setOnCheckedChangeListener { _, checked ->
                var mask = prefs.getInt(key, 0); mask = if (checked) mask or (1 shl index) else mask and (1 shl index).inv(); prefs.edit().putInt(key, mask).apply(); refresh()
                val first = stages.indices.firstOrNull { (mask and (1 shl it)) == 0 }; next.text = if (first == null) "Geschafft! Alle Lernstufen sind abgeschlossen." else "Dein nächster Schritt: ${stages[first].first}"
            }
            box.addView(check); val practice = a.button("Im Lernstudio üben"); practice.setOnClickListener { a.openSection(5) }; box.addView(practice)
            card.addView(box); root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(16), a.dp(5), a.dp(16), a.dp(5)) })
        }
        val reset = a.button("Lernpfad zurücksetzen"); reset.setOnClickListener { prefs.edit().putInt(key, 0).apply(); checks.forEach { it.isChecked = false }; refresh(); next.text = "Dein nächster Schritt: ${stages.first().first}"; Toast.makeText(a, "Lernpfad zurückgesetzt", Toast.LENGTH_SHORT).show() }
        root.addView(reset, LinearLayout.LayoutParams(-1, a.dp(48)).apply { setMargins(a.dp(16), a.dp(12), a.dp(16), a.dp(24)) })
        refresh(); val mask = prefs.getInt(key, 0); val first = stages.indices.firstOrNull { (mask and (1 shl it)) == 0 }; next.text = if (first == null) "Geschafft! Alle Lernstufen sind abgeschlossen." else "Dein nächster Schritt: ${stages[first].first}"
        return ScrollView(a).apply { addView(root) }
    }
}
