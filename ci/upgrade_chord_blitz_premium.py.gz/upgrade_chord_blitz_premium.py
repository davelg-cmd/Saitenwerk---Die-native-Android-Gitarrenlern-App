from pathlib import Path
import os

root = Path(os.environ.get('PROJECT_DIR', '/mnt/data/sw490'))
path = root / 'app/src/main/java/de/saitenwerk/app/MainActivity.kt'
s = path.read_text(encoding='utf-8')

# Expand the existing single source of truth; preserve all existing entries and names.
anchor = '        ChordShape("A5", "Power-Akkord", intArrayOf(-1,0,2,2,-1,-1), note="Powerchord", fingers=intArrayOf(0,0,1,3,0,0))\n'
if anchor not in s:
    raise SystemExit('FEHLER: Akkorddatenbank-Endanker nicht gefunden.')
additions = '''        ChordShape("A5", "Power-Akkord", intArrayOf(-1,0,2,2,-1,-1), note="Powerchord", fingers=intArrayOf(0,0,1,3,0,0)),
        // Ergänzte, spielbare Standard- und Barrévarianten – Teil derselben ChordLibrary.
        ChordShape("F#", "Dur", intArrayOf(2,4,4,3,2,2), 2, note="Fis-Dur-Barrégriff", fingers=intArrayOf(1,3,4,2,1,1)),
        ChordShape("C#", "Dur", intArrayOf(-1,4,6,6,6,4), 4, note="Cis-Dur-Barrégriff", fingers=intArrayOf(0,1,3,4,4,1)),
        ChordShape("G#", "Dur", intArrayOf(4,6,6,5,4,4), 4, note="Gis-Dur-Barrégriff", fingers=intArrayOf(1,3,4,2,1,1)),
        ChordShape("D#", "Dur", intArrayOf(-1,6,8,8,8,6), 6, note="Dis-Dur-Barrégriff", fingers=intArrayOf(0,1,3,4,4,1)),
        ChordShape("A#m", "Moll", intArrayOf(-1,1,3,3,2,1), note="Ais-Moll-Barrégriff", fingers=intArrayOf(0,1,3,4,2,1)),
        ChordShape("D#m", "Moll", intArrayOf(-1,6,8,8,7,6), 6, note="Dis-Moll-Barrégriff", fingers=intArrayOf(0,1,3,4,2,1)),
        ChordShape("G#m", "Moll", intArrayOf(4,6,6,4,4,4), 4, note="Gis-Moll-Barrégriff", fingers=intArrayOf(1,3,4,1,1,1)),
        ChordShape("Bm", "Moll", intArrayOf(-1,2,4,4,3,2), 2, note="H-Moll-Barrégriff (internationale Schreibweise)", fingers=intArrayOf(0,1,3,4,2,1)),
        ChordShape("F#m7", "Septakkord", intArrayOf(2,4,2,2,2,2), 2, note="Fis-Mollseptakkord", fingers=intArrayOf(1,3,1,1,1,1)),
        ChordShape("C#m7", "Septakkord", intArrayOf(-1,4,2,4,5,4), 2, note="Cis-Mollseptakkord", fingers=intArrayOf(0,2,1,3,4,2)),
        ChordShape("Bm7", "Septakkord", intArrayOf(-1,2,0,2,0,2), note="H-Mollseptakkord (internationale Schreibweise)", fingers=intArrayOf(0,2,0,3,0,4)),
        ChordShape("G#m7", "Septakkord", intArrayOf(4,6,4,4,4,4), 4, note="Gis-Mollseptakkord", fingers=intArrayOf(1,3,1,1,1,1)),
        ChordShape("A9", "Add-Akkord", intArrayOf(-1,0,2,4,2,3), note="Offener A-Add9-Klang", fingers=intArrayOf(0,0,1,3,2,4)),
        ChordShape("Eadd9", "Add-Akkord", intArrayOf(0,2,4,1,0,0), note="Offener E-Add9-Klang", fingers=intArrayOf(0,2,4,1,0,0)),
        ChordShape("Gadd9", "Add-Akkord", intArrayOf(3,0,0,0,0,3), note="Offener G-Add9-Klang", fingers=intArrayOf(2,0,0,0,0,3)),
        ChordShape("Fadd9", "Add-Akkord", intArrayOf(1,3,3,2,1,3), note="F-Add9-Barrévariante", fingers=intArrayOf(1,3,4,2,1,4)),
        ChordShape("F#7", "Septakkord", intArrayOf(2,4,2,3,2,2), 2, note="Fis-Dominantseptakkord", fingers=intArrayOf(1,3,1,2,1,1)),
        ChordShape("C#7", "Septakkord", intArrayOf(-1,4,3,4,2,-1), note="Cis-Dominantseptakkord", fingers=intArrayOf(0,3,2,4,1,0)),
        ChordShape("G#7", "Septakkord", intArrayOf(4,6,4,5,4,4), 4, note="Gis-Dominantseptakkord", fingers=intArrayOf(1,3,1,2,1,1)),
        ChordShape("D#7", "Septakkord", intArrayOf(-1,6,5,6,4,-1), 4, note="Dis-Dominantseptakkord", fingers=intArrayOf(0,3,2,4,1,0)),
        ChordShape("E7sus4", "Sus-Akkord", intArrayOf(0,2,0,2,0,0), note="Offener E7sus4-Klang", fingers=intArrayOf(0,1,0,2,0,0)),
        ChordShape("A7sus4", "Sus-Akkord", intArrayOf(-1,0,2,0,3,0), note="Offener A7sus4-Klang", fingers=intArrayOf(0,0,1,0,3,0)),
        ChordShape("C6", "Weitere Akkorde", intArrayOf(-1,3,2,2,1,0), note="C-Dur mit hinzugefügter Sexte", fingers=intArrayOf(0,3,2,4,1,0)),
        ChordShape("Am6", "Weitere Akkorde", intArrayOf(-1,0,2,2,1,2), note="A-Moll mit hinzugefügter Sexte", fingers=intArrayOf(0,0,2,3,1,4)),
        ChordShape("Eaug", "Weitere Akkorde", intArrayOf(0,3,2,1,1,0), note="E-übermäßiger Akkord", fingers=intArrayOf(0,3,2,1,1,0)),
        ChordShape("Edim7", "Vermindert", intArrayOf(0,1,2,0,2,0), note="E-verminderter Septakkord", fingers=intArrayOf(0,1,2,0,3,0))
'''
s = s.replace(anchor, additions, 1)

# Keep the one-shot blitz timer tied to the fragment lifecycle.
s = s.replace('    private var quizStartedAt = 0L\n', '    private var quizStartedAt = 0L\n    private var quizCountdownHandler: Handler? = null\n', 1)

# Replace only the existing Akkord-Blitztrainer implementation.
start = s.find('        fun showQuiz() {')
end = s.find('\n\n        fun showRhythm() {', start)
if start < 0 or end < 0:
    raise SystemExit('FEHLER: showQuiz()-Bereich nicht eindeutig gefunden.')
quiz = r'''        fun showQuiz() {
            finishQuizSession(); stopRhythm(); stopStrumming(); content.removeAllViews()
            quizStartedAt = android.os.SystemClock.elapsedRealtime()
            val (card, box) = panel("Akkord-Blitztrainer", "Trainiere Akkorderkennung mit der vollständigen Akkordbibliothek. Das System merkt sich deine Fehler und gewichtet unsichere Griffe stärker.")

            var mode = prefs.getString("learn_chord_quiz_mode", "recognize") ?: "recognize"
            var category = prefs.getString("learn_chord_quiz_category", "Alle") ?: "Alle"
            var currentShape: ChordShape? = null
            var locked = false
            var localStreak = 0
            var answered = 0
            var localCorrect = 0
            var questionStartedAt = android.os.SystemClock.elapsedRealtime()
            var remainingSeconds = 60
            var roundFinished = false
            var currentOptions: List<ChordShape> = emptyList()
            val quizHandler = Handler(Looper.getMainLooper())
            quizCountdownHandler = quizHandler
            var timerTask: Runnable? = null

            val modeNames = linkedMapOf(
                "recognize" to "Griffbild erkennen",
                "reverse" to "Griff zuordnen",
                "blitz" to "Blitzrunde · 60 Sek.",
                "mistakes" to "Fehlertraining"
            )
            val header = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val modeButton = a.button("Modus · " + (modeNames[mode] ?: modeNames["recognize"]))
            val categoryButton = a.button("Kategorie · $category")
            header.addView(modeButton, LinearLayout.LayoutParams(0, a.dp(44), 1f))
            header.addView(categoryButton, LinearLayout.LayoutParams(0, a.dp(44), 1f).apply { leftMargin = a.dp(6) })
            box.addView(header)

            val statsRow = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val score = TextView(a).apply { textSize = 12f; setTextColor(a.getColor(R.color.sw_muted)) }
            val streak = TextView(a).apply { textSize = 12f; setTextColor(a.getColor(R.color.sw_copper)); gravity = Gravity.END }
            statsRow.addView(score, LinearLayout.LayoutParams(0, a.dp(34), 1f))
            statsRow.addView(streak, LinearLayout.LayoutParams(0, a.dp(34), 1f))
            box.addView(statsRow)
            val timerLabel = TextView(a).apply { textSize = 13f; setTextColor(a.getColor(R.color.sw_copper)); gravity = Gravity.CENTER; text = if (mode == "blitz") "01:00" else "Ohne Zeitlimit" }
            box.addView(timerLabel, LinearLayout.LayoutParams(-1, a.dp(26)))
            val progress = ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100; progress = 0
                progressTintList = android.content.res.ColorStateList.valueOf(a.getColor(R.color.sw_copper))
            }
            box.addView(progress, LinearLayout.LayoutParams(-1, a.dp(5)))
            val prompt = TextView(a).apply {
                textSize = 17f; setTypeface(typeface, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER; setTextColor(a.getColor(R.color.sw_text)); setPadding(0, a.dp(12), 0, a.dp(4))
            }
            box.addView(prompt, LinearLayout.LayoutParams(-1, a.dp(48)))
            val diagram = FrameLayout(a)
            box.addView(diagram, LinearLayout.LayoutParams(-1, a.dp(210)))
            val choices = GridLayout(a).apply { columnCount = 2; useDefaultMargins = false }
            box.addView(choices, LinearLayout.LayoutParams(-1, -2))
            val feedback = TextView(a).apply {
                text = "Wähle die passende Antwort."; textSize = 13f; gravity = Gravity.CENTER
                setTextColor(a.getColor(R.color.sw_muted)); setPadding(a.dp(4), a.dp(10), a.dp(4), a.dp(8))
            }
            box.addView(feedback, LinearLayout.LayoutParams(-1, -2))
            val actions = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
            val next = a.button("Nächste Frage")
            val finish = a.button("Beenden")
            actions.addView(next, LinearLayout.LayoutParams(0, a.dp(46), 1f))
            actions.addView(finish, LinearLayout.LayoutParams(0, a.dp(46), 1f).apply { leftMargin = a.dp(6) })
            box.addView(actions)

            fun keyFor(name: String) = name.replace(Regex("[^A-Za-z0-9]"), "_")
            fun updateHeader() {
                val total = prefs.getInt("learn_quiz_total", 0)
                val correct = prefs.getInt("learn_quiz_correct", 0)
                val rate = if (total > 0) correct * 100 / total else 0
                score.text = "Gesamt $correct/$total · $rate%"
                streak.text = "Serie $localStreak · Runde $localCorrect/$answered"
                progress.progress = if (mode == "blitz") ((60 - remainingSeconds).coerceIn(0, 60) * 100 / 60) else (answered % 10) * 10
            }
            fun stopTimer() {
                timerTask?.let { quizHandler.removeCallbacks(it) }
                timerTask = null
            }
            fun finishRound() {
                if (roundFinished) return
                roundFinished = true
                locked = true
                stopTimer()
                for (j in 0 until choices.childCount) choices.getChildAt(j).isEnabled = false
                val accuracy = if (answered > 0) localCorrect * 100 / answered else 0
                prompt.text = "Runde abgeschlossen"
                diagram.removeAllViews()
                feedback.text = "$localCorrect von $answered richtig · $accuracy% Treffer · beste Serie ${prefs.getInt("learn_best_quiz_streak", 0)}. Unsichere Akkorde wurden für dein Fehlertraining gespeichert."
                feedback.setTextColor(a.getColor(R.color.sw_copper))
                next.text = "Neue Runde starten"
                updateHeader()
            }
            fun eligiblePool(): List<ChordShape> {
                val all = ChordLibrary.all
                    .filterNot { it.name == "Bb" } // Deutsches B ist der eindeutige Bibliotheksname für B-flat.
                    .distinctBy { it.name }
                val byCategory = if (category == "Alle") all else all.filter { it.quality == category }
                val mistakes = prefs.getStringSet("learn_chord_quiz_errors", emptySet()) ?: emptySet()
                val byMistakes = if (mode == "mistakes") byCategory.filter { it.name in mistakes } else byCategory
                val usable = when {
                    mode == "mistakes" && byMistakes.size >= 4 -> byMistakes
                    mode == "mistakes" -> all
                    byCategory.size >= 4 -> byCategory
                    else -> all
                }
                return usable.distinctBy { it.frets.joinToString(",") + "@" + it.baseFret }
            }
            fun chooseAdaptive(pool: List<ChordShape>): ChordShape {
                val ranked = pool.map { shape ->
                    val key = keyFor(shape.name)
                    val attempts = prefs.getInt("learn_chord_q_attempts_$key", 0)
                    val hits = prefs.getInt("learn_chord_q_correct_$key", 0)
                    val accuracy = if (attempts == 0) 0.45 else hits.toDouble() / attempts
                    val errors = prefs.getStringSet("learn_chord_quiz_errors", emptySet()) ?: emptySet()
                    shape to (if (shape.name in errors) 3.0 else 1.0) + (1.0 - accuracy) * 3.0
                }
                val weighted = ranked.sortedByDescending { it.second }.take(maxOf(1, (ranked.size * 0.55).toInt()))
                return weighted.random().first
            }
            fun recordAnswer(shape: ChordShape, correctAnswer: Boolean, responseMs: Long) {
                val key = keyFor(shape.name)
                val attempts = prefs.getInt("learn_chord_q_attempts_$key", 0) + 1
                val hits = prefs.getInt("learn_chord_q_correct_$key", 0) + if (correctAnswer) 1 else 0
                val streakKey = "learn_chord_q_streak_$key"
                val chordStreak = if (correctAnswer) prefs.getInt(streakKey, 0) + 1 else 0
                val errors = (prefs.getStringSet("learn_chord_quiz_errors", emptySet()) ?: emptySet()).toMutableSet()
                if (correctAnswer && chordStreak >= 3) errors.remove(shape.name) else if (!correctAnswer) errors.add(shape.name)
                val oldFastest = prefs.getLong("learn_chord_q_fastest_ms", 0L)
                val fastest = if (correctAnswer && (oldFastest == 0L || responseMs < oldFastest)) responseMs else oldFastest
                val total = prefs.getInt("learn_quiz_total", 0) + 1
                val correct = prefs.getInt("learn_quiz_correct", 0) + if (correctAnswer) 1 else 0
                val best = maxOf(prefs.getInt("learn_best_quiz_streak", 0), localStreak)
                prefs.edit()
                    .putInt("learn_chord_q_attempts_$key", attempts)
                    .putInt("learn_chord_q_correct_$key", hits)
                    .putInt(streakKey, chordStreak)
                    .putStringSet("learn_chord_quiz_errors", errors)
                    .putLong("learn_chord_q_fastest_ms", fastest)
                    .putLong("learn_chord_q_response_total_ms", prefs.getLong("learn_chord_q_response_total_ms", 0L) + responseMs)
                    .putInt("learn_chord_q_response_count", prefs.getInt("learn_chord_q_response_count", 0) + 1)
                    .putInt("learn_quiz_total", total).putInt("learn_quiz_correct", correct)
                    .putInt("learn_best_quiz_streak", best)
                    .putInt("learn_xp", prefs.getInt("learn_xp", 0) + if (correctAnswer) 10 else 3)
                    .apply()
            }
            var answerQuestion: ((String) -> Unit)? = null
            fun showChoices(options: List<ChordShape>, correctShape: ChordShape) {
                choices.removeAllViews()
                if (mode == "reverse") {
                    options.forEach { option ->
                        val tile = FrameLayout(a).apply {
                            background = android.graphics.drawable.GradientDrawable().apply {
                                cornerRadius = a.dp(12).toFloat(); setColor(a.getColor(R.color.sw_surface2)); setStroke(a.dp(1), a.getColor(R.color.sw_outline))
                            }
                            isClickable = true; isFocusable = true
                            contentDescription = "Griffbild ${option.quality} auswählen"
                            setOnClickListener { answerQuestion?.invoke(option.name) }
                        }
                        tile.addView(ChordDiagramView(a, option), FrameLayout.LayoutParams(-1, -1))
                        choices.addView(tile, GridLayout.LayoutParams().apply {
                            width = 0; height = a.dp(142); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                            setMargins(a.dp(3), a.dp(3), a.dp(3), a.dp(3))
                        })
                    }
                } else {
                    options.forEach { option ->
                        val button = a.button(option.name)
                        button.setOnClickListener { answerQuestion?.invoke(option.name) }
                        choices.addView(button, GridLayout.LayoutParams().apply {
                            width = 0; height = a.dp(48); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                            setMargins(a.dp(3), a.dp(3), a.dp(3), a.dp(3))
                        })
                    }
                }
            }
            fun newQuestion() {
                if (roundFinished) return
                val pool = eligiblePool()
                if (pool.size < 4) {
                    feedback.text = "Für diese Kategorie sind noch nicht genügend unterschiedliche Griffbilder vorhanden. Wähle bitte eine andere Kategorie."
                    return
                }
                currentShape = chooseAdaptive(pool)
                val shape = currentShape ?: return
                currentOptions = (listOf(shape) + pool.filter { it.name != shape.name }.shuffled().take(3)).shuffled()
                locked = false
                questionStartedAt = android.os.SystemClock.elapsedRealtime()
                feedback.text = if (mode == "mistakes") "Gezielte Wiederholung · unsichere Akkorde kommen häufiger." else "Nimm dir einen Moment – Genauigkeit zählt."
                feedback.setTextColor(a.getColor(R.color.sw_muted))
                if (mode == "reverse") {
                    prompt.text = "Welches Griffbild gehört zu ${shape.name}?"
                    diagram.removeAllViews()
                    diagram.addView(TextView(a).apply {
                        text = shape.name; textSize = 42f; gravity = Gravity.CENTER
                        setTypeface(typeface, android.graphics.Typeface.BOLD); setTextColor(a.getColor(R.color.sw_copper))
                    }, FrameLayout.LayoutParams(-1, -1))
                } else {
                    prompt.text = "Welcher Akkord ist auf dem Griffbild zu sehen?"
                    diagram.removeAllViews()
                    diagram.addView(ChordDiagramView(a, shape), FrameLayout.LayoutParams(-1, -1))
                }
                showChoices(currentOptions, shape)
                updateHeader()
            }
            fun answer(optionName: String) {
                if (locked || roundFinished) return
                val shape = currentShape ?: return
                locked = true
                val correctAnswer = optionName == shape.name
                val responseMs = (android.os.SystemClock.elapsedRealtime() - questionStartedAt).coerceAtLeast(0L)
                answered++
                if (correctAnswer) { localCorrect++; localStreak++ } else localStreak = 0
                recordAnswer(shape, correctAnswer, responseMs)
                for (j in 0 until choices.childCount) choices.getChildAt(j).isEnabled = false
                val seconds = String.format(java.util.Locale.GERMANY, "%.1f", responseMs / 1000.0)
                feedback.text = if (correctAnswer) "Richtig · ${shape.name} · $seconds s · Serie $localStreak" else "Noch nicht · gesucht war ${shape.name}. Dieser Akkord wird gezielt wiederholt."
                feedback.setTextColor(a.getColor(if (correctAnswer) R.color.sw_copper else R.color.sw_muted))
                updateHeader(); updatePracticeStats()
            }
            answerQuestion = { selectedName -> answer(selectedName) }
            modeButton.setOnClickListener {
                val entries = modeNames.values.toTypedArray()
                val keys = modeNames.keys.toList()
                androidx.appcompat.app.AlertDialog.Builder(a).setTitle("Trainingsmodus")
                    .setItems(entries) { _, which ->
                        mode = keys[which]; prefs.edit().putString("learn_chord_quiz_mode", mode).apply()
                        modeButton.text = "Modus · " + modeNames[mode]
                        roundFinished = false; answered = 0; localCorrect = 0; localStreak = 0; remainingSeconds = 60
                        timerLabel.text = if (mode == "blitz") "01:00" else "Ohne Zeitlimit"
                        stopTimer(); newQuestion()
                        if (mode == "blitz") {
                            val deadline = android.os.SystemClock.elapsedRealtime() + 60000L
                            val task = object : Runnable {
                                override fun run() {
                                    val left = ((deadline - android.os.SystemClock.elapsedRealtime() + 999L) / 1000L).toInt()
                                    remainingSeconds = left.coerceAtLeast(0)
                                    timerLabel.text = String.format(java.util.Locale.GERMANY, "%02d:%02d", remainingSeconds / 60, remainingSeconds % 60)
                                    if (left <= 0) finishRound() else quizHandler.postDelayed(this, 200L)
                                }
                            }
                            timerTask = task; quizHandler.post(task)
                        }
                    }.show()
            }
            val categories = listOf("Alle") + ChordLibrary.all.groupBy { it.quality }
                .filterValues { shapes -> shapes.map { it.name }.distinct().size >= 4 }.keys.sorted()
            categoryButton.setOnClickListener {
                androidx.appcompat.app.AlertDialog.Builder(a).setTitle("Akkordfamilie")
                    .setSingleChoiceItems(categories.toTypedArray(), categories.indexOf(category).coerceAtLeast(0)) { dialog, which ->
                        category = categories[which]; prefs.edit().putString("learn_chord_quiz_category", category).apply()
                        categoryButton.text = "Kategorie · $category"
                        roundFinished = false; answered = 0; localCorrect = 0; localStreak = 0
                        newQuestion(); dialog.dismiss()
                    }.setNegativeButton("Abbrechen", null).show()
            }
            next.setOnClickListener {
                if (roundFinished) {
                    roundFinished = false; answered = 0; localCorrect = 0; localStreak = 0; remainingSeconds = 60
                    timerLabel.text = if (mode == "blitz") "01:00" else "Ohne Zeitlimit"
                    newQuestion()
                    if (mode == "blitz") {
                        val deadline = android.os.SystemClock.elapsedRealtime() + 60000L
                        val task = object : Runnable {
                            override fun run() {
                                val left = ((deadline - android.os.SystemClock.elapsedRealtime() + 999L) / 1000L).toInt()
                                remainingSeconds = left.coerceAtLeast(0)
                                timerLabel.text = String.format(java.util.Locale.GERMANY, "%02d:%02d", remainingSeconds / 60, remainingSeconds % 60)
                                if (left <= 0) finishRound() else quizHandler.postDelayed(this, 200L)
                            }
                        }
                        timerTask = task; quizHandler.post(task)
                    }
                } else newQuestion()
            }
            finish.setOnClickListener { stopTimer(); quizHandler.removeCallbacksAndMessages(null); finishQuizSession(); overviewAction?.invoke() }

            fun startBlitzTimer() {
                stopTimer()
                val deadline = android.os.SystemClock.elapsedRealtime() + 60000L
                val task = object : Runnable {
                    override fun run() {
                        val left = ((deadline - android.os.SystemClock.elapsedRealtime() + 999L) / 1000L).toInt()
                        remainingSeconds = left.coerceAtLeast(0)
                        timerLabel.text = String.format(java.util.Locale.GERMANY, "%02d:%02d", remainingSeconds / 60, remainingSeconds % 60)
                        if (left <= 0) finishRound() else quizHandler.postDelayed(this, 200L)
                    }
                }
                timerTask = task; quizHandler.post(task)
            }
            modeButton.text = "Modus · " + (modeNames[mode] ?: modeNames["recognize"])
            categoryButton.text = "Kategorie · $category"
            newQuestion()
            if (mode == "blitz") startBlitzTimer()
            content.addView(card)
        }'''
s = s[:start] + quiz + s[end:]

# Ensure the per-question countdown is cleaned up when the quiz view/session ends.
old = '''    private fun finishQuizSession() {
        val started = quizStartedAt
        quizStartedAt = 0L
        if (started > 0L) onSessionElapsed?.invoke(((android.os.SystemClock.elapsedRealtime() - started) / 1000L).toInt().coerceAtLeast(1))
    }'''
new = '''    private fun finishQuizSession() {
        quizCountdownHandler?.removeCallbacksAndMessages(null)
        quizCountdownHandler = null
        val started = quizStartedAt
        quizStartedAt = 0L
        if (started > 0L) onSessionElapsed?.invoke(((android.os.SystemClock.elapsedRealtime() - started) / 1000L).toInt().coerceAtLeast(1))
    }'''
if old not in s:
    raise SystemExit('FEHLER: finishQuizSession nicht gefunden.')
s = s.replace(old, new, 1)

# Include adaptive chord-recognition metrics in the existing complete learning reset,
# while preserving the selected mode and category as training preferences.
reset_anchor = '''                        .remove("learn_fretboard_best_score")
                        .apply()
                    Toast.makeText(a, "Gesamter Lernfortschritt wurde zurückgesetzt", Toast.LENGTH_SHORT).show()'''
reset_replacement = '''                        .remove("learn_fretboard_best_score")
                        .apply()
                    val chordQuizPrefs = a.getSharedPreferences("saitenwerk", 0)
                    val chordQuizReset = chordQuizPrefs.edit()
                    chordQuizPrefs.all.keys.filter { it.startsWith("learn_chord_q_") || it == "learn_chord_quiz_errors" }
                        .forEach { chordQuizReset.remove(it) }
                    chordQuizReset.apply()
                    Toast.makeText(a, "Gesamter Lernfortschritt wurde zurückgesetzt", Toast.LENGTH_SHORT).show()'''
if reset_anchor not in s:
    raise SystemExit('FEHLER: Lernfortschritt-Reset-Ende nicht gefunden.')
s = s.replace(reset_anchor, reset_replacement, 1)
s = s.replace(
    "Setze sämtliche gespeicherten Lernzeiten, Punkte, XP, Serien, Quizwerte und Lernpfad-Fortschritte auf diesem Gerät zurück.",
    "Setze sämtliche gespeicherten Lernzeiten, Punkte, XP, Serien, Quizwerte, Akkord-Erkennungsdaten und Lernpfad-Fortschritte auf diesem Gerät zurück.",
    1,
)
s = s.replace(
    "Quizpunkte, Bestwerte, geführte Sessions, Schlagmuster-, Rhythmus-, Griffbrett- und Akkordwechsel-Statistiken sowie abgeschlossene Lernstufen.",
    "Quizpunkte, Akkord-Blitztrainer-Fehlerlisten und Einzelakkord-Statistiken, Bestwerte, geführte Sessions, Schlagmuster-, Rhythmus-, Griffbrett- und Akkordwechsel-Statistiken sowie abgeschlossene Lernstufen.",
    1,
)

path.write_text(s, encoding='utf-8')

# Structural and data checks; the workflow repeats these against the actual build source.
source = path.read_text(encoding='utf-8')
required = [
    'fun showQuiz() {', 'Griffbild erkennen', 'Griff zuordnen', 'Blitzrunde · 60 Sek.', 'Fehlertraining',
    'learn_chord_quiz_errors', 'learn_chord_q_attempts_', 'learn_chord_q_correct_',
    'learn_chord_q_fastest_ms', 'ChordDiagramView(a, option)', 'ChordLibrary.all', 'quizCountdownHandler?.removeCallbacksAndMessages(null)', 'answerQuestion?.invoke(option.name)', 'chordQuizPrefs.all.keys.filter',
    'ChordShape("G#m", "Moll"', 'ChordShape("C#", "Dur"', 'ChordShape("Eadd9", "Add-Akkord"',
]
missing = [item for item in required if item not in source]
if missing:
    raise SystemExit('FEHLER: Premium-Blitztrainer unvollständig: ' + ', '.join(missing))
if source.count('fun showQuiz() {') != 1:
    raise SystemExit('FEHLER: showQuiz() ist nicht eindeutig.')
if 'pool.filter { it.name in listOf("C", "G", "D", "A", "E", "F", "Am", "Em", "Dm") }' in source:
    raise SystemExit('FEHLER: Alter auf neun Akkorde begrenzter Quiz-Pool ist noch vorhanden.')
import re
import collections
library_start = source.find('object ChordLibrary')
library_end = source.find('\n}', library_start)
if library_start < 0 or library_end < 0:
    raise SystemExit('FEHLER: Zentrale ChordLibrary nicht gefunden.')
library = source[library_start:library_end]
pattern = re.compile(r'ChordShape\("([^"]+)"\s*,\s*"([^"]+)"\s*,\s*intArrayOf\(([^)]*)\)(?:\s*,\s*(\d+))?.*?fingers=intArrayOf\(([^)]*)\)\)', re.S)
entries = list(pattern.finditer(library))
if len(entries) < 90:
    raise SystemExit(f'FEHLER: Akkorddatenbank unerwartet klein: {len(entries)} Griffbilder.')
names = [entry.group(1) for entry in entries]
if len(names) != len(set(names)):
    duplicates = [name for name, count in collections.Counter(names).items() if count > 1]
    raise SystemExit('FEHLER: Doppelte Akkordnamen: ' + ', '.join(duplicates))
for entry in entries:
    name = entry.group(1)
    frets = [int(value.strip()) for value in entry.group(3).split(',')]
    fingers = [int(value.strip()) for value in entry.group(5).split(',')]
    if len(frets) != 6 or len(fingers) != 6:
        raise SystemExit(f'FEHLER: {name} besitzt kein vollständiges Sechs-Saiten-Griffbild.')
    if any(fret < -1 or fret > 24 for fret in frets):
        raise SystemExit(f'FEHLER: {name} enthält eine ungültige Bundposition.')
    if any((fret <= 0 and finger != 0) or (fret > 0 and finger not in range(1, 5)) for fret, finger in zip(frets, fingers)):
        raise SystemExit(f'FEHLER: {name} besitzt inkonsistente Finger-/Bundangaben.')
if 'learn_chord_quiz_errors' not in source or 'learn_chord_q_attempts_' not in source:
    raise SystemExit('FEHLER: Adaptive Akkord-Fehlerstatistik fehlt.')
if 'chordQuizPrefs.all.keys.filter' not in source:
    raise SystemExit('FEHLER: Adaptive Akkordmetriken werden beim Lernfortschritt-Reset nicht gelöscht.')
print(f'AKKORD-BLITZTRAINER PREMIUM: PASS – 4 Modi, adaptive Wiederholung, persistente Fehlerliste, Reaktionszeit und Lifecycle-Cleanup.')
print(f'AKKORDDATENBANK: PASS – {len(entries)} eindeutige Griffbilder, jeweils sechs Saiten und konsistente Fingerpositionen.')
