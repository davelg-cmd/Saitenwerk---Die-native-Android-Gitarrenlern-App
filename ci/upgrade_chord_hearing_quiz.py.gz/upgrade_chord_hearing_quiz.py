from pathlib import Path
import os

root = Path(os.environ.get('PROJECT_DIR', '/tmp/saitenwerk498'))
main = root / 'app/src/main/java/de/saitenwerk/app/MainActivity.kt'
s = main.read_text(encoding='utf-8')
if '"listen" to "Hör-Quiz · Akkord erkennen"' in s:
    required_existing = [
        '"listenMistakes" to "Hör-Fehlertraining"',
        'GuitarAudioEngine.playChord(a, shape, downstroke = true, volume = 0.88f, replace = true)',
        'learn_chord_listen_attempts_$key',
        'learn_chord_listen_errors',
        'learn_chord_listen_best_streak',
        'statsKeys.forEach { editor.remove(it) }',
    ]
    missing_existing = [x for x in required_existing if x not in s]
    if missing_existing:
        raise SystemExit('FEHLER: Vorhandene Hör-Quiz-Integration ist unvollständig: ' + ', '.join(missing_existing))
    print('AKKORD-HÖR-QUIZ: PASS – bereits vollständig und idempotent integriert.')
    raise SystemExit(0)

def replace_once(old, new, label):
    global s
    count = s.count(old)
    if count == 0:
        if new in s:
            return
        raise SystemExit(f'FEHLER: Einfügeanker fehlt: {label}')
    if count != 1:
        raise SystemExit(f'FEHLER: Einfügeanker nicht eindeutig ({count}): {label}')
    s = s.replace(old, new, 1)

# Add two hearing-only modes. The error mode uses a separate listening error list.
replace_once('''                "mistakes" to "Fehlertraining"
            )''', '''                "mistakes" to "Fehlertraining",
                "listen" to "Hör-Quiz · Akkord erkennen",
                "listenMistakes" to "Hör-Fehlertraining"
            )''', 'Modusliste')

# Reuse the app's recorded steel-string samples and existing chord voicings.
replace_once('''            val diagram = FrameLayout(a)
            box.addView(diagram, LinearLayout.LayoutParams(-1, a.dp(210)))
            val choices = GridLayout(a).apply { columnCount = 2; useDefaultMargins = false }''', '''            val diagram = FrameLayout(a)
            box.addView(diagram, LinearLayout.LayoutParams(-1, a.dp(210)))
            val listenButton = a.button("Akkord erneut anhören").apply {
                visibility = if (mode == "listen" || mode == "listenMistakes") View.VISIBLE else View.GONE
                contentDescription = "Gitarrenakkord erneut abspielen"
            }
            box.addView(listenButton, LinearLayout.LayoutParams(-1, a.dp(46)).apply { bottomMargin = a.dp(6) })
            listenButton.setOnClickListener {
                currentShape?.let { GuitarAudioEngine.playChord(a, it, downstroke = true, volume = 0.88f, replace = true) }
            }
            val choices = GridLayout(a).apply { columnCount = 2; useDefaultMargins = false }''', 'Hörwiedergabe-Steuerung')

# Show separate listening statistics while retaining the shared learning-studio counters.
replace_once('''            fun updateHeader() {
                val total = prefs.getInt("learn_quiz_total", 0)
                val correct = prefs.getInt("learn_quiz_correct", 0)
                val rate = if (total > 0) correct * 100 / total else 0
                score.text = "Gesamt $correct/$total · $rate%"
                streak.text = "Serie $localStreak · Runde $localCorrect/$answered"
                progress.progress = if (mode == "blitz") ((60 - remainingSeconds).coerceIn(0, 60) * 100 / 60) else (answered % 10) * 10
            }''', '''            fun updateHeader() {
                val listening = mode == "listen" || mode == "listenMistakes"
                val total = prefs.getInt(if (listening) "learn_chord_listen_total" else "learn_quiz_total", 0)
                val correct = prefs.getInt(if (listening) "learn_chord_listen_correct" else "learn_quiz_correct", 0)
                val rate = if (total > 0) correct * 100 / total else 0
                score.text = (if (listening) "Hören " else "Gesamt ") + "$correct/$total · $rate%"
                val best = if (listening) prefs.getInt("learn_chord_listen_best_streak", 0) else prefs.getInt("learn_best_quiz_streak", 0)
                streak.text = "Serie $localStreak · Best $best · Runde $localCorrect/$answered"
                progress.progress = if (mode == "blitz") ((60 - remainingSeconds).coerceIn(0, 60) * 100 / 60) else (answered % 10) * 10
            }''', 'Modusabhängige Statistik')

# The hearing mode has independent weighting and an independent error list.
replace_once('''            fun eligiblePool(): List<ChordShape> {
                val all = ChordLibrary.all
                    .filterNot { it.name == "Bb" } // Deutsches B ist der eindeutige Bibliotheksname für B-flat.
                    .distinctBy { it.name }
                val byCategory = if (category == "Alle") all else all.filter { ChordLibrary.difficultyFor(it) == category }
                val mistakes = prefs.getStringSet("learn_chord_quiz_errors", emptySet()) ?: emptySet()
                val byMistakes = if (mode == "mistakes") byCategory.filter { it.name in mistakes } else byCategory
                // Fehlertraining bleibt innerhalb der gewählten Stufe.
                val usable = if (mode == "mistakes" && byMistakes.size >= 4) byMistakes else byCategory
                return usable.distinctBy { it.frets.joinToString(",") + "@" + it.baseFret }
            }
            fun chooseAdaptive(pool: List<ChordShape>): ChordShape {
                val ranked = pool.map { shape ->
                    val key = keyFor(shape.name)
                    val attempts = prefs.getInt("learn_chord_q_attempts_$key", 0)
                    val hits = prefs.getInt("learn_chord_q_correct_$key", 0)
                    val accuracy = if (attempts == 0) 0.45 else hits.toDouble() / attempts
                    val errors = prefs.getStringSet("learn_chord_quiz_errors", emptySet()) ?: emptySet()
                    shape to (if (shape.name in errors) 3.0 else 1.0) + (1.0 - accuracy) * 3.0
                }''', '''            fun eligiblePool(): List<ChordShape> {
                val all = ChordLibrary.all
                    .filterNot { it.name == "Bb" } // Deutsches B ist der eindeutige Bibliotheksname für B-flat.
                    .distinctBy { it.name }
                val byCategory = if (category == "Alle") all else all.filter { ChordLibrary.difficultyFor(it) == category }
                val listening = mode == "listen" || mode == "listenMistakes"
                val mistakeKey = if (listening) "learn_chord_listen_errors" else "learn_chord_quiz_errors"
                val mistakes = prefs.getStringSet(mistakeKey, emptySet()) ?: emptySet()
                val mistakeMode = mode == "mistakes" || mode == "listenMistakes"
                val byMistakes = if (mistakeMode) byCategory.filter { it.name in mistakes } else byCategory
                // Beide Fehlertrainings bleiben innerhalb der gewählten Stufe.
                val usable = if (mistakeMode && byMistakes.size >= 4) byMistakes else byCategory
                return usable.distinctBy { it.frets.joinToString(",") + "@" + it.baseFret }
            }
            fun chooseAdaptive(pool: List<ChordShape>): ChordShape {
                val listening = mode == "listen" || mode == "listenMistakes"
                val ranked = pool.map { shape ->
                    val key = keyFor(shape.name)
                    val attempts = prefs.getInt(if (listening) "learn_chord_listen_attempts_$key" else "learn_chord_q_attempts_$key", 0)
                    val hits = prefs.getInt(if (listening) "learn_chord_listen_correct_$key" else "learn_chord_q_correct_$key", 0)
                    val accuracy = if (attempts == 0) 0.45 else hits.toDouble() / attempts
                    val errorKey = if (listening) "learn_chord_listen_errors" else "learn_chord_quiz_errors"
                    val errors = prefs.getStringSet(errorKey, emptySet()) ?: emptySet()
                    shape to (if (shape.name in errors) 3.0 else 1.0) + (1.0 - accuracy) * 3.0
                }''', 'Adaptive Hör-Auswahl')

# Keep hearing attempts entirely separate from visual chord-identification statistics.
replace_once('''            var answerQuestion: ((String) -> Unit)? = null
            fun showChoices(options: List<ChordShape>, correctShape: ChordShape) {''', '''            fun recordListenAnswer(shape: ChordShape, correctAnswer: Boolean, responseMs: Long) {
                val key = keyFor(shape.name)
                val attempts = prefs.getInt("learn_chord_listen_attempts_$key", 0) + 1
                val hits = prefs.getInt("learn_chord_listen_correct_$key", 0) + if (correctAnswer) 1 else 0
                val streakKey = "learn_chord_listen_streak_$key"
                val chordStreak = if (correctAnswer) prefs.getInt(streakKey, 0) + 1 else 0
                val errors = (prefs.getStringSet("learn_chord_listen_errors", emptySet()) ?: emptySet()).toMutableSet()
                if (correctAnswer && chordStreak >= 3) errors.remove(shape.name) else if (!correctAnswer) errors.add(shape.name)
                val total = prefs.getInt("learn_chord_listen_total", 0) + 1
                val correct = prefs.getInt("learn_chord_listen_correct", 0) + if (correctAnswer) 1 else 0
                val best = maxOf(prefs.getInt("learn_chord_listen_best_streak", 0), localStreak)
                val oldFastest = prefs.getLong("learn_chord_listen_fastest_ms", 0L)
                val fastest = if (correctAnswer && (oldFastest == 0L || responseMs < oldFastest)) responseMs else oldFastest
                prefs.edit()
                    .putInt("learn_chord_listen_attempts_$key", attempts)
                    .putInt("learn_chord_listen_correct_$key", hits)
                    .putInt(streakKey, chordStreak)
                    .putStringSet("learn_chord_listen_errors", errors)
                    .putInt("learn_chord_listen_total", total)
                    .putInt("learn_chord_listen_correct", correct)
                    .putInt("learn_chord_listen_best_streak", best)
                    .putLong("learn_chord_listen_fastest_ms", fastest)
                    .putLong("learn_chord_listen_response_total_ms", prefs.getLong("learn_chord_listen_response_total_ms", 0L) + responseMs)
                    .putInt("learn_chord_listen_response_count", prefs.getInt("learn_chord_listen_response_count", 0) + 1)
                    .putInt("learn_quiz_total", prefs.getInt("learn_quiz_total", 0) + 1)
                    .putInt("learn_quiz_correct", prefs.getInt("learn_quiz_correct", 0) + if (correctAnswer) 1 else 0)
                    .putInt("learn_best_quiz_streak", maxOf(prefs.getInt("learn_best_quiz_streak", 0), localStreak))
                    .putInt("learn_xp", prefs.getInt("learn_xp", 0) + if (correctAnswer) 10 else 3)
                    .apply()
            }
            var answerQuestion: ((String) -> Unit)? = null
            fun showChoices(options: List<ChordShape>, correctShape: ChordShape) {''', 'Hör-Statistik und Fehlerliste')

# A listening question contains no visual chord clue; the real guitar chord is played automatically.
replace_once('''                if (mode == "reverse") {
                    prompt.text = "Welches Griffbild gehört zu ${shape.name}?"
                    diagram.removeAllViews()
                    diagram.addView(TextView(a).apply {
                        text = shape.name; textSize = 42f; gravity = Gravity.CENTER
                        setTypeface(typeface, android.graphics.Typeface.BOLD); setTextColor(a.getColor(R.color.sw_copper))
                    }, FrameLayout.LayoutParams(-1, -1))
                } else {
                    prompt.text = "Welcher Akkord ist auf dem Griffbild zu sehen?"
                    diagram.removeAllViews()
                    diagram.addView(ChordDiagramView(a, shape), FrameLayout.LayoutParams(-1, -1))
                }
                showChoices(currentOptions, shape)''', '''                val listening = mode == "listen" || mode == "listenMistakes"
                listenButton.visibility = if (listening) View.VISIBLE else View.GONE
                if (listening) {
                    prompt.text = "Welcher Akkord ist zu hören?"
                    diagram.removeAllViews()
                    diagram.addView(TextView(a).apply {
                        text = "HÖR GENAU HIN\\n\\nDer Gitarrenakkord wird abgespielt."
                        textSize = 16f; gravity = Gravity.CENTER
                        setLineSpacing(a.dp(3).toFloat(), 1f)
                        setTypeface(typeface, android.graphics.Typeface.BOLD)
                        setTextColor(a.getColor(R.color.sw_text))
                    }, FrameLayout.LayoutParams(-1, -1))
                    GuitarAudioEngine.playChord(a, shape, downstroke = true, volume = 0.88f, replace = true)
                } else if (mode == "reverse") {
                    GuitarAudioEngine.stopAll()
                    prompt.text = "Welches Griffbild gehört zu ${shape.name}?"
                    diagram.removeAllViews()
                    diagram.addView(TextView(a).apply {
                        text = shape.name; textSize = 42f; gravity = Gravity.CENTER
                        setTypeface(typeface, android.graphics.Typeface.BOLD); setTextColor(a.getColor(R.color.sw_copper))
                    }, FrameLayout.LayoutParams(-1, -1))
                } else {
                    GuitarAudioEngine.stopAll()
                    prompt.text = "Welcher Akkord ist auf dem Griffbild zu sehen?"
                    diagram.removeAllViews()
                    diagram.addView(ChordDiagramView(a, shape), FrameLayout.LayoutParams(-1, -1))
                }
                showChoices(currentOptions, shape)''', 'Hörfrage mit Gitarrenklang')

# Branch scoring based on mode, and stop playback after an answer.
replace_once('''                recordAnswer(shape, correctAnswer, responseMs)
                for (j in 0 until choices.childCount) choices.getChildAt(j).isEnabled = false''', '''                if (mode == "listen" || mode == "listenMistakes") recordListenAnswer(shape, correctAnswer, responseMs)
                else recordAnswer(shape, correctAnswer, responseMs)
                GuitarAudioEngine.stopAll()
                for (j in 0 until choices.childCount) choices.getChildAt(j).isEnabled = false''', 'Getrennte Hör-Auswertung')

# Update replay visibility immediately when changing modes.
replace_once('''                        modeButton.text = "Modus · " + modeNames[mode]
                        roundFinished = false; answered = 0; localCorrect = 0; localStreak = 0; remainingSeconds = 60''', '''                        modeButton.text = "Modus · " + modeNames[mode]
                        listenButton.visibility = if (mode == "listen" || mode == "listenMistakes") View.VISIBLE else View.GONE
                        roundFinished = false; answered = 0; localCorrect = 0; localStreak = 0; remainingSeconds = 60''', 'Moduswechsel und Hörbutton')

# Stop any currently playing sample when the user leaves the trainer.
replace_once('''            finish.setOnClickListener { stopTimer(); quizHandler.removeCallbacksAndMessages(null); finishQuizSession(); overviewAction?.invoke() }''', '''            finish.setOnClickListener { stopTimer(); quizHandler.removeCallbacksAndMessages(null); GuitarAudioEngine.stopAll(); finishQuizSession(); overviewAction?.invoke() }''', 'Audio-Cleanup beim Verlassen')

# Reset all per-chord visual and listening statistics, without removing mode/stage preferences.
replace_once('''                        .remove("learn_fretboard_best_streak")
                        .remove("learn_fretboard_best_score")
                        .apply()''', '''                        .remove("learn_fretboard_best_streak")
                        .remove("learn_fretboard_best_score")
                        .also { editor ->
                            val statsKeys = a.getSharedPreferences("saitenwerk", 0).all.keys.filter {
                                it.startsWith("learn_chord_q_") || it == "learn_chord_quiz_errors" || it.startsWith("learn_chord_listen_")
                            }
                            statsKeys.forEach { editor.remove(it) }
                        }
                        .apply()''', 'Lernfortschritt-Reset für Hör- und Griffstatistiken')

main.write_text(s, encoding='utf-8')

required = [
    '"listen" to "Hör-Quiz · Akkord erkennen"',
    '"listenMistakes" to "Hör-Fehlertraining"',
    'GuitarAudioEngine.playChord(a, shape, downstroke = true, volume = 0.88f, replace = true)',
    'learn_chord_listen_attempts_$key',
    'learn_chord_listen_correct_$key',
    'learn_chord_listen_errors',
    'learn_chord_listen_total',
    'learn_chord_listen_best_streak',
    'if (mode == "listen" || mode == "listenMistakes") recordListenAnswer',
    'statsKeys.forEach { editor.remove(it) }',
]
missing = [x for x in required if x not in s]
if missing:
    raise SystemExit('FEHLER: Hör-Quiz-Integration unvollständig: ' + ', '.join(missing))
if s.count('"listen" to "Hör-Quiz · Akkord erkennen"') != 1:
    raise SystemExit('FEHLER: Hör-Quiz-Modus wurde mehrfach integriert.')
print('AKKORD-HÖR-QUIZ: PASS')
print('Gitarren-Sample-Wiedergabe, Replay, Schwierigkeitsstufen, adaptive Auswahl, getrennte Hörstatistik/Fehlerliste, Hör-Fehlertraining und Lernreset geprüft.')
