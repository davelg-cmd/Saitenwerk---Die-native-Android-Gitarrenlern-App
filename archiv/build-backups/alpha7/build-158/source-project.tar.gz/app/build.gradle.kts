plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    signingConfigs {
        create("saitenwerkUpload") {
            storeFile = rootProject.file("saitenwerk-upload.jks")
            storePassword = System.getenv("SAITENWERK_KEYSTORE_PASSWORD")
            keyAlias = System.getenv("SAITENWERK_KEY_ALIAS")
            keyPassword = System.getenv("SAITENWERK_KEYSTORE_PASSWORD")
        }
    }
    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("saitenwerkUpload")
        }
    }

 namespace = "de.saitenwerk.app"; compileSdk = 35
    defaultConfig { applicationId = "de.saitenwerk.app"; minSdk = 26; targetSdk = 35; versionCode = 1158; versionName = "3.1.0-alpha7.158" }

compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-ktx:1.10.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.fragment:fragment-ktx:1.8.5")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("com.google.android.material:material:1.12.0")
}
