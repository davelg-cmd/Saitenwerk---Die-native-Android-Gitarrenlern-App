# Saitenwerk 4.0.0-beta1

Native Android-Gitarrenlern-App (Kotlin, offline-first).

## Liederbuch – Beta-Ausbau
- Durchsuchbare Songbibliothek mit Suche über Titel, Künstler und Genre.
- Genre-Filter sowie Sortierung nach Titel, Künstler oder Genre.
- Separate Ansichten für alle Songs, Favoriten, persönliche Setlist und zuletzt geöffnete Songs.
- Eigene Songs können direkt in der App angelegt und lokal gespeichert werden.
- Songdetail mit abschnittsweisem Arrangement-Editor (Intro, Strophen, Refrain, Bridge, Outro), Capo und Transponierung.
- Setlist und Favoriten werden lokal auf dem Gerät gespeichert.
- Die vorhandenen 500 Katalogeinträge bleiben erhalten. Eigene Songs werden zusätzlich gespeichert.

## Weitere vorhandene Bereiche
- Natives Stimmgerät
- Akkordbibliothek mit hochkantem Griffbild und Gitarrenklang-Vorschau
- Lernstudio mit Übungen
- Persönlicher Lernpfad mit Fortschritt und Lernziel

## Beta-Hinweis
Die Beta ist ein testbarer Entwicklungsstand, kein Versprechen auf Fehlerfreiheit. Die GitHub-Actions-Buildprüfung bestätigt die Kompilierung; die Laufzeitfunktionen müssen zusätzlich auf realen Android-Geräten getestet werden.

## Build
Android SDK 35, JDK 17, Gradle 8.10.2, Android Gradle Plugin 8.7.3, Kotlin 2.0.21.

```bash
gradle --no-daemon assembleDebug
```
