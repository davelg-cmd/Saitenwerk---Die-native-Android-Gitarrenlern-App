# Saitenwerk Native 3.1 – Alpha 7.3

Native Android guitar-learning app (Kotlin), based on the verified Alpha-6 source project.

## Alpha 7.3 additions
- Song-specific, locally saved chord arrangements, organized by section (Intro, verses, chorus, bridge, outro).
- Editable chord progressions with a live transposition preview (-6 to +6 semitones).
- Capo setting (0–12) stored with each arrangement.
- Existing 500-song title catalogue, favorites, tuner, chord library, chord-change training, learning studio and learning path retained.
- No copyrighted lyrics or unverified chord charts are fabricated; users enter or supply arrangements they have rights to use.

## Build
Open this folder in Android Studio or use the included GitHub Actions workflow. The Alpha-6 workflow has already built successfully, but this Alpha-7 source revision still requires its own CI build and device testing.

## Notes
- Arrangements are stored locally using Android SharedPreferences.
- Transposition preview changes chord names; capo is stored separately and does not silently rewrite the entered progression.
- Tuner and metronome behaviour should be tested on physical Android devices.


## Alpha 7.3.1
- Akkordgriffbilder in standardisierter Hochkantdarstellung.
- Neue Funktion „Akkord anhören“ mit synthetischer Saitenprobe für die gespeicherte Griffposition.
- Versionsnummer 3.1.1-alpha7.


## Alpha 7.4
Sanftere Akkordprobe mit längerer Einschwingzeit, geringerer Anschlagsenergie, weicherem Ausklingen und reduzierter Ausgangslautstärke.
