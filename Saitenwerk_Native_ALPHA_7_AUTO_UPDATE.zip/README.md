# Saitenwerk 3.1.0-alpha7

Native Android-Gitarrenlern-App (Kotlin, offline-first). Entwicklungsstand: **Alpha 7**.

## Bereiche
- Natives Stimmgerät mit Instrumentenauswahl und alternativen Gitarrenstimmungen
- Akkordbibliothek mit Griffbildern und Gitarrenklang-Vorschau
- Liederbuch mit Suche, Favoriten und Arrangement-Editor
- Lernstudio mit Übungen
- Persönlicher Lernpfad mit Fortschritt und Lernziel

## Alpha-7-Tuner
- Instrumente: Gitarre, Bass, Ukulele, Violine und chromatischer Modus
- Alternative Gitarrenstimmungen: Standard, Drop D, Drop C, Double Drop D, DADGAD, Nashville, Open E, Open G, CGCFCE, DGCGCD und GABDEG
- Zieltonfrequenzen werden passend zur gewählten Stimmung berechnet
- Referenzton-Schaltfläche im Display entfernt; die Saiten-Zielwahl bleibt erhalten

## Build
Android SDK 35, JDK 17, Gradle 8.10.2.

```bash
gradle --no-daemon assembleDebug
```

Dies ist weiterhin eine Alpha-Version. Der Build muss über GitHub Actions geprüft und die Tuner-Erkennung anschließend auf einem echten Android-Gerät getestet werden.

## Automatische Alpha-Updates

Beim App-Start fragt Saitenwerk den GitHub-Release `alpha-latest` ab. Eine höhere `versionCode` wird angeboten, das APK wird über Androids DownloadManager geladen und anschließend über den offiziellen Android-Installationsdialog installiert. Android verlangt dafür weiterhin die Zustimmung des Nutzers und ggf. einmalig die Freigabe „Aus dieser Quelle zulassen“.

Der GitHub-Actions-Workflow nummeriert Builds fortlaufend und aktualisiert den Release-Asset `saitenwerk-alpha7.apk`. Dafür benötigt der Workflow `contents: write`.
