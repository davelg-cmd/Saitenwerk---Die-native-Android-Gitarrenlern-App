package de.saitenwerk.app

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.appcompat.app.AlertDialog
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/** Checks the Alpha channel's GitHub release and offers an Android-approved APK install. */
class AppUpdateManager(private val activity: MainActivity) {
    private val prefs = activity.getSharedPreferences("saitenwerk_updates", Context.MODE_PRIVATE)
    private val executor = Executors.newSingleThreadExecutor()
    private var receiverRegistered = false

    fun checkOnLaunch() {
        executor.execute {
            try {
                val connection = (URL(RELEASE_API).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8000
                    readTimeout = 8000
                    setRequestProperty("Accept", "application/vnd.github+json")
                    setRequestProperty("User-Agent", "Saitenwerk-Android-App")
                }
                val release = connection.inputStream.bufferedReader().use { JSONObject(it.readText()) }
                connection.disconnect()
                val body = release.optString("body")
                val remoteCode = Regex("(?m)^versionCode=(\\d+)\\s*$").find(body)?.groupValues?.get(1)?.toLongOrNull() ?: return@execute
                val currentCode = installedVersionCode()
                if (remoteCode <= currentCode) return@execute
                val asset = release.optJSONArray("assets") ?: return@execute
                var apkUrl: String? = null
                for (i in 0 until asset.length()) {
                    val item = asset.optJSONObject(i) ?: continue
                    if (item.optString("name") == APK_NAME) { apkUrl = item.optString("browser_download_url"); break }
                }
                val url = apkUrl ?: return@execute
                val versionName = Regex("(?m)^versionName=(.+)$").find(body)?.groupValues?.get(1)?.trim().orEmpty()
                activity.runOnUiThread {
                    if (!activity.isFinishing && !activity.isDestroyed) {
                        AlertDialog.Builder(activity)
                            .setTitle("Saitenwerk-Update verfügbar")
                            .setMessage("Eine neue Version${if (versionName.isNotBlank()) " ($versionName)" else ""} ist verfügbar. Möchtest du sie jetzt herunterladen?")
                            .setNegativeButton("Später", null)
                            .setPositiveButton("Jetzt aktualisieren") { _, _ -> download(url) }
                            .show()
                    }
                }
            } catch (_: Exception) {
                // Offline or GitHub temporarily unavailable: keep the app usable without interruption.
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun installedVersionCode(): Long {
        val info = activity.packageManager.getPackageInfo(activity.packageName, 0)
        return if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
    }

    private fun download(url: String) {
        try {
            val request = DownloadManager.Request(Uri.parse(url))
                .setTitle("Saitenwerk wird aktualisiert")
                .setDescription("Neue Alpha-Version wird heruntergeladen")
                .setMimeType("application/vnd.android.package-archive")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalFilesDir(activity, Environment.DIRECTORY_DOWNLOADS, APK_NAME)
            val manager = activity.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val id = manager.enqueue(request)
            prefs.edit().putLong(KEY_DOWNLOAD_ID, id).apply()
            registerReceiver()
            AlertDialog.Builder(activity).setTitle("Download gestartet")
                .setMessage("Saitenwerk lädt das Update herunter. Nach Abschluss öffnet sich der Android-Installationsdialog.")
                .setPositiveButton("OK", null).show()
        } catch (_: Exception) {
            AlertDialog.Builder(activity).setMessage("Das Update konnte nicht gestartet werden. Bitte prüfe deine Internetverbindung.")
                .setPositiveButton("OK", null).show()
        }
    }

    @Suppress("DEPRECATION")
    private fun registerReceiver() {
        if (receiverRegistered) return
        val filter = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
        if (Build.VERSION.SDK_INT >= 33) activity.registerReceiver(downloadReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else activity.registerReceiver(downloadReceiver, filter)
        receiverRegistered = true
    }

    private val downloadReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val id = intent?.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L) ?: -1L
            if (id != prefs.getLong(KEY_DOWNLOAD_ID, -2L)) return
            completeDownloadIfReady(id)
        }
    }

    fun resumePendingInstall() {
        if (prefs.getString(KEY_PENDING_APK, null) != null) {
            installIfAllowed()
            return
        }
        val id = prefs.getLong(KEY_DOWNLOAD_ID, -1L)
        if (id >= 0L) {
            val manager = activity.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.query(DownloadManager.Query().setFilterById(id)).use { cursor ->
                if (cursor.moveToFirst() && cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) == DownloadManager.STATUS_SUCCESSFUL) {
                    completeDownloadIfReady(id)
                }
            }
        }
    }

    private fun completeDownloadIfReady(id: Long) {
        if (id != prefs.getLong(KEY_DOWNLOAD_ID, -2L)) return
        val file = File(activity.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), APK_NAME)
        if (file.exists() && file.length() > 0L) {
            prefs.edit().putString(KEY_PENDING_APK, file.absolutePath).apply()
            installIfAllowed()
        }
    }

    fun dispose() {
        if (receiverRegistered) {
            try { activity.unregisterReceiver(downloadReceiver) } catch (_: Exception) { }
            receiverRegistered = false
        }
        executor.shutdown()
    }

    private fun installIfAllowed() {
        val path = prefs.getString(KEY_PENDING_APK, null) ?: return
        val file = File(path)
        if (!file.exists()) { prefs.edit().remove(KEY_PENDING_APK).apply(); return }
        if (Build.VERSION.SDK_INT >= 26 && !activity.packageManager.canRequestPackageInstalls()) {
            AlertDialog.Builder(activity)
                .setTitle("Installation erlauben")
                .setMessage("Android benötigt einmalig die Erlaubnis, Updates für Saitenwerk zu installieren. Aktiviere „Aus dieser Quelle zulassen“ und kehre anschließend zu Saitenwerk zurück.")
                .setNegativeButton("Später", null)
                .setPositiveButton("Einstellungen öffnen") { _, _ ->
                    activity.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${activity.packageName}")))
                }.show()
            return
        }
        try {
            val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.fileprovider", file)
            val install = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            activity.startActivity(install)
            prefs.edit().remove(KEY_PENDING_APK).apply()
        } catch (_: Exception) {
            AlertDialog.Builder(activity).setMessage("Der Android-Installationsdialog konnte nicht geöffnet werden. Bitte versuche es erneut.")
                .setPositiveButton("OK", null).show()
        }
    }

    companion object {
        private const val RELEASE_API = "https://api.github.com/repos/davelg-cmd/Saitenwerk---Die-native-Android-Gitarrenlern-App/releases/tags/alpha-latest"
        private const val APK_NAME = "saitenwerk-alpha7.apk"
        private const val KEY_DOWNLOAD_ID = "download_id"
        private const val KEY_PENDING_APK = "pending_apk"
    }
}
