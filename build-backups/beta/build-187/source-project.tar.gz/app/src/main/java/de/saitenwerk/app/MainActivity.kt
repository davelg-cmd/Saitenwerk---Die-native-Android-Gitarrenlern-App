package de.saitenwerk.app

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.AudioAttributes
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.media.MediaPlayer
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.card.MaterialCardView
import org.json.JSONArray
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.exp
import kotlin.math.PI

class MainActivity : AppCompatActivity() {
    fun openSong(song: Song) {
        show(SongDetailFragment.newInstance(song))
    }

    private lateinit var appUpdateManager: AppUpdateManager
    private var bottomNav: BottomNavigationView? = null
    private var suppressNavSelection = false
    private var micGrantedAction: (() -> Unit)? = null
    private var contentFrameId: Int = View.NO_ID
    private val requestMic = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) micGrantedAction?.invoke()
        else Toast.makeText(this, "Für das Stimmgerät wird Mikrofonzugriff benötigt.", Toast.LENGTH_LONG).show()
        micGrantedAction = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = getColor(R.color.sw_navy)
        window.navigationBarColor = getColor(R.color.sw_navy)
        // Android 15/Edge-to-Edge: Inhalte sicher unterhalb der Statusleiste halten
        // und die untere Navigation oberhalb der System-Gestenleiste platzieren.
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(buildRoot())
        if (savedInstanceState == null) show(HomeFragment(), addToBackStack = false)
        setupBackNavigation()
        // Updates werden ausschließlich auf ausdrücklichen Wunsch in den Einstellungen geprüft.
        appUpdateManager = AppUpdateManager(this)
    }

    override fun onDestroy() {
        if (::appUpdateManager.isInitialized) appUpdateManager.dispose()
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        if (::appUpdateManager.isInitialized) appUpdateManager.resumePendingInstall()
    }

    private fun buildRoot(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.sw_navy))
        }
        val frame = FrameLayout(this).also { contentFrameId = View.generateViewId(); it.id = contentFrameId }
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = BottomNavigationView(this).apply {
            // Bewusst dunkler als der Inhaltsbereich: Die Navigation ist klar abgesetzt.
            setBackgroundColor(getColor(R.color.sw_nav_bar))
            elevation = dp(10).toFloat()
            setItemIconSize(dp(27))
            itemPaddingTop = dp(8)
            itemPaddingBottom = dp(8)
            labelVisibilityMode = BottomNavigationView.LABEL_VISIBILITY_LABELED
            setItemIconTintList(android.content.res.ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(getColor(R.color.sw_copper), getColor(R.color.sw_nav_icon))
            ))
            setItemTextColor(android.content.res.ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(getColor(R.color.sw_copper), getColor(R.color.sw_nav_text))
            ))
            setItemTextAppearanceInactive(R.style.SaitenwerkBottomNavLabel)
            setItemTextAppearanceActive(R.style.SaitenwerkBottomNavLabelActive)
            menu.add(0, 1, 0, "Start").setIcon(R.drawable.ic_nav_home)
            menu.add(0, 2, 1, "Stimmen").setIcon(R.drawable.ic_nav_tuner)
            menu.add(0, 3, 2, "Akkorde").setIcon(R.drawable.ic_nav_chords)
            menu.add(0, 5, 4, "Lernstudio").setIcon(R.drawable.ic_nav_learn)
            // BottomNavigationView unterstützt maximal fünf Einträge.
            // Den Lernpfad erreichen Nutzer über das Lernstudio und die Startseite.
            setOnItemSelectedListener { item ->
                if (suppressNavSelection) true else { openSection(item.itemId); true }
            }
        }
        bottomNav = nav
        root.addView(nav, LinearLayout.LayoutParams(-1, dp(84)))
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(0, bars.top, 0, bars.bottom)
            insets
        }
        ViewCompat.requestApplyInsets(root)
        return root
    }

    private fun show(fragment: Fragment, addToBackStack: Boolean = true) {
        val tx = supportFragmentManager.beginTransaction().replace(contentFrameId, fragment)
        if (addToBackStack) tx.addToBackStack(null)
        tx.commit()
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (supportFragmentManager.backStackEntryCount > 0) {
                    supportFragmentManager.popBackStack()
                    syncBottomNavigation()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    private fun syncBottomNavigation() {
        val id = when (supportFragmentManager.findFragmentById(contentFrameId)) {
            is HomeFragment -> 1
            is TunerFragment -> 2
            is ChordsFragment -> 3
            is LearnFragment -> 5
            is PathFragment -> 5
            else -> 0
        }
        if (id != 0 && bottomNav?.selectedItemId != id) {
            suppressNavSelection = true
            bottomNav?.selectedItemId = id
            suppressNavSelection = false
        }
    }

    fun openSection(id: Int) {
        val current = supportFragmentManager.findFragmentById(contentFrameId)
        val alreadyOpen = when (id) {
            1 -> current is HomeFragment
            2 -> current is TunerFragment
            3 -> current is ChordsFragment
            5 -> current is LearnFragment
            6 -> current is PathFragment
            else -> false
        }
        if (alreadyOpen) return
        when (id) {
            1 -> show(HomeFragment())
            2 -> show(TunerFragment())
            3 -> show(ChordsFragment())
            5 -> show(LearnFragment())
            6 -> show(PathFragment())
        }
    }

    fun openSettings() {
        show(SettingsFragment())
    }

    fun checkForUpdatesManually() {
        if (::appUpdateManager.isInitialized) appUpdateManager.checkForUpdates()
    }

    fun askMic(onGranted: () -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) onGranted()
        else { micGrantedAction = onGranted; requestMic.launch(Manifest.permission.RECORD_AUDIO) }
    }

    fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()
    fun title(value: String) = TextView(this).apply {
        text = value; setTextColor(getColor(R.color.sw_text)); textSize = 27f
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(dp(20), dp(22), dp(20), dp(12))
    }
    fun body(value: String, size: Float = 15f) = TextView(this).apply {
        text = value; textSize = size; setTextColor(getColor(R.color.sw_muted)); setPadding(dp(20), 0, dp(20), dp(12))
    }
    fun card(): MaterialCardView = MaterialCardView(this).apply {
        setCardBackgroundColor(getColor(R.color.sw_surface)); radius = dp(18).toFloat()
        strokeColor = getColor(R.color.sw_surface2); strokeWidth = dp(1)
    }
    fun button(value: String) = Button(this).apply {
        text = value
        isAllCaps = false
        setTextColor(getColor(R.color.sw_text))
        textSize = 15f
        minHeight = dp(48)
        minimumHeight = dp(48)
        stateListAnimator = null
        elevation = dp(2).toFloat()
        background = android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = dp(28).toFloat()
            setColor(getColor(R.color.sw_surface2))
            setStroke(dp(2), getColor(R.color.sw_copper))
        }
    }

    fun spinnerAdapter(values: List<String>): ArrayAdapter<String> = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, values) {
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = super.getView(position, convertView, parent) as TextView
            v.setTextColor(getColor(R.color.sw_text))
            v.textSize = 14f
            v.setPadding(dp(14), 0, dp(14), 0)
            v.gravity = Gravity.CENTER_VERTICAL
            v.background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = dp(24).toFloat()
                setColor(getColor(R.color.sw_surface2))
                setStroke(dp(1), getColor(R.color.sw_copper))
            }
            return v
        }
        override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = super.getDropDownView(position, convertView, parent) as TextView
            v.setTextColor(getColor(R.color.sw_text))
            v.textSize = 14f
            v.setPadding(dp(14), dp(10), dp(14), dp(10))
            v.setBackgroundColor(getColor(R.color.sw_surface))
            return v
        }
    }
}

class HomeFragment : Fragment() {
    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity
        val root = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, a.dp(10), 0, a.dp(12))
        }

        // Das vollständige Original-Markenbild enthält Logo, Urheberzeile und Claim bereits.
        // FIT_CENTER erhält alle Bildränder; nichts wird oben oder unten abgeschnitten.
        val logo = ImageView(a).apply {
            setImageResource(R.drawable.saitenwerk_original)
            contentDescription = "Saitenwerk – Von David Elger – Gitarre, Stimmen, Üben und Akkorde. Dein persönlicher Gitarrenbegleiter – stimmen, Akkorde lernen, Songs spielen und Schritt für Schritt besser werden."
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            setBackgroundColor(android.graphics.Color.TRANSPARENT)
        }
        root.addView(logo, LinearLayout.LayoutParams(-1, -2).apply {
            setMargins(a.dp(12), a.dp(8), a.dp(12), a.dp(8))
        })

        val entries = listOf("🎸  Stimmgerät" to 2, "◉  Akkorde lernen" to 3, "◆  Lernstudio" to 5, "↗  Lernpfad" to 6)
        entries.forEach { (label, section) ->
            val b = a.button(label).apply {
                textSize = 16f
                setTextColor(a.getColor(R.color.sw_text))
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                    cornerRadius = a.dp(28).toFloat()
                    setColor(a.getColor(R.color.sw_surface2))
                    setStroke(a.dp(2), a.getColor(R.color.sw_copper))
                }
                minHeight = a.dp(56)
                stateListAnimator = null
                elevation = a.dp(2).toFloat()
            }
            b.setOnClickListener { a.openSection(section) }
            root.addView(b, LinearLayout.LayoutParams(-1, a.dp(56)).apply {
                setMargins(a.dp(18), a.dp(5), a.dp(18), a.dp(5))
            })
        }

        val settingsButton = a.button("⚙  Einstellungen").apply {
            textSize = 13f
            minHeight = a.dp(38)
            setPadding(a.dp(14), 0, a.dp(14), 0)
            background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = a.dp(22).toFloat()
                setColor(a.getColor(R.color.sw_surface))
                setStroke(a.dp(1), a.getColor(R.color.sw_copper))
            }
            stateListAnimator = null
        }
        settingsButton.setOnClickListener { a.openSettings() }
        root.addView(settingsButton, LinearLayout.LayoutParams(-2, a.dp(38)).apply {
            gravity = Gravity.END
            setMargins(a.dp(18), 0, a.dp(18), a.dp(10))
        })

        return ScrollView(a).apply {
            clipToPadding = false
            isFillViewport = false
            addView(root)
        }
    }
}

class SettingsFragment : Fragment() {
    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity
        val content = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dp(18), a.dp(8), a.dp(18), a.dp(24))
        }
        content.addView(a.title("Einstellungen"))
        content.addView(a.body("Saitenwerk anpassen und verwalten."))

        val updates = a.card()
        val updateContent = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dp(18), a.dp(16), a.dp(18), a.dp(16))
        }
        updateContent.addView(TextView(a).apply {
            text = "App-Updates"
            textSize = 18f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(a.getColor(R.color.sw_text))
        })
        updateContent.addView(TextView(a).apply {
            text = "Suche manuell nach einer neueren Saitenwerk-Version auf GitHub."
            textSize = 14f
            setTextColor(a.getColor(R.color.sw_muted))
            setPadding(0, a.dp(6), 0, a.dp(14))
        })
        val checkButton = a.button("Nach Updates suchen").apply {
            textSize = 15f
            background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = a.dp(24).toFloat()
                setColor(a.getColor(R.color.sw_surface2))
                setStroke(a.dp(2), a.getColor(R.color.sw_copper))
            }
            stateListAnimator = null
        }
        checkButton.setOnClickListener { a.checkForUpdatesManually() }
        updateContent.addView(checkButton, LinearLayout.LayoutParams(-1, a.dp(50)))
        updates.addView(updateContent)
        content.addView(updates, LinearLayout.LayoutParams(-1, -2).apply {
            setMargins(0, a.dp(8), 0, a.dp(14))
        })

        val appInfo = a.packageManager.getPackageInfo(a.packageName, 0)
        val appVersionName = appInfo.versionName ?: "unbekannt"
        val appVersionCode = appInfo.versionCode
        val credits = a.card().apply {
            isClickable = true
            isFocusable = true
            setOnClickListener {
                val about = "Saitenwerk ist mehr als nur eine Gitarren-App – es ist ein Experiment.\n\n" +
                    "Die Idee hinter diesem Projekt war von Anfang an eine ganz bestimmte: Ich wollte zeigen, dass man keine Programmierkenntnisse oder jahrelange Erfahrung in der Softwareentwicklung benötigt, um eine eigene App auf die Beine zu stellen.\n\n" +
                    "Mit Neugier, Ausdauer und der Unterstützung künstlicher Intelligenz ist Saitenwerk entstanden – von der ersten Idee bis hin zu einer eigenständigen Android-App.\n\n" +
                    "Mir ging es dabei vor allem darum, zu zeigen, was heute möglich ist, wenn man bereit ist, neue Wege auszuprobieren und KI als Werkzeug zu nutzen. Nicht darum, zu beweisen, dass ich ein professioneller Entwickler bin, sondern dass die Einstiegshürden in die App-Entwicklung längst nicht mehr so hoch sind, wie viele vielleicht denken.\n\n" +
                    "Saitenwerk ist deshalb auch ein Beispiel dafür, wie aus einer Idee mithilfe von KI Schritt für Schritt etwas Greifbares werden kann.\n\n" +
                    "Man muss nicht alles können, um etwas Eigenes zu erschaffen. Man muss nur anfangen."
                val details = "Saitenwerk\nDie native Android-Gitarrenlern-App\n\n" +
                    "Version: $appVersionName\n" +
                    "Build: $appVersionCode\n" +
                    "Release-Kanal: Beta\n" +
                    "Paket-ID: " + a.packageName + "\\n" +
                    "Mindestversion: Android 8.0 (API 26)\n" +
                    "Plattform: Android\n\n" +
                    "Über das Projekt\n$about"
                androidx.appcompat.app.AlertDialog.Builder(a)
                    .setTitle("Über Saitenwerk")
                    .setMessage(details)
                    .setPositiveButton("Schließen", null)
                    .show()
            }
        }
        val creditsContent = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dp(18), a.dp(16), a.dp(18), a.dp(16))
        }
        creditsContent.addView(TextView(a).apply {
            text = "Über"
            textSize = 18f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(a.getColor(R.color.sw_text))
        })
        creditsContent.addView(TextView(a).apply {
            text = "Saitenwerk · Version $appVersionName · Build $appVersionCode · Beta\nApp-Informationen und Projektgeschichte anzeigen"
            textSize = 14f
            setTextColor(a.getColor(R.color.sw_muted))
            setPadding(0, a.dp(6), 0, 0)
        })
        credits.addView(creditsContent)
        content.addView(credits, LinearLayout.LayoutParams(-1, -2).apply {
            setMargins(0, a.dp(14), 0, 0)
        })

        return ScrollView(a).apply { addView(content) }
    }
}

class TunerFragment : Fragment() {
    @Volatile private var active = false
    private var recorder: AudioRecord? = null
    private var worker: Thread? = null
    private var noteView: TextView? = null
    private var hzView: TextView? = null
    private var centsView: TextView? = null
    private var targetView: TextView? = null
    private var statusView: TextView? = null
    private var gauge: TunerGaugeView? = null
    private var startButton: Button? = null
    private var instrumentSpinner: Spinner? = null
    private var alternativeSpinner: TextView? = null
    private var selectedAlternative = AlternativeTuning("Standard E", listOf("E2", "A2", "D3", "G3", "B3", "E4"))
    private var availableTunings = listOf(selectedAlternative)
    private var selectedMode = TuningMode.GUITAR
    private var referenceA4 = 440.0
    private var referenceLabel: TextView? = null
    private var referenceSeekReset: SeekBar? = null
    private var stringPanel: LinearLayout? = null
    private var referenceTrack: AudioTrack? = null

    private enum class TuningMode(val label: String) {
        GUITAR("Gitarre · Standard · E–A–D–G–B–E"),
        CHROMATIC("Chromatisch · alle Töne"),
        BASS("Bass · Standard · E–A–D–G"),
        UKULELE("Ukulele · C-Stimmung · G–C–E–A"),
        VIOLIN("Violine · Standard · G–D–A–E"),
        VIOLA("Bratsche · Standard · C–G–D–A"),
        CELLO("Cello · Standard · C–G–D–A")
    }

    private data class Target(val name: String, val hz: Double)

    private data class AlternativeTuning(val label: String, val notes: List<String>)
    private fun tuningsFor(mode: TuningMode): List<AlternativeTuning> = when (mode) {
        TuningMode.GUITAR -> listOf(
            AlternativeTuning("Standard E", listOf("E2","A2","D3","G3","B3","E4")),
            AlternativeTuning("Drop D", listOf("D2","A2","D3","G3","B3","E4")),
            AlternativeTuning("Drop C", listOf("C2","G2","C3","F3","A3","D4")),
            AlternativeTuning("Double Drop D", listOf("D2","A2","D3","G3","B3","D4")),
            AlternativeTuning("DADGAD", listOf("D2","A2","D3","G3","A3","D4")),
            AlternativeTuning("Nashville", listOf("E3","A3","D4","G4","B3","E4")),
            AlternativeTuning("Open E", listOf("E2","B2","E3","G#3","B3","E4")),
            AlternativeTuning("Open G", listOf("D2","G2","D3","G3","B3","D4")),
            AlternativeTuning("Nick Drake · CGCFCE", listOf("C2","G2","C3","F3","C4","E4")),
            AlternativeTuning("Rain Song · DGCGCD", listOf("D2","G2","C3","G3","C4","D4"))
        )
        TuningMode.BASS -> listOf(
            AlternativeTuning("4-Saiter · E–A–D–G", listOf("E1","A1","D2","G2")),
            AlternativeTuning("4-Saiter · Drop D", listOf("D1","A1","D2","G2")),
            AlternativeTuning("4-Saiter · Drop C", listOf("C1","G1","C2","F2")),
            AlternativeTuning("5-Saiter · B–E–A–D–G", listOf("B0","E1","A1","D2","G2")),
            AlternativeTuning("6-Saiter · B–E–A–D–G–C", listOf("B0","E1","A1","D2","G2","C3"))
        )
        TuningMode.UKULELE -> listOf(
            AlternativeTuning("C-Stimmung · High G", listOf("G4","C4","E4","A4")),
            AlternativeTuning("C-Stimmung · Low G", listOf("G3","C4","E4","A4")),
            AlternativeTuning("D-Stimmung · A–D–F#–B", listOf("A4","D4","F#4","B4")),
            AlternativeTuning("Bariton · D–G–B–E", listOf("D3","G3","B3","E4"))
        )
        TuningMode.VIOLIN -> listOf(
            AlternativeTuning("Standard · G–D–A–E", listOf("G3","D4","A4","E5")),
            AlternativeTuning("Cross · A–E–A–E", listOf("A3","E4","A4","E5")),
            AlternativeTuning("GDGD", listOf("G3","D4","G4","D5"))
        )
        TuningMode.VIOLA -> listOf(
            AlternativeTuning("Standard · C–G–D–A", listOf("C3","G3","D4","A4")),
            AlternativeTuning("D-Stimmung · D–A–E–B", listOf("D3","A3","E4","B4"))
        )
        TuningMode.CELLO -> listOf(
            AlternativeTuning("Standard · C–G–D–A", listOf("C2","G2","D3","A3")),
            AlternativeTuning("D-Stimmung · D–A–D–A", listOf("D2","A2","D3","A3")),
            AlternativeTuning("Drop G · C–G–D–G", listOf("C2","G2","D3","G3"))
        )
        TuningMode.CHROMATIC -> emptyList()
    }

    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity
        val root = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        root.addView(a.title("Stimmgerät"))
        root.addView(a.body("Schnell und präzise stimmen · A4 = 440 Hz"))

        val selectorCard = a.card()
        val selector = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dp(16), a.dp(14), a.dp(16), a.dp(14))
        }
        selector.addView(TextView(a).apply {
            text = "Instrument & Stimmung"
            textSize = 13f
            setTextColor(a.getColor(R.color.sw_muted))
            setPadding(0, 0, 0, a.dp(6))
        })
        instrumentSpinner = Spinner(a).apply {
            val labels = TuningMode.values().map { it.label }
            adapter = object : ArrayAdapter<String>(a, android.R.layout.simple_spinner_item, labels) {
                private fun styled(position: Int, dropdown: Boolean): TextView = TextView(a).apply {
                    text = getItem(position).orEmpty()
                    setTextColor(a.getColor(R.color.sw_text))
                    textSize = if (dropdown) 14f else 15f
                    setTypeface(typeface, android.graphics.Typeface.BOLD)
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(a.dp(14), a.dp(if (dropdown) 12 else 10), a.dp(42), a.dp(if (dropdown) 12 else 10))
                    if (dropdown) {
                        setBackgroundColor(a.getColor(R.color.sw_surface))
                        minHeight = a.dp(48)
                    } else {
                        setBackground(android.graphics.drawable.GradientDrawable().apply {
                            setColor(a.getColor(R.color.sw_surface2))
                            cornerRadius = a.dp(12).toFloat()
                            setStroke(a.dp(1), a.getColor(R.color.sw_copper))
                        })
                        minHeight = a.dp(52)
                    }
                }
                override fun getView(position: Int, convertView: View?, parent: ViewGroup): View = styled(position, false)
                override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View = styled(position, true)
            }
            setSelection(TuningMode.values().indexOf(selectedMode))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) = Unit
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    selectedMode = TuningMode.values()[position]
                    configureAlternativeTunings()
                    targetView?.text = targetHint()
                    rebuildStringButtons()
                }
            }
        }
        selector.addView(instrumentSpinner, LinearLayout.LayoutParams(-1, a.dp(52)))

        val alternativeTitle = TextView(a).apply {
            text = "Alternative Stimmungen"
            textSize = 13f
            setTextColor(a.getColor(R.color.sw_muted))
            setPadding(0, a.dp(10), 0, a.dp(4))
        }
        selector.addView(alternativeTitle)
        alternativeSpinner = TextView(a).apply {
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(a.getColor(R.color.sw_text))
            gravity = Gravity.CENTER_VERTICAL
            setPadding(a.dp(14), a.dp(10), a.dp(42), a.dp(10))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(a.getColor(R.color.sw_surface2))
                cornerRadius = a.dp(12).toFloat()
                setStroke(a.dp(1), a.getColor(R.color.sw_copper))
            }
            minHeight = a.dp(52)
            isClickable = true
            isFocusable = true
            setOnClickListener {
                val options = availableTunings
                if (options.isEmpty()) return@setOnClickListener
                androidx.appcompat.app.AlertDialog.Builder(a)
                    .setTitle("Alternative Stimmung wählen")
                    .setItems(options.map { it.label }.toTypedArray()) { _, which ->
                        val chosen = options.getOrNull(which) ?: return@setItems
                        selectedAlternative = chosen
                        text = chosen.label
                        targetView?.text = targetHint()
                        rebuildStringButtons()
                    }
                    .setNegativeButton("Abbrechen", null)
                    .show()
            }
        }
        selector.addView(alternativeSpinner, LinearLayout.LayoutParams(-1, a.dp(52)))
        configureAlternativeTunings()

        val referenceHeader = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, a.dp(10), 0, a.dp(2))
        }
        referenceLabel = TextView(a).apply {
            text = "Kammerton A4 · 440 Hz"
            textSize = 13f
            setTextColor(a.getColor(R.color.sw_muted))
        }
        referenceHeader.addView(referenceLabel, LinearLayout.LayoutParams(0, -2, 1f))
        val referenceReset = TextView(a).apply {
            text = "↺  440 Hz"
            textSize = 11f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(a.getColor(R.color.sw_text))
            gravity = Gravity.CENTER
            setPadding(a.dp(10), a.dp(6), a.dp(10), a.dp(6))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(a.getColor(R.color.sw_surface2))
                cornerRadius = a.dp(9).toFloat()
                setStroke(a.dp(1), a.getColor(R.color.sw_copper))
            }
            contentDescription = "Kammerton auf Standard 440 Hertz zurücksetzen"
            setOnClickListener {
                referenceSeekReset?.progress = 8
            }
        }
        referenceHeader.addView(referenceReset, LinearLayout.LayoutParams(-2, -2))
        selector.addView(referenceHeader, LinearLayout.LayoutParams(-1, -2))
        val referenceSeek = SeekBar(a).apply {
            max = 10
            progress = 8
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(v: SeekBar?, progress: Int, fromUser: Boolean) {
                    referenceA4 = 432.0 + progress
                    referenceLabel?.text = "Kammerton A4 · ${referenceA4.roundToInt()} Hz"
                    targetView?.text = targetHint()
                    rebuildStringButtons()
                }
                override fun onStartTrackingTouch(v: SeekBar?) = Unit
                override fun onStopTrackingTouch(v: SeekBar?) = Unit
            })
        }
        referenceSeekReset = referenceSeek
        selector.addView(referenceSeek, LinearLayout.LayoutParams(-1, a.dp(42)))

        stringPanel = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, a.dp(6), 0, 0)
        }
        selector.addView(stringPanel, LinearLayout.LayoutParams(-1, a.dp(48)))
        selectorCard.addView(selector)
        root.addView(selectorCard, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(10)) })

        val displayCard = a.card()
        val display = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(a.dp(14), a.dp(10), a.dp(14), a.dp(16))
        }

        targetView = TextView(a).apply {
            text = targetHint()
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(a.getColor(R.color.sw_muted))
        }
        display.addView(targetView, LinearLayout.LayoutParams(-1, a.dp(30)))

        gauge = TunerGaugeView(a)
        display.addView(gauge, LinearLayout.LayoutParams(-1, a.dp(230)))

        noteView = TextView(a).apply {
            text = "—"
            textSize = 64f
            gravity = Gravity.CENTER
            setTextColor(a.getColor(R.color.sw_text))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        display.addView(noteView, LinearLayout.LayoutParams(-1, a.dp(76)))

        centsView = TextView(a).apply {
            text = "0 Cent"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(a.getColor(R.color.sw_muted))
        }
        display.addView(centsView, LinearLayout.LayoutParams(-1, a.dp(32)))

        hzView = TextView(a).apply {
            text = "Warte auf einen Ton"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(a.getColor(R.color.sw_muted))
        }
        display.addView(hzView, LinearLayout.LayoutParams(-1, a.dp(32)))

        statusView = TextView(a).apply {
            text = "BEREIT ZUM STIMMEN"
            textSize = 15f
            gravity = Gravity.CENTER
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(a.getColor(R.color.sw_copper))
        }
        display.addView(statusView, LinearLayout.LayoutParams(-1, a.dp(34)))

        startButton = a.button("Stimmen starten").also {
            it.setOnClickListener { if (active) stopTuner() else a.askMic { startTuner() } }
        }
        display.addView(startButton, LinearLayout.LayoutParams(-1, a.dp(52)).apply { topMargin = a.dp(8) })
        displayCard.addView(display)
        root.addView(displayCard, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(14)) })

        rebuildStringButtons()
        root.addView(a.body("Spiele eine einzelne Saite an. Die Anzeige zeigt den erkannten Ton, die Abweichung in Cent und die passende Zielsaite. Wähle oben dein Instrument und die passende Stimmung."))
        return ScrollView(a).apply { addView(root) }
    }

    private fun configureAlternativeTunings() {
        val options = tuningsFor(selectedMode)
        availableTunings = options
        val chosen = options.firstOrNull()
        selectedAlternative = chosen ?: AlternativeTuning("Chromatisch", emptyList())
        val selector = alternativeSpinner ?: return
        selector.text = chosen?.label ?: "Keine alternative Stimmung"
        selector.isEnabled = options.isNotEmpty()
        selector.alpha = if (options.isNotEmpty()) 1f else 0.5f
    }

    private fun targetHint(): String =
        if (selectedMode == TuningMode.CHROMATIC) "Chromatisch: jeder Ton wird erkannt"
        else "Zielsaiten: " + targets().joinToString(" · ") { it.name }

    private fun noteFrequency(note: String): Double {
        val match = Regex("^([A-G])(#?)(-?\\d+)$").matchEntire(note)
            ?: return 440.0
        val base = mapOf("C" to 0, "D" to 2, "E" to 4, "F" to 5, "G" to 7, "A" to 9, "B" to 11)
        val midi = (match.groupValues[3].toInt() + 1) * 12 + base.getValue(match.groupValues[1]) + if (match.groupValues[2] == "#") 1 else 0
        return referenceA4 * 2.0.pow((midi - 69) / 12.0)
    }

    private fun targets(): List<Target> {
        if (selectedMode == TuningMode.CHROMATIC) return emptyList()
        return selectedAlternative.notes.mapIndexed { index, note ->
            Target((selectedAlternative.notes.size - index).toString() + note.replace(Regex("[0-9]"), ""), noteFrequency(note))
        }
    }

    private fun rebuildStringButtons() {
        val panel = stringPanel ?: return
        panel.removeAllViews()
        val list = targets()
        if (list.isEmpty()) {
            panel.addView(TextView(requireContext()).apply {
                text = "Chromatisch · keine Zielsaiten"
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(requireContext().getColor(R.color.sw_muted))
            })
            return
        }
        list.forEach { target ->
            val b = Button(requireContext()).apply {
                text = target.name
                textSize = 12f
                minHeight = 0
                minimumHeight = 0
                setPadding(0, 0, 0, 0)
                setOnClickListener {
                    targetView?.text = "Ziel: ${target.name} · ${"%.1f".format(target.hz)} Hz"
                    playReferenceTone(target.hz)
                }
            }
            panel.addView(b, LinearLayout.LayoutParams(0, -1, 1f).apply {
                setMargins((2f * resources.displayMetrics.density).roundToInt(), 0, (2f * resources.displayMetrics.density).roundToInt(), 0)
            })
        }
    }

    private fun playReferenceTone(frequency: Double = referenceA4) {
        try {
            referenceTrack?.stop()
            referenceTrack?.release()
            val sampleRate = 44100
            val durationMs = 1500
            val count = sampleRate * durationMs / 1000
            val pcm = ShortArray(count)
            for (i in pcm.indices) {
                val t = i.toDouble() / sampleRate
                val envelope = kotlin.math.exp(-3.8 * t)
                val fundamental = kotlin.math.sin(2.0 * Math.PI * frequency * t)
                val second = 0.22 * kotlin.math.sin(2.0 * Math.PI * frequency * 2.0 * t)
                val third = 0.08 * kotlin.math.sin(2.0 * Math.PI * frequency * 3.0 * t)
                pcm[i] = (0.22 * envelope * (fundamental + second + third) * Short.MAX_VALUE).toInt().toShort()
            }
            val min = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val track = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(sampleRate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                .setBufferSizeInBytes(maxOf(min, pcm.size * 2))
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            referenceTrack = track
            track.write(pcm, 0, pcm.size)
            track.play()
        } catch (_: Exception) {
            Toast.makeText(requireContext(), "Referenzton konnte nicht abgespielt werden.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startTuner() {
        if (active) return
        val rate = 44100
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) { Toast.makeText(requireContext(), "Audioaufnahme wird von diesem Gerät nicht unterstützt.", Toast.LENGTH_LONG).show(); return }
        try {
            val size = maxOf(min, 8192)
            val audio = AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size)
            check(audio.state == AudioRecord.STATE_INITIALIZED) { "AudioRecord konnte nicht initialisiert werden" }
            recorder = audio; audio.startRecording(); active = true
            startButton?.text = "Stimmen stoppen"
            statusView?.text = "ICH HÖRE ZU …"
            worker = Thread {
                val samples = ShortArray(4096)
                var stablePitch = -1.0
                var stableFrames = 0
                var silentFrames = 0
                while (active) {
                    val n = audio.read(samples, 0, samples.size)
                    if (n > 2048) {
                        val hz = estimatePitch(samples, n, rate)
                        if (hz in 35.0..1100.0) {
                            silentFrames = 0
                            if (stablePitch > 0.0 && kotlin.math.abs(hz - stablePitch) / stablePitch < 0.035) {
                                stablePitch = stablePitch * 0.65 + hz * 0.35
                                stableFrames++
                            } else {
                                stablePitch = hz
                                stableFrames = 1
                            }
                            if (stableFrames >= 2) updatePitch(stablePitch)
                        } else {
                            stableFrames = 0
                            stablePitch = -1.0
                            silentFrames++
                            if (silentFrames == 5) resetPitchDisplay()
                        }
                    }
                }
            }.apply { name = "Saitenwerk-Tuner"; start() }
        } catch (e: Exception) {
            active = false; releaseRecorder(); startButton?.text = "Erneut versuchen"
            Toast.makeText(requireContext(), "Mikrofonfehler: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun updatePitch(hz: Double) {
        val result = if (selectedMode == TuningMode.CHROMATIC) {
            val midi = (69 + 12 * ln(hz / 440.0) / ln(2.0)).roundToInt()
            val target = 440.0 * 2.0.pow((midi - 69) / 12.0)
            val names = arrayOf("C", "C♯", "D", "D♯", "E", "F", "F♯", "G", "G♯", "A", "A♯", "B")
            val note = names[(midi % 12 + 12) % 12] + (midi / 12 - 1)
            note to target
        } else {
            val t = targets().minByOrNull { kotlin.math.abs(1200.0 * ln(hz / it.hz) / ln(2.0)) } ?: Target("—", 440.0)
            t.name to t.hz
        }
        val cents = (1200 * ln(hz / result.second) / ln(2.0)).roundToInt()
        val status = when {
            cents < -5 -> "ZU TIEF"
            cents > 5 -> "ZU HOCH"
            else -> "GESTIMMT"
        }
        activity?.runOnUiThread {
            if (!active) return@runOnUiThread
            noteView?.text = result.first
            hzView?.text = "%.1f Hz".format(hz)
            centsView?.text = when {
                cents > 0 -> "+$cents Cent"
                else -> "$cents Cent"
            }
            statusView?.text = status
            val tone = when {
                cents < -5 -> -1
                cents > 5 -> 1
                else -> 0
            }
            statusView?.setTextColor(requireContext().getColor(when (tone) {
                -1 -> R.color.sw_copper
                1 -> R.color.sw_copper
                else -> R.color.sw_copper
            }))
            gauge?.setCents(cents)
        }
    }

    private fun estimatePitch(x: ShortArray, n: Int, sr: Int): Double {
        if (n < 2048) return -1.0
        var mean = 0.0
        for (i in 0 until n) mean += x[i].toDouble()
        mean /= n.toDouble()
        var energy = 0.0
        var peak = 0.0
        for (i in 0 until n) {
            val v = x[i].toDouble() - mean
            energy += v * v
            peak = maxOf(peak, kotlin.math.abs(v))
        }
        val rms = kotlin.math.sqrt(energy / n.toDouble())
        if (rms < 220.0 || peak < 550.0) return -1.0

        val minLag = maxOf(2, sr / 1100)
        val maxLag = minOf(sr / 32, n / 3)
        val difference = DoubleArray(maxLag + 1)
        val usable = n - maxLag
        for (lag in minLag..maxLag) {
            var sum = 0.0
            for (i in 0 until usable step 2) {
                val a = x[i].toDouble() - mean
                val b = x[i + lag].toDouble() - mean
                val d = a - b
                sum += d * d
            }
            difference[lag] = sum
        }

        // Cumulative Mean Normalized Difference (YIN).
        var running = 0.0
        for (lag in minLag..maxLag) {
            running += difference[lag]
            difference[lag] = if (running > 0.0) difference[lag] * (lag - minLag + 1) / running else 1.0
        }

        // Pick the first sufficiently good local minimum to reduce octave errors.
        var chosen = -1
        var lag = minLag
        while (lag < maxLag - 1) {
            if (difference[lag] < 0.16) {
                while (lag + 1 <= maxLag && difference[lag + 1] < difference[lag]) lag++
                chosen = lag
                break
            }
            lag++
        }
        if (chosen < 0) {
            var best = minLag
            for (candidate in minLag + 1..maxLag) {
                if (difference[candidate] < difference[best]) best = candidate
            }
            if (difference[best] > 0.28) return -1.0
            chosen = best
        }

        // Parabolic interpolation gives sub-sample period resolution.
        val refined = if (chosen > minLag && chosen < maxLag) {
            val left = difference[chosen - 1]
            val center = difference[chosen]
            val right = difference[chosen + 1]
            val denominator = left - 2.0 * center + right
            val offset = if (kotlin.math.abs(denominator) > 1e-12)
                (0.5 * (left - right) / denominator).coerceIn(-0.5, 0.5)
            else 0.0
            chosen.toDouble() + offset
        } else chosen.toDouble()

        val hz = sr.toDouble() / refined
        return if (hz in 30.0..1100.0) hz else -1.0
    }

    private fun resetPitchDisplay() {
        activity?.runOnUiThread {
            if (!active) return@runOnUiThread
            noteView?.text = "—"
            hzView?.text = "— Hz"
            centsView?.text = "— Cent"
            statusView?.text = "BEREIT · SAITE ANSCHLAGEN"
            gauge?.setCents(0)
        }
    }

    private fun releaseRecorder() {
        try { recorder?.stop() } catch (_: Exception) { }
        try { recorder?.release() } catch (_: Exception) { }
        recorder = null; worker = null
    }
    private fun stopTuner() {
        active = false
        releaseRecorder()
        try { referenceTrack?.stop() } catch (_: Exception) { }
        try { referenceTrack?.release() } catch (_: Exception) { }
        referenceTrack = null
        startButton?.text = "Stimmen starten"
        statusView?.text = "BEREIT ZUM STIMMEN"
    }
    override fun onPause() { stopTuner(); super.onPause() }
    override fun onDestroyView() { stopTuner(); noteView = null; hzView = null; centsView = null; targetView = null; statusView = null; gauge = null; startButton = null; instrumentSpinner = null; alternativeSpinner = null; super.onDestroyView() }
}

class TunerGaugeView(context: android.content.Context) : View(context) {
    private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    private val rect = android.graphics.RectF()
    private var cents = 0

    fun setCents(value: Int) {
        cents = value.coerceIn(-50, 50)
        invalidate()
    }

    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h * 0.78f
        val radius = minOf(w * 0.42f, h * 0.67f)
        rect.set(cx - radius, cy - radius, cx + radius, cy + radius)

        // Große, gut lesbare Halbkreis-Anzeige wie bei einem klassischen Hardware-Tuner.
        val segments = 31
        for (i in 0 until segments) {
            val start = 200f + i * (140f / segments)
            val center = i - (segments - 1) / 2f
            paint.style = android.graphics.Paint.Style.STROKE
            paint.strokeWidth = dp(8f)
            paint.strokeCap = android.graphics.Paint.Cap.BUTT
            paint.color = when {
                kotlin.math.abs(center) <= 2 -> android.graphics.Color.rgb(92, 155, 135)
                center < 0 -> android.graphics.Color.rgb(218, 174, 76)
                else -> android.graphics.Color.rgb(190, 88, 82)
            }
            canvas.drawArc(rect, start, 140f / segments - 2.2f, false, paint)
        }

        val angle = 270f + (cents / 50f) * 70f
        val rad = Math.toRadians(angle.toDouble())
        val x1 = cx + kotlin.math.cos(rad).toFloat() * radius * 0.18f
        val y1 = cy + kotlin.math.sin(rad).toFloat() * radius * 0.18f
        val x2 = cx + kotlin.math.cos(rad).toFloat() * radius * 0.91f
        val y2 = cy + kotlin.math.sin(rad).toFloat() * radius * 0.91f
        paint.color = android.graphics.Color.WHITE
        paint.strokeWidth = dp(4f)
        paint.strokeCap = android.graphics.Paint.Cap.ROUND
        canvas.drawLine(x1, y1, x2, y2, paint)

        paint.style = android.graphics.Paint.Style.FILL
        paint.color = android.graphics.Color.WHITE
        canvas.drawCircle(cx, cy, dp(7f), paint)

        paint.textAlign = android.graphics.Paint.Align.CENTER
        paint.typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
        paint.textSize = dp(13f)
        paint.color = android.graphics.Color.LTGRAY
        canvas.drawText("−50", cx - radius * 0.82f, cy + dp(24f), paint)
        canvas.drawText("0", cx, cy - radius * 0.91f, paint)
        canvas.drawText("+50", cx + radius * 0.82f, cy + dp(24f), paint)
    }

    private fun dp(v: Float) = v * resources.displayMetrics.density
}

data class ChordShape(val name: String, val quality: String, val frets: IntArray, val baseFret: Int = 1, val note: String = "")
object ChordLibrary {
    val all = listOf(
        ChordShape("C", "Dur", intArrayOf(-1,3,2,0,1,0), note="Offener C-Dur-Griff"),
        ChordShape("G", "Dur", intArrayOf(3,2,0,0,0,3), note="Offener G-Dur-Griff"),
        ChordShape("D", "Dur", intArrayOf(-1,-1,0,2,3,2), note="Offener D-Dur-Griff"),
        ChordShape("A", "Dur", intArrayOf(-1,0,2,2,2,0), note="Offener A-Dur-Griff"),
        ChordShape("E", "Dur", intArrayOf(0,2,2,1,0,0), note="Offener E-Dur-Griff"),
        ChordShape("F", "Dur", intArrayOf(1,3,3,2,1,1), note="Barré-Griff im 1. Bund"),
        ChordShape("Am", "Moll", intArrayOf(-1,0,2,2,1,0)),
        ChordShape("Em", "Moll", intArrayOf(0,2,2,0,0,0)),
        ChordShape("Dm", "Moll", intArrayOf(-1,-1,0,2,3,1)),
        ChordShape("Bm", "Moll", intArrayOf(-1,2,4,4,3,2), 2),
        ChordShape("C7", "Septakkord", intArrayOf(-1,3,2,3,1,0)),
        ChordShape("D7", "Septakkord", intArrayOf(-1,-1,0,2,1,2)),
        ChordShape("E7", "Septakkord", intArrayOf(0,2,0,1,0,0)),
        ChordShape("G7", "Septakkord", intArrayOf(3,2,0,0,0,1)),
        ChordShape("Am7", "Septakkord", intArrayOf(-1,0,2,0,1,0)),
        ChordShape("Em7", "Septakkord", intArrayOf(0,2,0,0,0,0)),
        ChordShape("Dsus2", "Sus-Akkord", intArrayOf(-1,-1,0,2,3,0)),
        ChordShape("Dsus4", "Sus-Akkord", intArrayOf(-1,-1,0,2,3,3)),
        ChordShape("Asus2", "Sus-Akkord", intArrayOf(-1,0,2,2,0,0)),
        ChordShape("Asus4", "Sus-Akkord", intArrayOf(-1,0,2,2,3,0))
    )
}

class ChordDiagramView(context: android.content.Context, private val shape: ChordShape) : View(context) {
    private val gridPaint = android.graphics.Paint(3).apply { color = android.graphics.Color.LTGRAY; strokeWidth = 2f }
    private val textPaint = android.graphics.Paint(3).apply { color = android.graphics.Color.WHITE; textSize = 22f; textAlign = android.graphics.Paint.Align.CENTER }
    private val dotPaint = android.graphics.Paint(3).apply { color = android.graphics.Color.rgb(217,154,112); style = android.graphics.Paint.Style.FILL }

    // Standard-Hochkantdarstellung: sechs Saiten verlaufen senkrecht,
    // die Bünde waagerecht. Tiefe E-Saite links, hohe e-Saite rechts.
    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val top = dp(38f)
        val bottom = height - dp(42f)
        val left = width * .17f
        val right = width * .83f
        val dx = (right - left) / 5f
        val dy = (bottom - top) / 4f

        // Saiten
        for (i in 0..5) canvas.drawLine(left + i * dx, top, left + i * dx, bottom, gridPaint)
        // Bünde
        for (i in 0..4) canvas.drawLine(left, top + i * dy, right, top + i * dy, gridPaint)

        // Sattel / Bundnummer
        if (shape.baseFret == 1) {
            canvas.drawRect(left - dp(2f), top - dp(4f), right + dp(2f), top + dp(2f), gridPaint)
        } else {
            canvas.drawText("${shape.baseFret}.", left - dp(27f), top + dy * .55f, textPaint)
        }

        val labels = arrayOf("E", "A", "D", "G", "H", "e")
        for (i in 0..5) {
            val fret = shape.frets[i]
            val x = left + i * dx
            val marker = if (fret < 0) "×" else if (fret == 0) "○" else ""
            if (marker.isNotEmpty()) canvas.drawText(marker, x, top - dp(12f), textPaint)
            if (fret > 0) {
                val y = top + (fret - shape.baseFret + .5f) * dy
                if (y in top..bottom) canvas.drawCircle(x, y, dp(10f), dotPaint)
            }
            canvas.drawText(labels[i], x, height - dp(8f), textPaint)
        }
    }

    private fun dp(v: Float) = v * resources.displayMetrics.density
}

/** Spielt den ausgewählten Griff als kurze, gezupfte Gitarrenprobe. */
object ChordPreviewPlayer {
    @Volatile private var current: android.media.AudioTrack? = null

    fun play(shape: ChordShape) {
        stop()
        Thread {
            val sampleRate = 44100
            val durationMs = 3000
            val samples = sampleRate * durationMs / 1000
            val mix = DoubleArray(samples)
            val tuning = doubleArrayOf(82.4069, 110.0, 146.832, 196.0, 246.942, 329.628)
            val random = java.util.Random(shape.name.hashCode().toLong())
            var activeStrings = 0

            // Karplus-Strong: ein kurzer Rauschimpuls wird durch eine rückgekoppelte
            // Verzögerungsleitung geschickt. Dadurch entsteht ein deutlich natürlicherer
            // gezupfter Saitenklang als mit reinen Sinuswellen.
            shape.frets.forEachIndexed { stringIndex, fret ->
                if (fret >= 0) {
                    activeStrings++
                    val frequency = tuning[stringIndex] * 2.0.pow(fret / 12.0)
                    val delay = (sampleRate / frequency).roundToInt().coerceAtLeast(2)
                    val pluck = DoubleArray(delay)
                    for (i in pluck.indices) {
                        pluck[i] = random.nextDouble() * 2.0 - 1.0
                    }

                    val start = stringIndex * (sampleRate / 95)
                    var previous = 0.0
                    val decay = 0.9968 - stringIndex * 0.00006
                    val stringLength = minOf(samples - start, (durationMs * sampleRate / 1000))
                    if (stringLength <= 0) return@forEachIndexed

                    for (j in 0 until stringLength) {
                        val pos = j % delay
                        val currentSample = pluck[pos]
                        val nextPos = (pos + 1) % delay
                        // leichter Tiefpass in der Rückkopplung = typische Dämpfung hoher Obertöne
                        val filtered = 0.5 * (currentSample + previous)
                        pluck[pos] = filtered * decay
                        previous = currentSample

                        val t = j.toDouble() / sampleRate
                        val envelope = kotlin.math.exp(-0.95 * t)
                        // Weicher Anschlag: kein harter Klick am Anfang der Saite.
                        val attack = if (t < 0.055) {
                            val a = t / 0.055
                            a * a * (3.0 - 2.0 * a)
                        } else 1.0
                        val fadeOut = if (t > 2.35) ((3.0 - t) / 0.65).coerceIn(0.0, 1.0) else 1.0
                        mix[start + j] += currentSample * envelope * attack * fadeOut * 0.12
                    }
                }
            }

            if (activeStrings == 0) return@Thread

            // Sanfte Sättigung und Normalisierung verhindern harte digitale Spitzen.
            val max = mix.maxOf { kotlin.math.abs(it) }.coerceAtLeast(0.001)
            val pcm = ShortArray(samples) { i ->
                val x = (mix[i] / max * 0.26).coerceIn(-1.0, 1.0)
                val shaped = kotlin.math.tanh(x * 0.58)
                (shaped * Short.MAX_VALUE).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            }

            val track = android.media.AudioTrack.Builder()
                .setAudioAttributes(
                    android.media.AudioAttributes.Builder()
                        .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    android.media.AudioFormat.Builder()
                        .setEncoding(android.media.AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(android.media.AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(pcm.size * 2)
                .setTransferMode(android.media.AudioTrack.MODE_STATIC)
                .build()

            current = track
            track.write(pcm, 0, pcm.size)
            track.play()
            while (track.playState == android.media.AudioTrack.PLAYSTATE_PLAYING) {
                Thread.sleep(30)
            }
            track.release()
            if (current === track) current = null
        }.start()
    }

    fun stop() {
        val track = current
        current = null
        try { track?.stop() } catch (_: Exception) { }
        try { track?.release() } catch (_: Exception) { }
    }
}

class ChordsFragment : Fragment() {
    private var training: ChordTrainingPanel? = null
    override fun onDestroyView() { training?.stop(); training = null; super.onDestroyView() }
    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity
        val root = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        root.addView(a.title("Akkorde")); root.addView(a.body("Griffbilder · Akkordwissen · Wechseltraining"))
        val search = EditText(a).apply { hint = "Akkord suchen (z. B. Am, G7 …)"; setSingleLine(); setTextColor(a.getColor(R.color.sw_text)); setHintTextColor(a.getColor(R.color.sw_muted)); setPadding(a.dp(16), 0, a.dp(16), 0) }
        root.addView(search, LinearLayout.LayoutParams(-1, a.dp(50)).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(8)) })
        val filters = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; setPadding(a.dp(10), 0, a.dp(10), a.dp(8)) }
        val categories = listOf("Alle", "Dur", "Moll", "Septakkord", "Sus-Akkord"); var category = "Alle"
        val scroll = ScrollView(a)
        val content = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        val detailCard = a.card().apply { visibility = View.GONE }
        val detail = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(16), a.dp(14), a.dp(16), a.dp(16)) }
        detailCard.addView(detail)
        val grid = GridLayout(a).apply { columnCount = 3; setPadding(a.dp(10), a.dp(4), a.dp(10), a.dp(12)) }
        fun showChord(ch: ChordShape) {
            detail.removeAllViews()
            detail.addView(TextView(a).apply { text = ch.name; textSize = 29f; setTextColor(a.getColor(R.color.sw_copper)); setTypeface(typeface, 1) })
            detail.addView(TextView(a).apply { text = "${ch.quality} · ${ch.note}"; setTextColor(a.getColor(R.color.sw_muted)) })
            detail.addView(ChordDiagramView(a, ch), LinearLayout.LayoutParams(-1, a.dp(270)))
            detail.addView(TextView(a).apply { text = "Hochkant: tiefe E-Saite links · hohe e-Saite rechts\n× = nicht anschlagen · ○ = leere Saite"; setTextColor(a.getColor(R.color.sw_muted)); textSize = 13f })
            val preview = a.button("▶ Akkord anhören")
            preview.setOnClickListener { ChordPreviewPlayer.play(ch) }
            detail.addView(preview, LinearLayout.LayoutParams(-1, a.dp(48)).apply { topMargin = a.dp(8) })
            val prefs = a.getSharedPreferences("saitenwerk", 0); val key = "fav_chords"
            val saved = prefs.getStringSet(key, emptySet())?.toMutableSet() ?: mutableSetOf()
            val fav = a.button(if (ch.name in saved) "★ Favorit entfernen" else "☆ Als Favorit speichern")
            fav.setOnClickListener { val now = prefs.getStringSet(key, emptySet())?.toMutableSet() ?: mutableSetOf(); if (!now.add(ch.name)) now.remove(ch.name); prefs.edit().putStringSet(key, now).apply(); fav.text = if (ch.name in now) "★ Favorit entfernen" else "☆ Als Favorit speichern" }
            detail.addView(fav, LinearLayout.LayoutParams(-1, a.dp(46)).apply { topMargin = a.dp(8) })
            detailCard.visibility = View.VISIBLE
        }
        fun render() {
            grid.removeAllViews(); val q = search.text.toString().trim().lowercase()
            val matches = ChordLibrary.all.filter { (category == "Alle" || it.quality == category) && it.name.lowercase().contains(q) }
            matches.forEach { chord ->
                val b = a.button(chord.name); b.setOnClickListener { showChord(chord) }
                grid.addView(b, GridLayout.LayoutParams().apply { width = 0; height = a.dp(52); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(a.dp(3), a.dp(3), a.dp(3), a.dp(3)) })
            }
            if (matches.isEmpty()) grid.addView(a.body("Kein passender Akkord gefunden."))
        }
        categories.forEach { cat -> val b = a.button(cat); b.textSize = 11f; b.setOnClickListener { category = cat; render() }; filters.addView(b, LinearLayout.LayoutParams(0, a.dp(42), 1f).apply { setMargins(a.dp(2), 0, a.dp(2), 0) }) }
        search.addTextChangedListener(object : TextWatcher { override fun beforeTextChanged(s: CharSequence?, st: Int, count: Int, after: Int) {}; override fun onTextChanged(s: CharSequence?, st: Int, before: Int, count: Int) { render() }; override fun afterTextChanged(e: Editable?) {} })
        content.addView(detailCard); content.addView(grid)
        training = ChordTrainingPanel(a); content.addView(training, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(12), a.dp(12), a.dp(12), a.dp(20)) })
        scroll.addView(content); root.addView(filters); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f)); render()
        return root
    }
}

class ChordTrainingPanel(private val host: MainActivity) : LinearLayout(host) {
    private val handler = Handler(Looper.getMainLooper())
    private val tone = ToneGenerator(AudioManager.STREAM_MUSIC, 55)
    private val prefs = host.getSharedPreferences("saitenwerk", 0)
    private val defaultSequence = listOf("C", "G", "Am", "F")
    private val availableChords = ChordLibrary.all.map { it.name }.distinct().sorted()
    private var sequence = loadSequence()
    private var bpm = 72
    private var beat = 0
    private var changes = 0
    private var running = false
    private val current = TextView(host)
    private val status = TextView(host)
    private val sequenceLabel = TextView(host)
    private val chooseChords = host.button("Akkorde auswählen")
    private val start = host.button("Training starten")
    private val tempo = SeekBar(host)
    private val tempoLabel = TextView(host)
    private val stats = TextView(host)

    private fun loadSequence(): List<String> {
        val validNames = ChordLibrary.all.map { it.name }.toSet()
        val saved = prefs.getStringSet("chord_training_selected_chords", null)
        val valid = saved?.filter { it in validNames } ?: emptyList()
        return if (valid.size >= 2) valid.sorted() else defaultSequence
    }

    private fun refreshSequenceLabel() {
        sequenceLabel.text = "Deine Trainingsakkorde: " + sequence.joinToString(" · ")
        current.text = sequence.firstOrNull() ?: "—"
    }

    private fun openChordPicker() {
        if (running) {
            Toast.makeText(host, "Bitte stoppe das Training zuerst, um die Akkorde zu ändern.", Toast.LENGTH_SHORT).show()
            return
        }
        val names = availableChords
        val checked = names.map { it in sequence }.toBooleanArray()
        androidx.appcompat.app.AlertDialog.Builder(host)
            .setTitle("Trainingsakkorde auswählen")
            .setMultiChoiceItems(names.toTypedArray(), checked) { _, which, isChecked ->
                checked[which] = isChecked
            }
            .setPositiveButton("Übernehmen") { _, _ ->
                val selected = names.filterIndexed { index, _ -> checked[index] }
                if (selected.size < 2) {
                    Toast.makeText(host, "Wähle mindestens zwei Akkorde aus.", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                sequence = selected
                prefs.edit().putStringSet("chord_training_selected_chords", selected.toSet()).apply()
                beat = 0
                changes = 0
                refreshSequenceLabel()
                stats.text = "Akkordwechsel: 0 · Tempo: " + bpm + " BPM"
                status.text = selected.size.toString() + " Akkorde für dein Training gespeichert."
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            tone.startTone(if (beat % 4 == 0) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_BEEP, 65)
            if (beat % 4 == 0) {
                current.text = sequence[changes % sequence.size]
                changes++
                stats.text = "Akkordwechsel: " + (changes - 1) + " · Tempo: " + bpm + " BPM"
            }
            beat++
            handler.postDelayed(this, (60000L / bpm).coerceAtLeast(100L))
        }
    }

    init {
        orientation = VERTICAL
        setPadding(host.dp(16), host.dp(16), host.dp(16), host.dp(16))
        setBackgroundColor(host.getColor(R.color.sw_surface))
        addView(TextView(host).apply {
            text = "Akkordwechsel-Training"
            textSize = 20f
            setTextColor(host.getColor(R.color.sw_copper))
            setTypeface(typeface, 1)
        })
        sequenceLabel.apply {
            setTextColor(host.getColor(R.color.sw_muted))
            setPadding(0, host.dp(5), 0, host.dp(4))
            textSize = 13f
        }
        addView(sequenceLabel, LayoutParams(-1, -2))
        chooseChords.setOnClickListener { openChordPicker() }
        addView(chooseChords, LayoutParams(-1, host.dp(44)).apply { bottomMargin = host.dp(6) })
        current.apply {
            textSize = 40f
            gravity = Gravity.CENTER
            setTextColor(host.getColor(R.color.sw_text))
            setTypeface(typeface, 1)
        }
        addView(current, LayoutParams(-1, host.dp(76)))
        status.apply {
            text = "Bereit? Starte das Metronom."
            setTextColor(host.getColor(R.color.sw_muted))
            textSize = 13f
        }
        addView(status, LayoutParams(-1, -2))
        tempoLabel.apply {
            text = "Tempo: 72 BPM"
            setTextColor(host.getColor(R.color.sw_text))
            setPadding(0, host.dp(10), 0, 0)
        }
        addView(tempoLabel)
        tempo.max = 110
        tempo.progress = 22
        tempo.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(v: SeekBar?, progress: Int, fromUser: Boolean) {
                bpm = 50 + progress
                tempoLabel.text = "Tempo: " + bpm + " BPM"
            }
            override fun onStartTrackingTouch(v: SeekBar?) {}
            override fun onStopTrackingTouch(v: SeekBar?) {}
        })
        addView(tempo, LayoutParams(-1, host.dp(42)))
        start.setOnClickListener { if (running) stop() else begin() }
        addView(start, LayoutParams(-1, host.dp(48)))
        stats.apply {
            text = "Akkordwechsel: 0 · Tempo: 72 BPM"
            setTextColor(host.getColor(R.color.sw_muted))
            setPadding(0, host.dp(8), 0, host.dp(6))
        }
        addView(stats)
        val row = LinearLayout(host).apply { orientation = HORIZONTAL }
        val mastered = host.button("✓ Sitzt")
        val practice = host.button("↻ Weiter üben")
        mastered.setOnClickListener { saveRating(true) }
        practice.setOnClickListener { saveRating(false) }
        row.addView(mastered, LayoutParams(0, host.dp(44), 1f))
        row.addView(practice, LayoutParams(0, host.dp(44), 1f).apply { leftMargin = host.dp(6) })
        addView(row)
        refreshSequenceLabel()
        status.text = "Bisher: " + prefs.getInt("chord_training_mastered", 0) +
            " gemeisterte Bewertungen aus " + prefs.getInt("chord_training_sessions", 0) + " Einträgen."
    }

    private fun begin() {
        if (sequence.size < 2) {
            status.text = "Bitte wähle mindestens zwei Akkorde aus."
            return
        }
        running = true
        beat = 0
        changes = 0
        start.text = "Training stoppen"
        chooseChords.isEnabled = false
        status.text = "Läuft · auf den ersten Schlag achten"
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    fun stop() {
        running = false
        handler.removeCallbacks(tick)
        start.text = "Training starten"
        chooseChords.isEnabled = true
        try { tone.stopTone() } catch (_: Exception) {}
    }

    private fun saveRating(mastered: Boolean) {
        val sessions = prefs.getInt("chord_training_sessions", 0) + 1
        val wins = prefs.getInt("chord_training_mastered", 0) + if (mastered) 1 else 0
        prefs.edit().putInt("chord_training_sessions", sessions)
            .putInt("chord_training_mastered", wins).apply()
        status.text = if (mastered) "Als gemeistert markiert · " + wins + " von " + sessions
            else "Für weitere Übung vorgemerkt · " + wins + " von " + sessions
    }

    override fun onDetachedFromWindow() {
        stop()
        try { tone.release() } catch (_: Exception) {}
        super.onDetachedFromWindow()
    }
}

data class Song(val title: String, val artist: String = "", val genre: String = "", val custom: Boolean = false)
object SongRepository {
    private const val PREFS = "saitenwerk"
    private fun prefs(a: MainActivity) = a.getSharedPreferences(PREFS, 0)
    fun key(song: Song) = (song.title.trim() + "|" + song.artist.trim()).lowercase()

    fun load(a: MainActivity): MutableList<Song> {
        val base = try {
            val raw = a.assets.open("songs.json").bufferedReader().use { it.readText() }
            val array = JSONArray(raw)
            MutableList(array.length()) { index ->
                val o = array.getJSONObject(index)
                Song(o.optString("title"), o.optString("artist"), o.optString("genre"))
            }
        } catch (_: Exception) { mutableListOf() }
        val custom = try {
            val arr = JSONArray(prefs(a).getString("custom_songs", "[]"))
            MutableList(arr.length()) { i -> arr.getJSONObject(i).let { Song(it.optString("title"), it.optString("artist"), it.optString("genre", "Eigene Songs"), true) } }
        } catch (_: Exception) { mutableListOf() }
        val seen = base.map { key(it) }.toMutableSet()
        base.addAll(custom.filter { seen.add(key(it)) })
        return base
    }

    private fun stringSet(a: MainActivity, name: String) = prefs(a).getStringSet(name, emptySet())?.toMutableSet() ?: mutableSetOf()
    fun isFavorite(a: MainActivity, song: Song) = key(song) in stringSet(a, "song_favorites")
    fun toggleFavorite(a: MainActivity, song: Song): Boolean {
        val set = stringSet(a, "song_favorites"); val k = key(song)
        val now = if (set.remove(k)) false else { set.add(k); true }
        prefs(a).edit().putStringSet("song_favorites", set).apply(); return now
    }
    fun inSetlist(a: MainActivity, song: Song) = key(song) in stringSet(a, "song_setlist")
    fun toggleSetlist(a: MainActivity, song: Song): Boolean {
        val set = stringSet(a, "song_setlist"); val k = key(song)
        val now = if (set.remove(k)) false else { set.add(k); true }
        prefs(a).edit().putStringSet("song_setlist", set).apply(); return now
    }
    fun addRecent(a: MainActivity, song: Song) {
        val old = prefs(a).getString("song_recent", "")!!.split("\n").filter { it.isNotBlank() }.toMutableList()
        old.remove(key(song)); old.add(0, key(song))
        prefs(a).edit().putString("song_recent", old.take(30).joinToString("\n")).apply()
    }
    fun isRecent(a: MainActivity, song: Song) = key(song) in prefs(a).getString("song_recent", "")!!.split("\n")
    fun hasSongSheet(a: MainActivity, song: Song): Boolean {
        val prefix = "song_arrangement_${song.title}|${song.artist}_"
        return listOf("Intro", "Strophe 1", "Strophe 2", "Strophe 3", "Refrain", "Bridge", "Solo", "Outro").any { section ->
            val raw = prefs(a).getString(prefix + section, "{}") ?: "{}"
            try { org.json.JSONObject(raw).optString("content").isNotBlank() || org.json.JSONObject(raw).optString("chords").isNotBlank() }
            catch (_: Exception) { false }
        }
    }
    fun addCustom(a: MainActivity, song: Song) {
        val arr = try { JSONArray(prefs(a).getString("custom_songs", "[]")) } catch (_: Exception) { JSONArray() }
        if (load(a).any { key(it) == key(song) }) return
        arr.put(org.json.JSONObject().put("title", song.title).put("artist", song.artist).put("genre", song.genre.ifBlank { "Eigene Songs" }))
        prefs(a).edit().putString("custom_songs", arr.toString()).apply()
    }
}

class SongsFragment : Fragment() {
    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity
        val root = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        root.addView(a.title("Liederbuch"))
        val songs = SongRepository.load(a)
        val hero = a.card()
        val heroBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(18), a.dp(16), a.dp(18), a.dp(16)) }
        heroBox.addView(TextView(a).apply { text = "🎸  Gemeinfreies Gitarren-Songbook"; textSize = 20f; setTypeface(typeface, android.graphics.Typeface.BOLD); setTextColor(a.getColor(R.color.sw_copper)) })
        heroBox.addView(a.body("Nur freie bzw. traditionelle Werke · komplett mit Liedtext und spielbaren Akkorden · ohne moderne Copyright-Songs."))
        heroBox.addView(TextView(a).apply { text = "${songs.size} kuratierte Songs · bereit zum Spielen"; textSize = 13f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0, a.dp(8), 0, 0) })
        hero.addView(heroBox)
        root.addView(hero, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(16), a.dp(6), a.dp(16), a.dp(10)) })
        val count = a.body("${songs.size} Songtitel · vollständige Songblätter mit Text und Akkorden")
        root.addView(count)
        val search = EditText(a).apply {
            hint = "Titel, Künstler oder Genre suchen"; setSingleLine()
            setTextColor(a.getColor(R.color.sw_text)); setHintTextColor(a.getColor(R.color.sw_muted))
            setPadding(a.dp(16), 0, a.dp(16), 0)
            background = android.graphics.drawable.GradientDrawable().apply { setColor(a.getColor(R.color.sw_surface)); cornerRadius = a.dp(14).toFloat(); setStroke(a.dp(1), a.getColor(R.color.sw_surface2)) }
        }
        root.addView(search, LinearLayout.LayoutParams(-1, a.dp(50)).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(8)) })

        val genreValues = listOf("Alle Genres") + songs.map { it.genre }.filter { it.isNotBlank() }.distinct().sorted()
        val genre = Spinner(a).apply { adapter = a.spinnerAdapter(genreValues) }
        val sort = Spinner(a).apply { adapter = a.spinnerAdapter(listOf("Titel A–Z", "Künstler A–Z", "Genre")) }
        val controls = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        controls.addView(genre, LinearLayout.LayoutParams(0, a.dp(48), 1f).apply { setMargins(a.dp(12), 0, a.dp(4), 0) })
        controls.addView(sort, LinearLayout.LayoutParams(0, a.dp(48), 1f).apply { setMargins(a.dp(4), 0, a.dp(12), 0) })
        root.addView(controls)

        var filter = "Alle"
        var refreshList: (() -> Unit)? = null
        val filters = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        val buttons = linkedMapOf<String, Button>()
        listOf("Alle", "★ Favoriten", "♫ Setlist", "Zuletzt").forEach { label ->
            val b = a.button(label).apply { textSize = 12f; minWidth = 0; setPadding(a.dp(8), 0, a.dp(8), 0) }
            buttons[label] = b
            filters.addView(b, LinearLayout.LayoutParams(0, a.dp(42), 1f).apply { setMargins(a.dp(3), a.dp(8), a.dp(3), a.dp(8)) })
            b.setOnClickListener { filter = label; refreshList?.invoke() }
        }
        root.addView(filters)

        val list = RecyclerView(a).apply { layoutManager = LinearLayoutManager(a); setPadding(0, 0, 0, a.dp(8)); clipToPadding = false }
        val adapter = SongAdapter(songs, a) { song -> SongRepository.addRecent(a, song); a.openSong(song) }
        list.adapter = adapter
        fun refresh() {
            val term = search.text.toString().trim().lowercase()
            val selectedGenre = genre.selectedItem?.toString() ?: "Alle Genres"
            val filtered = songs.filter { song ->
                (term.isEmpty() || song.title.lowercase().contains(term) || song.artist.lowercase().contains(term) || song.genre.lowercase().contains(term)) &&
                (selectedGenre == "Alle Genres" || song.genre == selectedGenre) && when (filter) {
                    "★ Favoriten" -> SongRepository.isFavorite(a, song)
                    "♫ Setlist" -> SongRepository.inSetlist(a, song)
                    "Zuletzt" -> SongRepository.isRecent(a, song)
                    else -> true
                }
            }.let { result -> when (sort.selectedItemPosition) {
                1 -> result.sortedBy { it.artist.lowercase() + it.title.lowercase() }
                2 -> result.sortedBy { it.genre.lowercase() + it.title.lowercase() }
                else -> result.sortedBy { it.title.lowercase() }
            } }
            adapter.submit(filtered)
            count.text = "${filtered.size} angezeigt · ${songs.size} Songtitel insgesamt"
            buttons.forEach { (name, b) -> b.alpha = if ((name == "★ Favoriten" && filter == name) || (name == "♫ Setlist" && filter == name) || (name == filter)) 1f else .68f }
        }
        refreshList = { refresh() }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, before: Int, count: Int) { refresh() }
            override fun afterTextChanged(e: Editable?) {}
        })
        genre.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { refresh() }
        }
        sort.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { refresh() }
        }
        val add = a.button("＋ Eigenen Song hinzufügen")
        add.setOnClickListener {
            val panel = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(20), a.dp(8), a.dp(20), 0) }
            val title = EditText(a).apply { hint = "Songtitel" }
            val artist = EditText(a).apply { hint = "Künstler (optional)" }
            val category = EditText(a).apply { hint = "Genre (optional)" }
            panel.addView(title); panel.addView(artist); panel.addView(category)
            androidx.appcompat.app.AlertDialog.Builder(a).setTitle("Eigenen Song anlegen").setView(panel)
                .setNegativeButton("Abbrechen", null).setPositiveButton("Speichern") { _, _ ->
                    val name = title.text.toString().trim()
                    if (name.isBlank()) Toast.makeText(a, "Bitte einen Songtitel eingeben.", Toast.LENGTH_SHORT).show()
                    else {
                        val song = Song(name, artist.text.toString().trim(), category.text.toString().trim().ifBlank { "Eigene Songs" }, true)
                        if (songs.any { SongRepository.key(it) == SongRepository.key(song) }) Toast.makeText(a, "Dieser Song ist bereits vorhanden.", Toast.LENGTH_SHORT).show()
                        else { SongRepository.addCustom(a, song); songs.add(song); refresh(); Toast.makeText(a, "Song gespeichert", Toast.LENGTH_SHORT).show() }
                    }
                }.show()
        }
        root.addView(add, LinearLayout.LayoutParams(-1, a.dp(46)).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(6)) })
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        refresh()
        return root
    }
}

class SongAdapter(private val all: List<Song>, private val host: MainActivity, private val onClick: (Song) -> Unit) : RecyclerView.Adapter<SongAdapter.Holder>() {
    private var data = all.toList()
    class Holder(v: View) : RecyclerView.ViewHolder(v)
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val card = MaterialCardView(host).apply {
            setCardBackgroundColor(host.getColor(R.color.sw_surface)); radius = host.dp(14).toFloat()
            strokeColor = host.getColor(R.color.sw_surface2); strokeWidth = host.dp(1)
            val text = LinearLayout(host).apply { orientation = LinearLayout.VERTICAL; setPadding(host.dp(16), host.dp(12), host.dp(16), host.dp(12)) }
            addView(text); tag = text
        }
        return Holder(card)
    }
    override fun getItemCount() = data.size
    override fun onBindViewHolder(holder: Holder, position: Int) {
        val song = data[position]; val card = holder.itemView as MaterialCardView
        val text = card.tag as LinearLayout; text.removeAllViews()
        text.addView(TextView(host).apply { this.text = (if (SongRepository.isFavorite(host, song)) "★  " else "♫  ") + song.title; setTextColor(host.getColor(R.color.sw_text)); textSize = 16f; setTypeface(typeface, android.graphics.Typeface.BOLD) })
        val meta = listOf(song.artist.ifBlank { "Künstler unbekannt" }, song.genre.takeIf { it.isNotBlank() }, if (SongRepository.inSetlist(host, song)) "Setlist" else null, if (SongRepository.hasSongSheet(host, song)) "Songblatt vorhanden" else "Songblatt noch offen").filterNotNull().joinToString("   ·   ")
        text.addView(TextView(host).apply { this.text = meta; setTextColor(host.getColor(R.color.sw_muted)); textSize = 12f; setPadding(0, host.dp(4), 0, 0) })
        card.setOnClickListener { onClick(song) }
        card.layoutParams = RecyclerView.LayoutParams(-1, -2).apply {
            setMargins(host.dp(12), host.dp(4), host.dp(12), host.dp(4))
        }
    }
    fun submit(items: List<Song>) { data = items; notifyDataSetChanged() }
}

class SongDetailFragment : Fragment() {
    companion object {
        fun newInstance(song: Song) = SongDetailFragment().apply {
            arguments = Bundle().apply {
                putString("title", song.title)
                putString("artist", song.artist)
                putString("genre", song.genre)
            }
        }
    }

    private data class SongLine(val parts: List<Pair<String, String>>, val plainText: String)
    private data class PlayerChordEvent(
        val chord: String,
        val startMs: Long,
        val endMs: Long,
        val view: TextView
    )

    private data class PlayerNote(val midi: Int, val startMs: Long, val durationMs: Long, val velocity: Float = 0.72f)

    private class GuitarPlayerEngine(private val context: android.content.Context) {
        private val sampleRate = 22_050
        private val chunkFrames = 512
        private var audioTrack: AudioTrack? = null
        private var renderThread: Thread? = null
        @Volatile private var cancelled = false
        @Volatile private var running = false
        @Volatile private var paused = false
        private var totalDurationMs = 0

        fun stop() {
            cancelled = true
            running = false
            paused = false
            renderThread?.interrupt()
            renderThread = null
            audioTrack?.let {
                try { it.stop() } catch (_: Exception) {}
                try { it.release() } catch (_: Exception) {}
            }
            audioTrack = null
        }

        fun pause() {
            audioTrack?.pause()
            paused = true
            running = false
        }

        fun resume() {
            audioTrack?.play()
            paused = false
            running = true
        }

        fun position(): Int {
            val track = audioTrack ?: return 0
            val frames = track.playbackHeadPosition.toLong() and 0xffffffffL
            return ((frames * 1000L) / sampleRate).toInt().coerceIn(0, totalDurationMs)
        }

        fun duration(): Int = totalDurationMs

        fun play(
            chords: List<Pair<String, Long>>,
            melody: List<PlayerNote>,
            tempoBpm: Int,
            onReady: (Int) -> Unit,
            onCompleted: () -> Unit,
            onError: (Throwable) -> Unit
        ) {
            stop()
            cancelled = false
            val beatMs = 60_000.0 / tempoBpm.coerceIn(40, 180)
            val lastChordEnd = chords.maxOfOrNull { it.second } ?: 0L
            val lastNoteEnd = melody.maxOfOrNull { it.startMs + it.durationMs } ?: 0L
            totalDurationMs = maxOf(lastChordEnd + (beatMs * 2.0).toLong(), lastNoteEnd + 450L).toInt().coerceAtLeast(1000)

            try {
                val minBuffer = AudioTrack.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                ).coerceAtLeast(chunkFrames * 2 * 4)
                val track = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build())
                    .setAudioFormat(AudioFormat.Builder()
                        .setSampleRate(sampleRate)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build())
                    .setBufferSizeInBytes(minBuffer)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
                audioTrack = track

                // Start playback immediately. The audio is rendered in small chunks while it plays,
                // so there is no multi-second WAV generation delay before the first note.
                track.play()
                running = true
                onReady(totalDurationMs)

                val chordEvents = chords.mapIndexed { index, pair ->
                    val end = chords.getOrNull(index + 1)?.second ?: totalDurationMs.toLong()
                    Triple(pair.first, pair.second, end)
                }
                renderThread = Thread {
                    try {
                        val buffer = ShortArray(chunkFrames)
                        var frameCursor = 0L
                        var chordIndex = 0
                        var melodyIndex = 0
                        while (!cancelled && frameCursor < (totalDurationMs * sampleRate / 1000L)) {
                            while (paused && !cancelled) Thread.sleep(8L)
                            if (cancelled) break
                            var count = 0
                            while (count < chunkFrames && frameCursor < (totalDurationMs * sampleRate / 1000L)) {
                                val ms = frameCursor * 1000L / sampleRate
                                while (chordIndex + 1 < chordEvents.size && ms >= chordEvents[chordIndex].third) chordIndex++
                                while (melodyIndex + 1 < melody.size && ms >= melody[melodyIndex].startMs + melody[melodyIndex].durationMs) melodyIndex++

                                var sample = 0.0
                                if (chordIndex in chordEvents.indices) {
                                    val ev = chordEvents[chordIndex]
                                    if (ms >= ev.second && ms < ev.third) {
                                        val local = (ms - ev.second) / 1000.0
                                        val notes = chordToMidi(ev.first)
                                        notes.forEachIndexed { idx, midi ->
                                            sample += guitarPluck(midi, local, if (idx == 0) 0.31 else 0.24, 0.95 - idx * 0.08)
                                        }
                                        if (local < beatMs / 1000.0) {
                                            val bass = notes.firstOrNull()?.minus(12) ?: 48
                                            sample += guitarPluck(bass, local, 0.20, 0.78)
                                        }
                                    }
                                }

                                if (melodyIndex in melody.indices) {
                                    val note = melody[melodyIndex]
                                    if (ms >= note.startMs && ms < note.startMs + note.durationMs) {
                                        val local = (ms - note.startMs) / 1000.0
                                        sample += guitarPluck(note.midi, local, note.velocity.toDouble() * 0.64, 1.08)
                                    }
                                }

                                // Very subtle room/body resonance. It is deliberately quiet so the
                                // sound remains guitar-like instead of turning into an electronic pad.
                                sample += sin(2.0 * PI * 110.0 * (ms / 1000.0)) * 0.0015
                                val shaped = (sample * 0.92).coerceIn(-0.92, 0.92)
                                buffer[count] = (shaped * 32767.0).roundToInt().toShort()
                                count++
                                frameCursor++
                            }
                            var written = 0
                            while (written < count && !cancelled) {
                                val n = track.write(buffer, written, count - written, AudioTrack.WRITE_BLOCKING)
                                if (n <= 0) break
                                written += n
                            }
                        }
                        if (!cancelled) {
                            running = false
                            try { track.stop() } catch (_: Exception) {}
                            onCompleted()
                        }
                    } catch (t: Throwable) {
                        if (!cancelled) onError(t)
                    }
                }.also { it.start() }
            } catch (t: Throwable) {
                onError(t)
            }
        }

        private fun guitarPluck(midi: Int, t: Double, velocity: Double, brightness: Double): Double {
            if (t < 0.0) return 0.0
            val f = midiToHz(midi)
            // Inharmonische Teiltöne + kurzer Anschlag + schneller Verlust der hohen
            // Frequenzen. Das vermeidet den "Game-Sound" eines reinen Oszillators.
            val attack = (t / 0.0038).coerceAtMost(1.0)
            val fundamentalDecay = exp(-t * (2.35 + f / 2300.0))
            val phase = 2.0 * PI * f * t
            val p2 = 2.0 * PI * (f * 2.006) * t
            val p3 = 2.0 * PI * (f * 3.011) * t
            val p4 = 2.0 * PI * (f * 4.018) * t
            val p5 = 2.0 * PI * (f * 5.027) * t
            val body = sin(phase) * 0.56 +
                sin(p2 + 0.08) * (0.25 * brightness) * exp(-t * 4.7) +
                sin(p3 + 0.17) * (0.115 * brightness) * exp(-t * 7.2) +
                sin(p4 + 0.29) * (0.052 * brightness) * exp(-t * 10.0) +
                sin(p5 + 0.41) * (0.018 * brightness) * exp(-t * 13.5)
            val pickNoise = (sin(phase * 31.0 + 0.7) + sin(phase * 47.0 + 2.1)) * exp(-t * 150.0) * 0.010
            val wood = sin(2.0 * PI * (f * 0.497) * t + 0.9) * exp(-t * 18.0) * 0.010
            return (body * fundamentalDecay + pickNoise + wood) * attack * velocity
        }

        private fun midiToHz(midi: Int): Double = 440.0 * 2.0.pow((midi - 69) / 12.0)

        private fun chordToMidi(chord: String): List<Int> {
            val clean = chord.replace('♯', '#').replace('♭', 'b')
            val m = Regex("^([A-G](?:#|b)?)([^/]*)(?:/([A-G](?:#|b)?))?").find(clean) ?: return listOf(60)
            val root = noteIndex(m.groupValues[1]) ?: 0
            val suffix = m.groupValues[2].lowercase()
            val intervals = when {
                suffix.contains("dim") -> listOf(0, 3, 6)
                suffix.contains("sus4") -> listOf(0, 5, 7)
                suffix.contains("sus2") -> listOf(0, 2, 7)
                suffix.contains("7") -> listOf(0, 4, 7, 10)
                suffix.contains("m") && !suffix.contains("maj") -> listOf(0, 3, 7)
                else -> listOf(0, 4, 7)
            }
            return intervals.map { 48 + ((root + it) % 12) }.take(3)
        }

        private fun noteIndex(note: String): Int? = when (note) {
            "C" -> 0; "C#", "Db" -> 1; "D" -> 2; "D#", "Eb" -> 3; "E" -> 4; "F" -> 5
            "F#", "Gb" -> 6; "G" -> 7; "G#", "Ab" -> 8; "A" -> 9; "A#", "Bb" -> 10; "B" -> 11; else -> null
        }
    }

    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity
        val song = arguments?.let {
            Song(it.getString("title").orEmpty(), it.getString("artist").orEmpty(), it.getString("genre").orEmpty())
        } ?: Song("Unbekannter Titel")
        val prefs = a.getSharedPreferences("saitenwerk", 0)
        val storageKey = "song_arrangement_${song.title}|${song.artist}"
        val sections = listOf("Gesamter Song", "Intro", "Strophe 1", "Strophe 2", "Strophe 3", "Refrain", "Bridge", "Solo", "Outro")
        var selectedSection = "Gesamter Song"

        val bundledSheet = try {
            val raw = a.assets.open("public_domain_sheets.json").bufferedReader().use { it.readText() }
            val arr = JSONArray(raw)
            (0 until arr.length()).asSequence()
                .map { arr.getJSONObject(it) }
                .firstOrNull { it.optString("title") == song.title && it.optString("artist") == song.artist }
                ?: org.json.JSONObject()
        } catch (_: Exception) { org.json.JSONObject() }

        fun loadSection(name: String): org.json.JSONObject {
            val saved = try {
                org.json.JSONObject(prefs.getString("${storageKey}_$name", "{}") ?: "{}")
            } catch (_: Exception) { org.json.JSONObject() }
            if (saved.optString("content").isNotBlank()) return saved
            if (name == "Gesamter Song" && bundledSheet.optString("content").isNotBlank()) {
                return org.json.JSONObject().put("content", bundledSheet.optString("content"))
                    .put("capo", bundledSheet.optInt("capo", 0))
                    .put("transpose", bundledSheet.optInt("transpose", 0))
                    .put("formatVersion", 4)
            }
            return saved
        }

        val root = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, a.dp(20))
        }
        val back = a.button("‹  Zurück zum Liederbuch")
        back.setOnClickListener { a.openSection(4) }
        root.addView(back, LinearLayout.LayoutParams(-1, a.dp(48)).apply { setMargins(a.dp(16), a.dp(10), a.dp(16), a.dp(8)) })
        root.addView(a.title(song.title))
        root.addView(TextView(a).apply {
            text = listOf(song.artist, song.genre).filter { it.isNotBlank() }.joinToString(" · ")
            textSize = 14f
            setTextColor(a.getColor(R.color.sw_copper))
            setPadding(a.dp(20), 0, a.dp(20), a.dp(10))
        })

        val actions = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        val favorite = a.button(if (SongRepository.isFavorite(a, song)) "★ Favorit" else "☆ Favorit")
        favorite.textSize = 12f
        favorite.setOnClickListener {
            val now = SongRepository.toggleFavorite(a, song)
            favorite.text = if (now) "★ Favorit" else "☆ Favorit"
        }
        val setlist = a.button(if (SongRepository.inSetlist(a, song)) "✓ Setlist" else "＋ Setlist")
        setlist.textSize = 12f
        setlist.setOnClickListener {
            val now = SongRepository.toggleSetlist(a, song)
            setlist.text = if (now) "✓ Setlist" else "＋ Setlist"
        }
        actions.addView(favorite, LinearLayout.LayoutParams(0, a.dp(44), 1f).apply { setMargins(a.dp(16), 0, a.dp(5), 0) })
        actions.addView(setlist, LinearLayout.LayoutParams(0, a.dp(44), 1f).apply { setMargins(a.dp(5), 0, a.dp(16), 0) })
        root.addView(actions)

        val editorCard = a.card()
        val editor = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dp(16), a.dp(16), a.dp(16), a.dp(16))
        }
        editor.addView(TextView(a).apply {
            text = "Songblatt & Arrangement"
            textSize = 21f
            setTextColor(a.getColor(R.color.sw_copper))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        editor.addView(a.body("Liedtext und Akkorde werden zeilenweise gemeinsam gespeichert. Verwende Akkordmarkierungen direkt im Text, zum Beispiel: [C]Hier beginnt die Zeile [G]und hier wechselt der Akkord."))

        editor.addView(TextView(a).apply {
            text = "Abschnitt"
            setTextColor(a.getColor(R.color.sw_text))
            setPadding(0, a.dp(12), 0, a.dp(4))
        })
        val section = Spinner(a).apply {
            adapter = a.spinnerAdapter(sections)
            setSelection(0)
        }
        editor.addView(section, LinearLayout.LayoutParams(-1, a.dp(48)))

        var suppressPersistence = true
        val contentInput = EditText(a).apply {
            hint = "[C]Liedtext beginnt hier [G]Akkordwechsel\n[Am]Nächste Textzeile [F]mit weiterem Wechsel"
            setText(loadSection(selectedSection).optString("content", ""))
            setTextColor(a.getColor(R.color.sw_text))
            setHintTextColor(a.getColor(R.color.sw_muted))
            minLines = 7
            gravity = Gravity.TOP
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setPadding(a.dp(12), a.dp(12), a.dp(12), a.dp(12))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(a.getColor(R.color.sw_surface))
                cornerRadius = a.dp(12).toFloat()
                setStroke(a.dp(1), a.getColor(R.color.sw_surface2))
            }
        }
        editor.addView(TextView(a).apply {
            text = "Liedtext mit Akkorden"
            setTextColor(a.getColor(R.color.sw_text))
            setPadding(0, a.dp(12), 0, a.dp(5))
        })
        editor.addView(contentInput, LinearLayout.LayoutParams(-1, a.dp(190)))

        val capoLabel = TextView(a).apply { setTextColor(a.getColor(R.color.sw_text)); setPadding(0, a.dp(12), 0, 0) }
        val capo = SeekBar(a).apply { max = 12; progress = loadSection(selectedSection).optInt("capo", 0).coerceIn(0, 12) }
        val transposeLabel = TextView(a).apply { setTextColor(a.getColor(R.color.sw_text)); setPadding(0, a.dp(8), 0, 0) }
        val transpose = SeekBar(a).apply { max = 12; progress = (loadSection(selectedSection).optInt("transpose", 0) + 6).coerceIn(0, 12) }
        editor.addView(capoLabel); editor.addView(capo, LinearLayout.LayoutParams(-1, a.dp(40)))
        editor.addView(transposeLabel); editor.addView(transpose, LinearLayout.LayoutParams(-1, a.dp(40)))

        fun persistCurrentSection() {
            val data = org.json.JSONObject().apply {
                put("section", selectedSection)
                put("content", contentInput.text.toString())
                put("capo", capo.progress)
                put("transpose", transpose.progress - 6)
                put("updatedAt", System.currentTimeMillis())
                put("formatVersion", 3)
            }
            prefs.edit().putString("${storageKey}_$selectedSection", data.toString()).apply()
        }

        fun isChordSymbol(token: String): Boolean {
            // Accept common chord qualities and slash bass notes without mistaking ordinary bracketed text for chords.
            val pattern = Regex("^[A-G](?:#|b|♯|♭)?(?:maj|min|m|mi|sus|dim|aug|add|M|Δ|°|ø|[0-9]|\\+|-|\\(|\\)|#|b|♯|♭|,)*(?:/[A-G](?:#|b|♯|♭)?)?$")
            return token.isNotBlank() && pattern.matches(token)
        }

        fun parseLines(raw: String): List<SongLine> {
            val marker = Regex("\\[([^]\\r\\n]{1,16})\\]")
            return raw.lines().map { line ->
                val matches = marker.findAll(line).filter { isChordSymbol(it.groupValues[1].trim()) }.toList()
                if (matches.isEmpty()) SongLine(listOf("" to line), line)
                else {
                    val parts = mutableListOf<Pair<String, String>>()
                    var cursor = 0
                    matches.forEach { match ->
                        val before = line.substring(cursor, match.range.first)
                        if (before.isNotEmpty() && parts.isEmpty()) parts.add("" to before)
                        val nextStart = match.range.last + 1
                        val nextMatch = matches.firstOrNull { it.range.first > match.range.first }
                        val end = nextMatch?.range?.first ?: line.length
                        val lyric = line.substring(nextStart, end)
                        parts.add(match.groupValues[1] to lyric)
                        cursor = end
                    }
                    val plain = parts.joinToString("") { it.second }
                    SongLine(parts, plain)
                }
            }
        }

        fun transposeChord(token: String, semitones: Int): String {
            if (semitones == 0 || token.isBlank()) return token
            val names = listOf("C", "C♯", "D", "D♯", "E", "F", "F♯", "G", "G♯", "A", "A♯", "B")
            fun noteIndex(note: String): Int? = when (note.replace('♯', '#').replace('♭', 'b')) {
                "C" -> 0; "C#", "Db" -> 1; "D" -> 2; "D#", "Eb" -> 3
                "E", "Fb" -> 4; "F", "E#" -> 5; "F#", "Gb" -> 6
                "G" -> 7; "G#", "Ab" -> 8; "A" -> 9; "A#", "Bb" -> 10
                "B", "Cb" -> 11; else -> null
            }
            val match = Regex("^([A-G](?:#|b|♯|♭)?)([^/]*)(?:/([A-G](?:#|b|♯|♭)?))?$").matchEntire(token) ?: return token
            val root = noteIndex(match.groupValues[1]) ?: return token
            val suffix = match.groupValues[2]
            val bassToken = match.groupValues[3]
            val shiftedRoot = names[(root + semitones % 12 + 12) % 12]
            val shiftedBass = if (bassToken.isNotEmpty()) {
                val bass = noteIndex(bassToken) ?: return token
                "/" + names[(bass + semitones % 12 + 12) % 12]
            } else ""
            return shiftedRoot + suffix + shiftedBass
        }

        // Professioneller Lesemodus + Player: der Song wird als synchronisierte
        // Gitarren-Begleitung abgespielt. Die sichtbaren Akkorde folgen der Audiozeit.
        var autoScroll: Boolean = false
        var scrollRunnable: Runnable? = null
        val scrollHandler = Handler(Looper.getMainLooper())
        var lastScrollTime: Long = 0L
        var scrollRemainder: Float = 0f
        var resumeAfterTouch: Boolean = false
        val readerScroll = ScrollView(a).apply {
            setFillViewport(true)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(a.getColor(R.color.sw_surface)); cornerRadius = a.dp(14).toFloat()
            }
        }
        val readerContent = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dp(18), a.dp(18), a.dp(18), a.dp(28))
        }
        readerScroll.addView(readerContent)
        val playerEngine = GuitarPlayerEngine(a)
        var playerPlaying = false
        var playerPrepared = false
        var playerDuration = 0
        var playerTempo = bundledSheet.optInt("tempo", 72).coerceIn(40, 160)
        var playerProgressRunnable: Runnable? = null
        var chordEvents = emptyList<PlayerChordEvent>()
        var activeChordIndex = -1

        fun stopAutoScroll() {
            autoScroll = false
            scrollRunnable?.let { scrollHandler.removeCallbacks(it) }
            scrollRunnable = null
            lastScrollTime = 0L
            scrollRemainder = 0f
        }

        fun highlightChord(index: Int) {
            if (index == activeChordIndex) return
            if (activeChordIndex in chordEvents.indices) {
                chordEvents[activeChordIndex].view.setTextColor(a.getColor(R.color.sw_copper))
                chordEvents[activeChordIndex].view.setBackgroundColor(android.graphics.Color.TRANSPARENT)
                chordEvents[activeChordIndex].view.setPadding(a.dp(4), a.dp(3), a.dp(4), a.dp(3))
            }
            activeChordIndex = index
            if (index in chordEvents.indices) {
                val v = chordEvents[index].view
                v.setTextColor(a.getColor(R.color.sw_navy))
                v.setBackgroundColor(a.getColor(R.color.sw_copper))
                v.setPadding(a.dp(7), a.dp(4), a.dp(7), a.dp(4))
                v.post { readerScroll.smoothScrollTo(0, (v.top - readerScroll.height / 3).coerceAtLeast(0)) }
            }
        }

        fun resetChordHighlight() {
            if (activeChordIndex in chordEvents.indices) {
                val v = chordEvents[activeChordIndex].view
                v.setTextColor(a.getColor(R.color.sw_copper))
                v.setBackgroundColor(android.graphics.Color.TRANSPARENT)
                v.setPadding(a.dp(4), a.dp(3), a.dp(4), a.dp(3))
            }
            activeChordIndex = -1
        }

        fun stopPlayer() {
            playerEngine.stop()
            playerPlaying = false
            playerPrepared = false
            playerProgressRunnable?.let { scrollHandler.removeCallbacks(it) }
            playerProgressRunnable = null
            resetChordHighlight()
        }

        fun startAutoScroll() {
            stopAutoScroll()
            autoScroll = true
            lastScrollTime = android.os.SystemClock.uptimeMillis()
            scrollRemainder = 0f
            scrollRunnable = object : Runnable {
                override fun run() {
                    if (!autoScroll) return
                    if (playerPrepared && playerPlaying) {
                        // Der Player ist die Master-Zeitbasis. Der Reader folgt exakt der Audiozeit,
                        // statt mit einer eigenen Scrollgeschwindigkeit langsam auseinanderzulaufen.
                        val duration = playerDuration.coerceAtLeast(1)
                        val pos = playerEngine.position().coerceIn(0, duration)
                        val maxY = ((readerContent.height - readerScroll.height).coerceAtLeast(0))
                        val target = if (maxY == 0) 0 else ((pos.toDouble() / duration) * maxY).roundToInt()
                        val current = readerScroll.scrollY
                        val step = ((target - current) * 0.34f).roundToInt()
                        readerScroll.scrollTo(0, if (step == 0) target else current + step)
                        if (pos >= duration - 120L) {
                            readerScroll.scrollTo(0, maxY)
                            return
                        }
                    } else {
                        stopAutoScroll()
                        return
                    }
                    scrollHandler.postDelayed(this, 16L)
                }
            }
            scrollHandler.post(scrollRunnable!!)
        }

        fun melodyForSong(title: String, chordTimeline: List<Pair<String, Long>>, tempoBpm: Int): List<PlayerNote> {
            val t = title.lowercase()
            val beat = 60_000L / tempoBpm
            val known: Map<String, List<Int>> = mapOf(
                "alle meine entchen" to listOf(0,1,2,3,4,4,4,4,3,3,3,3,2,2,2,2,1,1,1,1,0,0,0,0),
                "hänschen klein" to listOf(0,1,2,3,4,4,4,1,3,3,3,3,1,2,2,2,0,1,2,3,4,4,4,1),
                "jingle bells" to listOf(2,2,2,2,2,2,2,4,0,1,2,3,3,3,3,3,2,2,2,2,2,1,1,2,1,4),
                "silent night" to listOf(0,1,0,4,3,0,1,0,4,3,0,6,4,3,1,0,4,3,0,1,0,4,3),
                "o tannenbaum" to listOf(0,1,2,3,4,4,4,4,5,5,4,3,2,1,0,1,2,3,4,4,3,2,1,0),
                "amazing grace" to listOf(0,3,5,3,5,4,3,1,0,3,5,3,5,4,3,1,0,3,5,6,5,4,3,1),
                "joy to the world" to listOf(4,3,2,1,0,1,2,3,4,4,4,3,2,1,0,1,2,3,4,4,4,3,2,1),
                "auld lang syne" to listOf(0,0,0,3,4,3,4,6,5,5,4,3,4,1,0,0,3,4,3,4,6,5,5,4,3,4),
                "scarborough fair" to listOf(2,3,4,2,1,0,1,2,3,4,6,4,3,2,0,1,2,3,4,2,1,0),
                "greensleeves" to listOf(2,3,4,6,5,4,2,1,0,1,2,4,3,2,0,1,2,4,5,4,3,2)
            )
            val degrees = known.entries.firstOrNull { t.contains(it.key) }?.value
            val notes = mutableListOf<PlayerNote>()
            if (degrees != null) {
                val minor = t.contains("greensleeves") || t.contains("scarborough fair")
                val scale = if (minor) listOf(0,2,3,5,7,8,10) else listOf(0,2,4,5,7,9,11)
                val base = when {
                    t.contains("jingle bells") -> 64
                    t.contains("amazing grace") -> 67
                    t.contains("greensleeves") || t.contains("scarborough fair") -> 64
                    else -> 60
                }
                degrees.forEachIndexed { i, degree ->
                    val octave = if (i % 16 >= 12) 12 else 0
                    val midi = base + scale[degree.coerceIn(0, 6)] + octave
                    val duration = (beat * if (i % 8 == 7) 1.35 else 0.76).toLong()
                    notes.add(PlayerNote(midi, i * beat, duration, if (i % 8 == 0) 0.82f else 0.70f))
                }
            } else {
                chordTimeline.forEachIndexed { i, pair ->
                    val root = Regex("^([A-G](?:#|b)?)").find(pair.first)?.groupValues?.get(1) ?: "C"
                    val idx = when (root) { "C"->0;"C#"->1;"Db"->1;"D"->2;"D#"->3;"Eb"->3;"E"->4;"F"->5;"F#"->6;"Gb"->6;"G"->7;"G#"->8;"Ab"->8;"A"->9;"A#"->10;"Bb"->10;"B"->11;else->0 }
                    notes.add(PlayerNote(60 + idx, pair.second, (beat * 0.68).toLong(), 0.48f))
                    notes.add(PlayerNote(60 + ((idx + 4) % 12), pair.second + beat, (beat * 0.55).toLong(), 0.34f))
                }
            }
            return notes
        }

        fun buildPlayerTimeline(raw: String): Pair<List<Pair<String, Long>>, List<PlayerNote>> {
            val beat = 60_000L / playerTempo
            var cursor = 0L
            val timeline = mutableListOf<Pair<String, Long>>()
            parseLines(raw).forEach { line ->
                val chords = line.parts.map { it.first }.filter { it.isNotBlank() }
                if (chords.isEmpty()) cursor += beat * 2
                else {
                    val perChord = (beat * 2).coerceAtLeast(beat)
                    chords.forEach { chord -> timeline.add(chord to cursor); cursor += perChord }
                }
            }
            return timeline to melodyForSong(song.title, timeline, playerTempo)
        }

        fun playSong(raw: String, playButton: Button, status: TextView, progress: ProgressBar) {
            if (raw.isBlank()) {
                Toast.makeText(a, "Dieser Song hat noch keinen Inhalt.", Toast.LENGTH_SHORT).show()
                return
            }
            stopPlayer()
            val (timeline, melody) = buildPlayerTimeline(raw)
            val bpm = playerTempo
            status.text = "⏳  Gitarren-Player wird vorbereitet …"
            playButton.isEnabled = false
            progress.setProgress(0)

            playerEngine.play(
                chords = timeline,
                melody = melody,
                tempoBpm = bpm,
                onReady = { duration ->
                    playerPrepared = true
                    playerPlaying = true
                    playerDuration = duration
                    a.runOnUiThread {
                        readerScroll.scrollTo(0, 0)
                        resetChordHighlight()
                        playButton.isEnabled = true
                        playButton.text = "Start"
                        status.text = "🎸  Spielt · ${bpm} BPM · synchron"
                        startAutoScroll()

                        playerProgressRunnable?.let { scrollHandler.removeCallbacks(it) }
                        playerProgressRunnable = object : Runnable {
                            override fun run() {
                                if (!playerPrepared) return
                                val position = playerEngine.position()
                                val durationMs = playerDuration.coerceAtLeast(1)
                                progress.setProgress((position * 100 / durationMs).coerceIn(0, 100))

                                val active = chordEvents.indexOfFirst { position >= it.startMs && position < it.endMs }
                                highlightChord(active)

                                if (playerPlaying) {
                                    scrollHandler.postDelayed(this, 50L)
                                }
                            }
                        }
                        scrollHandler.post(playerProgressRunnable!!)
                    }
                },
                onCompleted = {
                    a.runOnUiThread {
                        playerPlaying = false
                        playerPrepared = false
                        progress.setProgress(100)
                        highlightChord(-1)
                        playButton.isEnabled = true
                        playButton.text = "Start"
                        status.text = "✓  Song beendet"
                        playerProgressRunnable?.let { scrollHandler.removeCallbacks(it) }
                        playerProgressRunnable = null
                    }
                },
                onError = { error ->
                    a.runOnUiThread {
                        playerPlaying = false
                        playerPrepared = false
                        playButton.isEnabled = true
                        playButton.text = "Start"
                        status.text = "Fehler beim Abspielen"
                        progress.setProgress(0)
                        resetChordHighlight()
                        Toast.makeText(a, "Player-Fehler: ${error.message ?: "Unbekannter Fehler"}", Toast.LENGTH_LONG).show()
                    }
                }
            )
        }

        fun renderReader() {
            readerContent.removeAllViews(); chordEvents = emptyList(); activeChordIndex = -1
            val raw = contentInput.text.toString(); val semitones = transpose.progress - 6
            if (raw.isBlank()) { readerContent.addView(a.body("Noch kein Songblatt hinterlegt.")); return }
            val events = mutableListOf<PlayerChordEvent>()
            var fakeTime = 0L
            parseLines(raw).forEach { line ->
                if (line.plainText.isBlank() && line.parts.all { it.first.isBlank() }) {
                    readerContent.addView(TextView(a).apply { text = " "; textSize = 8f }); fakeTime += (60_000L / playerTempo) * 2L
                } else {
                    val row = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
                    val chordCount = line.parts.count { it.first.isNotBlank() }.coerceAtLeast(1)
                    val durationPerChord = (60_000L / playerTempo) * 2L
                    line.parts.forEach { (chord, lyric) ->
                        val segment = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
                        if (chord.isNotBlank()) {
                            val chordView = TextView(a).apply {
                                text = transposeChord(chord, semitones); textSize = 18f
                                setTypeface(typeface, android.graphics.Typeface.BOLD); setTextColor(a.getColor(R.color.sw_copper))
                                setPadding(a.dp(4), a.dp(3), a.dp(4), a.dp(3))
                            }
                            segment.addView(chordView)
                            events.add(PlayerChordEvent(chord, fakeTime, fakeTime + durationPerChord, chordView))
                            fakeTime += durationPerChord
                        }
                        segment.addView(TextView(a).apply {
                            text = if (lyric.isEmpty() && chord.isNotBlank()) " " else lyric
                            textSize = 19f; setTextColor(a.getColor(R.color.sw_text)); setPadding(0, 0, a.dp(5), a.dp(8))
                        })
                        row.addView(segment)
                    }
                    if (chordCount == 0) fakeTime += durationPerChord
                    readerContent.addView(row)
                }
            }
            chordEvents = events
        }
        contentInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                renderReader(); if (!suppressPersistence) persistCurrentSection()
            }
            override fun afterTextChanged(s: Editable?) {}
        })
        capo.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { renderReader(); persistCurrentSection() }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        transpose.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { renderReader(); persistCurrentSection() }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        section.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (sections[position] == selectedSection && contentInput.text.isNotBlank()) return
                persistCurrentSection()
                selectedSection = sections[position]
                val saved = loadSection(selectedSection)
                suppressPersistence = true
                contentInput.setText(saved.optString("content", ""))
                capo.progress = saved.optInt("capo", 0).coerceIn(0, 12)
                transpose.progress = (saved.optInt("transpose", 0) + 6).coerceIn(0, 12)
                suppressPersistence = false
                renderReader()
                stopAutoScroll()
            }
        }
        val save = a.button("Songabschnitt speichern")
        save.setOnClickListener {
            persistCurrentSection()
            Toast.makeText(a, "$selectedSection gespeichert", Toast.LENGTH_SHORT).show()
        }
        editor.addView(save, LinearLayout.LayoutParams(-1, a.dp(48)).apply { topMargin = a.dp(12) })
        editorCard.addView(editor)
        root.addView(editorCard, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(16), a.dp(14), a.dp(16), a.dp(12)) })

        val readerCard = a.card()
        val reader = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(16), a.dp(16), a.dp(16), a.dp(16)) }
        reader.addView(TextView(a).apply {
            text = "🎸  Song Player"
            textSize = 21f; setTextColor(a.getColor(R.color.sw_copper)); setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        reader.addView(a.body("Die Melodie läuft mit einer weichen Gitarrenbegleitung. Der aktuelle Akkord leuchtet exakt an seiner Spielposition auf."))
        val playerStatus = TextView(a).apply { text = "Bereit · Originaltempo ${playerTempo} BPM"; textSize = 13f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0, a.dp(8), 0, a.dp(5)) }
        reader.addView(playerStatus)
        val playerProgress = ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; setProgress(0) }
        reader.addView(playerProgress, LinearLayout.LayoutParams(-1, a.dp(8)))
        val startButton = a.button("Start").apply {
            textSize = 16f
            minHeight = a.dp(52)
        }
        reader.addView(startButton, LinearLayout.LayoutParams(-1, a.dp(52)).apply { topMargin = a.dp(8) })

        startButton.setOnClickListener {
            if (playerPlaying) {
                playerEngine.pause()
                playerPlaying = false
                playerStatus.text = "Ⅱ  Pausiert · ${playerTempo} BPM"
            } else if (playerPrepared) {
                playerEngine.resume()
                playerPlaying = true
                playerStatus.text = "🎸  Spielt · ${playerTempo} BPM · synchron"
                startAutoScroll()
            } else {
                playSong(contentInput.text.toString(), startButton, playerStatus, playerProgress)
            }
        }

        readerScroll.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> { resumeAfterTouch = autoScroll; if (autoScroll) stopAutoScroll() }
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> if (resumeAfterTouch) { resumeAfterTouch = false; if (playerPlaying) startAutoScroll() }
            }
            false
        }
        reader.addView(readerScroll, LinearLayout.LayoutParams(-1, a.dp(420)).apply { topMargin = a.dp(8) })
        readerCard.addView(reader)
        root.addView(readerCard, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(24)) })
        suppressPersistence = false
        renderReader()
        a.lifecycle.addObserver(object : androidx.lifecycle.DefaultLifecycleObserver {
            override fun onDestroy(owner: androidx.lifecycle.LifecycleOwner) {
                stopAutoScroll(); stopPlayer()
            }
        })
        return ScrollView(a).apply { addView(root) }
    }
}
class LearnFragment : Fragment() {
    private var chordTraining: ChordTrainingPanel? = null
    private var rhythmTone: ToneGenerator? = null
    private var rhythmHandler: Handler? = null
    private var rhythmRunning = false
    private var rhythmBeat = 0
    private var rhythmBpm = 80
    override fun onDestroyView() { chordTraining?.stop(); chordTraining = null; stopRhythm(); super.onDestroyView() }

    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity; val prefs = a.getSharedPreferences("saitenwerk", 0)
        val root = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        root.addView(a.title("Lernstudio")); root.addView(a.body("Kurze, praktische Einheiten für Akkorde, Wechsel und Rhythmus. Dein Fortschritt wird auf diesem Gerät gespeichert."))
        val pathButton = a.button("◆  Deinen Lernpfad öffnen")
        pathButton.setOnClickListener { a.openSection(6) }
        root.addView(pathButton, LinearLayout.LayoutParams(-1, a.dp(48)).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(12)) })
        val summary = a.body("Akkord-Quiz: ${prefs.getInt("learn_quiz_correct", 0)} richtige Antworten · ${prefs.getInt("learn_quiz_total", 0)} Versuche").apply { setTextColor(a.getColor(R.color.sw_copper)) }; root.addView(summary)
        val tabs = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; setPadding(a.dp(8), 0, a.dp(8), a.dp(8)) }
        val content = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(14), a.dp(4), a.dp(14), a.dp(24)) }
        val scroll = ScrollView(a).apply { addView(content) }
        fun panel(heading: String, description: String): Pair<MaterialCardView, LinearLayout> {
            val card = a.card(); val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(16), a.dp(16), a.dp(16), a.dp(16)) }
            box.addView(TextView(a).apply { text = heading; textSize = 20f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_copper)) })
            box.addView(a.body(description, 14f)); card.addView(box); return card to box
        }
        fun showQuiz() {
            chordTraining?.stop(); chordTraining = null; stopRhythm(); content.removeAllViews()
            val (card, box) = panel("Akkord-Blitztrainer", "Erkenne Griffbilder und festige die wichtigsten offenen Akkorde.")
            box.addView(TextView(a).apply { text = "Welcher Akkord ist das?"; textSize = 18f; gravity = Gravity.CENTER; setTextColor(a.getColor(R.color.sw_text)) })
            val diagram = FrameLayout(a); box.addView(diagram, LinearLayout.LayoutParams(-1, a.dp(210)))
            val choices = GridLayout(a).apply { columnCount = 2 }; box.addView(choices)
            val feedback = TextView(a).apply { text = "Wähle den passenden Akkord."; gravity = Gravity.CENTER; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0, a.dp(10), 0, a.dp(8)) }; box.addView(feedback)
            val next = a.button("Nächster Akkord"); box.addView(next, LinearLayout.LayoutParams(-1, a.dp(46)))
            var answer = ""; var locked = false
            fun newQuestion() {
                val pool = ChordLibrary.all.filter { it.name in listOf("C", "G", "D", "A", "E", "F", "Am", "Em", "Dm") }
                val shape = pool.random(); answer = shape.name; locked = false; feedback.text = "Wähle den passenden Akkord."; feedback.setTextColor(a.getColor(R.color.sw_muted))
                diagram.removeAllViews(); diagram.addView(ChordDiagramView(a, shape), FrameLayout.LayoutParams(-1, -1)); choices.removeAllViews()
                val options = (listOf(answer) + pool.filter { it.name != answer }.shuffled().take(3).map { it.name }).shuffled()
                options.forEach { option ->
                    val b = a.button(option); b.setOnClickListener {
                        if (!locked) {
                            locked = true; val correct = option == answer; val total = prefs.getInt("learn_quiz_total", 0) + 1
                            val score = prefs.getInt("learn_quiz_correct", 0) + if (correct) 1 else 0
                            prefs.edit().putInt("learn_quiz_total", total).putInt("learn_quiz_correct", score).apply()
                            summary.text = "Akkord-Quiz: $score richtige Antworten · $total Versuche"
                            feedback.text = if (correct) "Richtig! $answer sauber erkannt." else "Noch nicht ganz – gesucht war $answer.\nSchau dir die Fingerpositionen an."
                            feedback.setTextColor(a.getColor(if (correct) R.color.sw_copper else R.color.sw_muted))
                            for (j in 0 until choices.childCount) choices.getChildAt(j).isEnabled = false
                        }
                    }
                    choices.addView(b, GridLayout.LayoutParams().apply { width = 0; height = a.dp(46); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(a.dp(3), a.dp(3), a.dp(3), a.dp(3)) })
                }
            }
            next.setOnClickListener { newQuestion() }; newQuestion(); content.addView(card)
        }
        fun showChanges() {
            stopRhythm(); content.removeAllViews(); content.addView(a.body("Wechsle C · G · Am · F im gleichmäßigen Puls. Starte langsam und steigere das Tempo erst, wenn jeder Griff sauber klingt."))
            chordTraining = ChordTrainingPanel(a); content.addView(chordTraining, LinearLayout.LayoutParams(-1, -2))
        }
        fun showRhythm() {
            chordTraining?.stop(); chordTraining = null; stopRhythm(); content.removeAllViews()
            val (card, box) = panel("Rhythmus & Timing", "Übe einen gleichmäßigen Viertelpuls. Der erste Schlag jedes Taktes wird stärker markiert.")
            val label = TextView(a).apply { text = "Tempo: 80 BPM"; textSize = 17f; setTextColor(a.getColor(R.color.sw_text)) }; box.addView(label)
            val slider = SeekBar(a).apply { max = 110; progress = 30 }; slider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(v: SeekBar?, p: Int, from: Boolean) { rhythmBpm = 50 + p; label.text = "Tempo: $rhythmBpm BPM" }
                override fun onStartTrackingTouch(v: SeekBar?) {}; override fun onStopTrackingTouch(v: SeekBar?) {}
            }); box.addView(slider)
            val beat = TextView(a).apply { text = "Bereit"; textSize = 32f; gravity = Gravity.CENTER; setTextColor(a.getColor(R.color.sw_copper)); setPadding(0, a.dp(12), 0, a.dp(12)) }; box.addView(beat, LinearLayout.LayoutParams(-1, a.dp(72)))
            val start = a.button("Metronom starten"); box.addView(start, LinearLayout.LayoutParams(-1, a.dp(48)))
            start.setOnClickListener {
                if (rhythmRunning) { stopRhythm(); start.text = "Metronom starten"; beat.text = "Pausiert" }
                else {
                    rhythmRunning = true; rhythmBeat = 0; rhythmTone = ToneGenerator(AudioManager.STREAM_MUSIC, 65); rhythmHandler = Handler(Looper.getMainLooper()); start.text = "Metronom stoppen"
                    val task = object : Runnable { override fun run() {
                        if (!rhythmRunning) return
                        val strong = rhythmBeat % 4 == 0; rhythmTone?.startTone(if (strong) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_BEEP, 70)
                        beat.text = if (strong) "1 · TAKT" else "${rhythmBeat % 4 + 1}"; rhythmBeat++
                        rhythmHandler?.postDelayed(this, (60000L / rhythmBpm).coerceAtLeast(100L))
                    } }
                    rhythmHandler?.post(task)
                }
            }
            content.addView(card)
        }
        fun showRoutine() {
            chordTraining?.stop(); chordTraining = null; stopRhythm(); content.removeAllViews()
            val (card, box) = panel("Deine tägliche 10-Minuten-Routine", "Hake die Einheiten ab, wenn du sie erledigt hast. Der Tagesstand wird lokal gespeichert.")
            val day = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.GERMANY).format(java.util.Date())
            if (prefs.getString("learn_routine_day", "") != day) prefs.edit().putString("learn_routine_day", day).putInt("learn_routine_done", 0).apply()
            val tasks = listOf("2 Min. Akkordgriffe sauber aufsetzen", "3 Min. Wechsel C – G – Am – F", "3 Min. Rhythmus mit Metronom", "2 Min. Lieblingssong spielen")
            val progressLabel = TextView(a).apply { setTextColor(a.getColor(R.color.sw_text)) }; box.addView(progressLabel)
            val progress = ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply { max = tasks.size }; box.addView(progress, LinearLayout.LayoutParams(-1, a.dp(10)))
            fun update(mask: Int) { val n = Integer.bitCount(mask); progress.progress = n; progressLabel.text = "Heute erledigt: $n von ${tasks.size}" }
            tasks.forEachIndexed { index, task ->
                val cb = CheckBox(a).apply { text = task; setTextColor(a.getColor(R.color.sw_text)); isChecked = (prefs.getInt("learn_routine_done", 0) and (1 shl index)) != 0 }
                cb.setOnCheckedChangeListener { _, checked ->
                    var mask = prefs.getInt("learn_routine_done", 0); mask = if (checked) mask or (1 shl index) else mask and (1 shl index).inv()
                    prefs.edit().putInt("learn_routine_done", mask).apply(); update(mask)
                }; box.addView(cb)
            }
            update(prefs.getInt("learn_routine_done", 0)); content.addView(card)
        }
        val modes = listOf("Blitztrainer", "Wechsel", "Rhythmus", "Routine")
        val actions = listOf({ showQuiz() }, { showChanges() }, { showRhythm() }, { showRoutine() })
        modes.forEachIndexed { index, label -> val b = a.button(label); b.textSize = 11f; b.setOnClickListener { actions[index]() }; tabs.addView(b, LinearLayout.LayoutParams(0, a.dp(44), 1f).apply { setMargins(a.dp(2), 0, a.dp(2), 0) }) }
        root.addView(tabs); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f)); showQuiz(); return root
    }
    private fun stopRhythm() {
        rhythmRunning = false; rhythmHandler?.removeCallbacksAndMessages(null); rhythmHandler = null
        try { rhythmTone?.stopTone(); rhythmTone?.release() } catch (_: Exception) { }; rhythmTone = null
    }
}

class PathFragment : Fragment() {
    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity; val prefs = a.getSharedPreferences("saitenwerk", 0)
        val root = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        root.addView(a.title("Dein Lernpfad")); root.addView(a.body("Vom ersten Griff bis zum selbstständigen Spielen ganzer Songs. Du bestimmst dein Tempo – dein Fortschritt bleibt auf diesem Gerät gespeichert."))
        val stages = listOf(
            "Erste Akkorde" to "Lerne C, G, D, A, E sowie Am und Em kennen. Ziel: jeden Griff ruhig und einzeln aufsetzen.",
            "Saubere Griffbilder" to "Achte auf gekrümmte Finger, kurze Fingernägel und darauf, dass jede Saite klar klingt.",
            "Flüssige Wechsel" to "Verbinde zwei Akkorde zunächst langsam. Steigere das Tempo erst, wenn der Wechsel sicher sitzt.",
            "Rhythmus festigen" to "Halte einen gleichmäßigen Viertelpuls und übe den Wechsel ohne den Schlagfluss zu unterbrechen.",
            "Erste Songs begleiten" to "Wähle ein einfaches Lied und spiele die Akkordfolge langsam im passenden Takt.",
            "Selbstständig spielen" to "Spiele einen Song vom Anfang bis zum Ende und finde bei Bedarf selbst zurück in den Ablauf."
        )
        val key = "learning_path_done"
        val progressLabel = TextView(a).apply { setTextColor(a.getColor(R.color.sw_copper)); textSize = 17f; setPadding(a.dp(20), a.dp(8), a.dp(20), a.dp(8)) }
        val progress = ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply { max = stages.size }
        root.addView(progressLabel); root.addView(progress, LinearLayout.LayoutParams(-1, a.dp(10)).apply { setMargins(a.dp(20), 0, a.dp(20), a.dp(14)) })
        fun refresh() { val mask = prefs.getInt(key, 0); val count = Integer.bitCount(mask); progress.progress = count; progressLabel.text = "$count von ${stages.size} Lernstufen abgeschlossen · ${count * 100 / stages.size}%" }
        val goalCard = a.card(); val goalBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(16), a.dp(14), a.dp(16), a.dp(14)) }
        goalBox.addView(TextView(a).apply { text = "Mein persönliches Lernziel"; textSize = 19f; setTextColor(a.getColor(R.color.sw_copper)); setTypeface(typeface, 1) })
        val goal = EditText(a).apply { setText(prefs.getString("learning_path_goal", "")); hint = "z. B. In vier Wochen drei Songs begleiten"; setTextColor(a.getColor(R.color.sw_text)); setHintTextColor(a.getColor(R.color.sw_muted)); minLines = 2 }
        goalBox.addView(goal)
        val save = a.button("Lernziel speichern"); save.setOnClickListener { prefs.edit().putString("learning_path_goal", goal.text.toString().trim()).apply(); Toast.makeText(a, "Lernziel gespeichert", Toast.LENGTH_SHORT).show() }
        goalBox.addView(save); goalCard.addView(goalBox); root.addView(goalCard, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(14)) })
        val next = a.body("").apply { textSize = 16f; setTextColor(a.getColor(R.color.sw_text)) }; root.addView(next)
        val checks = mutableListOf<CheckBox>()
        stages.forEachIndexed { index, stage ->
            val card = a.card(); val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(14), a.dp(12), a.dp(14), a.dp(12)) }
            box.addView(TextView(a).apply { text = "${index + 1}. ${stage.first}"; textSize = 18f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_text)) })
            box.addView(a.body(stage.second, 14f))
            val check = CheckBox(a).apply { text = "Lernstufe abgeschlossen"; setTextColor(a.getColor(R.color.sw_text)); isChecked = (prefs.getInt(key, 0) and (1 shl index)) != 0 }; checks.add(check)
            check.setOnCheckedChangeListener { _, checked ->
                var mask = prefs.getInt(key, 0); mask = if (checked) mask or (1 shl index) else mask and (1 shl index).inv(); prefs.edit().putInt(key, mask).apply(); refresh()
                val first = stages.indices.firstOrNull { (mask and (1 shl it)) == 0 }; next.text = if (first == null) "Geschafft! Alle Lernstufen sind abgeschlossen." else "Dein nächster Schritt: ${stages[first].first}"
            }
            box.addView(check); val practice = a.button("Im Lernstudio üben"); practice.setOnClickListener { a.openSection(5) }; box.addView(practice)
            card.addView(box); root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(16), a.dp(5), a.dp(16), a.dp(5)) })
        }
        val reset = a.button("Lernpfad zurücksetzen"); reset.setOnClickListener { prefs.edit().putInt(key, 0).apply(); checks.forEach { it.isChecked = false }; refresh(); next.text = "Dein nächster Schritt: ${stages.first().first}"; Toast.makeText(a, "Lernpfad zurückgesetzt", Toast.LENGTH_SHORT).show() }
        root.addView(reset, LinearLayout.LayoutParams(-1, a.dp(48)).apply { setMargins(a.dp(16), a.dp(12), a.dp(16), a.dp(24)) })
        refresh(); val mask = prefs.getInt(key, 0); val first = stages.indices.firstOrNull { (mask and (1 shl it)) == 0 }; next.text = if (first == null) "Geschafft! Alle Lernstufen sind abgeschlossen." else "Dein nächster Schritt: ${stages[first].first}"
        return ScrollView(a).apply { addView(root) }
    }
}
