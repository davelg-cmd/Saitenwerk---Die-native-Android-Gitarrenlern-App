package de.saitenwerk.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

private data class LayoutToken(val text:String,val x:Float,val y:Float,val width:Float,val height:Float,val fontSize:Float=0f,val fontName:String="")
private data class LayoutLine(val text:String,val x:Float,val y:Float,val height:Float,val fontSize:Float,val fontName:String,val tokens:List<LayoutToken>)
private data class LayoutPage(val number:Int,val width:Float,val height:Float,val lines:List<LayoutLine>)

internal object SongbookLayoutImporter {
    @Volatile var lastDiagnostic:String = "Noch kein Diagnosebericht vorhanden."

    fun importPdf(context:Context, uri:Uri, source:String, progress:(String,Int,Int)->Unit = {_,_,_->}) :List<SongbookSong> {
        // pdfbox-android muss seine Android-Assets initialisieren, bevor PDFTextStripper
        // oder LegacyPDFStreamEngine erstmals geladen werden.
        PDFBoxResourceLoader.init(context.applicationContext)
        val resolver=context.contentResolver
        val descriptor=resolver.openFileDescriptor(uri,"r") ?: error("PDF-Datei konnte nicht geöffnet werden.")
        val renderer=PdfRenderer(descriptor)
        val recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        try {
            val pages=resolver.openInputStream(uri).use { input ->
                if(input==null) error("PDF-Datei konnte nicht gelesen werden.")
                PDDocument.load(input).use { document ->
                    val result=mutableListOf<LayoutPage>()
                    val totalPages=document.numberOfPages
                    progress("PDF wird analysiert…",0,totalPages)
                    for(index in 0 until totalPages) {
                        progress("Seite ${index+1} von $totalPages wird analysiert…",index+1,totalPages)
                        val page=document.getPage(index)
                        val pageWidth=page.mediaBox.width.coerceAtLeast(1f)
                        val pageHeight=page.mediaBox.height.coerceAtLeast(1f)
                        val stripper=object:PDFTextStripper() {
                            val positions=mutableListOf<TextPosition>()
                            override fun writeString(text:String, textPositions:MutableList<TextPosition>) {
                                positions.addAll(textPositions)
                            }
                        }
                        stripper.sortByPosition=true
                        stripper.startPage=index+1
                        stripper.endPage=index+1
                        stripper.getText(document)
                        var tokens=stripper.positions.mapNotNull { p ->
                            val value=p.unicode?.replace(Regex("""\s+"""),"") ?: ""
                            if(value.isBlank()) null else LayoutToken(
                                value,p.xDirAdj.coerceAtLeast(0f),p.yDirAdj.coerceAtLeast(0f),
                                p.widthDirAdj.coerceAtLeast(0.1f),p.heightDir.coerceAtLeast(1f),
                                p.fontSizeInPt.coerceAtLeast(1f),p.font?.name.orEmpty()
                            )
                        }
                        val extractedChars=tokens.sumOf{it.text.length}
                        if(extractedChars<18) {
                            val ocrTokens=mutableListOf<LayoutToken>()
                            val bitmapPage=renderer.openPage(index)
                            try {
                                val bitmap=Bitmap.createBitmap(
                                    max(1,bitmapPage.width*2),max(1,bitmapPage.height*2),Bitmap.Config.ARGB_8888
                                )
                                try {
                                    bitmapPage.render(bitmap,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                    val recognized=Tasks.await(recognizer.process(InputImage.fromBitmap(bitmap,0)))
                                    recognized.textBlocks.forEach { block ->
                                        block.lines.forEach { line ->
                                            line.elements.forEach { element ->
                                                val bounds=element.boundingBox ?: return@forEach
                                                val scaleX=pageWidth/bitmap.width
                                                val scaleY=pageHeight/bitmap.height
                                                ocrTokens += LayoutToken(
                                                    element.text,
                                                    bounds.left*scaleX,bounds.top*scaleY,
                                                    bounds.width()*scaleX,bounds.height()*scaleY,
                                                    (bounds.height()*scaleY).coerceAtLeast(1f),"OCR"
                                                )
                                            }
                                        }
                                    }
                                } finally { bitmap.recycle() }
                            } finally { bitmapPage.close() }
                            if(ocrTokens.sumOf{it.text.length}>extractedChars) tokens=ocrTokens
                        }
                        result += LayoutPage(index+1,pageWidth,pageHeight,groupLines(tokens))
                    }
                    result
                }
            }
            val songs=SongbookLayoutParser.parse(pages,source)
            lastDiagnostic=buildString {
                appendLine("SAITENWERK PDF-DIAGNOSE")
                appendLine("Seiten gesamt: ${pages.size}")
                appendLine("Erkannte Songs: ${songs.size}")
                appendLine("Auswertung der ersten ${min(10,pages.size)} Seiten:")
                pages.take(10).forEach { page ->
                    appendLine("\n--- PDF-Seite ${page.number} | Zeilen: ${page.lines.size} | Zeichen: ${page.lines.sumOf{it.text.length}} ---")
                    page.lines.take(24).forEachIndexed { index,line ->
                        appendLine(String.format(Locale.US,"%02d | y=%.1f | x=%.1f | Schrift=%.1f | %s",index+1,line.y,line.x,line.fontSize,line.text.take(180)))
                    }
                }
                appendLine("\nHinweis: Der Bericht enthält nur Textauszüge der ersten zehn Seiten.")
            }
            return songs
        } finally {
            recognizer.close()
            renderer.close()
            descriptor.close()
        }
    }

    private fun groupLines(tokens:List<LayoutToken>):List<LayoutLine> {
        if(tokens.isEmpty()) return emptyList()
        val sorted=tokens.sortedWith(compareBy<LayoutToken>{it.y}.thenBy{it.x})
        val rows=mutableListOf<MutableList<LayoutToken>>()
        sorted.forEach { token ->
            val row=rows.lastOrNull()
            val avg=row?.map{it.height}?.average()?.toFloat() ?: token.height
            if(row==null || abs(row.map{it.y}.average().toFloat()-token.y)>max(2.5f,avg*0.42f))
                rows += mutableListOf(token)
            else row += token
        }
        return rows.map { row ->
            val ordered=row.sortedBy{it.x}
            val words=mutableListOf<MutableList<LayoutToken>>()
            ordered.forEach { token ->
                val word=words.lastOrNull()
                val previous=word?.lastOrNull()
                if(word==null || previous==null || token.x-(previous.x+previous.width)>max(1.8f,previous.height*0.22f))
                    words += mutableListOf(token)
                else word += token
            }
            val wordTokens=words.map { chars ->
                LayoutToken(chars.joinToString(""){it.text},chars.first().x,
                    chars.map{it.y}.average().toFloat(),
                    (chars.last().x+chars.last().width-chars.first().x).coerceAtLeast(0.1f),
                    chars.map{it.height}.average().toFloat(),
                    chars.map{it.fontSize}.average().toFloat(),
                    chars.first().fontName)
            }
            val text=wordTokens.joinToString(" "){it.text}.trim()
            LayoutLine(text,wordTokens.minOf{it.x},wordTokens.map{it.y}.average().toFloat(),
                wordTokens.map{it.height}.average().toFloat(),
                wordTokens.map{it.fontSize}.maxOrNull() ?: 0f,
                wordTokens.firstOrNull()?.fontName.orEmpty(),wordTokens)
        }.filter{it.text.isNotBlank()}
    }
}

private object SongbookLayoutParser {
    private val chord=Regex("""^[A-G](?:#|b)?(?:maj(?:7|9|11|13)?|m(?:aj7|7|9|11|13)?|sus[24]?|add9|dim7?|aug|[0-9]{1,2})?(?:/[A-G](?:#|b)?)?$""")
    private val toc=Regex("""\s*(?:\.{2,}|…{1,})\s*\d{1,4}\s*$""")
    private fun isChordLine(line:LayoutLine)=line.tokens.isNotEmpty() &&
        line.tokens.all { chord.matches(it.text.trim(',',':',';','|')) } &&
        line.tokens.size<=18
    private fun letters(s:String)=s.count{it.isLetter()}
    private fun cleanTitle(s:String)=s.trim().trim('#','*','-','♪','♫',' ').replace(Regex("""\s+""")," ")
    private fun titleCandidate(page:LayoutPage,index:Int,median:Float):Boolean {
        val line=page.lines[index]
        val text=cleanTitle(line.text)
        if(text.length !in 3..100 || letters(text)<3 || isChordLine(line) || toc.containsMatchIn(text)) return false
        if(Regex("""(?i)^(seite|page|inhalt|inhaltsverzeichnis|index|copyright|www\.)""").containsMatchIn(text)) return false
        if(text.matches(Regex("""\d{1,4}.*"""))) return false
        if(text.count{it in ".!?;:"}>=3 && text.length>35) return false
        if(text.split(Regex("""\s+""")).size>14 && text.length>70) return false

        val prev=page.lines.getOrNull(index-1)
        val next=page.lines.getOrNull(index+1)
        val gapBefore=prev?.let{line.y-(it.y+it.height)} ?: line.y
        val gapAfter=next?.let{it.y-(line.y+line.height)} ?: line.height
        // Nur klar hervorgehobene Überschriften akzeptieren. Versalien allein
        // sind in Gitarren-Liederbüchern häufig normale Liedtextzeilen.
        val large=line.fontSize>=median*1.25f
        val bold=Regex("""(?i)(bold|black|demi|heavy|semibold)""").containsMatchIn(line.fontName)
        val atTop=line.y<page.height*0.10f

        var following=0
        var chordFollowing=0
        for(k in 1..min(6,page.lines.size-index-1)){
            val n=page.lines[index+k]
            if(isChordLine(n)) chordFollowing++ else if(letters(n.text)>=8) following++
        }
        val songBody=(following>=1 && (chordFollowing>=1 || following>=2))
        // Ein Liedtitel muss sich nicht nur inhaltlich, sondern auch typografisch
        // vom Liedtext abheben. Die frühere Regel zählte "Großbuchstaben" und
        // "Seitenanfang" als gleichwertige Signale. Dadurch wurden bei manchen
        // Songbooks viele normale Textzeilen als neue Titel erkannt.
        // Ein echter Titel muss sich sichtbar vom Fließtext abheben.
        // Großschreibung allein reicht nicht: In vielen Songbooks stehen
        // normale Liedzeilen ebenfalls komplett in Versalien.
        val nextIsChord=page.lines.getOrNull(index+1)?.let{isChordLine(it)}==true
        val strongGapBefore=gapBefore>median*1.25f
        val strongGapAfter=gapAfter>median*0.75f
        val shortEnough=text.length<=70 && text.split(Regex("""\s+""")).size<=10
        val titleShape=!text.endsWith(".") && !text.endsWith(",") && !text.endsWith(":") &&
            !text.matches(Regex("""(?i).*[!?].*[!?].*"""))
        val styleSignal=large || bold
        // Innerhalb einer Seite braucht ein Titel Abstand vor UND nach sich.
        // Am Seitenanfang genügt die deutliche typografische Hervorhebung plus
        // Abstand zum folgenden Inhalt. Ein nachfolgender Akkordblock stützt
        // die Erkennung, ersetzt aber niemals die Titel-Hervorhebung.
        val structurallySeparated =
            (strongGapBefore && strongGapAfter && styleSignal) ||
            (atTop && strongGapAfter && styleSignal)
        val supportedSongStart = songBody && (nextIsChord || following>=2)
        return supportedSongStart && shortEnough && titleShape && structurallySeparated
    }

    private fun Boolean.toInt():Int=if(this)1 else 0
    fun parse(pages:List<LayoutPage>,source:String):List<SongbookSong> {
        if(pages.isEmpty()) return emptyList()
        val rawStarts=mutableListOf<Pair<Int,Int>>()
        pages.forEachIndexed { pi,page ->
            val median=(page.lines.map{it.height}.sorted().let{it.getOrNull(it.size/2)} ?: 8f).coerceAtLeast(1f)
            page.lines.indices.forEach { li ->
                if(titleCandidate(page,li,median)) rawStarts += pi to li
            }
        }

        // Repeated running headers/footers are not songs. Remove candidate texts that
        // occur on several different pages before segmenting the book.
        val repeated=rawStarts.groupBy { cleanTitle(pages[it.first].lines[it.second].text).lowercase(Locale.ROOT) }
            .filter { (_,v)->v.map{it.first}.distinct().size>=3 }.keys
        val starts=rawStarts.filter { (pi,li)->
            cleanTitle(pages[pi].lines[li].text).lowercase(Locale.ROOT) !in repeated
        }.toMutableList()

        if(starts.size<2) return emptyList()
        val songs=mutableListOf<SongbookSong>()
        starts.forEachIndexed { si,pair ->
            val (pageIndex,lineIndex)=pair
            val end=starts.getOrNull(si+1)
            val collected=mutableListOf<Pair<LayoutPage,LayoutLine>>()
            for(pi in pageIndex..(end?.first ?: pages.lastIndex)) {
                val page=pages[pi]
                val from=if(pi==pageIndex) lineIndex else 0
                val until=if(end!=null && pi==end.first) end.second else page.lines.size
                if(from<until) page.lines.subList(from,until).forEach{collected += page to it}
            }
            if(collected.size<3) return@forEachIndexed
            val title=cleanTitle(collected.first().second.text).take(120)
            val body=mutableListOf<String>()
            val allChords=linkedSetOf<String>()
            var pending=mutableListOf<LayoutToken>()
            var pendingY=0f
            collected.drop(1).forEachIndexed { index,item ->
                val (page,line)=item
                if(isChordLine(line)) {
                    if(pending.isEmpty()) pendingY=line.y
                    pending.addAll(line.tokens)
                } else {
                    val chordTokens=if(pending.isNotEmpty() && (line.y-pendingY)<max(18f,line.height*2.2f)) pending else mutableListOf()
                    val placements=chordTokens.mapNotNull { token ->
                        val value=token.text.trim(',',':',';','|')
                        if(!chord.matches(value)) null else {
                            allChords += value
                            val x=(token.x/page.width).coerceIn(0f,0.98f)
                            "$value@"+String.format(Locale.US,"%.3f",x)
                        }
                    }
                    val marker=if(placements.isEmpty()) "" else "[[CHORDS:"+placements.joinToString(",")+"]]"
                    body += marker+line.text
                    pending.clear()
                }
            }
            val lyrics=body.joinToString("\n").trim()
            if(letters(title)>=3 && lyrics.count{it.isLetter()}>=30) {
                val fingerprint=title.lowercase(Locale.ROOT)
                if(songs.none{it.title.lowercase(Locale.ROOT)==fingerprint}) {
                    songs += SongbookSong(title=title,artist="Unbekannter Künstler",lyrics=lyrics,
                        chords=allChords.toList(),source=source)
                }
            }
        }
        return songs
    }
}
