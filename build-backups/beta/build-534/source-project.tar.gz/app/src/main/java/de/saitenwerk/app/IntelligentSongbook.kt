package de.saitenwerk.app

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.net.Uri
import android.provider.OpenableColumns
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import com.google.android.gms.common.api.Scope
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import androidx.activity.result.IntentSenderRequest
import android.app.Activity
import androidx.fragment.app.Fragment
import org.json.JSONArray
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.util.Locale
import java.util.concurrent.Executors
import java.util.regex.Pattern

data class SongbookSong(
    val id: Long = 0,
    val title: String,
    val artist: String,
    val lyrics: String,
    val chords: List<String>,
    val source: String,
    val youtubeId: String? = null,
    val youtubeConfidence: Int = 0
)

data class ImportedSongbookPdf(
    val uri: String,
    val displayName: String,
    val importedAt: Long,
    val songCount: Int
)

class SongbookDb(context: Context) {
    private val db = context.openOrCreateDatabase("saitenwerk_songbook.db", Context.MODE_PRIVATE, null)
    init {
        db.execSQL("""CREATE TABLE IF NOT EXISTS songs(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            artist TEXT NOT NULL,
            lyrics TEXT NOT NULL,
            chords TEXT NOT NULL,
            source TEXT NOT NULL,
            youtube_id TEXT,
            youtube_confidence INTEGER NOT NULL DEFAULT 0,
            UNIQUE(title, artist)
        )""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS imported_pdfs(
            uri TEXT PRIMARY KEY,
            display_name TEXT NOT NULL,
            imported_at INTEGER NOT NULL,
            song_count INTEGER NOT NULL DEFAULT 0
        )""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS song_pdf_sources(
            song_id INTEGER NOT NULL,
            pdf_uri TEXT NOT NULL,
            PRIMARY KEY(song_id, pdf_uri)
        )""")
        db.execSQL("INSERT OR IGNORE INTO song_pdf_sources(song_id,pdf_uri) SELECT id,source FROM songs WHERE source IS NOT NULL AND source <> ''")
    }
    fun registerPdf(uri: String, displayName: String, songCount: Int) {
        val cv = android.content.ContentValues().apply {
            put("uri", uri); put("display_name", displayName)
            put("imported_at", System.currentTimeMillis()); put("song_count", songCount)
        }
        db.insertWithOnConflict("imported_pdfs", null, cv, android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun importedPdfs(): List<ImportedSongbookPdf> {
        val out = mutableListOf<ImportedSongbookPdf>()
        db.rawQuery("SELECT uri,display_name,imported_at,song_count FROM imported_pdfs ORDER BY imported_at DESC", null).use { c ->
            while (c.moveToNext()) out += ImportedSongbookPdf(c.getString(0), c.getString(1), c.getLong(2), c.getInt(3))
        }
        return out
    }
    fun removePdf(uri: String): Int {
        db.beginTransaction()
        try {
            db.delete("song_pdf_sources", "pdf_uri=?", arrayOf(uri))
            val removed = db.delete("songs", "id NOT IN (SELECT song_id FROM song_pdf_sources)", null)
            db.delete("imported_pdfs", "uri=?", arrayOf(uri))
            db.setTransactionSuccessful()
            return removed
        } finally { db.endTransaction() }
    }
    fun upsert(song: SongbookSong): Long {
        val cv = android.content.ContentValues().apply {
            put("title", song.title); put("artist", song.artist); put("lyrics", song.lyrics)
            put("chords", JSONArray(song.chords).toString()); put("source", song.source)
            put("youtube_id", song.youtubeId); put("youtube_confidence", song.youtubeConfidence)
        }
        val existing = db.rawQuery("SELECT id FROM songs WHERE lower(title)=lower(?) AND lower(artist)=lower(?)",
            arrayOf(song.title, song.artist))
        val id = if (existing.moveToFirst()) {
            val value = existing.getLong(0); existing.close()
            db.update("songs", cv, "id=?", arrayOf(value.toString())); value
        } else {
            existing.close(); db.insertOrThrow("songs", null, cv)
        }
        db.execSQL("INSERT OR IGNORE INTO song_pdf_sources(song_id,pdf_uri) VALUES(?,?)", arrayOf(id, song.source))
        return id
    }
    fun all(): List<SongbookSong> {
        val out = mutableListOf<SongbookSong>()
        db.rawQuery("SELECT id,title,artist,lyrics,chords,source,youtube_id,youtube_confidence FROM songs ORDER BY title COLLATE NOCASE", null).use { c ->
            while (c.moveToNext()) {
                val chords = mutableListOf<String>()
                runCatching { val a=JSONArray(c.getString(4)); for(i in 0 until a.length()) chords += a.getString(i) }
                out += SongbookSong(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), chords, c.getString(5),
                    if(c.isNull(6)) null else c.getString(6), c.getInt(7))
            }
        }
        return out
    }
}

object SongbookParser {
    private val chordPattern = Pattern.compile("""(?<![A-Za-z0-9])([A-G](?:#|b)?(?:maj(?:7|9|11|13)?|m(?:aj7|7|9|11|13)?|m9|sus[24]?|add9|dim7?|aug|[0-9]{1,2})?(?:/[A-G](?:#|b)?)?)(?![A-Za-z0-9])""")

    fun parse(text: String, source: String): List<SongbookSong> {
        val clean = text.filter { it.code != 0 }.trim()
        if (clean.isBlank()) return emptyList()
        val pageBlocks = clean.split(Regex("""\[\[SAITENWERK_SEITE_\d+]]""")).map { it.trim() }.filter { it.isNotBlank() }
        val candidates = mutableListOf<String>()
        for (page in pageBlocks) {
            val sections = page.split(Regex("""
\s*
\s*
+""")).map { it.trim() }.filter { it.length >= 24 }
            if (sections.isEmpty()) candidates += page else candidates += sections
        }
        val songs = mutableListOf<SongbookSong>()
        val used = HashSet<String>()
        for (block in candidates) {
            val lines = block.lines().map { it.trim().replace(Regex("""\s{2,}"""), " ") }.filter { it.isNotBlank() }
            if (lines.isEmpty()) continue
            val titleIndex = lines.indexOfFirst { line ->
                val normalized = line.trim('#','*','-',' ').trim()
                normalized.length in 2..120 && normalized.count { it.isLetter() } >= 2 &&
                    !looksLikeChordLine(normalized) && !normalized.matches(Regex("""(?i)seite\s+\d+"""))
            }
            if (titleIndex < 0) continue
            val title = lines[titleIndex].trim('#','*','-',' ').trim().take(120)
            val artist = lines.drop(titleIndex + 1).firstOrNull { line ->
                line.length in 2..100 && !looksLikeChordLine(line) &&
                    !line.startsWith("[") && line.count { it.isLetter() } >= 2
            }?.trim() ?: "Unbekannter Künstler"
            val chords = linkedSetOf<String>()
            lines.forEach { line ->
                val matcher = chordPattern.matcher(line)
                while (matcher.find()) {
                    val chord = matcher.group(1)
                    if (isPlausibleChord(chord)) chords += chord
                }
            }
            val key = title.lowercase(Locale.ROOT) + "|" + artist.lowercase(Locale.ROOT)
            if (used.add(key)) songs += SongbookSong(
                title = title, artist = artist, lyrics = block,
                chords = chords.toList(), source = source
            )
        }
        if (songs.isEmpty()) {
            val lyrics = pageBlocks.joinToString(System.lineSeparator() + System.lineSeparator()).trim()
            val title = lyrics.lines().firstOrNull { it.trim().length >= 2 }?.trim()?.take(120) ?: "Importiertes Lied"
            val chords = linkedSetOf<String>()
            val matcher = chordPattern.matcher(lyrics)
            while (matcher.find()) if (isPlausibleChord(matcher.group(1))) chords += matcher.group(1)
            if (lyrics.length >= 20) songs += SongbookSong(
                title = title, artist = "Unbekannter Künstler", lyrics = lyrics,
                chords = chords.toList(), source = source
            )
        }
        return songs
    }

    private fun isPlausibleChord(value: String): Boolean =
        value.length <= 8 && value.firstOrNull() in listOf('A','B','C','D','E','F','G')

    private fun looksLikeChordLine(line: String): Boolean {
        val words = line.trim().split(Regex("""\s+""")).filter { it.isNotBlank() }
        if (words.isEmpty()) return false
        val matches = words.count { word ->
            val matcher = chordPattern.matcher(word.trim(',', ';', ':', '.', '|'))
            matcher.matches() && isPlausibleChord(matcher.group(1))
        }
        return matches >= maxOf(1, (words.size + 1) / 2)
    }
}

class SongbookFragment : Fragment() {
    private lateinit var root: LinearLayout
    private lateinit var db: SongbookDb
    private val executor = Executors.newSingleThreadExecutor()
    private val youtubePrefs by lazy {
        requireContext().getSharedPreferences("saitenwerk_youtube", Context.MODE_PRIVATE)
    }
    private var youtubeAccessToken: String? = null
    private var youtubeConnected = false
    private var youtubeChannelName: String? = null
    private val youtubeAuthLauncher =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
            if (result.resultCode != Activity.RESULT_OK) {
                Toast.makeText(requireContext(), "YouTube-Verbindung abgebrochen.", Toast.LENGTH_SHORT).show()
                return@registerForActivityResult
            }
            try {
                val authorizationResult =
                    Identity.getAuthorizationClient(requireContext())
                        .getAuthorizationResultFromIntent(result.data)
                youtubeAccessToken = authorizationResult.accessToken
                youtubeConnected = !youtubeAccessToken.isNullOrBlank()
                if (!youtubeConnected) {
                    Toast.makeText(requireContext(), "Keine YouTube-Berechtigung erhalten.", Toast.LENGTH_LONG).show()
                    return@registerForActivityResult
                }
                youtubePrefs.edit().putBoolean("connected", true).apply()
                fetchYoutubeChannel()
            } catch (e: ApiException) {
                Toast.makeText(requireContext(), "YouTube-Autorisierung fehlgeschlagen: ${e.statusCode}", Toast.LENGTH_LONG).show()
            } catch (t: Throwable) {
                Toast.makeText(requireContext(), "YouTube-Autorisierung fehlgeschlagen.", Toast.LENGTH_LONG).show()
            }
        }

    private val importPdf = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importPdf(uri)
    }

    override fun onCreateView(inflater: android.view.LayoutInflater, container: ViewGroup?, state: Bundle?): View {
        db = SongbookDb(requireContext())
        youtubeConnected = youtubePrefs.getBoolean("connected", false)
        youtubeChannelName = youtubePrefs.getString("channel_name", null)
        root = LinearLayout(requireContext()).apply {
            orientation=LinearLayout.VERTICAL
            setPadding(dp(18),dp(12),dp(18),dp(24))
            setBackgroundColor(Color.rgb(15,16,19))
        }
        buildHome()
        return root
    }

    private fun buildHome() {
        root.removeAllViews()
        addText("SONGBOOK", 30f, Color.WHITE, 8)
        addText("Deine Songs. Deine Akkorde. Dein Training.", 15f, Color.LTGRAY, 2)
        val stats = db.all()
        val stat = card()
        val row = LinearLayout(requireContext()).apply { orientation=LinearLayout.HORIZONTAL }
        stat.addView(label("MEINE SONGS\n" + stats.size, 18f, Color.WHITE), LinearLayout.LayoutParams(0,dp(72),1f))
        stat.addView(label(stats.sumOf{it.chords.size}.toString() + " AKKORDE\nverknüpft", 18f, Color.WHITE), LinearLayout.LayoutParams(0,dp(72),1f))
        root.addView(stat)
        val import = button("＋  PDF analysieren & Songs importieren")
        import.setOnClickListener { importPdf.launch(arrayOf("application/pdf")) }
        root.addView(import)
        val pdfs = db.importedPdfs()
        if (pdfs.isNotEmpty()) {
            addText("MEINE IMPORTIERTEN PDFS", 13f, Color.rgb(205,145,91), 2)
            pdfs.forEach { pdf ->
                val pdfCard = card()
                pdfCard.addView(label("▤  " + pdf.displayName, 16f, Color.WHITE))
                pdfCard.addView(label(pdf.songCount.toString() + " erkannte Songs", 12f, Color.LTGRAY))
                val remove = button("PDF aus Songbook entfernen")
                remove.setOnClickListener {
                    AlertDialog.Builder(requireContext())
                        .setTitle("Importiertes PDF entfernen?")
                        .setMessage("\"${pdf.displayName}\" und die ausschließlich daraus importierten Songs werden aus SaitenWerk entfernt. Die Originaldatei auf deinem Gerät bleibt erhalten.")
                        .setNegativeButton("Abbrechen", null)
                        .setPositiveButton("Entfernen") { _, _ ->
                            db.removePdf(pdf.uri)
                            runCatching {
                                requireContext().contentResolver.releasePersistableUriPermission(
                                    Uri.parse(pdf.uri), Intent.FLAG_GRANT_READ_URI_PERMISSION
                                )
                            }
                            buildHome()
                            Toast.makeText(requireContext(), "PDF und zugehörige Songs entfernt.", Toast.LENGTH_LONG).show()
                        }.show()
                }
                pdfCard.addView(remove)
                root.addView(pdfCard)
            }
        }
        val youtube = button(if (youtubeConnected) {
            "✓ YouTube verbunden" + (youtubeChannelName?.let { " · $it" } ?: "")
        } else {
            "▶ YouTube verbinden"
        })
        youtube.setOnClickListener {
            if (youtubeConnected) {
                AlertDialog.Builder(requireContext())
                    .setTitle("YouTube verbunden")
                    .setMessage(
                        "Saitenwerk ist für dein YouTube-Konto autorisiert. " +
                        "Die App nutzt die Berechtigung nur für YouTube-Funktionen im Songbook."
                    )
                    .setNegativeButton("Verbindung lokal trennen") {
                        _, _ ->
                        youtubeAccessToken = null
                        youtubeConnected = false
                        youtubeChannelName = null
                        youtubePrefs.edit().clear().apply()
                        buildHome()
                    }
                    .setPositiveButton("OK", null)
                    .show()
            } else {
                authorizeYoutube()
            }
        }
        root.addView(youtube)

        val search = EditText(requireContext()).apply {
            hint="Song oder Künstler suchen"; setSingleLine(); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            setPadding(dp(16),0,dp(16),0); inputType=InputType.TYPE_CLASS_TEXT
            setBackgroundColor(Color.rgb(31,33,38))
        }
        root.addView(search, LinearLayout.LayoutParams(-1,dp(52)).apply { topMargin=dp(12); bottomMargin=dp(10) })
        val list = LinearLayout(requireContext()).apply { orientation=LinearLayout.VERTICAL }
        root.addView(list)
        fun refresh(q:String="") {
            list.removeAllViews()
            db.all().filter { q.isBlank() || (it.title + " " + it.artist).contains(q,true) }.take(100).forEach { song ->
                val c=card()
                c.addView(label(song.title,19f,Color.WHITE))
                c.addView(label(song.artist + "  •  " + song.chords.size + " Akkorde",13f,Color.LTGRAY))
                val actions=LinearLayout(requireContext()).apply { orientation=LinearLayout.HORIZONTAL }
                val open=button("Öffnen"); open.setOnClickListener{showSong(song)}
                val yt=button(if(song.youtubeId==null) "YouTube suchen" else "▶ YouTube")
                yt.setOnClickListener { openYoutube(song) }
                actions.addView(open,LinearLayout.LayoutParams(0,dp(48),1f))
                actions.addView(yt,LinearLayout.LayoutParams(0,dp(48),1f))
                c.addView(actions); list.addView(c)
            }
        }
        search.addTextChangedListener(SimpleTextWatcher { refresh(it) })
        refresh()
    }

    private fun showSong(song: SongbookSong) {
        root.removeAllViews()
        val back=button("‹  Songbook"); back.setOnClickListener{buildHome()}; root.addView(back)
        addText(song.title,27f,Color.WHITE,4); addText(song.artist,15f,Color.LTGRAY,8)
        val meta=card()
        meta.addView(label("Akkorde",12f,Color.GRAY))
        meta.addView(label(if(song.chords.isEmpty()) "Keine Akkorde erkannt" else song.chords.joinToString("   "),16f,Color.WHITE))
        root.addView(meta)
        if(song.youtubeId!=null) {
            val web=WebView(requireContext()).apply {
                settings.javaScriptEnabled=true; settings.domStorageEnabled=true
                settings.mediaPlaybackRequiresUserGesture=false
                loadDataWithBaseURL("https://www.youtube.com", youtubeHtml(song.youtubeId), "text/html","UTF-8",null)
            }
            root.addView(web,LinearLayout.LayoutParams(-1,dp(230)))
        } else {
            val match=button("YouTube-Verknüpfung suchen"); match.setOnClickListener{openYoutube(song)}; root.addView(match)
        }
        val lyrics=TextView(requireContext()).apply {
            text=song.lyrics; setTextColor(Color.WHITE); textSize=16f; setPadding(dp(12),dp(12),dp(12),dp(40))
        }
        val scroll=ScrollView(requireContext()); scroll.addView(lyrics); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        val sync=button("⏱  Auto-Sync für Lyrics aktivieren")
        sync.setOnClickListener {
            Toast.makeText(requireContext(),"Synchronisation wird über gespeicherte Zeitmarker aufgebaut.",Toast.LENGTH_LONG).show()
        }
        root.addView(sync)
    }

    private fun authorizeYoutube() {
        val requestedScopes = listOf(
            Scope("https://www.googleapis.com/auth/youtube.readonly")
        )
        val request = AuthorizationRequest.builder()
            .setRequestedScopes(requestedScopes)
            .build()

        Identity.getAuthorizationClient(requireContext())
            .authorize(request)
            .addOnSuccessListener { authorizationResult ->
                if (authorizationResult.hasResolution()) {
                    val pendingIntent = authorizationResult.pendingIntent
                    if (pendingIntent == null) {
                        Toast.makeText(requireContext(), "Google konnte den Autorisierungsdialog nicht öffnen.", Toast.LENGTH_LONG).show()
                    } else {
                        youtubeAuthLauncher.launch(
                            IntentSenderRequest.Builder(pendingIntent.intentSender).build()
                        )
                    }
                } else {
                    youtubeAccessToken = authorizationResult.accessToken
                    youtubeConnected = !youtubeAccessToken.isNullOrBlank()
                    if (youtubeConnected) {
                        youtubePrefs.edit().putBoolean("connected", true).apply()
                        fetchYoutubeChannel()
                    } else {
                        Toast.makeText(requireContext(), "YouTube-Berechtigung wurde nicht erteilt.", Toast.LENGTH_LONG).show()
                    }
                }
            }
            .addOnFailureListener {
                Toast.makeText(requireContext(), "YouTube-Autorisierung konnte nicht gestartet werden.", Toast.LENGTH_LONG).show()
            }
    }

    private fun fetchYoutubeChannel() {
        val token = youtubeAccessToken ?: return
        executor.execute {
            try {
                val url = java.net.URL("https://www.googleapis.com/youtube/v3/channels?part=snippet&mine=true")
                val connection = (url.openConnection() as java.net.HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 10000
                    readTimeout = 10000
                    setRequestProperty("Authorization", "Bearer $token")
                    setRequestProperty("Accept", "application/json")
                }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
                connection.disconnect()
                if (code !in 200..299) {
                    requireActivity().runOnUiThread {
                        youtubePrefs.edit().putBoolean("connected", true).apply()
                        Toast.makeText(
                            requireContext(),
                            "YouTube ist verbunden. Kanalinformationen konnten nicht gelesen werden.",
                            Toast.LENGTH_LONG
                        ).show()
                        buildHome()
                    }
                    return@execute
                }
                val items = org.json.JSONObject(body).optJSONArray("items")
                val name = items?.optJSONObject(0)?.optJSONObject("snippet")?.optString("title").orEmpty()
                youtubeChannelName = name.ifBlank { null }
                youtubePrefs.edit().putBoolean("connected", true).apply {
                    if (name.isBlank()) remove("channel_name") else putString("channel_name", name)
                }.apply()
                requireActivity().runOnUiThread {
                    Toast.makeText(
                        requireContext(),
                        if (name.isBlank()) "YouTube erfolgreich verbunden." else "YouTube verbunden mit: $name",
                        Toast.LENGTH_LONG
                    ).show()
                    buildHome()
                }
            } catch (t: Throwable) {
                requireActivity().runOnUiThread {
                    Toast.makeText(requireContext(), "YouTube verbunden, Kanal konnte nicht geladen werden.", Toast.LENGTH_LONG).show()
                    buildHome()
                }
            }
        }
    }

    private fun openYoutube(song: SongbookSong) {
        val query=Uri.encode(song.artist + " " + song.title + " guitar")
        startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://www.youtube.com/results?search_query="+query)))
    }

    private fun youtubeHtml(id:String)= """
        <!doctype html><html><body style="margin:0;background:#000">
        <iframe width="100%" height="100%" src="https://www.youtube.com/embed/$id?enablejsapi=1&playsinline=1"
        title="YouTube Player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
        </body></html>
    """.trimIndent()

    private fun importPdf(uri:Uri) {
        val progress=ProgressBar(requireContext())
        root.addView(progress,0,LinearLayout.LayoutParams(-1,dp(5)))
        executor.execute {
            try {
                val context = requireContext().applicationContext
                runCatching {
                    requireContext().contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                }
                val displayName = queryPdfDisplayName(uri)
                PDFBoxResourceLoader.init(context)
                val extracted = requireContext().contentResolver.openInputStream(uri).use { input ->
                    if(input==null) error("PDF konnte nicht geöffnet werden.")
                    PDDocument.load(input).use { doc ->
                        val pages = mutableListOf<String>()
                        val renderer = runCatching {
                            val descriptor = requireContext().contentResolver.openFileDescriptor(uri, "r")
                                ?: error("PDF-Datei kann nicht für die Texterkennung geöffnet werden.")
                            PdfRenderer(descriptor)
                        }.getOrNull()
                        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                        try {
                            for (pageIndex in 0 until doc.numberOfPages) {
                                val stripper = PDFTextStripper().apply {
                                    sortByPosition = true
                                    lineSeparator = "\n"
                                    startPage = pageIndex + 1
                                    endPage = pageIndex + 1
                                }
                                var pageText = stripper.getText(doc).trim()
                                val usefulChars = pageText.count { it.isLetterOrDigit() }
                                if (usefulChars < 24 && renderer != null && pageIndex < renderer.pageCount) {
                                    val ocrText = renderer.openPage(pageIndex).use { page ->
                                        val bitmap = Bitmap.createBitmap(
                                            (page.width * 2).coerceAtLeast(1),
                                            (page.height * 2).coerceAtLeast(1),
                                            Bitmap.Config.ARGB_8888
                                        )
                                        try {
                                            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                            Tasks.await(recognizer.process(InputImage.fromBitmap(bitmap, 0))).text
                                        } finally { bitmap.recycle() }
                                    }
                                    if (ocrText.isNotBlank()) pageText = ocrText
                                }
                                if (pageText.isNotBlank()) pages += "[[SAITENWERK_SEITE_${pageIndex + 1}]]\n" + pageText
                            }
                        } finally {
                            recognizer.close()
                            renderer?.close()
                        }
                        pages.joinToString("\n\n")
                    }
                }
                val songs = SongbookParser.parse(extracted, uri.toString())
                if (songs.isEmpty()) error("Es konnten keine Songs erkannt werden. Bitte prüfe, ob die PDF lesbaren Text oder gut erkennbare Noten-/Akkordseiten enthält.")
                songs.forEach { db.upsert(it) }
                db.registerPdf(uri.toString(), displayName, songs.size)
                requireActivity().runOnUiThread {
                    if(progress.parent!=null) root.removeView(progress)
                    AlertDialog.Builder(requireContext()).setTitle("PDF analysiert")
                        .setMessage(songs.size.toString() + " Songs erkannt und in das Songbook übernommen.\n\nText-PDFs werden direkt ausgelesen; gescannte Seiten werden zusätzlich per Texterkennung (OCR) verarbeitet.")
                        .setPositiveButton("Songbook öffnen"){_,_->buildHome()}.show()
                }
            } catch(t:Throwable) {
                requireActivity().runOnUiThread {
                    if(progress.parent!=null) root.removeView(progress)
                    AlertDialog.Builder(requireContext()).setTitle("Import fehlgeschlagen")
                        .setMessage(t.cause?.message ?: t.message ?: "Unbekannter PDF-Fehler").setPositiveButton("OK",null).show()
                }
            }
        }
    }

    private fun queryPdfDisplayName(uri: Uri): String {
        var name = "Songbook-PDF"
        requireContext().contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) name = c.getString(0)?.takeIf { it.isNotBlank() } ?: name
        }
        return name
    }

    private fun card(): LinearLayout = LinearLayout(requireContext()).apply {
        orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(14),dp(16),dp(14))
        setBackgroundColor(Color.rgb(27,29,34))
        val p=LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT)
        p.setMargins(0,dp(7),0,dp(7))
        layoutParams = p
    }
    private fun button(text:String)=Button(requireContext()).apply { this.text=text; setTextColor(Color.WHITE); setAllCaps(false); minHeight=0; minimumHeight=0; setPadding(dp(8),0,dp(8),0) }
    private fun label(text:String,size:Float,color:Int)=TextView(requireContext()).apply { this.text=text; textSize=size; setTextColor(color); setPadding(0,dp(4),dp(8),dp(4)) }
    private fun addText(text:String,size:Float,color:Int,bottom:Int){ root.addView(label(text,size,color),LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT).apply{bottomMargin=dp(bottom)}) }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
}

private class SimpleTextWatcher(val changed:(String)->Unit): android.text.TextWatcher {
    override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}
    override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){changed(s?.toString()?:"")}
    override fun afterTextChanged(s:android.text.Editable?){}
}
