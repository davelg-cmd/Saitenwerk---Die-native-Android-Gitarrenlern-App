# Saitenwerk Alpha 7 – Songreader V3

## Inhalt
Diese Version erweitert das bestehende Liederbuch um einen getrennten Lesemodus für das praktische Spielen.

### Neu
- Songreader mit großer Akkord- und Liedtextdarstellung
- automatischer Bildlauf
- neun Scrollgeschwindigkeiten
- Stoppen und Zurückspringen an den Anfang
- Transponierung wird im Reader berücksichtigt
- bestehende Kapodaster-Einstellung bleibt erhalten
- bestehende Abschnitts-/Arrangement-Speicherung bleibt erhalten

### Bewusst unverändert
- Songkatalog und Navigation
- Favoriten und Setlist
- Abschnittsstruktur Intro / Strophen / Refrain / Bridge / Solo / Outro
- bestehendes Arrangement-Format Version 3
- GitHub-Action `build-apk.yml`

## Validierung
Die Änderung wurde statisch in der entpackten Projektstruktur geprüft. Ein lokaler Android/Gradle-Build war in der aktuellen Ausführungsumgebung nicht möglich, weil Gradle/Android-SDK nicht lokal installiert und die externe Gradle-Distribution nicht erreichbar war.
