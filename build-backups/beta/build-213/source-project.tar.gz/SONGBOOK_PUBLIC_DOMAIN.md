# Saitenwerk – Freies Songbook

Die bisherige 500-Titel-Datenbank wurde vollständig aus `app/src/main/assets/songs.json` entfernt.

Die neue Alpha-Datenbank enthält 21 kuratierte traditionelle bzw. gemeinfreie Werke. Zu jedem Titel liegt in `public_domain_sheets.json` ein vollständiges, neu gesetztes Songblatt mit Text und Akkordmarkierungen vor.

## Rechteprinzip

- Es werden keine modernen Pop-/Rock-Songs aus der bisherigen Datenbank weitergeführt.
- Traditionelle Werke werden als traditionelle/gemeinfreie Titel gekennzeichnet.
- Bei namentlich genannten Autoren wurden nur historische Werke verwendet, deren Urheberrecht nach der in Deutschland grundsätzlich geltenden Schutzfrist von Leben + 70 Jahren abgelaufen ist.
- Akkordsetzungen und Formatierung wurden für Saitenwerk neu erstellt; sie sind keine kopierten modernen Tab-/Chord-Webseiten.
- Vor einer kommerziellen Veröffentlichung sollte die konkrete Rechtslage für jede veröffentlichte Fassung nochmals juristisch geprüft werden, insbesondere bei traditionellen Werken mit mehreren späteren Bearbeitungen oder Übersetzungen.

## Enthaltene Titel

1. Amazing Grace
2. Auld Lang Syne
3. Scarborough Fair
4. Greensleeves
5. Oh! Susanna
6. Camptown Races
7. Clementine
8. Red River Valley
9. My Bonnie Lies Over the Ocean
10. She'll Be Coming Round the Mountain
11. Down by the Riverside
12. When the Saints Go Marching In
13. Silent Night / Stille Nacht
14. O Tannenbaum
15. Alle meine Entchen
16. Hänschen klein
17. Der Mond ist aufgegangen
18. Die Gedanken sind frei
19. Swing Low, Sweet Chariot
20. Jingle Bells
21. Joy to the World

## Datenformat

`public_domain_sheets.json` enthält pro Titel:
- Titel
- Urheber-/Herkunftshinweis
- Genre
- Tonart
- Tempo
- vollständigen Liedtext
- Akkordmarkierungen im Saitenwerk-Format `[C]Text [G]Text`
