# Saitenwerk Alpha 7 – Update-Pipeline-Fix

## Nachgewiesene Ursache
GitHub Actions Lauf Nr. 76 baute die APK erfolgreich und lud die beiden Actions-Artefakte hoch. Der Release-Schritt meldete eine URL mit `untagged-...`. Gleichzeitig existiert zwar der Git-Tag `alpha-latest`, aber die GitHub Releases API liefert keinen Release zu diesem Tag. Der AppUpdateManager sucht gezielt nach einem veröffentlichten Release mit `tag_name == alpha-latest`. Deshalb findet die App kein Update.

## Korrektur
Der Workflow erstellt/aktualisiert den Release jetzt explizit über die GitHub Releases REST API mit `tag_name=alpha-latest`. Danach wird `saitenwerk-alpha7.apk` als Release-Asset hochgeladen. Der vorhandene AppUpdateManager kann diesen Release anschließend lesen und vergleicht `versionCode`.

## Einspielen
1. Im GitHub-Repository `.github/workflows/build-apk.yml` öffnen.
2. Den vollständigen Inhalt durch `Saitenwerk_build-apk_UPDATEFIX.yml` ersetzen.
3. Committen.
4. Workflow `Saitenwerk Alpha 7 - APK Build` manuell starten.
5. Nach erfolgreichem Lauf kontrollieren, dass unter Releases ein Release mit Tag `alpha-latest` existiert und `saitenwerk-alpha7.apk` enthält.

Der Workflow benötigt `contents: write`. Die App prüft Updates weiterhin ausschließlich manuell über Einstellungen; ein Updatecheck beim App-Start wird nicht aktiviert.
