# Saitenwerk 3.1.0-alpha7

Native Android-Gitarrenlern-App (Kotlin, offline-first). Entwicklungsstand: **Alpha 7**.

## Bereiche
- Natives Stimmgerät mit Instrumentenauswahl und alternativen Gitarrenstimmungen
- Akkordbibliothek mit Griffbildern und Gitarrenklang-Vorschau
- Liederbuch mit Suche, Favoriten, Setlist und erweitertem Songblatt-Editor für abschnittsweise Liedtexte mit Akkordmarkierungen, automatischer Zwischenspeicherung und Akkordtransponierung inklusive Slash-Bassnoten
- Lernstudio mit Übungen
- Persönlicher Lernpfad mit Fortschritt und Lernziel

## Alpha-7-Tuner
- Instrumente: Gitarre, Bass, Ukulele, Violine und chromatischer Modus
- Alternative Gitarrenstimmungen: Standard, Drop D, Drop C, Double Drop D, DADGAD, Nashville, Open E, Open G, CGCFCE, DGCGCD und GABDEG
- Zieltonfrequenzen werden passend zur gewählten Stimmung berechnet
- Referenzton-Schaltfläche im Display entfernt; die Saiten-Zielwahl bleibt erhalten

## Build
Android SDK 35, JDK 17, Gradle 8.10.2.

```bash
gradle --no-daemon assembleDebug
```

Dies ist weiterhin eine Alpha-Version. Der Build muss über GitHub Actions geprüft und die Tuner-Erkennung anschließend auf einem echten Android-Gerät getestet werden.

## Manuelle Alpha-Updates

Updates werden nicht automatisch beim App-Start gesucht. Die Prüfung erfolgt nach manueller Auswahl in den Einstellungen. Eine höhere `versionCode` wird angeboten; das APK wird über Androids DownloadManager geladen und anschließend über den offiziellen Android-Installationsdialog installiert. Android verlangt dafür weiterhin die Zustimmung des Nutzers und ggf. einmalig die Freigabe „Aus dieser Quelle zulassen“.

## Liederbuch – Songblattformat

Songtexte und Akkorde können abschnittsweise gemeinsam gespeichert werden. Akkorde werden im Text mit eckigen Klammern markiert, zum Beispiel `[C]Text [G]mit Akkordwechsel`. Die Vorschau stellt die Akkorde oberhalb der jeweiligen Textsegmente dar. Änderungen werden beim Tippen und beim Verändern von Kapodaster/Transponierung automatisch zwischengespeichert; ein Abschnittswechsel verwirft dadurch keine ungespeicherten Eingaben. Die Akkorderkennung berücksichtigt unter anderem Dur-/Moll-, Sus-, Dim-, Aug-, Add-, Erweiterungs- und Slash-Akkorde. Bei der Transponierung werden Grundton und Bassnote gemeinsam verschoben. Eigene, gemeinfreie oder entsprechend lizenzierte Inhalte verwenden; vollständige geschützte Liedtexte und fremde Transkriptionen dürfen nicht ohne Rechte übernommen oder veröffentlicht werden.

Der GitHub-Actions-Workflow nummeriert Builds fortlaufend und aktualisiert den Release-Asset `saitenwerk-alpha7.apk`. Dafür benötigt der Workflow `contents: write`.
