#!/usr/bin/env python3
from pathlib import Path
import re, sys

roots = [Path("."), Path("extracted")]
matches=[]
for root in roots:
    if root.exists():
        matches += list(root.rglob("MainActivity.kt"))
if not matches:
    raise SystemExit("MainActivity.kt nicht gefunden")
p = matches[0]
s = p.read_text(encoding="utf-8")

# Restore the reader runtime state required by the existing V2/V3 reader touch/scroll code.
fields = """\
    private var autoScroll: Boolean = false
    private var scrollRunnable: Runnable = Runnable { }
    private val scrollHandler = Handler(Looper.getMainLooper())
    private var lastScrollTime: Long = 0L
    private var scrollRemainder: Float = 0f
    private var resumeAfterTouch: Boolean = false
"""
marker = "class SongDetailFragment"
if "private var autoScroll: Boolean" not in s:
    i=s.find(marker)
    if i < 0: raise SystemExit("SongDetailFragment nicht gefunden")
    i=s.find("\n",i)+1
    s=s[:i]+fields+s[i:]

# Avoid Kotlin property-shadowing problems in ProgressBar/SeekBar apply blocks.
s=s.replace("apply { max = 100; progress = 0 }", "apply { max = 100; setProgress(0) }")
s=s.replace("apply { max = 56; progress = 16 }", "apply { max = 56; setProgress(16) }")

# Keep the old reader state variables self-contained; this is a compatibility fix,
# not a second independent clock. The player remains the master clock in V3.
p.write_text(s, encoding="utf-8")
print(f"FIXED={p}")
