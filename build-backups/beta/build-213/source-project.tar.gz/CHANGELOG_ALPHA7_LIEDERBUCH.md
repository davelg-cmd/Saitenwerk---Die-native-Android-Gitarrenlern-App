# Saitenwerk Alpha 7 – Liederbuch-Iteration

## Änderungen
- Automatische Zwischenspeicherung des aktuellen Songabschnitts bei Texteingabe.
- Automatische Speicherung der Kapodaster- und Transponierungseinstellungen.
- Sicherung des bisherigen Abschnitts vor dem Wechsel zu einem anderen Abschnitt.
- Erweiterte Erkennung gängiger Akkordqualitäten und Slash-Akkorde.
- Transponierung verschiebt jetzt sowohl den Akkordgrundton als auch eine vorhandene Bassnote (z. B. `C#m7/G#` → zwei Halbtöne höher → `D♯m7/A♯`).
- Vorhandene Songdaten, Favoriten, Setlist, Navigation und sonstige App-Bereiche wurden nicht absichtlich verändert.

## Prüfung
- ZIP-Archivstruktur geprüft.
- 500 vorhandene Songdatensätze geprüft und erhalten.
- Kotlin-Logik für Akkorderkennung und Transponierung isoliert kompiliert und mit Beispielen geprüft.
- Vollständiger Android-Gradle-Build in dieser Umgebung nicht ausgeführt: Gradle/Android-SDK sind hier nicht eingerichtet.
- Reale Geräteprüfung steht aus.

## Hinweis zu Songinhalten
Die 500 vorhandenen Einträge bleiben Songkatalog-Einträge. Vollständige Liedtexte und Akkordarrangements werden nur ergänzt, wenn sie selbst erstellt, gemeinfrei oder entsprechend lizenziert sind.

## Alpha 7 – Songreader V3 (15.11.2026)
- Neuer separater Songreader zum sicheren Spielen gespeicherter Songblätter.
- Große Akkordanzeige und größere Liedtextdarstellung.
- Automatischer Bildlauf mit einstellbarem Scrolltempo.
- Schnellzugriff auf Anfang und Stoppen des Bildlaufs.
- Reader übernimmt aktuelle Transponierung und Kapodaster-Einstellung.
- Bestehende Speicherstruktur und Songkatalog bleiben unverändert.

Hinweis: Diese Quellprojekt-ZIP wurde hier erstellt, konnte in dieser Umgebung mangels erreichbarem Gradle/Android-SDK nicht lokal kompiliert werden. Der GitHub-Workflow bleibt unverändert.

## Alpha 7 – Freies Songbook / Public-Domain-Rework (15.11.2026)

- bisherige 500-Titel-Datenbank vollständig entfernt
- neues kuratiertes Songbook mit 21 traditionellen bzw. gemeinfreien Titeln
- vollständige Songtexte und spielbare Akkordmarkierungen direkt als App-Asset hinterlegt
- neuer `Gesamter Song`-Abschnitt im Songreader
- bestehende eigene Songs bleiben als lokale Benutzerinhalte möglich
- neue Liederbuch-Kopfkarte mit klarer Kennzeichnung des freien Songbestands
- Rechtehinweise in `SONGBOOK_PUBLIC_DOMAIN.md` dokumentiert
