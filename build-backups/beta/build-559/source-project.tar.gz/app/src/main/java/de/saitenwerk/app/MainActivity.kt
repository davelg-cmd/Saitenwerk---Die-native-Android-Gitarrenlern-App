package de.saitenwerk.app

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.SoundPool
import android.media.AudioAttributes
import android.media.MediaRecorder
import android.media.MediaPlayer
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.card.MaterialCardView
import org.json.JSONArray
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.exp
import kotlin.math.PI

class MainActivity : AppCompatActivity() {

    private lateinit var appUpdateManager: AppUpdateManager
    private var bottomNav: BottomNavigationView? = null
    private var suppressNavSelection = false
    private var micGrantedAction: (() -> Unit)? = null
    private var contentFrameId: Int = View.NO_ID
    private val requestMic = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) micGrantedAction?.invoke()
        else Toast.makeText(this, "Für das Stimmgerät wird Mikrofonzugriff benötigt.", Toast.LENGTH_LONG).show()
        micGrantedAction = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = getColor(R.color.sw_navy)
        window.navigationBarColor = getColor(R.color.sw_navy)
        // Android 15/Edge-to-Edge: Inhalte sicher unterhalb der Statusleiste halten
        // und die untere Navigation oberhalb der System-Gestenleiste platzieren.
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(buildRoot())
        if (savedInstanceState == null) show(HomeFragment(), addToBackStack = false)
        supportFragmentManager.registerFragmentLifecycleCallbacks(
            object : androidx.fragment.app.FragmentManager.FragmentLifecycleCallbacks() {
                override fun onFragmentViewCreated(
                    fm: androidx.fragment.app.FragmentManager,
                    fragment: Fragment,
                    view: View,
                    savedInstanceState: Bundle?
                ) {
                    super.onFragmentViewCreated(fm, fragment, view, savedInstanceState)
                    applySaitenwerkButtonStyle(view)
                }
            },
            true
        )
        setupBackNavigation()
        // Updates werden ausschließlich auf ausdrücklichen Wunsch in den Einstellungen geprüft.
        appUpdateManager = AppUpdateManager(this)
    }

    override fun onDestroy() {
        if (::appUpdateManager.isInitialized) appUpdateManager.dispose()
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        if (::appUpdateManager.isInitialized) appUpdateManager.resumePendingInstall()
    }

    private fun buildRoot(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.sw_navy))
        }
        val frame = FrameLayout(this).also { contentFrameId = View.generateViewId(); it.id = contentFrameId }
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = BottomNavigationView(this).apply {
            // Bewusst dunkler als der Inhaltsbereich: Die Navigation ist klar abgesetzt.
            setBackgroundColor(getColor(R.color.sw_nav_bar))
            elevation = dp(12).toFloat()
            setItemIconSize(dp(24))
            itemPaddingTop = dp(6)
            itemPaddingBottom = dp(6)
            labelVisibilityMode = BottomNavigationView.LABEL_VISIBILITY_LABELED
            setItemIconTintList(android.content.res.ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(getColor(R.color.sw_copper), getColor(R.color.sw_nav_icon))
            ))
            setItemTextColor(android.content.res.ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(getColor(R.color.sw_copper), getColor(R.color.sw_nav_text))
            ))
            setItemTextAppearanceInactive(R.style.SaitenwerkBottomNavLabel)
            setItemTextAppearanceActive(R.style.SaitenwerkBottomNavLabelActive)
            menu.add(0, 1, 0, "Start").setIcon(R.drawable.ic_nav_home)
            menu.add(0, 2, 1, "Stimmen").setIcon(R.drawable.ic_nav_tuner)
            menu.add(0, 3, 2, "Akkorde").setIcon(R.drawable.ic_nav_chords)
            menu.add(0, 4, 3, "Songbook").setIcon(R.drawable.ic_nav_songbook).setIcon(R.drawable.ic_nav_songbook).setIcon(R.drawable.ic_nav_songbook).setIcon(R.drawable.ic_nav_songbook).setIcon(R.drawable.ic_nav_songbook).setIcon(R.drawable.ic_nav_songbook).setIcon(R.drawable.ic_nav_songbook)
            menu.add(0, 5, 4, "Lernstudio").setIcon(R.drawable.ic_nav_learn)
            // BottomNavigationView unterstützt maximal fünf Einträge.
            // Den Lernpfad erreichen Nutzer über das Lernstudio und die Startseite.
            setOnItemSelectedListener { item ->
                if (suppressNavSelection) true else { openSection(item.itemId); true }
            }
        }
        bottomNav = nav
        root.addView(nav, LinearLayout.LayoutParams(-1, dp(76)))
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(0, bars.top, 0, bars.bottom)
            insets
        }
        ViewCompat.requestApplyInsets(root)
        return root
    }

    fun premiumButtonBackground(primary: Boolean = false): android.graphics.drawable.Drawable {
        val shape = android.graphics.drawable.GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(getColor(if (primary) R.color.sw_copper else R.color.sw_surface2))
            if (!primary) setStroke(dp(1), getColor(R.color.sw_outline))
        }
        return android.graphics.drawable.RippleDrawable(
            android.content.res.ColorStateList.valueOf(getColor(R.color.sw_ripple)), shape, null
        )
    }

    fun premiumDropdownItemBackground(): android.graphics.drawable.Drawable {
        val shape = android.graphics.drawable.GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
            setColor(getColor(R.color.sw_surface2))
        }
        return android.graphics.drawable.RippleDrawable(
            android.content.res.ColorStateList.valueOf(getColor(R.color.sw_ripple)), shape, null
        )
    }

    private fun applySaitenwerkButtonStyle(root: View) {
        val density = resources.displayMetrics.density
        fun dp(value: Int) = (value * density + 0.5f).toInt()
        if (root is Button) {
            val primary = root.tag == "saitenwerk-primary"
            root.isAllCaps = false
            root.textSize = 14f
            root.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            root.setTextColor(getColor(if (primary) R.color.sw_on_accent else R.color.sw_copper))
            root.gravity = Gravity.CENTER
            root.textAlignment = View.TEXT_ALIGNMENT_CENTER
            root.includeFontPadding = true
            root.minLines = 1
            root.maxLines = 2
            root.setLineSpacing(dp(2).toFloat(), 1.05f)
            root.setPadding(dp(16), dp(10), dp(16), dp(10))
            root.minHeight = dp(52)
            root.minimumHeight = dp(52)
            root.minimumWidth = 0
            root.stateListAnimator = null
            root.elevation = dp(1).toFloat()
            root.background = premiumButtonBackground(primary)
            val params = root.layoutParams
            if (params != null && params.height > 0 && params.height < dp(52)) {
                params.height = dp(52)
                root.layoutParams = params
            }
        }
        if (root is MaterialCardView) {
            root.radius = dp(20).toFloat()
            root.strokeColor = getColor(R.color.sw_outline)
            root.strokeWidth = dp(1)
            root.cardElevation = dp(2).toFloat()
            root.setCardBackgroundColor(getColor(R.color.sw_surface))
        }
        if (root is Spinner) {
            root.setPopupBackgroundDrawable(android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(getColor(R.color.sw_surface))
                setStroke(dp(1), getColor(R.color.sw_outline))
            })
            root.dropDownVerticalOffset = dp(6)
            root.elevation = dp(1).toFloat()
        }
        if (root is ViewGroup) {
            for (index in 0 until root.childCount) applySaitenwerkButtonStyle(root.getChildAt(index))
        }
    }

    private fun show(fragment: Fragment, addToBackStack: Boolean = true) {
        val tx = supportFragmentManager.beginTransaction().replace(contentFrameId, fragment)
        if (addToBackStack) tx.addToBackStack(null)
        tx.commit()
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (supportFragmentManager.backStackEntryCount > 0) {
                    supportFragmentManager.popBackStack()
                    syncBottomNavigation()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    private fun syncBottomNavigation() {
        val id = when (supportFragmentManager.findFragmentById(contentFrameId)) {
            is HomeFragment -> 1
            is SongbookFragment -> 4
            is TunerFragment -> 2
            is ChordsFragment -> 3
            is LearnFragment -> 5
            is PathFragment -> 5
            else -> 0
        }
        if (id != 0 && bottomNav?.selectedItemId != id) {
            suppressNavSelection = true
            bottomNav?.selectedItemId = id
            suppressNavSelection = false
        }
    }

    fun openSection(id: Int) {
        val current = supportFragmentManager.findFragmentById(contentFrameId)
        val alreadyOpen = when (id) {
            1 -> current is HomeFragment
            2 -> current is TunerFragment
            3 -> current is ChordsFragment
            5 -> current is LearnFragment
            6 -> current is PathFragment
            else -> false
        }
        if (alreadyOpen) return
        when (id) {
            1 -> show(HomeFragment())
            4 -> show(SongbookFragment())
            2 -> show(TunerFragment())
            3 -> show(ChordsFragment())
            5 -> show(LearnFragment())
            6 -> show(PathFragment())
        }
    }

    fun openSettings() {
        show(SettingsFragment())
    }

    fun checkForUpdatesManually() {
        if (::appUpdateManager.isInitialized) appUpdateManager.checkForUpdates()
    }

    fun askMic(onGranted: () -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) onGranted()
        else { micGrantedAction = onGranted; requestMic.launch(Manifest.permission.RECORD_AUDIO) }
    }

    fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()
    fun title(value: String) = TextView(this).apply {
        text = value; setTextColor(getColor(R.color.sw_text)); textSize = 26f
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(dp(20), dp(18), dp(20), dp(8))
        letterSpacing = -0.02f
    }
    fun body(value: String, size: Float = 15f) = TextView(this).apply {
        text = value; textSize = size; setTextColor(getColor(R.color.sw_muted)); setPadding(dp(20), 0, dp(20), dp(14))
        setLineSpacing(dp(2).toFloat(),1f)
    }
    fun card(): MaterialCardView = MaterialCardView(this).apply {
        setCardBackgroundColor(getColor(R.color.sw_surface)); radius = dp(20).toFloat()
        strokeColor = getColor(R.color.sw_outline); strokeWidth = dp(1)
        cardElevation = dp(2).toFloat()
    }
    fun button(value: String) = Button(this).apply {
        text = value
        isAllCaps = false
        setTextColor(getColor(R.color.sw_copper))
        textSize = 14f
        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        gravity = Gravity.CENTER
        textAlignment = View.TEXT_ALIGNMENT_CENTER
        includeFontPadding = true
        minLines = 1
        maxLines = 2
        setLineSpacing(dp(2).toFloat(), 1.05f)
        setPadding(dp(16), dp(10), dp(16), dp(10))
        minHeight = dp(52)
        minimumHeight = dp(52)
        minimumWidth = 0
        stateListAnimator = null
        elevation = dp(1).toFloat()
        background = premiumButtonBackground()
    }

    fun spinnerAdapter(values: List<String>): ArrayAdapter<String> = object : ArrayAdapter<String>(this, R.layout.sw_spinner_item, values) {
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = super.getView(position, convertView, parent) as TextView
            v.setTextColor(getColor(R.color.sw_text))
            v.textSize = 14f
            v.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            v.gravity = Gravity.CENTER_VERTICAL
            v.includeFontPadding = true
            v.maxLines = 2
            v.setPadding(dp(16), dp(8), dp(42), dp(8))
            v.minHeight = dp(52)
            v.background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(getColor(R.color.sw_surface2))
                setStroke(dp(1), getColor(R.color.sw_outline))
            }
            return v
        }
        override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = super.getDropDownView(position, convertView, parent) as TextView
            v.setTextColor(getColor(R.color.sw_text))
            v.textSize = 14f
            v.typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
            v.gravity = Gravity.CENTER_VERTICAL
            v.includeFontPadding = true
            v.maxLines = 2
            v.setPadding(dp(16), dp(12), dp(16), dp(12))
            v.minHeight = dp(52)
            v.background = premiumDropdownItemBackground()
            return v
        }
    }
}

class HomeFragment : Fragment() {
    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a=requireActivity() as MainActivity
        val prefs=a.getSharedPreferences("saitenwerk",0)
        val page=LinearLayout(a).apply { orientation=LinearLayout.VERTICAL; setPadding(a.dp(20),a.dp(14),a.dp(20),a.dp(28)) }
        val top=LinearLayout(a).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        val brand=LinearLayout(a).apply { orientation=LinearLayout.VERTICAL }
        brand.addView(TextView(a).apply { text="SAITENWERK"; textSize=12f; letterSpacing=0.18f; setTypeface(typeface,1); setTextColor(a.getColor(R.color.sw_copper)) })
        brand.addView(TextView(a).apply { text="Dein Sound. Dein Fortschritt."; textSize=13f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0,a.dp(3),0,0) })
        top.addView(brand,LinearLayout.LayoutParams(0,-2,1f))
        top.addView(TextView(a).apply {
            text="⚙"; textSize=22f; gravity=Gravity.CENTER; setTextColor(a.getColor(R.color.sw_text))
            background=android.graphics.drawable.GradientDrawable().apply { shape=android.graphics.drawable.GradientDrawable.OVAL; setColor(a.getColor(R.color.sw_surface2)); setStroke(a.dp(1),a.getColor(R.color.sw_outline)) }
            contentDescription="Einstellungen öffnen"; isClickable=true; isFocusable=true; setOnClickListener { a.openSettings() }
        },LinearLayout.LayoutParams(a.dp(46),a.dp(46)))
        page.addView(top)

        // Persönlicher Tagesüberblick: nutzt ausschließlich vorhandene Lernfortschrittsdaten.
        val todayKey = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.GERMANY).format(java.util.Date())
        val weekCalendar = java.util.Calendar.getInstance()
        val weekKey = weekCalendar.get(java.util.Calendar.YEAR).toString() + "-" + weekCalendar.get(java.util.Calendar.WEEK_OF_YEAR).toString()
        val routineDone = if (prefs.getString("learn_routine_day", "") == todayKey) Integer.bitCount(prefs.getInt("learn_routine_done", 0)) else 0
        val routineTotal = 5
        val dailySeconds = if (prefs.getString("learn_daily_day", "") == todayKey) prefs.getInt("learn_daily_seconds", prefs.getInt("learn_daily_minutes", 0) * 60) else 0
        val weeklySeconds = if (prefs.getString("learn_week_key", "") == weekKey) prefs.getInt("learn_week_seconds", 0) else 0
        val streak = prefs.getInt("learn_streak", 0)
        val pathStages = listOf("Erste Akkorde", "Saubere Griffbilder", "Flüssige Wechsel", "Rhythmus festigen", "Erste Songs begleiten", "Selbstständig spielen")
        val pathMask = prefs.getInt("learning_path_done", 0)
        val nextPathIndex = pathStages.indices.firstOrNull { (pathMask and (1 shl it)) == 0 }
        val nextPath = nextPathIndex?.let { pathStages[it] } ?: "Alle Lernstufen geschafft"

        val todayCard = a.card().apply {
            radius = a.dp(20).toFloat()
            strokeColor = a.getColor(R.color.sw_outline)
            strokeWidth = a.dp(1)
            cardElevation = a.dp(2).toFloat()
        }
        val todayBox = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dp(17), a.dp(16), a.dp(17), a.dp(16))
        }
        val todayHeader = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        todayHeader.addView(TextView(a).apply {
            text = "DEIN HEUTIGES TRAINING"
            textSize = 11f
            letterSpacing = 0.12f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(a.getColor(R.color.sw_copper))
        }, LinearLayout.LayoutParams(0, -2, 1f))
        todayHeader.addView(TextView(a).apply {
            text = if (routineDone == routineTotal) "GESCHAFFT" else "$routineDone / $routineTotal"
            textSize = 12f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(a.getColor(R.color.sw_copper))
        })
        todayBox.addView(todayHeader)
        todayBox.addView(TextView(a).apply {
            text = if (routineDone == routineTotal) "Stark – deine Tagesroutine ist erledigt." else "Ein paar gezielte Minuten bringen dich weiter."
            textSize = 14f
            setTextColor(a.getColor(R.color.sw_text))
            setPadding(0, a.dp(7), 0, a.dp(10))
        })
        val todayProgress = ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = routineTotal
            progress = routineDone
            progressTintList = android.content.res.ColorStateList.valueOf(a.getColor(R.color.sw_copper))
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(a.getColor(R.color.sw_outline))
        }
        todayBox.addView(todayProgress, LinearLayout.LayoutParams(-1, a.dp(7)))
        val metrics = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, a.dp(12), 0, a.dp(12))
        }
        fun metric(value: String, label: String) {
            val item = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
            item.addView(TextView(a).apply {
                text = value
                textSize = 17f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(a.getColor(R.color.sw_text))
                gravity = Gravity.CENTER
            })
            item.addView(TextView(a).apply {
                text = label
                textSize = 10f
                setTextColor(a.getColor(R.color.sw_muted))
                gravity = Gravity.CENTER
                setPadding(0, a.dp(2), 0, 0)
            })
            metrics.addView(item, LinearLayout.LayoutParams(0, -2, 1f))
        }
        metric(String.format(java.util.Locale.GERMANY, "%.0f min", dailySeconds / 60.0), "Heute")
        metric(String.format(java.util.Locale.GERMANY, "%.0f min", weeklySeconds / 60.0), "Diese Woche")
        metric("$streak Tage", "Serie")
        todayBox.addView(metrics)
        todayBox.addView(TextView(a).apply {
            text = "Als Nächstes: $nextPath"
            textSize = 12f
            setTextColor(a.getColor(R.color.sw_muted))
            setPadding(0, 0, 0, a.dp(12))
        })
        val todayActions = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        todayActions.addView(Button(a).apply {
            tag = "saitenwerk-primary"
            text = "Training starten"
            isAllCaps = false
            setOnClickListener { a.openSection(5) }
        }, LinearLayout.LayoutParams(0, a.dp(50), 1f).apply { rightMargin = a.dp(6) })
        todayActions.addView(a.button("Lernpfad").apply {
            setOnClickListener { a.openSection(6) }
        }, LinearLayout.LayoutParams(0, a.dp(50), 1f).apply { leftMargin = a.dp(6) })
        todayBox.addView(todayActions)
        todayCard.addView(todayBox)
        page.addView(todayCard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = a.dp(16) })

        val hero=a.card().apply { radius=a.dp(24).toFloat(); strokeColor=a.getColor(R.color.sw_outline); strokeWidth=a.dp(1); elevation=a.dp(3).toFloat() }
        val box=LinearLayout(a).apply { orientation=LinearLayout.VERTICAL; setPadding(a.dp(20),a.dp(18),a.dp(20),a.dp(18)) }
        box.addView(ImageView(a).apply { setImageResource(R.drawable.saitenwerk_original); contentDescription="Saitenwerk – Dein persönlicher Gitarrenbegleiter"; scaleType=ImageView.ScaleType.FIT_CENTER; adjustViewBounds=true },LinearLayout.LayoutParams(-1,a.dp(180)).apply { bottomMargin=a.dp(12) })
        box.addView(TextView(a).apply { text="DEIN MUSIKALISCHER BEGLEITER"; textSize=10f; letterSpacing=0.16f; setTypeface(typeface,1); setTextColor(a.getColor(R.color.sw_copper)) })
        box.addView(TextView(a).apply { text="Spiel. Lerne. Kling besser."; textSize=25f; setTypeface(typeface,1); setTextColor(a.getColor(R.color.sw_text)); setPadding(0,a.dp(7),0,a.dp(5)) })
        box.addView(TextView(a).apply { text="Alles, was du zum Stimmen, Üben und Weiterkommen brauchst – an einem Ort."; textSize=14f; setLineSpacing(a.dp(2).toFloat(),1f); setTextColor(a.getColor(R.color.sw_muted)) })
        box.addView(Button(a).apply {
            tag = "saitenwerk-primary"
            text="Stimmgerät öffnen   →"; isAllCaps=false; textSize=15f; setTypeface(typeface,1); setTextColor(a.getColor(R.color.sw_on_accent)); minHeight=a.dp(54); stateListAnimator=null
            background=android.graphics.drawable.GradientDrawable().apply { cornerRadius=a.dp(16).toFloat(); setColor(a.getColor(R.color.sw_copper)) }
            setOnClickListener { a.openSection(2) }
        },LinearLayout.LayoutParams(-1,a.dp(54)).apply { topMargin=a.dp(16) })
        hero.addView(box)
        page.addView(hero,LinearLayout.LayoutParams(-1,-2).apply { topMargin=a.dp(20) })
        page.addView(TextView(a).apply { text="DEIN WORKSPACE"; textSize=11f; letterSpacing=0.14f; setTypeface(typeface,1); setTextColor(a.getColor(R.color.sw_muted)); setPadding(a.dp(2),a.dp(24),0,a.dp(10)) })
        fun tile(symbol:String,title:String,detail:String,section:Int) {
            val card=a.card().apply { radius=a.dp(18).toFloat(); strokeColor=a.getColor(R.color.sw_outline); strokeWidth=a.dp(1); isClickable=true; isFocusable=true; setOnClickListener { a.openSection(section) } }
            val row=LinearLayout(a).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(a.dp(15),a.dp(15),a.dp(14),a.dp(15)) }
            row.addView(TextView(a).apply { text=symbol; textSize=23f; gravity=Gravity.CENTER; setTextColor(a.getColor(R.color.sw_copper)); background=android.graphics.drawable.GradientDrawable().apply { cornerRadius=a.dp(13).toFloat(); setColor(a.getColor(R.color.sw_surface2)) } },LinearLayout.LayoutParams(a.dp(48),a.dp(48)))
            val texts=LinearLayout(a).apply { orientation=LinearLayout.VERTICAL }
            texts.addView(TextView(a).apply { text=title; textSize=16f; setTypeface(typeface,1); setTextColor(a.getColor(R.color.sw_text)) })
            texts.addView(TextView(a).apply { text=detail; textSize=12f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0,a.dp(3),0,0) })
            row.addView(texts,LinearLayout.LayoutParams(0,-2,1f).apply { leftMargin=a.dp(13) })
            row.addView(TextView(a).apply { text="›"; textSize=25f; setTextColor(a.getColor(R.color.sw_muted)) })
            card.addView(row); page.addView(card,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=a.dp(10) })
        }
        tile("♬","Akkorde","Griffbilder entdecken und speichern",3)
        tile("✦","Lernstudio","Übungen, Rhythmus und tägliche Routine",5)
        tile("↗","Dein Lernpfad","Deinen Fortschritt Schritt für Schritt verfolgen",6)
        val stats=LinearLayout(a).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(a.dp(2),a.dp(12),a.dp(2),0) }
        stats.addView(TextView(a).apply { text="LERNFORTSCHRITT"; textSize=10f; letterSpacing=0.12f; setTypeface(typeface,1); setTextColor(a.getColor(R.color.sw_muted)) },LinearLayout.LayoutParams(0,-2,1f))
        stats.addView(TextView(a).apply { text=prefs.getInt("learn_quiz_correct",0).toString()+" / "+prefs.getInt("learn_quiz_total",0)+" Quiz-Treffer"; textSize=12f; setTextColor(a.getColor(R.color.sw_copper)) })
        page.addView(stats)
        return ScrollView(a).apply { clipToPadding=false; isFillViewport=true; addView(page) }
    }
}

class SettingsFragment : Fragment() {
    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a=requireActivity() as MainActivity
        val page=LinearLayout(a).apply { orientation=LinearLayout.VERTICAL; setPadding(a.dp(20),a.dp(12),a.dp(20),a.dp(28)) }
        page.addView(TextView(a).apply { text="Einstellungen"; textSize=27f; setTypeface(typeface,1); setTextColor(a.getColor(R.color.sw_text)); setPadding(0,a.dp(8),0,a.dp(4)) })
        page.addView(TextView(a).apply { text="Saitenwerk an deinen Alltag anpassen."; textSize=14f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0,0,0,a.dp(20)) })
        fun section(title:String,description:String,actionLabel:String,action:()->Unit) {
            val card=a.card().apply { radius=a.dp(18).toFloat(); strokeColor=a.getColor(R.color.sw_outline); strokeWidth=a.dp(1) }
            val box=LinearLayout(a).apply { orientation=LinearLayout.VERTICAL; setPadding(a.dp(18),a.dp(17),a.dp(18),a.dp(17)) }
            box.addView(TextView(a).apply { text=title; textSize=17f; setTypeface(typeface,1); setTextColor(a.getColor(R.color.sw_text)) })
            box.addView(TextView(a).apply { text=description; textSize=13f; setLineSpacing(a.dp(2).toFloat(),1f); setTextColor(a.getColor(R.color.sw_muted)); setPadding(0,a.dp(5),0,a.dp(14)) })
            box.addView(a.button(actionLabel).apply { textSize=14f; minHeight=a.dp(48); background=android.graphics.drawable.GradientDrawable().apply { cornerRadius=a.dp(14).toFloat(); setColor(a.getColor(R.color.sw_surface2)); setStroke(a.dp(1),a.getColor(R.color.sw_copper)) }; setOnClickListener { action() } },LinearLayout.LayoutParams(-1,a.dp(48)))
            card.addView(box); page.addView(card,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=a.dp(13) })
        }
        section("App-Updates","Prüfe manuell, ob eine neue Saitenwerk-Version verfügbar ist. Deine installierte Version bleibt erhalten, bis du das Update bestätigst.","Nach Updates suchen") { a.checkForUpdatesManually() }
        val info=a.packageManager.getPackageInfo(a.packageName,0)
        val version=info.versionName ?: "unbekannt"; val code=info.versionCode
        section("Lernfortschritt","Setze sämtliche gespeicherten Lernzeiten, Punkte, XP, Serien, Quizwerte und Lernpfad-Fortschritte auf diesem Gerät zurück. Trainings-Einstellungen wie Akkordauswahl, Tempo und Taktart bleiben erhalten.","Alles zurücksetzen") {
            androidx.appcompat.app.AlertDialog.Builder(a, R.style.ThemeOverlay_Saitenwerk_Dialog)
                .setTitle("Gesamten Lernfortschritt zurücksetzen?")
                .setMessage("Dabei werden alle Lernstudio- und Lernpfad-Werte gelöscht: Übungsminuten, Tages- und Wochenzeiten, XP, Level, Serien, Quizpunkte, Bestwerte, geführte Sessions, Schlagmuster-, Rhythmus-, Griffbrett- und Akkordwechsel-Statistiken sowie abgeschlossene Lernstufen. Deine App-Einstellungen, Akkordauswahl, Tempi, Taktarten und Song-Arrangements bleiben erhalten.")
                .setNegativeButton("Abbrechen", null)
                .setPositiveButton("Alles zurücksetzen") { _, _ ->
                    val resetPrefs = a.getSharedPreferences("saitenwerk", 0)
                    val editor = resetPrefs.edit()
                    editor
                        // Lernstudio: Zeit, Serien, XP, Quiz und Routine
                        .remove("learn_daily_day")
                        .remove("learn_daily_seconds")
                        .remove("learn_daily_minutes")
                        .remove("learn_last_session_day")
                        .remove("learn_week_key")
                        .remove("learn_week_seconds")
                        .remove("learn_sessions")
                        .remove("learn_streak")
                        .remove("learn_xp")
                        .remove("learn_quiz_correct")
                        .remove("learn_quiz_total")
                        .remove("learn_best_quiz_streak")
                        .remove("learn_routine_day")
                        .remove("learn_routine_done")
                        .remove("learn_guided_day")
                        .remove("learn_guided_done")
                        // Lernpfad / Kompetenzwerte
                        .remove("learning_path_done")
                        .remove("learn_skill_changes")
                        .remove("learn_skill_rhythm")
                        .remove("learn_skill_strum")
                        // Rhythmus- und Schlagmuster-Bestwerte
                        .remove("learn_strum_best_score")
                        .remove("learn_strum_best_rounds")
                        .remove("learn_strum_best_combo")
                        // Akkordwechsel-Training
                        .remove("chord_training_best_streak")
                        .remove("chord_training_sessions")
                        .remove("chord_training_mastered")
                        // Griffbrett-Notentrainer
                        .remove("learn_fretboard_best_streak")
                        .remove("learn_fretboard_best_score")
                    val statsKeys = resetPrefs.all.keys.filter {
                        it.startsWith("learn_chord_listen_attempts_") ||
                        it.startsWith("learn_chord_listen_correct_")
                    }
                    statsKeys.forEach { editor.remove(it) }
                    editor.remove("learn_chord_listen_errors")
                    editor.remove("learn_chord_listen_best_streak")
                    editor.apply()
                    Toast.makeText(a, "Gesamter Lernfortschritt wurde zurückgesetzt", Toast.LENGTH_SHORT).show()
                }
                .show()
        }

        val aboutText = "Saitenwerk ist mehr als nur eine Gitarren-App – es ist ein Experiment.\n\n" +
            "Die Idee hinter diesem Projekt war von Anfang an eine ganz bestimmte: Ich wollte zeigen, dass man keine Programmierkenntnisse oder jahrelange Erfahrung in der Softwareentwicklung benötigt, um eine eigene App auf die Beine zu stellen.\n\n" +
            "Mit Neugier, Ausdauer und der Unterstützung künstlicher Intelligenz ist Saitenwerk entstanden – von der ersten Idee bis hin zu einer eigenständigen Android-App.\n\n" +
            "Man muss nicht alles können, um etwas Eigenes zu erschaffen. Man muss nur anfangen."
        val aboutCard = a.card().apply { radius = a.dp(18).toFloat(); strokeColor = a.getColor(R.color.sw_outline); strokeWidth = a.dp(1) }
        val aboutBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(18), a.dp(17), a.dp(18), a.dp(17)) }
        aboutBox.addView(TextView(a).apply {
            text = "Über Saitenwerk"
            textSize = 17f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(a.getColor(R.color.sw_copper))
        })
        aboutBox.addView(TextView(a).apply {
            text = aboutText
            textSize = 14f
            setLineSpacing(a.dp(2).toFloat(), 1f)
            setTextColor(a.getColor(R.color.sw_muted))
            setPadding(0, a.dp(7), 0, 0)
        })
        aboutCard.addView(aboutBox)
        page.addView(aboutCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = a.dp(13) })

        val buildNumber = version.substringAfterLast(".")
        val appInfoCard = a.card().apply { radius = a.dp(18).toFloat(); strokeColor = a.getColor(R.color.sw_outline); strokeWidth = a.dp(1) }
        val appInfoBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(18), a.dp(17), a.dp(18), a.dp(17)) }
        appInfoBox.addView(TextView(a).apply {
            text = "App-Informationen"
            textSize = 17f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(a.getColor(R.color.sw_copper))
        })
        fun infoRow(label: String, value: String) {
            val line = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, a.dp(8), 0, a.dp(4)) }
            line.addView(TextView(a).apply {
                text = label
                textSize = 13f
                setTextColor(a.getColor(R.color.sw_muted))
            }, LinearLayout.LayoutParams(0, -2, 1f))
            line.addView(TextView(a).apply {
                text = value
                textSize = 13f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(a.getColor(R.color.sw_text))
                gravity = Gravity.END
            })
            appInfoBox.addView(line)
        }
        infoRow("Version", version)
        infoRow("Build-Nummer", buildNumber)
        infoRow("Version-Code", code.toString())
        infoRow("Release-Kanal", "Beta")
        infoRow("Plattform", "Android")
        infoRow("Paket-ID", a.packageName)
        infoRow("Mindestversion", "Android 8.0 (API 26)")
        appInfoBox.addView(TextView(a).apply {
            text = "Changelog"
            textSize = 16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(a.getColor(R.color.sw_copper))
            setPadding(0, a.dp(16), 0, a.dp(4))
        })
        val changes = listOf(
            "27.11.2026 · Build 559" to "Premium-Akkordbereich: vollständige Bibliotheks-Startseite mit Suche, Favoriten, Qualitätsfiltern und zweispaltiger Akkordübersicht. Detailansicht mit hochkantem Griffbild, Saiten-/Fingerlegende, authentischer Gitarren-Hörprobe und Favoritenverwaltung. Navigation und leere Such-/Favoritenzustände überarbeitet; bestehende ChordLibrary und Lerntrainer bleiben gemeinsame Datenbasis.",
            "25.11.2026 · Build 503" to "Akkord-Blitztrainer Hör-Quiz: Akkorde ausschließlich anhand authentischer Gitarrenklänge erkennen. Wiederholbare Wiedergabe, vier Antwortmöglichkeiten und dieselben vier Schwierigkeitsstufen. Eigene Hör-Trefferquoten, Fehlerliste, Serien und Reaktionszeiten bleiben von der visuellen Akkorderkennung getrennt; stufengebundenes Hör-Fehlertraining. Der vollständige Lernfortschritt-Reset löscht auch sämtliche Hör- und Einzelakkord-Statistiken.",
            "25.11.2026 · Build 498" to "Akkord-Blitztrainer: vier technikbasierte Schwierigkeitsstufen (Anfänger, Fortgeschrittene Anfänger, Fortgeschritten, Experte). 93 eindeutige Griffbilder werden nach Grifftechnik einsortiert; Beschreibung und Akkordanzahl werden angezeigt. Adaptive Wiederholung, Fehlerliste und Einzelakkord-Statistiken bleiben erhalten; Fehlertraining bleibt innerhalb der gewählten Stufe.",
            "25.11.2026 · Build 495" to "Akkordgriff-Korrektur: C#7 und D#7 um die fehlende Quinte ergänzt. Das C6-Griffbild wurde als gültiger Shell-Akkord mit Grundton, Terz und Sexte geprüft; die Quinte darf hier bewusst entfallen. Die CI prüft Tonklassen sowie Sechs-Saiten- und Fingerpositionen. Der Premium-Blitztrainer und seine adaptive Datenbank bleiben erhalten.",
            "25.11.2026 · Build 491" to "Akkord-Blitztrainer Premium: vier Modi (Griffbild erkennen, Griff zuordnen, 60-Sekunden-Blitzrunde und Fehlertraining), adaptive Wiederholung nach individueller Trefferquote, dauerhaft gespeicherte Fehlerliste, Reaktionszeit und Serien. Die zentrale ChordLibrary wurde von 67 auf 94 eindeutige Griffbilder erweitert; neue Dur-, Moll-, Sept-, Add-, Sus-, Power-, übermäßige und verminderte Akkorde mit geprüften Sechs-Saiten- und Fingerpositionen. Der vollständige Lernfortschritt-Reset löscht auch die neuen Einzelakkord-Statistiken, bewahrt aber Modus- und Kategorieeinstellungen.",
            "25.11.2026 · Build 490" to "Update-Installation repariert: DownloadManager-Abschlussmeldungen werden auf Android 13+ über einen exportierten, auf die erwartete Download-ID und den tatsächlichen Download-Status geprüften Broadcast-Empfänger verarbeitet. Nach erfolgreichem APK-Download kann der Android-Installationsdialog automatisch geöffnet werden, ohne die Download-Benachrichtigung antippen zu müssen.",
            "25.11.2026 · Build 483" to "Verworfenes Songbook vollständig zurückgebaut: Navigation, Datenmodell, Repository, Listen-/Detailansichten, PDF-Importer, PDF-Viewer, PDFBox-Abhängigkeit und zugehörige Ressourcen aus dem App-Projekt entfernt. Song-Praxis, gemeinsamer Gitarrentrainer, Akkordbibliothek, Lernstudio, Lernfortschritt und Stimmgerät bleiben erhalten. Die CI prüft die Abwesenheit aller Songbook-Komponenten vor dem Build.",
            "20.11.2026 · Build 436" to "Gemeinsamer Gitarrentrainer: Akkordwechsel- und Schlagmuster-Training zu einem Trainer zusammengeführt. Beide Modi teilen Akkordauswahl, geordnete Akkordfolge, Taktart und Tempo; vorhandene Einstellungen werden übernommen. Akkordwechsel zeigt den aktuellen und nächsten Griff samt Griffbild, Schlagmuster nutzt die bestehende Wischsteuerung mit Tonwiedergabe und Timing-Auswertung. Separate ChordTrainingPanel-Implementierung und doppelte Traineroberfläche entfernt; Einstiege aus Song-Praxis und Akkordbibliothek auf den gemeinsamen Trainer umgestellt.",
            "19.11.2026 · Build 427" to "Gemeinsamer Gitarrentrainer: Akkordwechsel- und Schlagmuster-Modus in einer einzigen Trainingsoberfläche zusammengeführt. Akkordauswahl, geordnete Akkordfolge, Taktart und Tempo werden gemeinsam verwaltet; Modusumschaltung, ein Start-/Stopp-Steuerelement und ein gemeinsamer Trainingsablauf. Im Akkordwechsel-Modus werden Akkorddiagramm, Akkordfolge und Gitarrenwiedergabe pro Takt angezeigt; im Schlagmuster-Modus bleiben Wischgesten, Tonwiedergabe und Timing-Auswertung aktiv. Bestehende Akkordfolgen, Taktarten, Tempi und Trainingsfortschritte aus beiden bisherigen Trainern werden migriert und die Statistikwerte getrennt fortgeführt. Die separate Trainerklasse und doppelte Traineroberfläche in der Akkordbibliothek entfernt; Song-Praxis besitzt nur noch einen gemeinsamen Trainer-Einstieg.",
            "19.11.2026 · Build 426" to "Akkordwechsel-Training: Akkordauswahl-Dialog überarbeitet, damit Übernehmen auch bei langen Listen sichtbar bleibt. Schlagmuster-Trainer: Mehrfachauswahl von Gitarrenakkorden und Taktarten 3/4, 4/4 und 6/8; Akkordwechsel pro Takt. Bedienoberfläche vereinfacht: Muster-vorhören-Button, Takte-Button sowie Abschlag- und Aufschlag-Buttons entfernt. Schlag-Eingabe durch vertikale Wischgesten direkt auf den Schlagpfeilen ersetzt und mit Tonwiedergabe sowie Timing-Auswertung verbunden. Verwaiste Vorschau- und Taktanzahl-Zustände entfernt, erster Taktschlag korrigiert und Akkordreihenfolge dauerhaft geordnet gespeichert. Startbutton heißt jetzt Training starten. Redundante Pattern-Textzeile entfernt und Schlagpfeile vergrößert.",
            "18.11.2026 · Build 399" to "Vollständiger Lernfortschritt-Reset unter Einstellungen → Lernfortschritt. Übungszeiten, Tages- und Wochenwerte, XP, Level, Serien, Quizstatistiken, Lernpfad-Fortschritt und Trainings-Bestwerte werden gemeinsam zurückgesetzt. Persönliche App-Einstellungen und Trainingskonfigurationen bleiben erhalten.",
            "18.11.2026 · Build 394" to "Interaktiver Griffbrett-Notentrainer mit sechs Saiten und zwölf Bünden, zufälligen Notenaufgaben, Gitarrenton-Wiedergabe, direkter Richtig/Falsch-Rückmeldung und 10-Runden-Training. Bestserie und persönliche Bestleistung werden gespeichert.",
            "18.11.2026 · Build 392" to "Intelligenter Schlagmuster-Trainer mit acht Rhythmen in vier Schwierigkeitsstufen. Muster können vorgehört und anschließend selbst gespielt werden. Timing-Fenster, Rückmeldung und persönliche Bestwerte unterstützen das Training.",
            "18.11.2026 · Build 390" to "Persönliches Heute-üben-Dashboard im Lernstudio mit Schnellstart, Wochenübersicht und direktem Einstieg in die Trainingseinheiten.",
            "18.11.2026 · Build 387" to "Ausgangsbasis für die anschließenden Lernstudio-, Trainings- und Fortschrittsverbesserungen."
        )
        changes.forEach { (date, description) ->
            val entry = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(0, a.dp(8), 0, a.dp(8)) }
            entry.addView(TextView(a).apply {
                text = date
                textSize = 13f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(a.getColor(R.color.sw_text))
            })
            entry.addView(TextView(a).apply {
                text = description
                textSize = 13f
                setLineSpacing(a.dp(1).toFloat(), 1f)
                setTextColor(a.getColor(R.color.sw_muted))
                setPadding(0, a.dp(3), 0, 0)
            })
            appInfoBox.addView(entry)
        }
        appInfoCard.addView(appInfoBox)
        page.addView(appInfoCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = a.dp(13) })

        return ScrollView(a).apply { clipToPadding=false; addView(page) }
    }
}

class TunerFragment : Fragment() {
    @Volatile private var active = false
    private var recorder: AudioRecord? = null
    private var worker: Thread? = null
    private var noteView: TextView? = null
    private var hzView: TextView? = null
    private var centsView: TextView? = null
    private var targetView: TextView? = null
    private var statusView: TextView? = null
    private var gauge: TunerGaugeView? = null
    private var startButton: Button? = null
    private var instrumentSpinner: Spinner? = null
    private var alternativeSpinner: TextView? = null
    private var selectedAlternative = AlternativeTuning("Standard E", listOf("E2", "A2", "D3", "G3", "B3", "E4"))
    private var availableTunings = listOf(selectedAlternative)
    private var selectedMode = TuningMode.GUITAR
    private var referenceA4 = 440.0
    private var stringPanel: LinearLayout? = null
    private var selectedReferenceName: String? = null

    private enum class TuningMode(val label: String) {
        GUITAR("Gitarre · Standard · E–A–D–G–B–E"),
        CHROMATIC("Chromatisch · alle Töne"),
        BASS("Bass · Standard · E–A–D–G"),
        UKULELE("Ukulele · C-Stimmung · G–C–E–A"),
        VIOLIN("Violine · Standard · G–D–A–E"),
        VIOLA("Bratsche · Standard · C–G–D–A"),
        CELLO("Cello · Standard · C–G–D–A")
    }

    private data class Target(val name: String, val hz: Double)

    private data class AlternativeTuning(val label: String, val notes: List<String>)
    private fun tuningsFor(mode: TuningMode): List<AlternativeTuning> = when (mode) {
        TuningMode.GUITAR -> listOf(
            AlternativeTuning("Standard E", listOf("E2","A2","D3","G3","B3","E4")),
            AlternativeTuning("Drop D", listOf("D2","A2","D3","G3","B3","E4")),
            AlternativeTuning("Drop C", listOf("C2","G2","C3","F3","A3","D4")),
            AlternativeTuning("Double Drop D", listOf("D2","A2","D3","G3","B3","D4")),
            AlternativeTuning("DADGAD", listOf("D2","A2","D3","G3","A3","D4")),
            AlternativeTuning("Nashville", listOf("E3","A3","D4","G4","B3","E4")),
            AlternativeTuning("Open E", listOf("E2","B2","E3","G#3","B3","E4")),
            AlternativeTuning("Open G", listOf("D2","G2","D3","G3","B3","D4")),
            AlternativeTuning("Nick Drake · CGCFCE", listOf("C2","G2","C3","F3","C4","E4")),
            AlternativeTuning("Rain Song · DGCGCD", listOf("D2","G2","C3","G3","C4","D4"))
        )
        TuningMode.BASS -> listOf(
            AlternativeTuning("4-Saiter · E–A–D–G", listOf("E1","A1","D2","G2")),
            AlternativeTuning("4-Saiter · Drop D", listOf("D1","A1","D2","G2")),
            AlternativeTuning("4-Saiter · Drop C", listOf("C1","G1","C2","F2")),
            AlternativeTuning("5-Saiter · B–E–A–D–G", listOf("B0","E1","A1","D2","G2")),
            AlternativeTuning("6-Saiter · B–E–A–D–G–C", listOf("B0","E1","A1","D2","G2","C3"))
        )
        TuningMode.UKULELE -> listOf(
            AlternativeTuning("C-Stimmung · High G", listOf("G4","C4","E4","A4")),
            AlternativeTuning("C-Stimmung · Low G", listOf("G3","C4","E4","A4")),
            AlternativeTuning("D-Stimmung · A–D–F#–B", listOf("A4","D4","F#4","B4")),
            AlternativeTuning("Bariton · D–G–B–E", listOf("D3","G3","B3","E4"))
        )
        TuningMode.VIOLIN -> listOf(
            AlternativeTuning("Standard · G–D–A–E", listOf("G3","D4","A4","E5")),
            AlternativeTuning("Cross · A–E–A–E", listOf("A3","E4","A4","E5")),
            AlternativeTuning("GDGD", listOf("G3","D4","G4","D5"))
        )
        TuningMode.VIOLA -> listOf(
            AlternativeTuning("Standard · C–G–D–A", listOf("C3","G3","D4","A4")),
            AlternativeTuning("D-Stimmung · D–A–E–B", listOf("D3","A3","E4","B4"))
        )
        TuningMode.CELLO -> listOf(
            AlternativeTuning("Standard · C–G–D–A", listOf("C2","G2","D3","A3")),
            AlternativeTuning("D-Stimmung · D–A–D–A", listOf("D2","A2","D3","A3")),
            AlternativeTuning("Drop G · C–G–D–G", listOf("C2","G2","D3","G3"))
        )
        TuningMode.CHROMATIC -> emptyList()
    }














    override fun onResume() {
        super.onResume()
        requireActivity().window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

































































































































































































    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity
        val root = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        root.addView(a.title("Stimmgerät"))
        root.addView(a.body("Schnell und präzise stimmen · A4 = 440 Hz"))

        val selectorCard = a.card()
        val selector = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dp(16), a.dp(14), a.dp(16), a.dp(14))
        }
        selector.addView(TextView(a).apply {
            text = "INSTRUMENT"
            textSize = 13f
            setTextColor(a.getColor(R.color.sw_muted))
            setPadding(0, 0, 0, a.dp(6))
        })
        instrumentSpinner = Spinner(a).apply {
            val labels = TuningMode.values().map { it.label }
            adapter = object : ArrayAdapter<String>(a, R.layout.sw_spinner_item, labels) {
                private fun styled(position: Int, dropdown: Boolean): TextView = TextView(a).apply {
                    text = getItem(position).orEmpty()
                    setTextColor(a.getColor(R.color.sw_text))
                    textSize = if (dropdown) 14f else 15f
                    setTypeface(typeface, android.graphics.Typeface.BOLD)
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(a.dp(14), a.dp(if (dropdown) 12 else 10), a.dp(42), a.dp(if (dropdown) 12 else 10))
                    includeFontPadding = true
                    maxLines = 2
                    if (dropdown) {
                        background = a.premiumDropdownItemBackground()
                        minHeight = a.dp(52)
                    } else {
                        setBackground(android.graphics.drawable.GradientDrawable().apply {
                            setColor(a.getColor(R.color.sw_surface2))
                            cornerRadius = a.dp(14).toFloat()
                            setStroke(a.dp(1), a.getColor(R.color.sw_outline))
                        })
                        minHeight = a.dp(52)
                    }
                }
                override fun getView(position: Int, convertView: View?, parent: ViewGroup): View = styled(position, false)
                override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View = styled(position, true)
            }
            setSelection(TuningMode.values().indexOf(selectedMode))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) = Unit
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    selectedMode = TuningMode.values()[position]
                    configureAlternativeTunings()
                    targetView?.text = targetHint()
                    rebuildStringButtons()
                }
            }
        }
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        selector.addView(instrumentSpinner, LinearLayout.LayoutParams(-1, a.dp(52)))

        val alternativeTitle = TextView(a).apply {
            text = "STIMMUNG"
            textSize = 13f
            setTextColor(a.getColor(R.color.sw_muted))
            setPadding(0, a.dp(10), 0, a.dp(4))
        }
        selector.addView(alternativeTitle)
        alternativeSpinner = TextView(a).apply {
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(a.getColor(R.color.sw_text))
            gravity = Gravity.CENTER_VERTICAL
            setPadding(a.dp(14), a.dp(10), a.dp(42), a.dp(10))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(a.getColor(R.color.sw_surface2))
                cornerRadius = a.dp(12).toFloat()
                setStroke(a.dp(1), a.getColor(R.color.sw_copper))
            }
            minHeight = a.dp(52)
            isClickable = true
            isFocusable = true
            contentDescription = "Stimmung auswählen"
            setOnClickListener {
                val options = availableTunings
                if (options.isEmpty()) return@setOnClickListener
                androidx.appcompat.app.AlertDialog.Builder(a, R.style.ThemeOverlay_Saitenwerk_Dialog)
                    .setTitle("Alternative Stimmung wählen")
                    .setItems(options.map { it.label }.toTypedArray()) { _, which ->
                        val chosen = options.getOrNull(which) ?: return@setItems
                        selectedAlternative = chosen
                        text = chosen.label
                        targetView?.text = targetHint()
                        rebuildStringButtons()
                    }
                    .setNegativeButton("Abbrechen", null)
                    .show()
            }
        }
        selector.addView(alternativeSpinner, LinearLayout.LayoutParams(-1, a.dp(52)))
        configureAlternativeTunings()

        stringPanel = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, a.dp(6), 0, 0)
        }
        selector.addView(stringPanel, LinearLayout.LayoutParams(-1, a.dp(60)))
        selectorCard.addView(selector)

        val displayCard = a.card()
        val display = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(a.dp(14), a.dp(10), a.dp(14), a.dp(16))
        }

        targetView = TextView(a).apply {
            text = targetHint()
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(a.getColor(R.color.sw_muted))
        }
        display.addView(targetView, LinearLayout.LayoutParams(-1, a.dp(30)))

        noteView = TextView(a).apply {
            text = "—"
            textSize = 68f
            gravity = Gravity.CENTER
            setTextColor(a.getColor(R.color.sw_text))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            contentDescription = "Erkannter Ton"
        }
        display.addView(noteView, LinearLayout.LayoutParams(-1, a.dp(78)))

        gauge = TunerGaugeView(a).apply {
            contentDescription = "Stimmungsanzeige: links zu tief, Mitte gestimmt, rechts zu hoch"
        }
        display.addView(gauge, LinearLayout.LayoutParams(-1, a.dp(190)))

        centsView = TextView(a).apply {
            text = "0 Cent · möglichst nahe an 0 stimmen"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(a.getColor(R.color.sw_muted))
        }
        display.addView(centsView, LinearLayout.LayoutParams(-1, a.dp(32)))

        hzView = TextView(a).apply {
            text = "— Hz"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(a.getColor(R.color.sw_muted))
        }
        display.addView(hzView, LinearLayout.LayoutParams(-1, a.dp(32)))

        statusView = TextView(a).apply {
            text = "BEREIT · SAITE ANSCHLAGEN"
            textSize = 15f
            gravity = Gravity.CENTER
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(a.getColor(R.color.sw_copper))
        }
        display.addView(statusView, LinearLayout.LayoutParams(-1, a.dp(34)))

        startButton = a.button("Stimmen starten").also {
            it.setOnClickListener { if (active) stopTuner() else a.askMic { startTuner() } }
        }
        display.addView(startButton, LinearLayout.LayoutParams(-1, a.dp(52)).apply { topMargin = a.dp(8) })
        displayCard.addView(display)
        root.addView(displayCard, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(14)) })
        root.addView(selectorCard, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(10)) })

        rebuildStringButtons()
        return ScrollView(a).apply { addView(root) }
    }

    private fun configureAlternativeTunings() {
        val options = tuningsFor(selectedMode)
        availableTunings = options
        val chosen = options.firstOrNull()
        selectedAlternative = chosen ?: AlternativeTuning("Chromatisch", emptyList())
        val selector = alternativeSpinner ?: return
        selector.text = chosen?.label ?: "Keine alternative Stimmung"
        selector.isEnabled = options.isNotEmpty()
        selector.alpha = if (options.isNotEmpty()) 1f else 0.5f
    }

    private fun targetHint(): String =
        if (selectedMode == TuningMode.CHROMATIC) "Chromatisch: jeder Ton wird erkannt"
        else "Zielsaiten: " + targets().joinToString(" · ") { it.name }

    private fun noteFrequency(note: String): Double {
        val match = Regex("^([A-G])(#?)(-?\\d+)$").matchEntire(note)
            ?: return 440.0
        val base = mapOf("C" to 0, "D" to 2, "E" to 4, "F" to 5, "G" to 7, "A" to 9, "B" to 11)
        val midi = (match.groupValues[3].toInt() + 1) * 12 + base.getValue(match.groupValues[1]) + if (match.groupValues[2] == "#") 1 else 0
        return referenceA4 * 2.0.pow((midi - 69) / 12.0)
    }

    private fun targets(): List<Target> {
        if (selectedMode == TuningMode.CHROMATIC) return emptyList()
        return selectedAlternative.notes.mapIndexed { index, note ->
            Target((selectedAlternative.notes.size - index).toString() + note.replace(Regex("[0-9]"), ""), noteFrequency(note))
        }
    }

    private fun rebuildStringButtons() {
        val panel = stringPanel ?: return
        panel.removeAllViews()
        val list = targets()
        if (list.isEmpty()) {
            panel.addView(TextView(requireContext()).apply {
                text = "Chromatisch · keine Zielsaiten"; textSize = 12f
                gravity = Gravity.CENTER; setTextColor(requireContext().getColor(R.color.sw_muted))
            })
            return
        }
        list.forEach { target ->
            val selected = selectedReferenceName == target.name
            val button = TextView(requireContext()).apply {
                text = target.name + "\n" + "%.1f".format(target.hz) + " Hz"
                textSize = 11.5f; gravity = Gravity.CENTER; includeFontPadding = false
                setLineSpacing(0f, 1.05f); setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(if (selected) android.graphics.Color.WHITE else requireContext().getColor(R.color.sw_text))
                minHeight = (54 * resources.displayMetrics.density).toInt()
                isClickable = true; isFocusable = true
                contentDescription = "Referenzton Saite " + target.name + ", " + "%.1f".format(target.hz) + " Hertz abspielen"
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                    cornerRadius = 11f * resources.displayMetrics.density
                    setColor(if (selected) requireContext().getColor(R.color.sw_copper) else requireContext().getColor(R.color.sw_surface2))
                    setStroke(((if (selected) 2f else 1f) * resources.displayMetrics.density).toInt(),
                        if (selected) requireContext().getColor(R.color.sw_copper) else requireContext().getColor(R.color.sw_outline))
                }
                setPadding(2, 5, 2, 5)
                setOnClickListener {
                    selectedReferenceName = target.name
                    targetView?.text = "Referenzton · " + target.name + " · " + "%.1f".format(target.hz) + " Hz"
                    rebuildStringButtons()
                    playReferenceTone(target.hz)
                }
            }
            panel.addView(button, LinearLayout.LayoutParams(0, -1, 1f).apply {
                val m = (3f * resources.displayMetrics.density).roundToInt()
                setMargins(m, 0, m, 0)
            })
        }
    }

    /** Spielt eine echte, aufgenommene Gitarrensaite aus dem CC0-Samplepaket. */
    private fun playReferenceTone(frequency: Double = referenceA4) {
        if (!frequency.isFinite() || frequency !in 20.0..2000.0) return
        val stringNumber = selectedReferenceName?.take(1)?.toIntOrNull() ?: return
        GuitarAudioEngine.playTunedString(requireContext(), stringNumber, frequency, 0.88f)
    }

    private fun stopReferenceTone() {
        GuitarAudioEngine.stopAll()
    }

    private fun startTuner() {
        if (active) return
        val rate = 44100
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) { Toast.makeText(requireContext(), "Audioaufnahme wird von diesem Gerät nicht unterstützt.", Toast.LENGTH_LONG).show(); return }
        try {
            val size = maxOf(min, 8192)
            val audio = AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size)
            check(audio.state == AudioRecord.STATE_INITIALIZED) { "AudioRecord konnte nicht initialisiert werden" }
            recorder = audio; audio.startRecording(); active = true
            startButton?.text = "Stimmen stoppen"
            statusView?.text = "ICH HÖRE ZU …"
            worker = Thread {
                val samples = ShortArray(4096)
                var stablePitch = -1.0
                var stableFrames = 0
                var silentFrames = 0
                while (active) {
                    val n = audio.read(samples, 0, samples.size)
                    if (n > 2048) {
                        val hz = estimatePitch(samples, n, rate)
                        if (hz in 35.0..1100.0) {
                            silentFrames = 0
                            if (stablePitch > 0.0 && kotlin.math.abs(hz - stablePitch) / stablePitch < 0.035) {
                                stablePitch = stablePitch * 0.65 + hz * 0.35
                                stableFrames++
                            } else {
                                stablePitch = hz
                                stableFrames = 1
                            }
                            if (stableFrames >= 2) updatePitch(stablePitch)
                        } else {
                            stableFrames = 0
                            stablePitch = -1.0
                            silentFrames++
                            if (silentFrames == 5) resetPitchDisplay()
                        }
                    }
                }
            }.apply { name = "Saitenwerk-Tuner"; start() }
        } catch (e: Exception) {
            active = false; releaseRecorder(); startButton?.text = "Erneut versuchen"
            Toast.makeText(requireContext(), "Mikrofonfehler: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun updatePitch(hz: Double) {
        val result = if (selectedMode == TuningMode.CHROMATIC) {
            val midi = (69 + 12 * ln(hz / 440.0) / ln(2.0)).roundToInt()
            val target = 440.0 * 2.0.pow((midi - 69) / 12.0)
            val names = arrayOf("C", "C♯", "D", "D♯", "E", "F", "F♯", "G", "G♯", "A", "A♯", "B")
            val note = names[(midi % 12 + 12) % 12] + (midi / 12 - 1)
            note to target
        } else {
            val t = targets().minByOrNull { kotlin.math.abs(1200.0 * ln(hz / it.hz) / ln(2.0)) } ?: Target("—", 440.0)
            t.name to t.hz
        }
        val cents = (1200 * ln(hz / result.second) / ln(2.0)).roundToInt()
        val status = when {
            cents < -5 -> "ZU TIEF"
            cents > 5 -> "ZU HOCH"
            else -> "GESTIMMT"
        }
        activity?.runOnUiThread {
            if (!active) return@runOnUiThread
            noteView?.text = result.first
            hzView?.text = "%.1f Hz".format(hz)
            centsView?.text = when {
                cents > 0 -> "+$cents Cent"
                else -> "$cents Cent"
            }
            statusView?.text = status
            val tone = when {
                cents < -5 -> -1
                cents > 5 -> 1
                else -> 0
            }
            val statusColor = when (tone) {
                -1 -> android.graphics.Color.rgb(218, 174, 76)
                1 -> android.graphics.Color.rgb(210, 105, 98)
                else -> android.graphics.Color.rgb(92, 175, 142)
            }
            statusView?.setTextColor(statusColor)
            noteView?.setTextColor(if (tone == 0) statusColor else requireContext().getColor(R.color.sw_text))
            gauge?.setCents(cents)
        }
    }

    private fun estimatePitch(x: ShortArray, n: Int, sr: Int): Double {
        if (n < 2048) return -1.0
        var mean = 0.0
        for (i in 0 until n) mean += x[i].toDouble()
        mean /= n.toDouble()
        var energy = 0.0
        var peak = 0.0
        for (i in 0 until n) {
            val v = x[i].toDouble() - mean
            energy += v * v
            peak = maxOf(peak, kotlin.math.abs(v))
        }
        val rms = kotlin.math.sqrt(energy / n.toDouble())
        if (rms < 220.0 || peak < 550.0) return -1.0

        val minLag = maxOf(2, sr / 1100)
        val maxLag = minOf(sr / 32, n / 3)
        val difference = DoubleArray(maxLag + 1)
        val usable = n - maxLag
        for (lag in minLag..maxLag) {
            var sum = 0.0
            for (i in 0 until usable step 2) {
                val a = x[i].toDouble() - mean
                val b = x[i + lag].toDouble() - mean
                val d = a - b
                sum += d * d
            }
            difference[lag] = sum
        }

        // Cumulative Mean Normalized Difference (YIN).
        var running = 0.0
        for (lag in minLag..maxLag) {
            running += difference[lag]
            difference[lag] = if (running > 0.0) difference[lag] * (lag - minLag + 1) / running else 1.0
        }

        // Pick the first sufficiently good local minimum to reduce octave errors.
        var chosen = -1
        var lag = minLag
        while (lag < maxLag - 1) {
            if (difference[lag] < 0.16) {
                while (lag + 1 <= maxLag && difference[lag + 1] < difference[lag]) lag++
                chosen = lag
                break
            }
            lag++
        }
        if (chosen < 0) {
            var best = minLag
            for (candidate in minLag + 1..maxLag) {
                if (difference[candidate] < difference[best]) best = candidate
            }
            if (difference[best] > 0.28) return -1.0
            chosen = best
        }

        // Parabolic interpolation gives sub-sample period resolution.
        val refined = if (chosen > minLag && chosen < maxLag) {
            val left = difference[chosen - 1]
            val center = difference[chosen]
            val right = difference[chosen + 1]
            val denominator = left - 2.0 * center + right
            val offset = if (kotlin.math.abs(denominator) > 1e-12)
                (0.5 * (left - right) / denominator).coerceIn(-0.5, 0.5)
            else 0.0
            chosen.toDouble() + offset
        } else chosen.toDouble()

        val hz = sr.toDouble() / refined
        return if (hz in 30.0..1100.0) hz else -1.0
    }

    private fun resetPitchDisplay() {
        activity?.runOnUiThread {
            if (!active) return@runOnUiThread
            noteView?.text = "—"
            hzView?.text = "— Hz"
            centsView?.text = "— Cent"
            statusView?.text = "BEREIT · SAITE ANSCHLAGEN"
            gauge?.setCents(0)
        }
    }

    private fun releaseRecorder() {
        try { recorder?.stop() } catch (_: Exception) { }
        try { recorder?.release() } catch (_: Exception) { }
        recorder = null; worker = null
    }
    private fun stopTuner() {
        active = false
        releaseRecorder()
        stopReferenceTone()
        startButton?.text = "Stimmen starten"
        statusView?.text = "BEREIT · SAITE ANSCHLAGEN"
    }
    override fun onPause() { stopTuner(); requireActivity().window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        super.onPause() }
    override fun onDestroyView() { stopTuner(); noteView = null; hzView = null; centsView = null; targetView = null; statusView = null; gauge = null; startButton = null; instrumentSpinner = null; alternativeSpinner = null; super.onDestroyView() }
}
class TunerGaugeView(context: android.content.Context) : View(context) {
    private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    private val rect = android.graphics.RectF()
    private var cents = 0

    fun setCents(value: Int) {
        cents = value.coerceIn(-50, 50)
        invalidate()
    }

    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h * 0.78f
        val radius = minOf(w * 0.42f, h * 0.67f)
        rect.set(cx - radius, cy - radius, cx + radius, cy + radius)

        // Große, gut lesbare Halbkreis-Anzeige wie bei einem klassischen Hardware-Tuner.
        val segments = 31
        for (i in 0 until segments) {
            val start = 200f + i * (140f / segments)
            val center = i - (segments - 1) / 2f
            paint.style = android.graphics.Paint.Style.STROKE
            paint.strokeWidth = dp(8f)
            paint.strokeCap = android.graphics.Paint.Cap.BUTT
            paint.color = when {
                kotlin.math.abs(center) <= 2 -> android.graphics.Color.rgb(92, 155, 135)
                center < 0 -> android.graphics.Color.rgb(218, 174, 76)
                else -> android.graphics.Color.rgb(190, 88, 82)
            }
            canvas.drawArc(rect, start, 140f / segments - 2.2f, false, paint)
        }

        val angle = 270f + (cents / 50f) * 70f
        val rad = Math.toRadians(angle.toDouble())
        val x1 = cx + kotlin.math.cos(rad).toFloat() * radius * 0.18f
        val y1 = cy + kotlin.math.sin(rad).toFloat() * radius * 0.18f
        val x2 = cx + kotlin.math.cos(rad).toFloat() * radius * 0.91f
        val y2 = cy + kotlin.math.sin(rad).toFloat() * radius * 0.91f
        paint.color = android.graphics.Color.WHITE
        paint.strokeWidth = dp(4f)
        paint.strokeCap = android.graphics.Paint.Cap.ROUND
        canvas.drawLine(x1, y1, x2, y2, paint)

        paint.style = android.graphics.Paint.Style.FILL
        paint.color = android.graphics.Color.WHITE
        canvas.drawCircle(cx, cy, dp(7f), paint)

        paint.textAlign = android.graphics.Paint.Align.CENTER
        paint.typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
        paint.textSize = dp(13f)
        paint.color = android.graphics.Color.LTGRAY
        canvas.drawText("−50", cx - radius * 0.82f, cy + dp(24f), paint)
        canvas.drawText("0", cx, cy - radius * 0.91f, paint)
        canvas.drawText("+50", cx + radius * 0.82f, cy + dp(24f), paint)
    }

    private fun dp(v: Float) = v * resources.displayMetrics.density
}

data class ChordShape(val name: String, val quality: String, val frets: IntArray, val baseFret: Int = 1, val note: String = "", val fingers: IntArray = IntArray(6))
object ChordLibrary {
    val all = listOf(
        ChordShape("C", "Dur", intArrayOf(-1,3,2,0,1,0), note="Offener C-Dur-Griff", fingers=intArrayOf(0,3,2,0,1,0)),
        ChordShape("G", "Dur", intArrayOf(3,2,0,0,0,3), note="Offener G-Dur-Griff", fingers=intArrayOf(2,1,0,0,0,3)),
        ChordShape("D", "Dur", intArrayOf(-1,-1,0,2,3,2), note="Offener D-Dur-Griff", fingers=intArrayOf(0,0,0,1,3,2)),
        ChordShape("A", "Dur", intArrayOf(-1,0,2,2,2,0), note="Offener A-Dur-Griff", fingers=intArrayOf(0,0,1,2,3,0)),
        ChordShape("E", "Dur", intArrayOf(0,2,2,1,0,0), note="Offener E-Dur-Griff", fingers=intArrayOf(0,2,3,1,0,0)),
        ChordShape("F", "Dur", intArrayOf(1,3,3,2,1,1), note="Barré-Griff im 1. Bund", fingers=intArrayOf(1,3,4,2,1,1)),
        ChordShape("Am", "Moll", intArrayOf(-1,0,2,2,1,0), fingers=intArrayOf(0,0,2,3,1,0)),
        ChordShape("Em", "Moll", intArrayOf(0,2,2,0,0,0), fingers=intArrayOf(0,2,3,0,0,0)),
        ChordShape("Dm", "Moll", intArrayOf(-1,-1,0,2,3,1), fingers=intArrayOf(0,0,0,2,3,1)),
        ChordShape("Hm", "Moll", intArrayOf(-1,2,4,4,3,2), 2, note="Deutscher H-Moll-Barrégriff", fingers=intArrayOf(0,1,3,4,2,1)),
        ChordShape("C7", "Septakkord", intArrayOf(-1,3,2,3,1,0), fingers=intArrayOf(0,3,2,4,1,0)),
        ChordShape("D7", "Septakkord", intArrayOf(-1,-1,0,2,1,2), fingers=intArrayOf(0,0,0,2,1,3)),
        ChordShape("E7", "Septakkord", intArrayOf(0,2,0,1,0,0), fingers=intArrayOf(0,2,0,1,0,0)),
        ChordShape("G7", "Septakkord", intArrayOf(3,2,0,0,0,1), fingers=intArrayOf(3,2,0,0,0,1)),
        ChordShape("Am7", "Septakkord", intArrayOf(-1,0,2,0,1,0), fingers=intArrayOf(0,0,2,0,1,0)),
        ChordShape("Em7", "Septakkord", intArrayOf(0,2,0,0,0,0), fingers=intArrayOf(0,2,0,0,0,0)),
        ChordShape("Dsus2", "Sus-Akkord", intArrayOf(-1,-1,0,2,3,0), fingers=intArrayOf(0,0,0,1,3,0)),
        ChordShape("Dsus4", "Sus-Akkord", intArrayOf(-1,-1,0,2,3,3), fingers=intArrayOf(0,0,0,1,3,4)),
        ChordShape("Asus2", "Sus-Akkord", intArrayOf(-1,0,2,2,0,0), fingers=intArrayOf(0,0,2,3,0,0)),
        ChordShape("Asus4", "Sus-Akkord", intArrayOf(-1,0,2,2,3,0), fingers=intArrayOf(0,0,1,2,3,0)),
        ChordShape("H", "Dur", intArrayOf(-1,2,4,4,4,2), 2, note="H-Dur-Barrégriff", fingers=intArrayOf(0,1,3,3,3,1)),
        ChordShape("H7", "Septakkord", intArrayOf(-1,2,1,2,0,2), note="H-Dominantseptakkord", fingers=intArrayOf(0,2,1,3,0,4)),
        ChordShape("Hmaj7", "Septakkord", intArrayOf(-1,2,4,3,4,2), 2, note="H-Dur mit großer Septime", fingers=intArrayOf(0,1,3,2,4,1)),
        ChordShape("Hm7", "Septakkord", intArrayOf(-1,2,0,2,0,2), note="H-Mollseptakkord", fingers=intArrayOf(0,2,0,3,0,4)),
        ChordShape("Hsus2", "Sus-Akkord", intArrayOf(-1,2,4,4,2,2), 2, note="H-Sus2-Barrégriff", fingers=intArrayOf(0,1,3,4,1,1)),
        ChordShape("Hsus4", "Sus-Akkord", intArrayOf(-1,2,4,4,5,2), 2, note="H-Sus4-Barrégriff", fingers=intArrayOf(0,1,3,3,4,1)),
        ChordShape("Hadd9", "Add-Akkord", intArrayOf(-1,2,1,4,2,2), note="Hadd9-Barrégriff", fingers=intArrayOf(0,2,1,4,3,3)),
        ChordShape("H5", "Power-Akkord", intArrayOf(-1,2,4,4,-1,-1), 2, note="H-Powerchord", fingers=intArrayOf(0,1,3,4,0,0)),
        ChordShape("Bbm", "Moll", intArrayOf(-1,1,3,3,2,1), note="B-Moll-Barrégriff", fingers=intArrayOf(0,1,3,4,2,1)),
        ChordShape("Bbmaj7", "Septakkord", intArrayOf(-1,1,3,2,3,1), note="B-Dur mit großer Septime", fingers=intArrayOf(0,1,4,2,3,1)),
        ChordShape("Bbm7", "Septakkord", intArrayOf(-1,1,3,1,2,1), note="B-Mollseptakkord", fingers=intArrayOf(0,1,3,1,2,1)),
        ChordShape("Bbsus4", "Sus-Akkord", intArrayOf(-1,1,3,3,4,1), note="B-Sus4-Barrégriff", fingers=intArrayOf(0,1,3,3,4,1)),
        ChordShape("Bb5", "Power-Akkord", intArrayOf(-1,1,3,-1,-1,-1), note="B-Powerchord", fingers=intArrayOf(0,1,3,0,0,0)),
        ChordShape("Amaj7", "Septakkord", intArrayOf(-1,0,2,1,2,0), note="A-Dur mit großer Septime", fingers=intArrayOf(0,0,2,1,3,0)),
        ChordShape("Aadd9", "Add-Akkord", intArrayOf(-1,0,2,4,2,0), note="Offener Aadd9-Klang", fingers=intArrayOf(0,0,1,3,2,0)),
        ChordShape("Cm", "Moll", intArrayOf(-1,3,5,5,4,3), 3, note="C-Moll-Barrégriff", fingers=intArrayOf(0,1,3,4,2,1)),
        ChordShape("Cm7", "Septakkord", intArrayOf(-1,3,5,3,4,3), 3, note="C-Mollseptakkord", fingers=intArrayOf(0,1,3,1,2,1)),
        ChordShape("Csus4", "Sus-Akkord", intArrayOf(-1,3,3,0,1,1), note="C-Sus4", fingers=intArrayOf(0,3,4,0,1,1)),
        ChordShape("C5", "Power-Akkord", intArrayOf(-1,3,5,5,-1,-1), 3, note="C-Powerchord", fingers=intArrayOf(0,1,3,4,0,0)),
        ChordShape("Dadd9", "Add-Akkord", intArrayOf(-1,-1,0,2,3,0), note="Offener Dadd9-Klang", fingers=intArrayOf(0,0,0,1,3,0)),
        ChordShape("D5", "Power-Akkord", intArrayOf(-1,-1,0,2,3,-1), note="D-Powerchord", fingers=intArrayOf(0,0,0,1,3,0)),
        ChordShape("Emaj7", "Septakkord", intArrayOf(0,2,1,1,0,0), note="E-Dur mit großer Septime", fingers=intArrayOf(0,2,1,3,0,0)),
        ChordShape("Esus2", "Sus-Akkord", intArrayOf(0,2,4,4,0,0), note="E-Sus2", fingers=intArrayOf(0,1,3,4,0,0)),
        ChordShape("Esus4", "Sus-Akkord", intArrayOf(0,2,2,2,0,0), note="E-Sus4", fingers=intArrayOf(0,1,2,3,0,0)),
        ChordShape("Fm", "Moll", intArrayOf(1,3,3,1,1,1), note="F-Moll-Barrégriff", fingers=intArrayOf(1,3,4,1,1,1)),
        ChordShape("F7", "Septakkord", intArrayOf(1,3,1,2,1,1), note="F-Dominantseptakkord", fingers=intArrayOf(1,3,1,2,1,1)),
        ChordShape("Fmaj7", "Septakkord", intArrayOf(-1,-1,3,2,1,0), note="F-Dur mit großer Septime", fingers=intArrayOf(0,0,3,2,1,0)),
        ChordShape("Fm7", "Septakkord", intArrayOf(1,3,1,1,1,1), note="F-Mollseptakkord", fingers=intArrayOf(1,3,1,1,1,1)),
        ChordShape("Fsus4", "Sus-Akkord", intArrayOf(1,3,3,3,1,1), note="F-Sus4-Barrégriff", fingers=intArrayOf(1,3,3,3,1,1)),
        ChordShape("F5", "Power-Akkord", intArrayOf(1,3,3,-1,-1,-1), note="F-Powerchord", fingers=intArrayOf(1,3,4,0,0,0)),
        ChordShape("Gm", "Moll", intArrayOf(3,5,5,3,3,3), 3, note="G-Moll-Barrégriff", fingers=intArrayOf(1,3,4,1,1,1)),
        ChordShape("Gmaj7", "Septakkord", intArrayOf(3,2,0,0,0,2), note="Offener G-Durseptakkord", fingers=intArrayOf(2,1,0,0,0,3)),
        ChordShape("Gm7", "Septakkord", intArrayOf(3,5,3,3,3,3), 3, note="G-Mollseptakkord", fingers=intArrayOf(1,3,1,1,1,1)),
        ChordShape("Gsus2", "Sus-Akkord", intArrayOf(3,0,0,0,3,3), note="Offener G-Sus2-Klang", fingers=intArrayOf(2,0,0,0,3,4)),
        ChordShape("G5", "Power-Akkord", intArrayOf(3,5,5,-1,-1,-1), 3, note="G-Powerchord", fingers=intArrayOf(1,3,4,0,0,0)),
        ChordShape("B", "Dur", intArrayOf(-1,1,3,3,3,1), note="Deutscher B-Dur-Griff (international Bb)", fingers=intArrayOf(0,1,3,3,3,1)),
        ChordShape("Bb", "Dur", intArrayOf(-1,1,3,3,3,1), note="Barré-Durgriff", fingers=intArrayOf(0,1,3,3,3,1)),
        ChordShape("F#m", "Moll", intArrayOf(2,4,4,2,2,2), 2, note="Barré-Mollgriff", fingers=intArrayOf(1,3,4,1,1,1)),
        ChordShape("C#m", "Moll", intArrayOf(-1,4,6,6,5,4), 4, note="Barré-Mollgriff", fingers=intArrayOf(0,1,3,4,2,1)),
        ChordShape("B7", "Septakkord", intArrayOf(-1,1,3,1,3,1), note="Deutscher B7 (international Bb7)", fingers=intArrayOf(0,1,3,1,4,1)),
        ChordShape("A7", "Septakkord", intArrayOf(-1,0,2,0,2,0), note="Offener Septakkord", fingers=intArrayOf(0,0,1,0,2,0)),
        ChordShape("Dmaj7", "Septakkord", intArrayOf(-1,-1,0,2,2,2), note="Dur-Septakkord", fingers=intArrayOf(0,0,0,1,2,3)),
        ChordShape("Cmaj7", "Septakkord", intArrayOf(-1,3,2,0,0,0), note="Offener Dur-Septakkord", fingers=intArrayOf(0,3,2,0,0,0)),
        ChordShape("Dm7", "Septakkord", intArrayOf(-1,-1,0,2,1,1), note="Moll-Septakkord", fingers=intArrayOf(0,0,0,2,1,1)),
        ChordShape("Cadd9", "Add-Akkord", intArrayOf(-1,3,2,0,3,0), note="Offener Add9-Klang", fingers=intArrayOf(0,2,1,0,3,0)),
        ChordShape("Gsus4", "Sus-Akkord", intArrayOf(3,3,0,0,1,3), note="Sus4-Klang", fingers=intArrayOf(2,3,0,0,1,4)),
        ChordShape("E5", "Power-Akkord", intArrayOf(0,2,2,-1,-1,-1), note="Powerchord", fingers=intArrayOf(0,1,3,0,0,0)),
        ChordShape("A5", "Power-Akkord", intArrayOf(-1,0,2,2,-1,-1), note="Powerchord", fingers=intArrayOf(0,0,1,3,0,0)),
        // Ergänzte, spielbare Standard- und Barrévarianten – Teil derselben ChordLibrary.
        ChordShape("F#", "Dur", intArrayOf(2,4,4,3,2,2), 2, note="Fis-Dur-Barrégriff", fingers=intArrayOf(1,3,4,2,1,1)),
        ChordShape("C#", "Dur", intArrayOf(-1,4,6,6,6,4), 4, note="Cis-Dur-Barrégriff", fingers=intArrayOf(0,1,3,4,4,1)),
        ChordShape("G#", "Dur", intArrayOf(4,6,6,5,4,4), 4, note="Gis-Dur-Barrégriff", fingers=intArrayOf(1,3,4,2,1,1)),
        ChordShape("D#", "Dur", intArrayOf(-1,6,8,8,8,6), 6, note="Dis-Dur-Barrégriff", fingers=intArrayOf(0,1,3,4,4,1)),
        ChordShape("A#m", "Moll", intArrayOf(-1,1,3,3,2,1), note="Ais-Moll-Barrégriff", fingers=intArrayOf(0,1,3,4,2,1)),
        ChordShape("D#m", "Moll", intArrayOf(-1,6,8,8,7,6), 6, note="Dis-Moll-Barrégriff", fingers=intArrayOf(0,1,3,4,2,1)),
        ChordShape("G#m", "Moll", intArrayOf(4,6,6,4,4,4), 4, note="Gis-Moll-Barrégriff", fingers=intArrayOf(1,3,4,1,1,1)),
        ChordShape("Bm", "Moll", intArrayOf(-1,2,4,4,3,2), 2, note="H-Moll-Barrégriff (internationale Schreibweise)", fingers=intArrayOf(0,1,3,4,2,1)),
        ChordShape("F#m7", "Septakkord", intArrayOf(2,4,2,2,2,2), 2, note="Fis-Mollseptakkord", fingers=intArrayOf(1,3,1,1,1,1)),
        ChordShape("C#m7", "Septakkord", intArrayOf(-1,4,2,4,5,4), 2, note="Cis-Mollseptakkord", fingers=intArrayOf(0,2,1,3,4,2)),
        ChordShape("Bm7", "Septakkord", intArrayOf(-1,2,0,2,0,2), note="H-Mollseptakkord (internationale Schreibweise)", fingers=intArrayOf(0,2,0,3,0,4)),
        ChordShape("G#m7", "Septakkord", intArrayOf(4,6,4,4,4,4), 4, note="Gis-Mollseptakkord", fingers=intArrayOf(1,3,1,1,1,1)),
        ChordShape("A9", "Add-Akkord", intArrayOf(-1,0,2,4,2,3), note="Offener A-Add9-Klang", fingers=intArrayOf(0,0,1,3,2,4)),
        ChordShape("Eadd9", "Add-Akkord", intArrayOf(0,2,4,1,0,0), note="Offener E-Add9-Klang", fingers=intArrayOf(0,2,4,1,0,0)),
        ChordShape("Gadd9", "Add-Akkord", intArrayOf(3,0,0,0,0,3), note="Offener G-Add9-Klang", fingers=intArrayOf(2,0,0,0,0,3)),
        ChordShape("Fadd9", "Add-Akkord", intArrayOf(1,3,3,2,1,3), note="F-Add9-Barrévariante", fingers=intArrayOf(1,3,4,2,1,4)),
        ChordShape("F#7", "Septakkord", intArrayOf(2,4,2,3,2,2), 2, note="Fis-Dominantseptakkord", fingers=intArrayOf(1,3,1,2,1,1)),
        ChordShape("C#7", "Septakkord", intArrayOf(4,4,3,4,2,-1), note="Cis-Dominantseptakkord", fingers=intArrayOf(3,4,2,4,1,0)),
        ChordShape("G#7", "Septakkord", intArrayOf(4,6,4,5,4,4), 4, note="Gis-Dominantseptakkord", fingers=intArrayOf(1,3,1,2,1,1)),
        ChordShape("D#7", "Septakkord", intArrayOf(-1,6,5,6,4,6), 4, note="Dis-Dominantseptakkord", fingers=intArrayOf(0,3,2,4,1,4)),
        ChordShape("E7sus4", "Sus-Akkord", intArrayOf(0,2,0,2,0,0), note="Offener E7sus4-Klang", fingers=intArrayOf(0,1,0,2,0,0)),
        ChordShape("A7sus4", "Sus-Akkord", intArrayOf(-1,0,2,0,3,0), note="Offener A7sus4-Klang", fingers=intArrayOf(0,0,1,0,3,0)),
        ChordShape("C6", "Weitere Akkorde", intArrayOf(-1,3,2,2,1,0), note="C-Dur mit hinzugefügter Sexte", fingers=intArrayOf(0,3,2,4,1,0)),
        ChordShape("Am6", "Weitere Akkorde", intArrayOf(-1,0,2,2,1,2), note="A-Moll mit hinzugefügter Sexte", fingers=intArrayOf(0,0,2,3,1,4)),
        ChordShape("Eaug", "Weitere Akkorde", intArrayOf(0,3,2,1,1,0), note="E-übermäßiger Akkord", fingers=intArrayOf(0,3,2,1,1,0)),
        ChordShape("Edim7", "Vermindert", intArrayOf(0,1,2,0,2,0), note="E-verminderter Septakkord", fingers=intArrayOf(0,1,2,0,3,0))
    )
    val difficultyStages = listOf("Anfänger", "Fortgeschrittene Anfänger", "Fortgeschritten", "Experte")
    private val beginnerOpenChords = setOf("C", "G", "D", "A", "E", "Am", "Em", "Dm")
    private val expertExtensions = setOf(
        "C6", "Am6", "Eaug", "Edim7", "Hmaj7", "Bbmaj7", "Amaj7", "Emaj7", "Dmaj7", "Cmaj7",
        "Hadd9", "Fadd9", "A9"
    )
    fun difficultyFor(shape: ChordShape): String {
        if (shape.name in beginnerOpenChords) return "Anfänger"
        if (shape.name in expertExtensions || shape.quality == "Vermindert" || shape.name.endsWith("aug")) return "Experte"
        val fretted = shape.frets.filter { it > 0 }
        val indexBarre = shape.fingers.count { it == 1 } >= 3
        val movablePosition = shape.baseFret > 1 || (fretted.isNotEmpty() && fretted.minOrNull()!! > 0 && indexBarre)
        if (shape.quality == "Power-Akkord" || movablePosition) return "Fortgeschritten"
        return "Fortgeschrittene Anfänger"
    }

}





























/** Gemeinsame Sample-Engine für authentische Gitarrenklänge in der gesamten App. */
object GuitarAudioEngine {
    private val handler = Handler(Looper.getMainLooper())
    private var pool: SoundPool? = null
    private val sampleIds = IntArray(6)
    private val loadedIds = mutableSetOf<Int>()
    private val activeStreams = mutableSetOf<Int>()
    private val scheduled = mutableSetOf<Runnable>()
    private val pendingActions = mutableListOf<() -> Unit>()
    private var progressionTask: Runnable? = null
    private val openFrequencies = doubleArrayOf(82.4069, 110.0, 146.832, 196.0, 246.942, 329.628)

    @Synchronized
    private fun initialize(context: android.content.Context) {
        if (pool != null) return
        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        val created = SoundPool.Builder().setMaxStreams(16).setAudioAttributes(attributes).build()
        pool = created
        created.setOnLoadCompleteListener { _, sampleId, status ->
            if (status == 0) loadedIds.add(sampleId)
            if (loadedIds.size == 6) {
                val ready = pendingActions.toList()
                pendingActions.clear()
                ready.forEach { it.invoke() }
            }
        }
        val resources = intArrayOf(
            R.raw.guitar_string_6e, R.raw.guitar_string_5a, R.raw.guitar_string_4d,
            R.raw.guitar_string_3g, R.raw.guitar_string_2b, R.raw.guitar_string_1e
        )
        resources.forEachIndexed { index, resourceId ->
            sampleIds[index] = created.load(context.applicationContext, resourceId, 1)
        }
    }

    private fun whenReady(context: android.content.Context, action: () -> Unit) {
        initialize(context)
        if (loadedIds.size == 6) action() else pendingActions.add(action)
    }

    private fun playStringNow(index: Int, fret: Int, volume: Float, fadeMs: Long = 0L): Int {
        val player = pool ?: return 0
        if (index !in 0..5) return 0
        val rate = (2.0.pow(fret.coerceIn(0, 24) / 12.0)).coerceIn(0.5, 2.0).toFloat()
        val safeVolume = volume.coerceIn(0f, 1f)
        val stream = player.play(sampleIds[index], safeVolume, safeVolume, 1, 0, rate)
        if (stream != 0) {
            activeStreams.add(stream)
            if (activeStreams.size > 64) activeStreams.clear()
            if (fadeMs > 0L) {
                val steps = 5
                for (step in 1..steps) {
                    lateinit var task: Runnable
                    task = Runnable {
                        val level = safeVolume * (1f - step.toFloat() / steps)
                        try {
                            player.setVolume(stream, level, level)
                            if (step == steps) {
                                player.stop(stream)
                                activeStreams.remove(stream)
                            }
                        } catch (_: Exception) { }
                        scheduled.remove(task)
                    }
                    scheduled.add(task)
                    handler.postDelayed(task, fadeMs * step / steps)
                }
            }
        }
        return stream
    }

    fun playTunedString(context: android.content.Context, stringNumber: Int, frequency: Double, volume: Float = 0.86f) {
        if (stringNumber !in 1..6 || !frequency.isFinite() || frequency !in 20.0..2000.0) return
        val index = 6 - stringNumber
        val rate = (frequency / openFrequencies[index]).coerceIn(0.5, 2.0).toFloat()
        whenReady(context) {
            stopAll()
            val player = pool ?: return@whenReady
            val stream = player.play(sampleIds[index], volume.coerceIn(0f, 1f), volume.coerceIn(0f, 1f), 2, 0, rate)
            if (stream != 0) activeStreams.add(stream)
        }
    }

    fun playString(context: android.content.Context, index: Int, fret: Int = 0, volume: Float = 0.6f, fadeMs: Long = 0L) {
        whenReady(context) { playStringNow(index, fret, volume, fadeMs) }
    }

    /** Kurzer, echter Saitenanschlag als musikalischer Metronom-Puls. */
    fun playTick(context: android.content.Context, accented: Boolean) {
        playString(context, if (accented) 0 else 5, 0, if (accented) 0.62f else 0.38f, 145L)
    }

    /** Zupft die Saiten eines Akkords mit leicht versetztem Anschlag. */
    fun playChord(
        context: android.content.Context,
        shape: ChordShape,
        downstroke: Boolean = true,
        volume: Float = 0.72f,
        replace: Boolean = false
    ) {
        if (replace) stopAll()
        whenReady(context) {
            val order = if (downstroke) (0..5).toList() else (5 downTo 0).toList()
            order.forEachIndexed { position, stringIndex ->
                val fret = shape.frets.getOrNull(stringIndex) ?: -1
                if (fret >= 0) {
                    lateinit var task: Runnable
                    task = Runnable {
                        playStringNow(stringIndex, fret, volume * if (stringIndex == 0 || stringIndex == 5) 0.88f else 1f)
                        scheduled.remove(task)
                    }
                    scheduled.add(task)
                    handler.postDelayed(task, position * 15L)
                }
            }
        }
    }

    /** Spielt eine Song-Akkordfolge mit vier gleichmäßigen Schlägen pro Akkord. */
    fun playProgression(context: android.content.Context, chordNames: List<String>, bpm: Int = 80, onFinished: (() -> Unit)? = null) {
        val shapes = chordNames.mapNotNull { name -> ChordLibrary.all.firstOrNull { it.name == name.trim() } }
        if (shapes.isEmpty()) return
        stopAll()
        whenReady(context) {
            var index = 0
            val interval = (240000L / bpm.coerceIn(40, 180)).coerceAtLeast(500L)
            val task = object : Runnable {
                override fun run() {
                    if (index >= shapes.size) {
                        progressionTask = null
                        onFinished?.invoke()
                        return
                    }
                    playChord(context, shapes[index], downstroke = true, volume = 0.78f)
                    index++
                    handler.postDelayed(this, interval)
                }
            }
            progressionTask = task
            handler.post(task)
        }
    }

    fun stopAll() {
        progressionTask?.let { handler.removeCallbacks(it) }
        progressionTask = null
        scheduled.toList().forEach { handler.removeCallbacks(it) }
        scheduled.clear()
        pendingActions.clear()
        val player = pool
        activeStreams.toList().forEach { stream ->
            try { player?.stop(stream) } catch (_: Exception) { }
        }
        activeStreams.clear()
    }
}

open class ChordDiagramView(context: android.content.Context, initialShape: ChordShape? = null) : View(context) {
    private var shape: ChordShape? = initialShape
    private val gridPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(142, 151, 163)
        strokeWidth = dp(1.35f)
        style = android.graphics.Paint.Style.STROKE
    }
    private val nutPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(224, 226, 229)
        strokeWidth = dp(4f)
        strokeCap = android.graphics.Paint.Cap.ROUND
    }
    private val dotPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(217, 154, 112)
        style = android.graphics.Paint.Style.FILL
    }
    private val fingerPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.WHITE
        textAlign = android.graphics.Paint.Align.CENTER
        textSize = dp(10f)
        typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
    }
    private val labelPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.LTGRAY
        textAlign = android.graphics.Paint.Align.CENTER
        textSize = dp(11f)
        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
    }
    private val titlePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(217, 154, 112)
        textAlign = android.graphics.Paint.Align.LEFT
        textSize = dp(11f)
        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
    }

    fun setChord(value: ChordShape?) {
        shape = value
        contentDescription = value?.let { "Akkord ${it.name}, sechs Saiten, Griffbild mit Fingerzahlen und Barré" } ?: "Gitarrengriffbild"
        invalidate()
    }

    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val chord = shape ?: return
        val left = dp(51f)
        val right = width - dp(13f)
        val top = dp(39f)
        val bottom = height - dp(31f)
        if (right <= left || bottom <= top) return
        val fretWidth = (right - left) / 4f
        val stringGap = (bottom - top) / 5f
        val radius = dp(8.5f)
        val strings = arrayOf("E", "A", "D", "G", "H", "e")

        canvas.drawText(if (chord.baseFret <= 1) "Sattel" else "Bund ${chord.baseFret}", left, dp(15f), titlePaint)
        // Sechs waagerechte Saiten, von der tiefen E- bis zur hohen e-Saite.
        for (i in 0..5) {
            val y = bottom - i * stringGap
            gridPaint.strokeWidth = dp(if (i == 0 || i == 5) 1.8f else 1.25f)
            canvas.drawLine(left, y, right, y, gridPaint)
            canvas.drawText(strings[i], dp(10f), y + dp(4f), labelPaint)
        }
        // Senkrechte Bundlinien; am ersten Bund ersetzt der kräftige Sattel die Linie.
        for (i in 0..4) {
            val x = left + i * fretWidth
            gridPaint.strokeWidth = dp(1.25f)
            canvas.drawLine(x, top, x, bottom, gridPaint)
        }
        if (chord.baseFret <= 1) canvas.drawLine(left, top, left, bottom, nutPaint)
        else {
            for (i in 0..3) {
                val x = left + (i + .5f) * fretWidth
                labelPaint.textSize = dp(9f)
                canvas.drawText((chord.baseFret + i).toString(), x, dp(28f), labelPaint)
            }
            labelPaint.textSize = dp(11f)
        }

        // Gleicher Finger auf gleichem Bund über mehrere Saiten = Barré.
        val fingerGroups = (0..5).mapNotNull { string ->
            val fret = chord.frets.getOrElse(string) { -1 }
            val finger = chord.fingers.getOrElse(string) { 0 }
            if (fret > 0 && finger in 1..4) Triple(string, fret, finger) else null
        }.groupBy { Pair(it.second, it.third) }
        fingerGroups.values.filter { it.size > 1 }.forEach { group ->
            val fret = group.first().second
            val relative = fret - chord.baseFret
            if (relative in 0..3) {
                val x = left + (relative + .5f) * fretWidth
                val firstY = bottom - group.maxOf { it.first } * stringGap
                val lastY = bottom - group.minOf { it.first } * stringGap
                val barrePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                    color = dotPaint.color
                    strokeWidth = dp(16f)
                    strokeCap = android.graphics.Paint.Cap.ROUND
                }
                canvas.drawLine(x, firstY, x, lastY, barrePaint)
            }
        }

        for (i in 0..5) {
            val y = bottom - i * stringGap
            val fret = chord.frets.getOrElse(i) { -1 }
            val finger = chord.fingers.getOrElse(i) { 0 }
            when {
                fret < 0 -> canvas.drawText("×", dp(32f), y + dp(4f), labelPaint)
                fret == 0 -> canvas.drawText("○", dp(32f), y + dp(4f), labelPaint)
                else -> {
                    val relative = fret - chord.baseFret
                    if (relative in 0..3) {
                        val x = left + (relative + .5f) * fretWidth
                        canvas.drawCircle(x, y, radius, dotPaint)
                        if (finger in 1..4) {
                            val baseline = y - (fingerPaint.ascent() + fingerPaint.descent()) / 2f
                            canvas.drawText(finger.toString(), x, baseline, fingerPaint)
                        }
                    }
                }
            }
        }
        labelPaint.textSize = dp(9f)
        canvas.drawText("1 Zeige  ·  2 Mitte  ·  3 Ring  ·  4 Klein", width / 2f, height - dp(7f), labelPaint)
        labelPaint.textSize = dp(11f)
    }

    private fun dp(value: Float) = value * resources.displayMetrics.density
}
/** Spielt den ausgewählten Griff als kurze, gezupfte Gitarrenprobe. */
object ChordPreviewPlayer {
    fun play(shape: ChordShape, context: android.content.Context) {
        GuitarAudioEngine.playChord(context, shape, downstroke = true, volume = 0.88f, replace = true)
    }
    fun stop() = GuitarAudioEngine.stopAll()
}

class ChordsFragment : Fragment() {
    // SAITENWERK_CHORDS_PREMIUM_V1
    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity
        val prefs = a.getSharedPreferences("saitenwerk", 0)
        val favKey = "fav_chords"
        val root = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(a).apply { clipToPadding = false; isFillViewport = true }
        val page = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dp(18), a.dp(10), a.dp(18), a.dp(30))
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, -1))
        scroll.addView(page)

        page.addView(a.title("Akkorde"))
        page.addView(a.body("Deine Akkordbibliothek · entdecken, anhören und sicher greifen"))

        val total = ChordLibrary.all.distinctBy { it.name }.size
        val hero = a.card().apply { radius = a.dp(22).toFloat(); strokeColor = a.getColor(R.color.sw_outline); strokeWidth = a.dp(1) }
        val heroBox = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dp(18), a.dp(17), a.dp(18), a.dp(17))
            background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = a.dp(22).toFloat()
                setColor(a.getColor(R.color.sw_surface2))
            }
        }
        heroBox.addView(TextView(a).apply {
            text = "DEIN AKKORD-ATLAS"
            textSize = 10f; letterSpacing = .16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(a.getColor(R.color.sw_copper))
        })
        heroBox.addView(TextView(a).apply {
            text = "$total Akkorde. Ein Griff nach dem anderen."
            textSize = 20f; setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(a.getColor(R.color.sw_text)); setPadding(0, a.dp(7), 0, a.dp(5))
        })
        heroBox.addView(TextView(a).apply {
            text = "Finde deinen Klang, sieh dir den Fingersatz an und höre jeden Akkord direkt in der App."
            textSize = 13f; setLineSpacing(a.dp(2).toFloat(), 1f)
            setTextColor(a.getColor(R.color.sw_muted))
        })
        val heroStats = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, a.dp(14), 0, 0) }
        fun stat(value: String, label: String): View {
            val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            box.addView(TextView(a).apply { text = value; textSize = 18f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_copper)) })
            box.addView(TextView(a).apply { text = label; textSize = 11f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0, a.dp(2), 0, 0) })
            return box
        }
        heroStats.addView(stat(total.toString(), "Griffbilder"), LinearLayout.LayoutParams(0, -2, 1f))
        heroStats.addView(stat((prefs.getStringSet(favKey, emptySet())?.size ?: 0).toString(), "Favoriten"), LinearLayout.LayoutParams(0, -2, 1f))
        heroStats.addView(stat("6", "Saiten im Blick"), LinearLayout.LayoutParams(0, -2, 1f))
        heroBox.addView(heroStats)
        hero.addView(heroBox)
        page.addView(hero, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = a.dp(17) })

        val searchWrap = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(a.dp(14), 0, a.dp(12), 0)
            background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = a.dp(16).toFloat(); setColor(a.getColor(R.color.sw_surface))
                setStroke(a.dp(1), a.getColor(R.color.sw_outline))
            }
        }
        searchWrap.addView(TextView(a).apply { text = "⌕"; textSize = 25f; setTextColor(a.getColor(R.color.sw_copper)); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(a.dp(30), a.dp(54)))
        val search = EditText(a).apply {
            hint = "Akkord suchen – z. B. C, Am7, F# …"
            textSize = 14f; setSingleLine(true)
            setTextColor(a.getColor(R.color.sw_text)); setHintTextColor(a.getColor(R.color.sw_muted))
            background = android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT)
            setPadding(a.dp(8), 0, 0, 0)
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
        }
        searchWrap.addView(search, LinearLayout.LayoutParams(0, a.dp(54), 1f))
        page.addView(searchWrap, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = a.dp(14) })

        val filters = listOf("Alle", "Favoriten", "Dur", "Moll", "Septakkorde", "Sus", "Add", "Power")
        var activeFilter = "Alle"
        val filterScroll = HorizontalScrollView(a).apply { isHorizontalScrollBarEnabled = false; clipToPadding = false }
        val filterRow = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        filterScroll.addView(filterRow)
        page.addView(filterScroll, LinearLayout.LayoutParams(-1, a.dp(48)).apply { bottomMargin = a.dp(15) })

        val countLabel = TextView(a).apply {
            textSize = 12f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(a.dp(2), 0, 0, a.dp(9))
        }
        page.addView(countLabel)
        val grid = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        page.addView(grid)

        val detailCard = a.card().apply { visibility = View.GONE; radius = a.dp(22).toFloat(); strokeColor = a.getColor(R.color.sw_outline); strokeWidth = a.dp(1) }
        val detail = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(17), a.dp(16), a.dp(17), a.dp(17)) }
        detailCard.addView(detail)
        page.addView(detailCard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = a.dp(18) })

        var selected: ChordShape? = null
        lateinit var render: () -> Unit
        fun showDetail(ch: ChordShape) {
            selected = ch
            detail.removeAllViews()
            val heading = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val nameBlock = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            nameBlock.addView(TextView(a).apply { text = ch.name; textSize = 31f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_copper)) })
            nameBlock.addView(TextView(a).apply { text = ch.quality + if (ch.note.isNotBlank()) " · ${ch.note}" else ""; textSize = 12f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0, a.dp(2), 0, 0) })
            heading.addView(nameBlock, LinearLayout.LayoutParams(0, -2, 1f))
            val close = TextView(a).apply { text = "✕"; textSize = 19f; gravity = Gravity.CENTER; setTextColor(a.getColor(R.color.sw_muted)); setPadding(a.dp(10), a.dp(5), a.dp(5), a.dp(5)); setOnClickListener { detailCard.visibility = View.GONE; selected = null } }
            heading.addView(close)
            detail.addView(heading)
            val diagramPanel = LinearLayout(a).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                setPadding(a.dp(8), a.dp(8), a.dp(8), a.dp(8))
                background = android.graphics.drawable.GradientDrawable().apply { cornerRadius = a.dp(18).toFloat(); setColor(a.getColor(R.color.sw_surface2)) }
            }
            diagramPanel.addView(ChordDiagramView(a, ch), LinearLayout.LayoutParams(-1, a.dp(265)))
            detail.addView(diagramPanel, LinearLayout.LayoutParams(-1, -2).apply { topMargin = a.dp(13) })
            detail.addView(TextView(a).apply {
                text = "Tiefe E-Saite links · hohe e-Saite rechts\n× nicht spielen  ·  ○ leer anschlagen  ·  Zahlen = Greiffinger"
                textSize = 11f; setLineSpacing(a.dp(2).toFloat(), 1f); setTextColor(a.getColor(R.color.sw_muted)); setPadding(a.dp(2), a.dp(9), a.dp(2), a.dp(8))
            })
            val play = a.button("▶  Akkord anhören").apply { tag = "saitenwerk-primary" }
            play.setOnClickListener { ChordPreviewPlayer.play(ch, a) }
            detail.addView(play, LinearLayout.LayoutParams(-1, a.dp(52)).apply { topMargin = a.dp(4) })
            val saved = prefs.getStringSet(favKey, emptySet())?.toMutableSet() ?: mutableSetOf()
            val favorite = a.button(if (ch.name in saved) "★  Aus Favoriten entfernen" else "☆  Zu Favoriten hinzufügen")
            favorite.setOnClickListener {
                val now = prefs.getStringSet(favKey, emptySet())?.toMutableSet() ?: mutableSetOf()
                if (!now.add(ch.name)) now.remove(ch.name)
                prefs.edit().putStringSet(favKey, now).apply()
                favorite.text = if (ch.name in now) "★  Aus Favoriten entfernen" else "☆  Zu Favoriten hinzufügen"
                render()
            }
            detail.addView(favorite, LinearLayout.LayoutParams(-1, a.dp(50)).apply { topMargin = a.dp(8) })
            detailCard.visibility = View.VISIBLE
            scroll.post { scroll.smoothScrollTo(0, detailCard.top - a.dp(12)) }
        }

        render = {
            val query = search.text?.toString()?.trim()?.lowercase(java.util.Locale.GERMAN).orEmpty()
            val favorites = prefs.getStringSet(favKey, emptySet()) ?: emptySet()
            val filtered = ChordLibrary.all.distinctBy { it.name }.filter { chord ->
                val matchesQuery = query.isBlank() || chord.name.lowercase(java.util.Locale.GERMAN).contains(query) || chord.quality.lowercase(java.util.Locale.GERMAN).contains(query) || chord.note.lowercase(java.util.Locale.GERMAN).contains(query)
                val f = when (activeFilter) {
                    "Favoriten" -> chord.name in favorites
                    "Dur" -> chord.quality == "Dur"
                    "Moll" -> chord.quality == "Moll"
                    "Septakkorde" -> chord.quality == "Septakkord"
                    "Sus" -> chord.quality == "Sus-Akkord"
                    "Add" -> chord.quality == "Add-Akkord"
                    "Power" -> chord.quality == "Power-Akkord"
                    else -> true
                }
                matchesQuery && f
            }.sortedWith(compareBy<ChordShape> { it.name.firstOrNull()?.uppercaseChar() ?: 'Z' }.thenBy { it.name })
            countLabel.text = "${filtered.size} ${if (filtered.size == 1) "Akkord" else "Akkorde"}  ·  ${if (activeFilter == "Alle") "gesamte Bibliothek" else activeFilter}"
            grid.removeAllViews()
            if (filtered.isEmpty()) {
                val empty = a.card()
                empty.addView(TextView(a).apply { text = if (activeFilter == "Favoriten") "Noch keine Favoriten gespeichert. Öffne einen Akkord und tippe auf „Zu Favoriten hinzufügen“." else "Keine passenden Akkorde gefunden. Ändere den Suchbegriff oder wähle einen anderen Filter."; textSize = 13f; setLineSpacing(a.dp(3).toFloat(), 1f); setTextColor(a.getColor(R.color.sw_muted)); setPadding(a.dp(16), a.dp(17), a.dp(16), a.dp(17)) })
                grid.addView(empty)
            } else {
                filtered.chunked(2).forEach { pair ->
                    val row = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.TOP }
                    pair.forEach { chord ->
                        val card = a.card().apply {
                            radius = a.dp(17).toFloat(); strokeColor = a.getColor(R.color.sw_outline); strokeWidth = a.dp(1)
                            isClickable = true; isFocusable = true
                            setOnClickListener { showDetail(chord) }
                        }
                        val body = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(13), a.dp(13), a.dp(12), a.dp(13)) }
                        val topLine = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                        topLine.addView(TextView(a).apply { text = chord.name; textSize = 22f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_copper)) }, LinearLayout.LayoutParams(0, -2, 1f))
                        if (chord.name in favorites) topLine.addView(TextView(a).apply { text = "★"; textSize = 13f; setTextColor(a.getColor(R.color.sw_copper)) })
                        body.addView(topLine)
                        body.addView(TextView(a).apply { text = chord.quality; textSize = 11f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0, a.dp(2), 0, a.dp(8)) })
                        val action = TextView(a).apply { text = "Griff ansehen  ›"; textSize = 11f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_text)) }
                        body.addView(action)
                        card.addView(body)
                        row.addView(card, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = a.dp(if (pair.indexOf(chord) == 0) 5 else 0); leftMargin = a.dp(if (pair.indexOf(chord) == 1) 5 else 0); bottomMargin = a.dp(10) })
                    }
                    if (pair.size == 1) row.addView(View(a), LinearLayout.LayoutParams(0, 1, 1f))
                    grid.addView(row)
                }
            }
        }
        filters.forEach { filter ->
            val chip = TextView(a).apply {
                text = filter; textSize = 12f; gravity = Gravity.CENTER; setPadding(a.dp(15), 0, a.dp(15), 0)
                isClickable = true; isFocusable = true
                setOnClickListener { activeFilter = filter; (0 until filterRow.childCount).map { filterRow.getChildAt(it) }.forEach { v ->
                    if (v is TextView) {
                        val active = v.text.toString() == activeFilter
                        v.setTextColor(a.getColor(if (active) R.color.sw_on_accent else R.color.sw_text))
                        v.background = android.graphics.drawable.GradientDrawable().apply { cornerRadius = a.dp(20).toFloat(); setColor(a.getColor(if (active) R.color.sw_copper else R.color.sw_surface2)); if (!active) setStroke(a.dp(1), a.getColor(R.color.sw_outline)) }
                    }
                }; render() }
            }
            filterRow.addView(chip, LinearLayout.LayoutParams(-2, a.dp(38)).apply { rightMargin = a.dp(7) })
        }
        (0 until filterRow.childCount).map { filterRow.getChildAt(it) }.forEach { v -> if (v is TextView) {
            val active = v.text.toString() == activeFilter
            v.setTextColor(a.getColor(if (active) R.color.sw_on_accent else R.color.sw_text))
            v.background = android.graphics.drawable.GradientDrawable().apply { cornerRadius = a.dp(20).toFloat(); setColor(a.getColor(if (active) R.color.sw_copper else R.color.sw_surface2)); if (!active) setStroke(a.dp(1), a.getColor(R.color.sw_outline)) }
        } }
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { render() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        render()

        val footer = a.button("⚡  Akkord-Blitztrainer öffnen")
        footer.setOnClickListener { a.openSection(5) }
        page.addView(footer, LinearLayout.LayoutParams(-1, a.dp(52)).apply { topMargin = a.dp(18) })
        page.addView(TextView(a).apply {
            text = "Tipp: Speichere häufig benötigte Griffe als Favoriten. So findest du sie beim nächsten Üben sofort wieder."
            textSize = 11f; setLineSpacing(a.dp(2).toFloat(), 1f); setTextColor(a.getColor(R.color.sw_muted)); setPadding(a.dp(3), a.dp(11), a.dp(3), 0)
        })
        return root
    }
}

class GuitarFretboardView(context: android.content.Context) : View(context) {
    private var chord: ChordShape? = null
    private val line = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(145, 153, 164)
        strokeWidth = dp(1.25f)
    }
    private val nut = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(224, 224, 218)
        strokeWidth = dp(4f)
    }
    private val marker = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(217, 154, 112)
        style = android.graphics.Paint.Style.FILL
    }
    private val markerText = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.WHITE
        textSize = dp(11f)
        textAlign = android.graphics.Paint.Align.CENTER
        typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    private val labels = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.LTGRAY
        textSize = dp(10f)
        textAlign = android.graphics.Paint.Align.CENTER
    }

    fun setChord(value: ChordShape?) {
        chord = value
        contentDescription = value?.let { "Gitarrengriffbrett für Akkord ${it.name}" } ?: "Gitarrengriffbrett"
        invalidate()
    }

    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val shape = chord ?: return
        val left = dp(35f)
        val right = width - dp(12f)
        val top = dp(22f)
        val bottom = height - dp(18f)
        if (right <= left || bottom <= top) return
        val fretWidth = (right - left) / 5f
        val stringGap = (bottom - top) / 5f
        val stringNames = arrayOf("E", "A", "D", "G", "H", "e")

        // Griffbrett: tiefe E-Saite unten, hohe e-Saite oben.
        for (i in 0..5) {
            val y = bottom - i * stringGap
            line.strokeWidth = dp(if (i == 0 || i == 5) 1.8f else 1.2f)
            canvas.drawLine(left, y, right, y, line)
            canvas.drawText(stringNames[i], dp(15f), y + dp(3.5f), labels)
        }
        for (fret in 0..5) {
            val x = left + fret * fretWidth
            canvas.drawLine(x, top, x, bottom, if (fret == 0 && shape.baseFret == 1) nut else line)
        }

        if (shape.baseFret > 1) {
            canvas.drawText("${shape.baseFret}. Bund", left + dp(34f), dp(12f), labels)
        } else {
            canvas.drawText("Sattel", left + dp(18f), dp(12f), labels)
        }

        shape.frets.forEachIndexed { stringIndex, fret ->
            val y = bottom - stringIndex * stringGap
            when {
                fret < 0 -> canvas.drawText("×", left - dp(13f), y + dp(4f), markerText)
                fret == 0 -> canvas.drawText("○", left - dp(13f), y + dp(4f), markerText)
                else -> {
                    val relative = fret - shape.baseFret
                    if (relative in 0..4) {
                        val x = left + (relative + .5f) * fretWidth
                        canvas.drawCircle(x, y, dp(7f), marker)
                    }
                }
            }
        }
    }

    private fun dp(value: Float) = value * resources.displayMetrics.density
}





/** Interaktives Griffbrett für das Finden einzelner Töne. */
class FretboardNoteView(context: android.content.Context) : View(context) {
    private val grid = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(92, 104, 120); strokeWidth = dp(1f)
        style = android.graphics.Paint.Style.STROKE
    }
    private val stringPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(205, 209, 214); strokeWidth = dp(1.6f)
    }
    private val accent = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(217, 154, 112); style = android.graphics.Paint.Style.FILL
    }
    private val text = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(224, 226, 229); textAlign = android.graphics.Paint.Align.CENTER
        textSize = dp(10f); typeface = android.graphics.Typeface.create("sans-serif-medium", 0)
    }
    var onNoteTap: ((Int, Int) -> Unit)? = null
    var highlighted: Pair<Int, Int>? = null
        set(value) { field = value; invalidate() }

    private val strings = arrayOf("E", "A", "D", "G", "H", "e")
    private val frets = 12

    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val left = dp(34f); val right = width - dp(12f)
        val top = dp(30f); val bottom = height - dp(34f)
        if (right <= left || bottom <= top) return
        val fw = (right - left) / frets.toFloat()
        val sg = (bottom - top) / 5f
        for (fret in 0..frets) {
            val x = left + fret * fw
            grid.strokeWidth = dp(if (fret == 0) 4f else 1.15f)
            canvas.drawLine(x, top, x, bottom, grid)
        }
        for (string in 0..5) {
            val y = bottom - string * sg
            stringPaint.strokeWidth = dp(1.25f + string * .16f)
            canvas.drawLine(left, y, right, y, stringPaint)
            canvas.drawText(strings[string], dp(15f), y + dp(4f), text)
        }
        for (fret in 1..frets) {
            val x = left + (fret - .5f) * fw
            if (fret == 3 || fret == 5 || fret == 7 || fret == 9) canvas.drawCircle(x, (top + bottom) / 2f, dp(4f), accent)
            if (fret == 12) {
                canvas.drawCircle(x, top + (bottom-top)*.34f, dp(4f), accent)
                canvas.drawCircle(x, top + (bottom-top)*.66f, dp(4f), accent)
            }
            canvas.drawText(fret.toString(), x, height - dp(12f), text)
        }
        highlighted?.let { (string, fret) ->
            val x = left + (fret.coerceIn(0, frets) + .5f) * fw
            val y = bottom - string.coerceIn(0, 5) * sg
            canvas.drawCircle(x, y, dp(10f), accent)
        }
    }

    override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
        if (event.action != android.view.MotionEvent.ACTION_UP) return true
        val left = dp(34f); val right = width - dp(12f)
        val top = dp(30f); val bottom = height - dp(34f)
        if (right <= left || bottom <= top) return true
        val fw = (right - left) / frets.toFloat()
        val sg = (bottom - top) / 5f
        val string = ((bottom - event.y) / sg).toInt().coerceIn(0, 5)
        val fret = ((event.x - left) / fw).toInt().coerceIn(0, frets)
        onNoteTap?.invoke(string, fret)
        performClick()
        return true
    }
    override fun performClick(): Boolean { super.performClick(); return true }
    private fun dp(v: Float) = v * resources.displayMetrics.density
}

class LearnFragment : Fragment() {
    private var rhythmHandler: Handler? = null
    private var rhythmRunning = false
    private var rhythmBeat = 0
    private var rhythmBpm = 80
    private var rhythmMeter = "4/4"
    private var rhythmStartedAt = 0L
    private var quizStartedAt = 0L
    private var quizCountdownHandler: Handler? = null
    private var onSessionElapsed: ((Int) -> Unit)? = null
    private var strumHandler: Handler? = null
    private var strumRunning = false
    private var strumStartedAt = 0L

    override fun onDestroyView() {
        finishQuizSession()
        stopRhythm()
        stopStrumming()
        onSessionElapsed = null
        super.onDestroyView()
    }

    override fun onResume() {
        super.onResume()
        requireActivity().window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onPause() {
        requireActivity().window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        super.onPause()
    }

    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity
        val prefs = a.getSharedPreferences("saitenwerk", 0)
        val root = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dp(16), a.dp(8), a.dp(16), a.dp(24))
        }
        val scroll = ScrollView(a).apply { clipToPadding = false; isFillViewport = true }
        val content = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, a.dp(20)) }
        scroll.addView(content)

        fun roundedCard(): MaterialCardView = a.card().apply {
            radius = a.dp(20).toFloat()
            strokeColor = a.getColor(R.color.sw_outline)
            strokeWidth = a.dp(1)
            cardElevation = a.dp(2).toFloat()
        }
        fun addGap(dp: Int = 10) { content.addView(Space(a), LinearLayout.LayoutParams(1, a.dp(dp))) }

        fun updatePracticeStats() {
            val correct = prefs.getInt("learn_quiz_correct", 0)
            val total = prefs.getInt("learn_quiz_total", 0)
            val best = prefs.getInt("learn_best_quiz_streak", 0)
            val day = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.GERMANY).format(java.util.Date())
            val dailySeconds = if (prefs.getString("learn_daily_day", "") == day) prefs.getInt("learn_daily_seconds", prefs.getInt("learn_daily_minutes", 0) * 60) else 0
            val minutes = String.format(java.util.Locale.GERMANY, "%.1f min", dailySeconds / 60.0)
            val routineDone = if (prefs.getString("learn_routine_day", "") == day) Integer.bitCount(prefs.getInt("learn_routine_done", 0)) else 0
            val routineTotal = 5
            val rate = if (total > 0) correct * 100 / total else 0
            val stats = content.findViewWithTag<LinearLayout>("learnStats")
            stats?.let {
                it.removeAllViews()
                fun stat(value: String, label: String) {
                    val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
                    box.addView(TextView(a).apply { text = value; textSize = 21f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_copper)); gravity = Gravity.CENTER })
                    box.addView(TextView(a).apply { text = label; textSize = 10f; setTextColor(a.getColor(R.color.sw_muted)); gravity = Gravity.CENTER; setPadding(0, a.dp(2), 0, 0) })
                    it.addView(box, LinearLayout.LayoutParams(0, a.dp(58), 1f))
                }
                stat("$routineDone/$routineTotal", "Heute")
                stat(minutes, "Übungszeit")
                stat("$rate%", "Quiz-Treffer")
                stat("$best", "Beste Serie")
            }
            content.findViewWithTag<TextView>("learnToday")?.text =
                if (routineDone == routineTotal) "Heute geschafft · starke Arbeit!" else "Heute: $routineDone von $routineTotal Einheiten"
            content.findViewWithTag<ProgressBar>("learnTodayProgress")?.apply { max = routineTotal; progress = routineDone }
        }

        fun recordPracticeDay() {
            val day = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.GERMANY).format(java.util.Date())
            val last = prefs.getString("learn_last_session_day", "")
            val streak = prefs.getInt("learn_streak", 0)
            val yesterday = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.GERMANY).format(java.util.Date(System.currentTimeMillis() - 86400000L))
            if (last != day) {
                prefs.edit().putString("learn_last_session_day", day).putInt("learn_streak", if (last == yesterday) streak + 1 else 1).apply()
            }
        }

        fun recordSession(seconds: Int) {
            val day = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.GERMANY).format(java.util.Date())
            recordPracticeDay()
            val oldSeconds = if (prefs.getString("learn_daily_day", "") == day) prefs.getInt("learn_daily_seconds", prefs.getInt("learn_daily_minutes", 0) * 60) else 0
            val totalSeconds = oldSeconds + seconds.coerceAtLeast(1)
            val cal = java.util.Calendar.getInstance()
            val weekKey = cal.get(java.util.Calendar.YEAR).toString() + "-" + cal.get(java.util.Calendar.WEEK_OF_YEAR).toString()
            val oldWeekSeconds = if (prefs.getString("learn_week_key", "") == weekKey) prefs.getInt("learn_week_seconds", 0) else 0
            prefs.edit().putString("learn_daily_day", day).putInt("learn_daily_seconds", totalSeconds)
                .putInt("learn_daily_minutes", totalSeconds / 60)
                .putString("learn_week_key", weekKey)
                .putInt("learn_week_seconds", oldWeekSeconds + seconds.coerceAtLeast(1))
                .putInt("learn_sessions", prefs.getInt("learn_sessions", 0) + 1).apply()
            updatePracticeStats()
        }
        onSessionElapsed = { seconds -> recordSession(seconds) }

        fun finishQuizSession() { this@LearnFragment.finishQuizSession() }

        var overviewAction: (() -> Unit)? = null

        fun panel(heading: String, description: String): Pair<MaterialCardView, LinearLayout> {
            val card = roundedCard()
            val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(16), a.dp(15), a.dp(16), a.dp(16)) }
            box.addView(TextView(a).apply { text = heading; textSize = 19f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_copper)) })
            box.addView(a.body(description, 13f))
            card.addView(box)
            return card to box
        }

        fun showQuiz() {
            finishQuizSession(); stopRhythm(); stopStrumming(); content.removeAllViews()
            quizStartedAt = android.os.SystemClock.elapsedRealtime()
            val (card, box) = panel("Akkord-Blitztrainer", "Trainiere Akkorderkennung mit der vollständigen Akkordbibliothek. Das System merkt sich deine Fehler und gewichtet unsichere Griffe stärker.")

            var mode = prefs.getString("learn_chord_quiz_mode", "recognize") ?: "recognize"
            val validStages = listOf("Alle") + ChordLibrary.difficultyStages
            var category = (prefs.getString("learn_chord_quiz_category", "Alle") ?: "Alle")
                .takeIf { it in validStages } ?: "Alle"
            if (prefs.getString("learn_chord_quiz_category", "Alle") !in validStages) {
                prefs.edit().putString("learn_chord_quiz_category", "Alle").apply()
            }
            var currentShape: ChordShape? = null
            var locked = false
            var localStreak = 0
            var answered = 0
            var localCorrect = 0
            var questionStartedAt = android.os.SystemClock.elapsedRealtime()
            var remainingSeconds = 60
            var roundFinished = false
            var currentOptions: List<ChordShape> = emptyList()
            val quizHandler = Handler(Looper.getMainLooper())
            quizCountdownHandler = quizHandler
            var timerTask: Runnable? = null

            val modeNames = linkedMapOf(
                "recognize" to "Griffbild erkennen",
                "reverse" to "Griff zuordnen",
                "blitz" to "Blitzrunde · 60 Sek.",
                "mistakes" to "Fehlertraining",
                "listen" to "Hör-Quiz · Akkord erkennen",
                "listenMistakes" to "Hör-Fehlertraining"
            )
            val header = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val modeButton = a.button("Modus · " + (modeNames[mode] ?: modeNames["recognize"]))
            val categoryButton = a.button("Stufe · $category")
            header.addView(modeButton, LinearLayout.LayoutParams(0, a.dp(44), 1f))
            header.addView(categoryButton, LinearLayout.LayoutParams(0, a.dp(44), 1f).apply { leftMargin = a.dp(6) })
            box.addView(header)
            val stageHint = TextView(a).apply {
                textSize = 12f
                setTextColor(a.getColor(R.color.sw_muted))
                setPadding(a.dp(2), a.dp(5), a.dp(2), a.dp(4))
            }
            box.addView(stageHint, LinearLayout.LayoutParams(-1, -2))
            val stageDescriptions = mapOf(
                "Alle" to "Alle Griffbilder · gemischtes Training",
                "Anfänger" to "Offene Grundakkorde · sichere erste Wechsel",
                "Fortgeschrittene Anfänger" to "Offene Sus-, Sept- und Add9-Griffe",
                "Fortgeschritten" to "Barré-Griffe und Powerchords",
                "Experte" to "Erweiterte Voicings, Jazz- und Sonderakkorde"
            )
            fun updateStageHeader() {
                val count = ChordLibrary.all.filterNot { it.name == "Bb" }.distinctBy { it.name }
                    .count { category == "Alle" || ChordLibrary.difficultyFor(it) == category }
                categoryButton.text = if (category == "Alle") "Stufe · Alle" else "Stufe · $category"
                stageHint.text = (stageDescriptions[category] ?: "") + " · $count Akkorde"
            }
            updateStageHeader()

            val statsRow = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val score = TextView(a).apply { textSize = 12f; setTextColor(a.getColor(R.color.sw_muted)) }
            val streak = TextView(a).apply { textSize = 12f; setTextColor(a.getColor(R.color.sw_copper)); gravity = Gravity.END }
            statsRow.addView(score, LinearLayout.LayoutParams(0, a.dp(34), 1f))
            statsRow.addView(streak, LinearLayout.LayoutParams(0, a.dp(34), 1f))
            box.addView(statsRow)
            val timerLabel = TextView(a).apply { textSize = 13f; setTextColor(a.getColor(R.color.sw_copper)); gravity = Gravity.CENTER; text = if (mode == "blitz") "01:00" else "Ohne Zeitlimit" }
            box.addView(timerLabel, LinearLayout.LayoutParams(-1, a.dp(26)))
            val progress = ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100; progress = 0
                progressTintList = android.content.res.ColorStateList.valueOf(a.getColor(R.color.sw_copper))
            }
            box.addView(progress, LinearLayout.LayoutParams(-1, a.dp(5)))
            val prompt = TextView(a).apply {
                textSize = 17f; setTypeface(typeface, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER; setTextColor(a.getColor(R.color.sw_text)); setPadding(0, a.dp(12), 0, a.dp(4))
            }
            box.addView(prompt, LinearLayout.LayoutParams(-1, a.dp(48)))
            val diagram = FrameLayout(a)
            box.addView(diagram, LinearLayout.LayoutParams(-1, a.dp(210)))
            val listenButton = a.button("Akkord erneut anhören").apply {
                visibility = if (mode == "listen" || mode == "listenMistakes") View.VISIBLE else View.GONE
                contentDescription = "Gitarrenakkord erneut abspielen"
            }
            box.addView(listenButton, LinearLayout.LayoutParams(-1, a.dp(46)).apply { bottomMargin = a.dp(6) })
            listenButton.setOnClickListener {
                currentShape?.let { GuitarAudioEngine.playChord(a, it, downstroke = true, volume = 0.88f, replace = true) }
            }
            val choices = GridLayout(a).apply { columnCount = 2; useDefaultMargins = false }
            box.addView(choices, LinearLayout.LayoutParams(-1, -2))
            val feedback = TextView(a).apply {
                text = "Wähle die passende Antwort."; textSize = 13f; gravity = Gravity.CENTER
                setTextColor(a.getColor(R.color.sw_muted)); setPadding(a.dp(4), a.dp(10), a.dp(4), a.dp(8))
            }
            box.addView(feedback, LinearLayout.LayoutParams(-1, -2))
            val actions = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
            val next = a.button("Nächste Frage")
            val finish = a.button("Beenden")
            actions.addView(next, LinearLayout.LayoutParams(0, a.dp(46), 1f))
            actions.addView(finish, LinearLayout.LayoutParams(0, a.dp(46), 1f).apply { leftMargin = a.dp(6) })
            box.addView(actions)

            fun keyFor(name: String) = name.replace(Regex("[^A-Za-z0-9]"), "_")
            fun updateHeader() {
                val listening = mode == "listen" || mode == "listenMistakes"
                val total = prefs.getInt(if (listening) "learn_chord_listen_total" else "learn_quiz_total", 0)
                val correct = prefs.getInt(if (listening) "learn_chord_listen_correct" else "learn_quiz_correct", 0)
                val rate = if (total > 0) correct * 100 / total else 0
                score.text = (if (listening) "Hören " else "Gesamt ") + "$correct/$total · $rate%"
                val best = if (listening) prefs.getInt("learn_chord_listen_best_streak", 0) else prefs.getInt("learn_best_quiz_streak", 0)
                streak.text = "Serie $localStreak · Best $best · Runde $localCorrect/$answered"
                progress.progress = if (mode == "blitz") ((60 - remainingSeconds).coerceIn(0, 60) * 100 / 60) else (answered % 10) * 10
            }
            fun stopTimer() {
                timerTask?.let { quizHandler.removeCallbacks(it) }
                timerTask = null
            }
            fun finishRound() {
                if (roundFinished) return
                roundFinished = true
                locked = true
                stopTimer()
                for (j in 0 until choices.childCount) choices.getChildAt(j).isEnabled = false
                val accuracy = if (answered > 0) localCorrect * 100 / answered else 0
                prompt.text = "Runde abgeschlossen"
                diagram.removeAllViews()
                feedback.text = "$localCorrect von $answered richtig · $accuracy% Treffer · beste Serie ${prefs.getInt("learn_best_quiz_streak", 0)}. Unsichere Akkorde wurden für dein Fehlertraining gespeichert."
                feedback.setTextColor(a.getColor(R.color.sw_copper))
                next.text = "Neue Runde starten"
                updateHeader()
            }
            fun eligiblePool(): List<ChordShape> {
                val all = ChordLibrary.all
                    .filterNot { it.name == "Bb" } // Deutsches B ist der eindeutige Bibliotheksname für B-flat.
                    .distinctBy { it.name }
                val byCategory = if (category == "Alle") all else all.filter { ChordLibrary.difficultyFor(it) == category }
                val listening = mode == "listen" || mode == "listenMistakes"
                val mistakeKey = if (listening) "learn_chord_listen_errors" else "learn_chord_quiz_errors"
                val mistakes = prefs.getStringSet(mistakeKey, emptySet()) ?: emptySet()
                val mistakeMode = mode == "mistakes" || mode == "listenMistakes"
                val byMistakes = if (mistakeMode) byCategory.filter { it.name in mistakes } else byCategory
                // Beide Fehlertrainings bleiben innerhalb der gewählten Stufe.
                val usable = if (mistakeMode && byMistakes.size >= 4) byMistakes else byCategory
                return usable.distinctBy { it.frets.joinToString(",") + "@" + it.baseFret }
            }
            fun chooseAdaptive(pool: List<ChordShape>): ChordShape {
                val listening = mode == "listen" || mode == "listenMistakes"
                val ranked = pool.map { shape ->
                    val key = keyFor(shape.name)
                    val attempts = prefs.getInt(if (listening) "learn_chord_listen_attempts_$key" else "learn_chord_q_attempts_$key", 0)
                    val hits = prefs.getInt(if (listening) "learn_chord_listen_correct_$key" else "learn_chord_q_correct_$key", 0)
                    val accuracy = if (attempts == 0) 0.45 else hits.toDouble() / attempts
                    val errorKey = if (listening) "learn_chord_listen_errors" else "learn_chord_quiz_errors"
                    val errors = prefs.getStringSet(errorKey, emptySet()) ?: emptySet()
                    shape to (if (shape.name in errors) 3.0 else 1.0) + (1.0 - accuracy) * 3.0
                }
                val weighted = ranked.sortedByDescending { it.second }.take(maxOf(1, (ranked.size * 0.55).toInt()))
                return weighted.random().first
            }
            fun recordAnswer(shape: ChordShape, correctAnswer: Boolean, responseMs: Long) {
                val key = keyFor(shape.name)
                val attempts = prefs.getInt("learn_chord_q_attempts_$key", 0) + 1
                val hits = prefs.getInt("learn_chord_q_correct_$key", 0) + if (correctAnswer) 1 else 0
                val streakKey = "learn_chord_q_streak_$key"
                val chordStreak = if (correctAnswer) prefs.getInt(streakKey, 0) + 1 else 0
                val errors = (prefs.getStringSet("learn_chord_quiz_errors", emptySet()) ?: emptySet()).toMutableSet()
                if (correctAnswer && chordStreak >= 3) errors.remove(shape.name) else if (!correctAnswer) errors.add(shape.name)
                val oldFastest = prefs.getLong("learn_chord_q_fastest_ms", 0L)
                val fastest = if (correctAnswer && (oldFastest == 0L || responseMs < oldFastest)) responseMs else oldFastest
                val total = prefs.getInt("learn_quiz_total", 0) + 1
                val correct = prefs.getInt("learn_quiz_correct", 0) + if (correctAnswer) 1 else 0
                val best = maxOf(prefs.getInt("learn_best_quiz_streak", 0), localStreak)
                prefs.edit()
                    .putInt("learn_chord_q_attempts_$key", attempts)
                    .putInt("learn_chord_q_correct_$key", hits)
                    .putInt(streakKey, chordStreak)
                    .putStringSet("learn_chord_quiz_errors", errors)
                    .putLong("learn_chord_q_fastest_ms", fastest)
                    .putLong("learn_chord_q_response_total_ms", prefs.getLong("learn_chord_q_response_total_ms", 0L) + responseMs)
                    .putInt("learn_chord_q_response_count", prefs.getInt("learn_chord_q_response_count", 0) + 1)
                    .putInt("learn_quiz_total", total).putInt("learn_quiz_correct", correct)
                    .putInt("learn_best_quiz_streak", best)
                    .putInt("learn_xp", prefs.getInt("learn_xp", 0) + if (correctAnswer) 10 else 3)
                    .apply()
            }
            fun recordListenAnswer(shape: ChordShape, correctAnswer: Boolean, responseMs: Long) {
                val key = keyFor(shape.name)
                val attempts = prefs.getInt("learn_chord_listen_attempts_$key", 0) + 1
                val hits = prefs.getInt("learn_chord_listen_correct_$key", 0) + if (correctAnswer) 1 else 0
                val streakKey = "learn_chord_listen_streak_$key"
                val chordStreak = if (correctAnswer) prefs.getInt(streakKey, 0) + 1 else 0
                val errors = (prefs.getStringSet("learn_chord_listen_errors", emptySet()) ?: emptySet()).toMutableSet()
                if (correctAnswer && chordStreak >= 3) errors.remove(shape.name) else if (!correctAnswer) errors.add(shape.name)
                val total = prefs.getInt("learn_chord_listen_total", 0) + 1
                val correct = prefs.getInt("learn_chord_listen_correct", 0) + if (correctAnswer) 1 else 0
                val best = maxOf(prefs.getInt("learn_chord_listen_best_streak", 0), localStreak)
                val oldFastest = prefs.getLong("learn_chord_listen_fastest_ms", 0L)
                val fastest = if (correctAnswer && (oldFastest == 0L || responseMs < oldFastest)) responseMs else oldFastest
                prefs.edit()
                    .putInt("learn_chord_listen_attempts_$key", attempts)
                    .putInt("learn_chord_listen_correct_$key", hits)
                    .putInt(streakKey, chordStreak)
                    .putStringSet("learn_chord_listen_errors", errors)
                    .putInt("learn_chord_listen_total", total)
                    .putInt("learn_chord_listen_correct", correct)
                    .putInt("learn_chord_listen_best_streak", best)
                    .putLong("learn_chord_listen_fastest_ms", fastest)
                    .putLong("learn_chord_listen_response_total_ms", prefs.getLong("learn_chord_listen_response_total_ms", 0L) + responseMs)
                    .putInt("learn_chord_listen_response_count", prefs.getInt("learn_chord_listen_response_count", 0) + 1)
                    .putInt("learn_quiz_total", prefs.getInt("learn_quiz_total", 0) + 1)
                    .putInt("learn_quiz_correct", prefs.getInt("learn_quiz_correct", 0) + if (correctAnswer) 1 else 0)
                    .putInt("learn_best_quiz_streak", maxOf(prefs.getInt("learn_best_quiz_streak", 0), localStreak))
                    .putInt("learn_xp", prefs.getInt("learn_xp", 0) + if (correctAnswer) 10 else 3)
                    .apply()
            }
            var answerQuestion: ((String) -> Unit)? = null
            fun showChoices(options: List<ChordShape>, correctShape: ChordShape) {
                choices.removeAllViews()
                if (mode == "reverse") {
                    options.forEach { option ->
                        val tile = FrameLayout(a).apply {
                            background = android.graphics.drawable.GradientDrawable().apply {
                                cornerRadius = a.dp(12).toFloat(); setColor(a.getColor(R.color.sw_surface2)); setStroke(a.dp(1), a.getColor(R.color.sw_outline))
                            }
                            isClickable = true; isFocusable = true
                            contentDescription = "Griffbild ${option.quality} auswählen"
                            setOnClickListener { answerQuestion?.invoke(option.name) }
                        }
                        tile.addView(ChordDiagramView(a, option), FrameLayout.LayoutParams(-1, -1))
                        choices.addView(tile, GridLayout.LayoutParams().apply {
                            width = 0; height = a.dp(142); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                            setMargins(a.dp(3), a.dp(3), a.dp(3), a.dp(3))
                        })
                    }
                } else {
                    options.forEach { option ->
                        val button = a.button(option.name)
                        button.setOnClickListener { answerQuestion?.invoke(option.name) }
                        choices.addView(button, GridLayout.LayoutParams().apply {
                            width = 0; height = a.dp(48); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                            setMargins(a.dp(3), a.dp(3), a.dp(3), a.dp(3))
                        })
                    }
                }
            }
            fun newQuestion() {
                if (roundFinished) return
                val pool = eligiblePool()
                if (pool.size < 4) {
                    feedback.text = "Für diese Kategorie sind noch nicht genügend unterschiedliche Griffbilder vorhanden. Wähle bitte eine andere Kategorie."
                    return
                }
                currentShape = chooseAdaptive(pool)
                val shape = currentShape ?: return
                currentOptions = (listOf(shape) + pool.filter { it.name != shape.name }.shuffled().take(3)).shuffled()
                locked = false
                questionStartedAt = android.os.SystemClock.elapsedRealtime()
                feedback.text = if (mode == "mistakes") "Gezielte Wiederholung · unsichere Akkorde kommen häufiger." else "Nimm dir einen Moment – Genauigkeit zählt."
                feedback.setTextColor(a.getColor(R.color.sw_muted))
                val listening = mode == "listen" || mode == "listenMistakes"
                listenButton.visibility = if (listening) View.VISIBLE else View.GONE
                if (listening) {
                    prompt.text = "Welcher Akkord ist zu hören?"
                    diagram.removeAllViews()
                    diagram.addView(TextView(a).apply {
                        text = "HÖR GENAU HIN\n\nDer Gitarrenakkord wird abgespielt."
                        textSize = 16f; gravity = Gravity.CENTER
                        setLineSpacing(a.dp(3).toFloat(), 1f)
                        setTypeface(typeface, android.graphics.Typeface.BOLD)
                        setTextColor(a.getColor(R.color.sw_text))
                    }, FrameLayout.LayoutParams(-1, -1))
                    GuitarAudioEngine.playChord(a, shape, downstroke = true, volume = 0.88f, replace = true)
                } else if (mode == "reverse") {
                    GuitarAudioEngine.stopAll()
                    prompt.text = "Welches Griffbild gehört zu ${shape.name}?"
                    diagram.removeAllViews()
                    diagram.addView(TextView(a).apply {
                        text = shape.name; textSize = 42f; gravity = Gravity.CENTER
                        setTypeface(typeface, android.graphics.Typeface.BOLD); setTextColor(a.getColor(R.color.sw_copper))
                    }, FrameLayout.LayoutParams(-1, -1))
                } else {
                    GuitarAudioEngine.stopAll()
                    prompt.text = "Welcher Akkord ist auf dem Griffbild zu sehen?"
                    diagram.removeAllViews()
                    diagram.addView(ChordDiagramView(a, shape), FrameLayout.LayoutParams(-1, -1))
                }
                showChoices(currentOptions, shape)
                updateHeader()
            }
            fun answer(optionName: String) {
                if (locked || roundFinished) return
                val shape = currentShape ?: return
                locked = true
                val correctAnswer = optionName == shape.name
                val responseMs = (android.os.SystemClock.elapsedRealtime() - questionStartedAt).coerceAtLeast(0L)
                answered++
                if (correctAnswer) { localCorrect++; localStreak++ } else localStreak = 0
                if (mode == "listen" || mode == "listenMistakes") recordListenAnswer(shape, correctAnswer, responseMs)
                else recordAnswer(shape, correctAnswer, responseMs)
                GuitarAudioEngine.stopAll()
                for (j in 0 until choices.childCount) choices.getChildAt(j).isEnabled = false
                val seconds = String.format(java.util.Locale.GERMANY, "%.1f", responseMs / 1000.0)
                feedback.text = if (correctAnswer) "Richtig · ${shape.name} · $seconds s · Serie $localStreak" else "Noch nicht · gesucht war ${shape.name}. Dieser Akkord wird gezielt wiederholt."
                feedback.setTextColor(a.getColor(if (correctAnswer) R.color.sw_copper else R.color.sw_muted))
                updateHeader(); updatePracticeStats()
            }
            answerQuestion = { selectedName -> answer(selectedName) }
            modeButton.setOnClickListener {
                val entries = modeNames.values.toTypedArray()
                val keys = modeNames.keys.toList()
                androidx.appcompat.app.AlertDialog.Builder(a, R.style.ThemeOverlay_Saitenwerk_Dialog).setTitle("Trainingsmodus")
                    .setItems(entries) { _, which ->
                        mode = keys[which]; prefs.edit().putString("learn_chord_quiz_mode", mode).apply()
                        modeButton.text = "Modus · " + modeNames[mode]
                        listenButton.visibility = if (mode == "listen" || mode == "listenMistakes") View.VISIBLE else View.GONE
                        roundFinished = false; answered = 0; localCorrect = 0; localStreak = 0; remainingSeconds = 60
                        timerLabel.text = if (mode == "blitz") "01:00" else "Ohne Zeitlimit"
                        stopTimer(); newQuestion()
                        if (mode == "blitz") {
                            val deadline = android.os.SystemClock.elapsedRealtime() + 60000L
                            val task = object : Runnable {
                                override fun run() {
                                    val left = ((deadline - android.os.SystemClock.elapsedRealtime() + 999L) / 1000L).toInt()
                                    remainingSeconds = left.coerceAtLeast(0)
                                    timerLabel.text = String.format(java.util.Locale.GERMANY, "%02d:%02d", remainingSeconds / 60, remainingSeconds % 60)
                                    if (left <= 0) finishRound() else quizHandler.postDelayed(this, 200L)
                                }
                            }
                            timerTask = task; quizHandler.post(task)
                        }
                    }.show()
            }
            val stageOptions = listOf("Alle") + ChordLibrary.difficultyStages
            val stageCounts = stageOptions.associateWith { stage ->
                ChordLibrary.all.filterNot { it.name == "Bb" }.distinctBy { it.name }
                    .count { stage == "Alle" || ChordLibrary.difficultyFor(it) == stage }
            }
            val categoryLabels = stageOptions.map { stage ->
                val count = stageCounts[stage] ?: 0
                if (stage == "Alle") "Alle Akkorde · $count" else "$stage · $count Akkorde"
            }
            categoryButton.setOnClickListener {
                androidx.appcompat.app.AlertDialog.Builder(a, R.style.ThemeOverlay_Saitenwerk_Dialog).setTitle("Schwierigkeitsstufe")
                    .setSingleChoiceItems(categoryLabels.toTypedArray(), stageOptions.indexOf(category).coerceAtLeast(0)) { dialog, which ->
                        category = stageOptions[which]
                        prefs.edit().putString("learn_chord_quiz_category", category).apply()
                        updateStageHeader()
                        roundFinished = false; answered = 0; localCorrect = 0; localStreak = 0
                        newQuestion(); dialog.dismiss()
                    }.setNegativeButton("Abbrechen", null).show()
            }
            next.setOnClickListener {
                if (roundFinished) {
                    roundFinished = false; answered = 0; localCorrect = 0; localStreak = 0; remainingSeconds = 60
                    timerLabel.text = if (mode == "blitz") "01:00" else "Ohne Zeitlimit"
                    newQuestion()
                    if (mode == "blitz") {
                        val deadline = android.os.SystemClock.elapsedRealtime() + 60000L
                        val task = object : Runnable {
                            override fun run() {
                                val left = ((deadline - android.os.SystemClock.elapsedRealtime() + 999L) / 1000L).toInt()
                                remainingSeconds = left.coerceAtLeast(0)
                                timerLabel.text = String.format(java.util.Locale.GERMANY, "%02d:%02d", remainingSeconds / 60, remainingSeconds % 60)
                                if (left <= 0) finishRound() else quizHandler.postDelayed(this, 200L)
                            }
                        }
                        timerTask = task; quizHandler.post(task)
                    }
                } else newQuestion()
            }
            finish.setOnClickListener { stopTimer(); quizHandler.removeCallbacksAndMessages(null); GuitarAudioEngine.stopAll(); finishQuizSession(); overviewAction?.invoke() }

            fun startBlitzTimer() {
                stopTimer()
                val deadline = android.os.SystemClock.elapsedRealtime() + 60000L
                val task = object : Runnable {
                    override fun run() {
                        val left = ((deadline - android.os.SystemClock.elapsedRealtime() + 999L) / 1000L).toInt()
                        remainingSeconds = left.coerceAtLeast(0)
                        timerLabel.text = String.format(java.util.Locale.GERMANY, "%02d:%02d", remainingSeconds / 60, remainingSeconds % 60)
                        if (left <= 0) finishRound() else quizHandler.postDelayed(this, 200L)
                    }
                }
                timerTask = task; quizHandler.post(task)
            }
            modeButton.text = "Modus · " + (modeNames[mode] ?: modeNames["recognize"])
            updateStageHeader()
            newQuestion()
            if (mode == "blitz") startBlitzTimer()
            content.addView(card)
        }

        fun showRhythm() {
            prefs.edit().putInt("learn_skill_rhythm", prefs.getInt("learn_skill_rhythm", 0) + 1).apply()
            finishQuizSession(); stopRhythm(); content.removeAllViews()
            val (card, box) = panel("Rhythmus & Timing", "Trainiere Puls, Taktgefühl und Geschwindigkeit. Im 6/8-Takt hörst du zwei große Pulse pro Takt.")
            rhythmBpm = prefs.getInt("learn_rhythm_bpm", 80).coerceIn(50, 160)
            rhythmMeter = prefs.getString("learn_rhythm_meter", "4/4") ?: "4/4"
            val tempoLabel = TextView(a).apply { text = "BPM $rhythmBpm"; textSize = 18f; setTextColor(a.getColor(R.color.sw_text)); gravity = Gravity.CENTER }
            box.addView(tempoLabel, LinearLayout.LayoutParams(-1, a.dp(36)))
            val slider = SeekBar(a).apply { max = 110; progress = rhythmBpm - 50 }
            slider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(v: SeekBar?, p: Int, from: Boolean) { rhythmBpm = 50 + p; tempoLabel.text = "BPM $rhythmBpm"; prefs.edit().putInt("learn_rhythm_bpm", rhythmBpm).apply() }
                override fun onStartTrackingTouch(v: SeekBar?) {}
                override fun onStopTrackingTouch(v: SeekBar?) {}
            })
            box.addView(slider, LinearLayout.LayoutParams(-1, a.dp(42)))
            val meterRow = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            meterRow.addView(TextView(a).apply { text = "Takt"; textSize = 13f; setTextColor(a.getColor(R.color.sw_muted)) }, LinearLayout.LayoutParams(0, a.dp(46), 1f))
            val meterButton = a.button(rhythmMeter); meterRow.addView(meterButton, LinearLayout.LayoutParams(a.dp(100), a.dp(46))); box.addView(meterRow)
            val meterHint = TextView(a).apply { text = if (rhythmMeter == "6/8") "Zwei große Pulse pro Takt (1–2), jeweils über drei Achtel." else "Ein Puls pro Zählzeit."; textSize = 12f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0, 0, 0, a.dp(4)) }
            box.addView(meterHint)
            meterButton.setOnClickListener {
                val meters = arrayOf("2/4", "3/4", "4/4", "6/8")
                androidx.appcompat.app.AlertDialog.Builder(a, R.style.ThemeOverlay_Saitenwerk_Dialog).setTitle("Taktart").setSingleChoiceItems(meters, meters.indexOf(rhythmMeter).coerceAtLeast(0)) { d, which ->
                    rhythmMeter = meters[which]; meterButton.text = rhythmMeter
                    meterHint.text = if (rhythmMeter == "6/8") "Zwei große Pulse pro Takt (1–2), jeweils über drei Achtel." else "Ein Puls pro Zählzeit."
                    prefs.edit().putString("learn_rhythm_meter", rhythmMeter).apply(); d.dismiss()
                }.setNegativeButton("Abbrechen", null).show()
            }
            val beat = TextView(a).apply { text = "Bereit"; textSize = 30f; gravity = Gravity.CENTER; setTextColor(a.getColor(R.color.sw_copper)); setPadding(0, a.dp(12), 0, a.dp(8)) }
            box.addView(beat, LinearLayout.LayoutParams(-1, a.dp(72)))
            val start = a.button("Metronom starten"); box.addView(start, LinearLayout.LayoutParams(-1, a.dp(48)))
            start.setOnClickListener {
                if (rhythmRunning) { stopRhythm(); start.text = "Metronom starten"; beat.text = "Pausiert" }
                else {
                    rhythmRunning = true; rhythmStartedAt = android.os.SystemClock.elapsedRealtime(); rhythmBeat = 0; rhythmHandler = Handler(Looper.getMainLooper()); start.text = "Metronom stoppen"
                    val compoundSixEight = rhythmMeter == "6/8"
                    val beatsPerBar = if (compoundSixEight) 2 else rhythmMeter.substringBefore("/").toIntOrNull() ?: 4
                    val pulseInterval = if (compoundSixEight) 90000L / rhythmBpm else 60000L / rhythmBpm
                    val task = object : Runnable {
                        override fun run() {
                            if (!rhythmRunning) return
                            val beatInBar = rhythmBeat % beatsPerBar
                            val strong = beatInBar == 0
                            GuitarAudioEngine.playTick(a, strong)
                            beat.text = if (strong) "1 · TAKT" else "${beatInBar + 1}"
                            rhythmBeat++; rhythmHandler?.postDelayed(this, pulseInterval.coerceAtLeast(100L))
                        }
                    }
                    rhythmHandler?.post(task)
                }
            }
            content.addView(card)
        }

        fun showStrumming(initialMode: String = "strumming") {
            prefs.edit().remove("learn_strum_bars").apply()
            finishQuizSession(); stopRhythm(); stopStrumming(); content.removeAllViews()
            val (card, box) = panel("Gemeinsamer Gitarrentrainer", "Trainiere Akkordwechsel oder Schlagmuster mit denselben Akkorden, derselben Taktart und demselben Tempo.")

            val patterns = linkedMapOf(
                "Anfänger · ↓ ↓ ↓ ↓" to listOf("↓","↓","↓","↓"),
                "Grundlagen · ↓ ↑ ↓ ↑" to listOf("↓","↑","↓","↑"),
                "Pop · ↓ ↓ ↑ ↑ ↓ ↑" to listOf("↓","↓","↑","↑","↓","↑"),
                "Achtel · ↓ ↑ ↓ ↑ ↓ ↑ ↓ ↑" to listOf("↓","↑","↓","↑","↓","↑","↓","↑"),
                "Akustik · ↓ ↓ ↑ ↓ ↑" to listOf("↓","↓","↑","↓","↑"),
                "Flow · ↓ ↑ ↑ ↓ ↑ ↓" to listOf("↓","↑","↑","↓","↑","↓"),
                "Offbeat · ↓ ↑ · ↑ ↓ ↑ · ↑" to listOf("↓","↑","·","↑","↓","↑","·","↑"),
                "Profi · ↓ · ↑ ↑ · ↑ ↓ ↑" to listOf("↓","·","↑","↑","·","↑","↓","↑")
            )
            val levels = linkedMapOf(
                "Anfänger" to Triple(60, 420L, 3),
                "Grundlagen" to Triple(75, 330L, 4),
                "Fortgeschritten" to Triple(95, 240L, 5),
                "Profi" to Triple(115, 150L, 6)
            )

            var selectedName = prefs.getString("learn_strum_pattern", patterns.keys.first()) ?: patterns.keys.first()
            var selected = patterns[selectedName] ?: patterns.values.first()
            val orderedChordJson = prefs.getString("learn_strum_chords_ordered", null)
            val savedChordNames = if (!orderedChordJson.isNullOrBlank()) {
                runCatching {
                    val array = org.json.JSONArray(orderedChordJson)
                    (0 until array.length()).map { array.getString(it) }
                }.getOrElse { prefs.getStringSet("learn_strum_chords", null)?.toList().orEmpty() }
            } else {
                prefs.getStringSet("learn_strum_chords", null)?.toList()
                    ?: listOf(prefs.getString("learn_strum_chord", "G") ?: "G")
            }
            val selectedChordNames = savedChordNames.distinct()
                .filter { name -> ChordLibrary.all.any { it.name == name } }
                .ifEmpty { listOf(ChordLibrary.all.first().name) }.toMutableList()
            var selectedChords = selectedChordNames.mapNotNull { name -> ChordLibrary.all.firstOrNull { it.name == name } }
            val legacyChordSequence = prefs.getStringSet("chord_training_selected_chords", null)?.sorted().orEmpty()
            val legacyChordJson = prefs.getString("learn_strum_chords_ordered", null)
            val canonicalChordJson = prefs.getString("learn_training_chords_ordered", null)
            fun decodeChordOrder(raw: String?): List<String>? = raw?.takeIf { it.isNotBlank() }?.let {
                runCatching { org.json.JSONArray(it).let { array -> (0 until array.length()).map { index -> array.getString(index) } } }.getOrNull()
            }
            val sharedChordNames = decodeChordOrder(canonicalChordJson)
                ?: if (initialMode == "changes") legacyChordSequence.takeIf { it.isNotEmpty() } ?: decodeChordOrder(legacyChordJson) ?: listOf("C", "G", "Am", "F")
                else decodeChordOrder(legacyChordJson) ?: legacyChordSequence.takeIf { it.isNotEmpty() } ?: savedChordNames
            selectedChordNames.clear()
            selectedChordNames.addAll(sharedChordNames.distinct().filter { name -> ChordLibrary.all.any { it.name == name } }
                .ifEmpty { listOf(ChordLibrary.all.first().name) })
            selectedChords = selectedChordNames.mapNotNull { name -> ChordLibrary.all.firstOrNull { it.name == name } }
            val legacyMeter = if (initialMode == "changes") prefs.getString("chord_training_meter", null) ?: prefs.getString("learn_strum_meter", "4/4")
                else prefs.getString("learn_strum_meter", null) ?: prefs.getString("chord_training_meter", "4/4")
            var selectedMeter = (prefs.getString("learn_training_meter", null) ?: legacyMeter ?: "4/4")
            if (selectedMeter !in listOf("2/4", "3/4", "4/4", "6/8")) selectedMeter = "4/4"
            var difficulty = prefs.getString("learn_strum_difficulty", "Grundlagen") ?: "Grundlagen"
            if (!levels.containsKey(difficulty)) difficulty = "Grundlagen"
            val legacyBpm = if (initialMode == "changes") prefs.getInt("chord_training_bpm", prefs.getInt("learn_strum_bpm", levels[difficulty]!!.first)) else prefs.getInt("learn_strum_bpm", prefs.getInt("chord_training_bpm", levels[difficulty]!!.first))
            var bpm = prefs.getInt("learn_training_bpm", legacyBpm).coerceIn(50, 160)
            var trainingMode = initialMode
            prefs.edit().putString("learn_training_mode", trainingMode)
                .putString("learn_training_meter", selectedMeter)
                .putInt("learn_training_bpm", bpm)
                .putString("learn_training_chords_ordered", org.json.JSONArray(selectedChordNames).toString())
                .putString("learn_strum_meter", selectedMeter).putString("chord_training_meter", selectedMeter)
                .putInt("learn_strum_bpm", bpm).putInt("chord_training_bpm", bpm)
                .putStringSet("chord_training_selected_chords", selectedChordNames.toSet()).apply()

            var phase = "ready"
            var step = 0
            var round = 0
            var hits = 0
            var misses = 0
            var score = 0
            var combo = 0
            var bestCombo = 0
            var expectedAt = 0L
            var answered = true
            var sessionBest = prefs.getInt("learn_strum_best_score", 0)
            var roundBest = prefs.getInt("learn_strum_best_rounds", 0)

            val modeButton = a.button(if (trainingMode == "changes") "Trainingsmodus · Akkordwechsel" else "Trainingsmodus · Schlagmuster")
            val chordButton = a.button("Akkorde · " + selectedChordNames.joinToString(" – "))
            val chordSequenceLabel = TextView(a).apply {
                text = selectedChordNames.joinToString("   →   ")
                textSize = 19f; gravity = Gravity.CENTER
                setTextColor(a.getColor(R.color.sw_copper)); setPadding(0, a.dp(8), 0, a.dp(8))
            }
            val chordDiagram = ChordDiagramView(a, selectedChords.firstOrNull())
            val patternButton = a.button(selectedName)
            val meterButton = a.button("Taktart · " + selectedMeter)
            val levelButton = a.button("Stufe · " + difficulty)
            val status = TextView(a).apply {
                text = "Bereit · Training starten"
                textSize = 13f
                gravity = Gravity.CENTER
                setTextColor(a.getColor(R.color.sw_muted))
                setPadding(0, a.dp(7), 0, a.dp(8))
            }
            val beatRow = LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                isClickable = true
                isFocusable = true
            }
            val gestureHint = TextView(a).apply {
                text = "Im Training auf den Schlagpfeilen wischen: ↓ Abschlag · ↑ Aufschlag"
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(a.getColor(R.color.sw_muted))
                setPadding(a.dp(4), a.dp(2), a.dp(4), a.dp(6))
            }
            val tempoLabel = TextView(a).apply {
                text = "Tempo: " + bpm + " BPM"
                textSize = 14f
                setTextColor(a.getColor(R.color.sw_text))
            }
            val slider = SeekBar(a).apply { max = 110; progress = bpm - 50 }
            val stats = TextView(a).apply {
                text = "Punkte: 0 · Genauigkeit: 0% · Serie: 0"
                textSize = 12f
                setTextColor(a.getColor(R.color.sw_muted))
                gravity = Gravity.CENTER
            }
            val roundLabel = TextView(a).apply {
                text = "Runde 0 · Bestwert " + sessionBest
                textSize = 12f
                setTextColor(a.getColor(R.color.sw_muted))
                gravity = Gravity.CENTER
            }
            val timing = TextView(a).apply {
                text = "Timing-Fenster · ±" + levels[difficulty]!!.second + " ms"
                textSize = 12f
                setTextColor(a.getColor(R.color.sw_muted))
                gravity = Gravity.CENTER
            }
            val start = a.button("Training starten")

            box.addView(modeButton, LinearLayout.LayoutParams(-1, a.dp(44)).apply { bottomMargin = a.dp(5) })
            box.addView(chordButton, LinearLayout.LayoutParams(-1, a.dp(44)).apply { bottomMargin = a.dp(5) })
            box.addView(chordSequenceLabel, LinearLayout.LayoutParams(-1, -2))
            box.addView(chordDiagram, LinearLayout.LayoutParams(-1, a.dp(190)))
            box.addView(levelButton, LinearLayout.LayoutParams(-1, a.dp(44)).apply { bottomMargin = a.dp(5) })
            box.addView(meterButton, LinearLayout.LayoutParams(-1, a.dp(42)).apply { bottomMargin = a.dp(4) })
            box.addView(patternButton, LinearLayout.LayoutParams(-1, a.dp(46)))
            box.addView(beatRow, LinearLayout.LayoutParams(-1, a.dp(76)))
            box.addView(gestureHint)
            box.addView(status)
            box.addView(roundLabel)
            box.addView(tempoLabel)
            box.addView(slider, LinearLayout.LayoutParams(-1, a.dp(42)))
            box.addView(timing)
            box.addView(stats)
            box.addView(start, LinearLayout.LayoutParams(-1, a.dp(48)).apply { topMargin = a.dp(4) })

            fun rebuildBeats() {
                beatRow.removeAllViews()
                selected.forEachIndexed { index, dir ->
                    beatRow.addView(TextView(a).apply {
                        text = dir
                        textSize = 22f
                        gravity = Gravity.CENTER
                        setTypeface(typeface, android.graphics.Typeface.BOLD)
                        setTextColor(a.getColor(R.color.sw_muted))
                        contentDescription = "Schlag " + (index + 1) + ": " + dir
                    }, LinearLayout.LayoutParams(0, a.dp(68), 1f))
                }
            }
            fun markBeat(active: Int = step) {
                for (i in 0 until beatRow.childCount) {
                    val v = beatRow.getChildAt(i) as TextView
                    val isActive = i == active
                    v.setTextColor(a.getColor(if (isActive) R.color.sw_copper else R.color.sw_muted))
                    v.textSize = if (isActive) 38f else 30f
                }
            }
            fun refreshStats() {
                val attempts = hits + misses
                val accuracy = if (attempts > 0) hits * 100 / attempts else 0
                stats.text = "Punkte: " + score + " · Genauigkeit: " + accuracy + "% · Serie: " + combo + " · Bestserie: " + bestCombo
                roundLabel.text = "Runde " + round + " · Bestwert " + sessionBest
            }
            fun updateTimingLabel() {
                timing.text = "Timing-Fenster · ±" + levels[difficulty]!!.second + " ms · Zieltempo " + levels[difficulty]!!.first + " BPM"
            }

            fun updateTrainingModeUi() {
                val changesMode = trainingMode == "changes"
                modeButton.text = if (changesMode) "Trainingsmodus · Akkordwechsel" else "Trainingsmodus · Schlagmuster"
                levelButton.visibility = if (changesMode) View.GONE else View.VISIBLE
                patternButton.visibility = if (changesMode) View.GONE else View.VISIBLE
                beatRow.visibility = if (changesMode) View.GONE else View.VISIBLE
                gestureHint.visibility = if (changesMode) View.GONE else View.VISIBLE
                chordSequenceLabel.visibility = if (changesMode) View.VISIBLE else View.GONE
                chordDiagram.visibility = if (changesMode) View.VISIBLE else View.GONE
                timing.visibility = if (changesMode) View.GONE else View.VISIBLE
                status.text = if (changesMode) "Ein Akkord pro Takt · mindestens zwei Akkorde auswählen" else "Spiele passend zur Markierung"
            }
            modeButton.setOnClickListener {
                if (phase == "play") return@setOnClickListener
                trainingMode = if (trainingMode == "changes") "strumming" else "changes"
                prefs.edit().putString("learn_training_mode", trainingMode).apply()
                updateTrainingModeUi()
            }
            chordButton.setOnClickListener {
                if (phase == "play") return@setOnClickListener
                val names = ChordLibrary.all.map { it.name }.toTypedArray()
                val checked = BooleanArray(names.size) { names[it] in selectedChordNames }
                val selectionOrder = selectedChordNames.toMutableList()
                androidx.appcompat.app.AlertDialog.Builder(a, R.style.ThemeOverlay_Saitenwerk_Dialog)
                    .setTitle("Akkordfolge für den Gitarrenklang")
                    .setMultiChoiceItems(names, checked) { _, which, isChecked ->
                        checked[which] = isChecked
                        if (isChecked) {
                            if (names[which] !in selectionOrder) selectionOrder.add(names[which])
                        } else {
                            selectionOrder.remove(names[which])
                        }
                    }
                    .setPositiveButton("Übernehmen") { dialog, _ ->
                        val chosen = selectionOrder.filter { name ->
                            val index = names.indexOf(name)
                            index >= 0 && checked[index]
                        }
                        if (chosen.isNotEmpty() && (trainingMode != "changes" || chosen.size >= 2)) {
                            selectedChordNames.clear()
                            selectedChordNames.addAll(chosen)
                            selectedChords = selectedChordNames.mapNotNull { name -> ChordLibrary.all.firstOrNull { it.name == name } }
                            val ordered = org.json.JSONArray(selectedChordNames).toString()
                            prefs.edit().putString("learn_training_chords_ordered", ordered)
                                .putString("learn_strum_chords_ordered", ordered)
                                .putStringSet("learn_strum_chords", selectedChordNames.toSet())
                                .putString("learn_strum_chord", selectedChordNames.first())
                                .putStringSet("chord_training_selected_chords", selectedChordNames.toSet()).apply()
                            chordButton.text = "Akkorde · " + selectedChordNames.joinToString(" – ")
                            chordSequenceLabel.text = selectedChordNames.joinToString("   →   ")
                            chordDiagram.setChord(selectedChords.firstOrNull())
                            status.text = selectedChordNames.size.toString() + " Akkorde ausgewählt · ein Akkord pro Takt"
                        } else {
                            android.widget.Toast.makeText(a, if (trainingMode == "changes") "Wähle mindestens zwei Akkorde für Akkordwechsel." else "Bitte mindestens einen Akkord auswählen.", android.widget.Toast.LENGTH_SHORT).show()
                        }
                        dialog.dismiss()
                    }.setNegativeButton("Abbrechen", null).show()
            }
            meterButton.setOnClickListener {
                if (phase == "play") return@setOnClickListener
                val meters = arrayOf("2/4", "3/4", "4/4", "6/8")
                androidx.appcompat.app.AlertDialog.Builder(a, R.style.ThemeOverlay_Saitenwerk_Dialog)
                    .setTitle("Taktart auswählen")
                    .setSingleChoiceItems(meters, meters.indexOf(selectedMeter).coerceAtLeast(0)) { dialog, which ->
                        selectedMeter = meters[which]
                        meterButton.text = "Taktart · " + selectedMeter
                        prefs.edit().putString("learn_training_meter", selectedMeter).putString("learn_strum_meter", selectedMeter).putString("chord_training_meter", selectedMeter).apply()
                        dialog.dismiss()
                    }.setNegativeButton("Abbrechen", null).show()
            }
            levelButton.setOnClickListener {
                if (phase == "play") return@setOnClickListener
                val names = levels.keys.toTypedArray()
                androidx.appcompat.app.AlertDialog.Builder(a, R.style.ThemeOverlay_Saitenwerk_Dialog)
                    .setTitle("Trainingsstufe")
                    .setSingleChoiceItems(names, names.indexOf(difficulty).coerceAtLeast(0)) { dialog, which ->
                        difficulty = names[which]
                        bpm = levels[difficulty]!!.first
                        slider.progress = bpm - 50
                        levelButton.text = "Stufe · " + difficulty
                        prefs.edit().putString("learn_strum_difficulty", difficulty).putInt("learn_training_bpm", bpm).putInt("learn_strum_bpm", bpm).putInt("chord_training_bpm", bpm).apply()
                        updateTimingLabel()
                        status.text = "Stufe gesetzt · " + difficulty
                        dialog.dismiss()
                    }.setNegativeButton("Abbrechen", null).show()
            }
            patternButton.setOnClickListener {
                if (phase == "play") return@setOnClickListener
                val names = patterns.keys.toTypedArray()
                androidx.appcompat.app.AlertDialog.Builder(a, R.style.ThemeOverlay_Saitenwerk_Dialog)
                    .setTitle("Schlagmuster auswählen")
                    .setSingleChoiceItems(names, names.indexOf(selectedName).coerceAtLeast(0)) { dialog, which ->
                        selectedName = names[which]
                        selected = patterns[selectedName] ?: selected
                        step = 0
                        patternButton.text = selectedName
                        status.text = "Muster gewählt · bereit zum Training"
                        rebuildBeats(); markBeat()
                        dialog.dismiss()
                    }.setNegativeButton("Abbrechen", null).show()
            }
            slider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(v: SeekBar?, p: Int, from: Boolean) {
                    bpm = 50 + p
                    tempoLabel.text = "Tempo: " + bpm + " BPM"
                    prefs.edit().putInt("learn_training_bpm", bpm).putInt("learn_strum_bpm", bpm).putInt("chord_training_bpm", bpm).apply()
                }
                override fun onStartTrackingTouch(v: SeekBar?) {}
                override fun onStopTrackingTouch(v: SeekBar?) {}
            })

            fun userHit(direction: String) {
                if (phase != "play" || selected.isEmpty() || answered) return
                val expected = selected[step % selected.size]
                if (expected == "·") {
                    misses++; combo = 0; status.text = "✕ Pause · hier nicht anschlagen"; refreshStats(); answered = true; return
                }
                val delta = kotlin.math.abs(android.os.SystemClock.elapsedRealtime() - expectedAt)
                val window = levels[difficulty]!!.second
                answered = true
                if (direction == expected && delta <= window) {
                    hits++; combo++; bestCombo = maxOf(bestCombo, combo)
                    when {
                        delta <= window / 4 -> { score += 100 + combo.coerceAtMost(20) * 3; status.text = "✓ Perfekt · " + delta + " ms" }
                        delta <= window / 2 -> { score += 80 + combo.coerceAtMost(20) * 2; status.text = "✓ Sehr gut · " + delta + " ms" }
                        else -> { score += 60; status.text = "✓ Im Timing · " + delta + " ms" }
                    }
                } else {
                    misses++; combo = 0
                    status.text = if (direction != expected) "✕ " + direction + " · erwartet " + expected else "◷ Zu spät/früh · " + delta + " ms"
                }
                refreshStats()
            }

            var gestureStartX = 0f
            var gestureStartY = 0f
            beatRow.setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    android.view.MotionEvent.ACTION_DOWN -> {
                        gestureStartX = event.x
                        gestureStartY = event.y
                        true
                    }
                    android.view.MotionEvent.ACTION_UP -> {
                        val deltaX = event.x - gestureStartX
                        val deltaY = event.y - gestureStartY
                        if (phase == "play" && trainingMode == "strumming" &&
                            kotlin.math.abs(deltaY) >= a.dp(28).toFloat() &&
                            kotlin.math.abs(deltaY) > kotlin.math.abs(deltaX)) {
                            val direction = if (deltaY > 0f) "↓" else "↑"
                            val chord = selectedChords[round.coerceAtLeast(0) % selectedChords.size]
                            GuitarAudioEngine.playChord(
                                a, chord, downstroke = direction == "↓", volume = 0.84f
                            )
                            userHit(direction)
                        }
                        true
                    }
                    android.view.MotionEvent.ACTION_CANCEL -> true
                    else -> true
                }
            }

            start.setOnClickListener {
                if (phase == "play") {
                    if (trainingMode == "strumming") {
                        prefs.edit().putInt("learn_strum_best_score", maxOf(sessionBest, score))
                            .putInt("learn_strum_best_rounds", maxOf(roundBest, round))
                            .putInt("learn_strum_best_combo", maxOf(prefs.getInt("learn_strum_best_combo", 0), bestCombo)).apply()
                        sessionBest = maxOf(sessionBest, score); roundBest = maxOf(roundBest, round)
                    } else prefs.edit().putInt("chord_training_best_streak", maxOf(prefs.getInt("chord_training_best_streak", 0), round)).apply()
                    stopStrumming()
                    phase = "ready"
                    start.text = "Training starten"
                    status.text = "Pausiert · " + score + " Punkte"
                    return@setOnClickListener
                }

                if (trainingMode == "changes" && selectedChords.size < 2) {
                    android.widget.Toast.makeText(a, "Wähle zuerst mindestens zwei Akkorde aus.", android.widget.Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                if (trainingMode == "changes") prefs.edit().putInt("learn_skill_changes", prefs.getInt("learn_skill_changes", 0) + 1)
                    .putInt("chord_training_sessions", prefs.getInt("chord_training_sessions", 0) + 1).apply()
                else prefs.edit().putInt("learn_skill_strum", prefs.getInt("learn_skill_strum", 0) + 1).apply()
                phase = "play"
                start.text = "Training stoppen"
                step = -1; hits = 0; misses = 0; score = 0; combo = 0; bestCombo = 0; round = 0; answered = false
                strumRunning = true
                strumStartedAt = android.os.SystemClock.elapsedRealtime()
                strumHandler = Handler(Looper.getMainLooper())
                val interval = (if (trainingMode == "changes" && selectedMeter == "6/8") 90000L / bpm else 60000L / bpm / (if (trainingMode == "changes") 1 else 2)).coerceAtLeast(100L)
                val task = object : Runnable {
                    override fun run() {
                        if (!strumRunning || phase != "play") return
                        val beatsPerBar = when (selectedMeter) { "2/4" -> 2; "3/4" -> 3; "6/8" -> if (trainingMode == "changes") 2 else 6; else -> 4 }
                        val stepsPerBar = if (trainingMode == "changes") beatsPerBar else if (selected.size >= 6) beatsPerBar * 2 else beatsPerBar
                        step += 1
                        if (step >= stepsPerBar) { step = 0; round++ }
                        answered = false
                        expectedAt = android.os.SystemClock.elapsedRealtime()
                        val chord = selectedChords[round % selectedChords.size]
                        if (trainingMode == "changes") {
                            chordSequenceLabel.text = "Jetzt: ${chord.name}    →    Danach: ${selectedChords[(round + 1) % selectedChords.size].name}"
                            chordDiagram.setChord(chord)
                            status.text = "Akkordwechsel · Takt ${round + 1} · ${step + 1}/${beatsPerBar}"
                            GuitarAudioEngine.playChord(a, chord, downstroke = step % 2 == 0, volume = if (step == 0) 0.80f else 0.56f)
                            roundLabel.text = "Takt ${round + 1} · ${chord.name} · ${selectedChords.size} Akkorde in Folge"
                            stats.text = "Akkordwechsel · ${round} abgeschlossene Takte · Tempo ${bpm} BPM"
                        } else {
                            markBeat(step % selected.size)
                            val patternIndex = step % selected.size
                            val dir = selected[patternIndex]
                            if (dir != "·") GuitarAudioEngine.playChord(a, chord, downstroke = dir == "↓", volume = if (patternIndex == 0) 0.78f else 0.56f)
                            else status.text = "• Pause · nächster Schlag vorbereitet"
                            refreshStats()
                        }
                        strumHandler?.postDelayed(this, interval)
                    }
                }
                status.text = if (trainingMode == "changes") "Akkordwechsel läuft" else "Spiele passend zur Markierung"
                strumHandler?.post(task)
            }

            updateTimingLabel()
            updateTrainingModeUi()
            rebuildBeats()
            markBeat(0)
            refreshStats()
            content.addView(card)
        }

        fun showChanges() { showStrumming("changes") }

        fun showFretboard() {
            finishQuizSession(); stopRhythm(); stopStrumming()
            content.removeAllViews()
            val card = roundedCard()
            val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(14), a.dp(14), a.dp(14), a.dp(14)) }
            box.addView(TextView(a).apply {
                text = "🎸 Griffbrett entdecken"; textSize = 21f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_text))
            })
            box.addView(a.body("Finde den gesuchten Ton auf dem Griffbrett. Spiele ihn direkt an und trainiere Orientierung, Gehör und Notennamen.", 13f))
            val target = TextView(a).apply {
                textSize = 25f; setTypeface(typeface, 1); gravity = Gravity.CENTER
                setTextColor(a.getColor(R.color.sw_copper)); setPadding(0, a.dp(10), 0, a.dp(8))
            }
            box.addView(target)
            val feedback = TextView(a).apply {
                textSize = 13f; gravity = Gravity.CENTER; setTextColor(a.getColor(R.color.sw_muted)); minLines = 2
            }
            box.addView(feedback)
            val stats = TextView(a).apply { textSize = 12f; gravity = Gravity.CENTER; setTextColor(a.getColor(R.color.sw_text)); setPadding(0, a.dp(4), 0, a.dp(8)) }
            box.addView(stats)
            val fretboard = FretboardNoteView(a).apply { contentDescription = "Interaktives Gitarrengriffbrett, zwölf Bünde" }
            box.addView(fretboard, LinearLayout.LayoutParams(-1, a.dp(230)).apply { topMargin = a.dp(4) })
            val progress = ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply { max = 10 }
            box.addView(progress, LinearLayout.LayoutParams(-1, a.dp(8)).apply { topMargin = a.dp(8) })
            val next = a.button("Nächsten Ton anzeigen").apply { tag = "saitenwerk-primary" }
            box.addView(next, LinearLayout.LayoutParams(-1, a.dp(52)).apply { topMargin = a.dp(10) })
            val reset = a.button("Runde neu starten")
            box.addView(reset, LinearLayout.LayoutParams(-1, a.dp(48)).apply { topMargin = a.dp(6) })
            card.addView(box); content.addView(card)

            val natural = arrayOf("C", "D", "E", "F", "G", "A", "H")
            val semitones = arrayOf("C", "Cis", "D", "Dis", "E", "F", "Fis", "G", "Gis", "A", "B", "H")
            val openMidi = intArrayOf(40, 45, 50, 55, 59, 64)
            val random = java.util.Random()
            var targetName = natural[random.nextInt(natural.size)]
            var round = 0; var correct = 0; var streak = 0
            var best = prefs.getInt("learn_fretboard_best_streak", 0)

            fun noteAt(string: Int, fret: Int) = semitones[(openMidi[string] + fret) % 12]
            fun update() {
                target.text = "Gesucht:  $targetName"
                stats.text = "Runde $round/10   ·   Treffer $correct   ·   Serie $streak   ·   Bestwert $best"
                progress.progress = round.coerceAtMost(10)
            }
            fun newTarget() {
                targetName = natural[random.nextInt(natural.size)]
                fretboard.highlighted = null
                feedback.text = "Tippe eine Saite und einen Bund an."
                update()
            }
            fun finishRound() {
                best = maxOf(best, streak, prefs.getInt("learn_fretboard_best_streak", 0))
                prefs.edit().putInt("learn_fretboard_best_streak", best).putInt("learn_fretboard_best_score", correct).apply()
                feedback.text = "Runde geschafft · $correct/10 Treffer · beste Serie $best"
                next.text = "Neue Runde starten"; progress.progress = 10
            }
            fretboard.onNoteTap = { string, fret ->
                if (round < 10) {
                    val found = noteAt(string, fret)
                    GuitarAudioEngine.playString(a, string, fret, 0.68f)
                    if (found == targetName) {
                        correct++; streak++; best = maxOf(best, streak); round++
                        fretboard.highlighted = Pair(string, fret)
                        feedback.text = "✓ Richtig · " + found + " auf Saite " + (string + 1) + ", Bund " + fret
                        if (round >= 10) finishRound() else newTarget()
                    } else {
                        streak = 0; fretboard.highlighted = Pair(string, fret)
                        feedback.text = "Noch nicht · du hast " + found + " getroffen. Gesucht ist " + targetName + "."
                        update()
                    }
                }
            }
            next.setOnClickListener {
                if (round >= 10) { round = 0; correct = 0; streak = 0; next.text = "Nächsten Ton anzeigen"; newTarget() }
                else newTarget()
            }
            reset.setOnClickListener {
                round = 0; correct = 0; streak = 0; next.text = "Nächsten Ton anzeigen"; newTarget()
                Toast.makeText(a, "Griffbrett-Training zurückgesetzt", Toast.LENGTH_SHORT).show()
            }
            update(); newTarget()
        }

        fun showSongPractice() {
            finishQuizSession(); stopRhythm(); stopStrumming()
            content.removeAllViews()
            val (card, box) = panel("Song-Praxis", "Übe typische Song-Akkordfolgen im eigenen Tempo. Wähle eine Folge und trainiere anschließend Wechsel, Rhythmus und Anschlag.")
            val selected = TextView(a).apply {
                text = "Aktuelle Folge: " + (prefs.getString("learn_song_progression", "G – D – Em – C") ?: "G – D – Em – C")
                textSize = 16f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_copper))
                setPadding(0, a.dp(10), 0, a.dp(8))
            }
            box.addView(selected)
            val playProgression = a.button("▶ Akkordfolge anhören").apply {
                gravity = Gravity.CENTER
                textAlignment = View.TEXT_ALIGNMENT_CENTER
                includeFontPadding = true
                minLines = 1
                maxLines = 1
                setPadding(a.dp(16), a.dp(14), a.dp(16), a.dp(14))
                minHeight = a.dp(60)
                minimumHeight = a.dp(60)
            }
            box.addView(playProgression, LinearLayout.LayoutParams(-1, a.dp(60)).apply { topMargin = a.dp(8) })
            var progressionPlaying = false
            playProgression.setOnClickListener {
                if (progressionPlaying) {
                    GuitarAudioEngine.stopAll()
                    progressionPlaying = false
                    playProgression.text = "▶ Akkordfolge anhören"
                } else {
                    val names = selected.text.toString().substringAfter(":").split("–").map { it.trim() }
                    if (names.any { name -> ChordLibrary.all.none { it.name == name } }) {
                        Toast.makeText(a, "Für diese Folge fehlt ein Akkordgriff.", Toast.LENGTH_SHORT).show()
                    } else {
                        progressionPlaying = true
                        playProgression.text = "■ Wiedergabe stoppen"
                        GuitarAudioEngine.playProgression(a, names, 80) {
                            progressionPlaying = false
                            playProgression.text = "▶ Akkordfolge anhören"
                        }
                    }
                }
            }
            val progressions = listOf("G – D – Em – C", "C – Am – F – G", "Am – F – C – G", "Em – C – G – D")
            progressions.forEach { progression ->
                box.addView(a.button(progression).apply {
                    isAllCaps = false
                    setOnClickListener {
                        GuitarAudioEngine.stopAll()
                        progressionPlaying = false
                        playProgression.text = "▶ Akkordfolge anhören"
                        prefs.edit().putString("learn_song_progression", progression).apply()
                        selected.text = "Aktuelle Folge: $progression"
                    }
                }, LinearLayout.LayoutParams(-1, a.dp(44)).apply { topMargin = a.dp(5) })
            }
            box.addView(a.body("Tipp: Spiele jeden Akkord zunächst vier gleichmäßige Schläge. Wenn der Wechsel sicher sitzt, erhöhe das Tempo schrittweise.", 12f).apply {
                setPadding(0, a.dp(10), 0, a.dp(8))
            })
            content.addView(card)
            val actions = roundedCard()
            val actionBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(14), a.dp(12), a.dp(14), a.dp(12)) }
            actionBox.addView(a.button("🎸 Griffbrett entdecken").apply { setOnClickListener { showFretboard() } },
                LinearLayout.LayoutParams(-1, a.dp(46)).apply { bottomMargin = a.dp(8) })
            actionBox.addView(a.button("Akkordwechsel & Schlagmuster trainieren").apply { setOnClickListener { showChanges() } },
                LinearLayout.LayoutParams(-1, a.dp(46)))
            actionBox.addView(a.button("♩ Rhythmus und Tempo üben").apply { setOnClickListener { showRhythm() } },
                LinearLayout.LayoutParams(-1, a.dp(46)))
            actionBox.addView(a.button("Zur Lernstudio-Übersicht").apply { setOnClickListener { overviewAction?.invoke() } },
                LinearLayout.LayoutParams(-1, a.dp(44)).apply { topMargin = a.dp(12) })
            actions.addView(actionBox)
            content.addView(actions)
        }

        fun showGuidedSession() {
            finishQuizSession(); stopRhythm(); stopStrumming(); content.removeAllViews()
            val (card, box) = panel("🎯 Geführte 10-Minuten-Session", "Eine kompakte, adaptive Trainingseinheit. Die Reihenfolge passt sich deinem bisherigen Lernstand an.")
            val day = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.GERMANY).format(java.util.Date())
            val doneKey = "learn_guided_day"; val doneCountKey = "learn_guided_done"
            val already = if (prefs.getString(doneKey, "") == day) prefs.getInt(doneCountKey, 0) else 0
            val tasks = listOf(
                Triple("Akkorde", "2 Min · C – G – Am – F sauber greifen", 2),
                Triple("Wechsel", "3 Min · langsame, gleichmäßige Wechsel", 3),
                Triple("Rhythmus", "2 Min · Metronom und gleichmäßiger Puls", 2),
                Triple("Schlagmuster", "2 Min · Anschlag mit Timing-Fenster", 2),
                Triple("Freies Spielen", "1 Min · das Gelernte in einem Song anwenden", 1)
            )
            val progressLabel = TextView(a).apply { textSize = 13f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0, 0, 0, a.dp(8)) }
            val progress = ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply { max = 10; this.progress = already.coerceIn(0, 10) }
            box.addView(progressLabel); box.addView(progress, LinearLayout.LayoutParams(-1, a.dp(10)).apply { bottomMargin = a.dp(10) })
            fun updateGuided() {
                val n = if (prefs.getString(doneKey, "") == day) prefs.getInt(doneCountKey, 0) else 0
                progress.progress = n.coerceIn(0, 10)
                progressLabel.text = if (n >= 10) "Heute abgeschlossen · +10 XP" else n.toString() + "/10 Minuten abgeschlossen"
            }
            tasks.forEach { task ->
                val row = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, a.dp(5), 0, a.dp(5)) }
                val textBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
                textBox.addView(TextView(a).apply { text = task.first; textSize = 15f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_text)) })
                textBox.addView(TextView(a).apply { text = task.second; textSize = 12f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0, a.dp(2), 0, 0) })
                row.addView(textBox, LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(a.button("Start").apply {
                    minWidth = a.dp(74)
                    setOnClickListener {
                        val current = if (prefs.getString(doneKey, "") == day) prefs.getInt(doneCountKey, 0) else 0
                        val next = (current + task.third).coerceAtMost(10)
                        prefs.edit().putString(doneKey, day).putInt(doneCountKey, next).putInt("learn_xp", prefs.getInt("learn_xp", 0) + task.third * 10).apply()
                        updateGuided()
                        (it as Button).text = "✓"; it.isEnabled = false
                        recordSession(task.third * 60)
                    }
                })
                box.addView(row)
            }
            box.addView(a.button("Schlagmuster direkt trainieren").apply { setOnClickListener { showStrumming() } }, LinearLayout.LayoutParams(-1, a.dp(46)).apply { topMargin = a.dp(8) })
            updateGuided()
            content.addView(card)
        }

        fun showRoutine() {
            finishQuizSession(); stopRhythm(); content.removeAllViews()
            val (card, box) = panel("Deine tägliche 10-Minuten-Routine", "Fünf kurze Einheiten statt einer langen Session. Hake ab, was du heute erledigt hast.")
            val day = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.GERMANY).format(java.util.Date())
            if (prefs.getString("learn_routine_day", "") != day) prefs.edit().putString("learn_routine_day", day).putInt("learn_routine_done", 0).apply()
            val tasks = listOf("2 Min. Akkordgriffe sauber aufsetzen", "3 Min. C – G – Am – F wechseln", "2 Min. Rhythmus mit Metronom", "2 Min. einen Song begleiten", "1 Min. freies Spielen")
            val progressLabel = TextView(a).apply { setTextColor(a.getColor(R.color.sw_text)); textSize = 14f }
            val progress = ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply { max = tasks.size }
            box.addView(progressLabel); box.addView(progress, LinearLayout.LayoutParams(-1, a.dp(10)).apply { bottomMargin = a.dp(8) })
            fun update(mask: Int) {
                val n = Integer.bitCount(mask); progress.progress = n
                progressLabel.text = if (n == tasks.size) "Heute komplett · 10 Minuten geschafft" else "Heute erledigt: $n von ${tasks.size}"
                prefs.edit().putInt("learn_routine_done", mask).apply(); updatePracticeStats()
            }
            tasks.forEachIndexed { index, task ->
                val cb = CheckBox(a).apply { text = task; textSize = 14f; setTextColor(a.getColor(R.color.sw_text)); isChecked = (prefs.getInt("learn_routine_done", 0) and (1 shl index)) != 0 }
                cb.setOnCheckedChangeListener { _, checked ->
                    val previous = prefs.getInt("learn_routine_done", 0)
                    var mask = previous; mask = if (checked) mask or (1 shl index) else mask and (1 shl index).inv()
                    if (checked && previous == 0) recordPracticeDay()
                    update(mask)
                }
                box.addView(cb)
            }
            update(prefs.getInt("learn_routine_done", 0))
            box.addView(a.button("Lernpfad öffnen").apply { setOnClickListener { a.openSection(6) } }, LinearLayout.LayoutParams(-1, a.dp(46)).apply { topMargin = a.dp(8) })
            content.addView(card)
        }

        overviewAction = {
            finishQuizSession(); stopRhythm(); content.removeAllViews()
            content.addView(a.title("Lernstudio"))
            content.addView(a.body("Dein persönlicher Trainingsbereich für Akkorde, Rhythmus, Timing, Schlagmuster und Songs."))

            val cal = java.util.Calendar.getInstance()
            val weekKey = cal.get(java.util.Calendar.YEAR).toString() + "-" + cal.get(java.util.Calendar.WEEK_OF_YEAR).toString()
            val weekSeconds = if (prefs.getString("learn_week_key", "") == weekKey) prefs.getInt("learn_week_seconds", 0) else 0
            val weekGoal = 60 * 60
            val quick = roundedCard()
            val quickBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(14), a.dp(14), a.dp(14), a.dp(14)) }
            quickBox.addView(TextView(a).apply { text = "Schnellstart"; textSize = 18f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_text)) })
            quickBox.addView(TextView(a).apply { text = "Wähle nach deinem aktuellen Ziel."; textSize = 12f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0, a.dp(3), 0, a.dp(8)) })
            val row1 = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }; val row2 = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
            fun quickButton(text: String, action: () -> Unit): Button = a.button(text).apply { textSize = 12f; minHeight = a.dp(48); setOnClickListener { action() } }
            row1.addView(quickButton("⚡ Akkorde erkennen") { showQuiz() }, LinearLayout.LayoutParams(0, a.dp(48), 1f).apply { rightMargin = a.dp(5) })
            row1.addView(quickButton("↔ Wechsel üben") { showChanges() }, LinearLayout.LayoutParams(0, a.dp(48), 1f).apply { leftMargin = a.dp(5) })
            row2.addView(quickButton("♩ Rhythmus") { showRhythm() }, LinearLayout.LayoutParams(0, a.dp(48), 1f).apply { rightMargin = a.dp(5); topMargin = a.dp(8) })
            row2.addView(quickButton("✓ Tagesroutine") { showRoutine() }, LinearLayout.LayoutParams(0, a.dp(48), 1f).apply { leftMargin = a.dp(5); topMargin = a.dp(8) })
            val row3 = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
            row3.addView(quickButton("↘ Schlagmuster") { showStrumming() }, LinearLayout.LayoutParams(0, a.dp(48), 1f).apply { rightMargin = a.dp(5); topMargin = a.dp(8) })
            row3.addView(quickButton("♬ Song-Praxis") { showSongPractice() }, LinearLayout.LayoutParams(0, a.dp(48), 1f).apply { leftMargin = a.dp(5); topMargin = a.dp(8) })
            val row4 = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
            row4.addView(quickButton("🎯 10-Min-Session") { showGuidedSession() }, LinearLayout.LayoutParams(-1, a.dp(48)).apply { topMargin = a.dp(8) })
            quickBox.addView(row1); quickBox.addView(row2); quickBox.addView(row3); quick.addView(quickBox); content.addView(quick); addGap(10)


            val focusCard = roundedCard()
            val focusBox = LinearLayout(a).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(a.dp(14), a.dp(13), a.dp(14), a.dp(13))
            }
            val focusTitle = TextView(a).apply {
                text = "🎯 Dein Fokus heute"
                textSize = 17f
                setTypeface(typeface, 1)
                setTextColor(a.getColor(R.color.sw_text))
            }
            val focusText = TextView(a).apply {
                textSize = 13f
                setTextColor(a.getColor(R.color.sw_muted))
                setPadding(0, a.dp(3), 0, a.dp(8))
            }
            val focusButton = a.button("Jetzt trainieren").apply { minHeight = a.dp(44) }
            val quizTotal = prefs.getInt("learn_quiz_total", 0)
            val quizCorrect = prefs.getInt("learn_quiz_correct", 0)
            val quizRate = if (quizTotal > 0) quizCorrect * 100 / quizTotal else 0
            val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.GERMANY).format(java.util.Date())
            val minutesToday = if (prefs.getString("learn_daily_day", "") == today) prefs.getInt("learn_daily_minutes", 0) else 0
            val focusAction: () -> Unit = when {
                quizTotal < 5 -> {
                    focusText.text = "Starte mit dem Akkord-Blitztrainer und sammle deine ersten sicheren Treffer."
                    { showQuiz() }
                }
                quizRate < 70 -> {
                    focusText.text = "Deine Akkorderkennung ist noch ausbaufähig. Kurze, häufige Wiederholungen bringen dich weiter."
                    { showQuiz() }
                }
                prefs.getString("learn_daily_day", "") != today || minutesToday < 5 -> {
                    focusText.text = "Du hast heute noch wenig Übungszeit gesammelt. Ein kurzer Wechselblock reicht."
                    { showChanges() }
                }
                prefs.getInt("learn_strum_best_score", 0) < 250 -> {
                    focusText.text = "Dein Schlagmuster-Score ist noch ausbaufähig. Trainiere Timing und Anschlag mit kurzen, präzisen Serien."
                    { showStrumming() }
                }
                weekSeconds < 20 * 60 -> {
                    focusText.text = "Dein Wochenziel ist noch nicht halb voll. Ein kurzer Wechsel- oder Rhythmusblock bringt dich direkt weiter."
                    { showChanges() }
                }
                else -> {
                    focusText.text = "Deine Basis sitzt. Trainiere jetzt Timing und Anschlag mit einem Schlagmuster."
                    { showStrumming() }
                }
            }
            focusButton.setOnClickListener { focusAction() }
            focusBox.addView(focusTitle)
            focusBox.addView(focusText)
            focusBox.addView(focusButton, LinearLayout.LayoutParams(-1, a.dp(44)))
            focusCard.addView(focusBox)
            content.addView(focusCard)
            addGap(10)



            val xp = prefs.getInt("learn_xp", 0)
            val level = (xp / 100) + 1
            val levelXp = xp % 100
            val levelCard = roundedCard()
            val levelBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(16), a.dp(15), a.dp(16), a.dp(15)) }
            levelBox.addView(TextView(a).apply { text = "⭐ Level " + level; textSize = 22f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_copper)) })
            levelBox.addView(TextView(a).apply { text = xp.toString() + " XP · " + (100 - levelXp) + " XP bis Level " + (level + 1); textSize = 12f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0, a.dp(3), 0, a.dp(8)) })
            levelBox.addView(ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progress = levelXp }, LinearLayout.LayoutParams(-1, a.dp(10)))
            levelCard.addView(levelBox); content.addView(levelCard); addGap(8)

            val sessionCard = roundedCard()
            val sessionBox = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(a.dp(14), a.dp(12), a.dp(14), a.dp(12)) }
            val sessionText = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            sessionText.addView(TextView(a).apply { text = "🎯 Heute trainieren"; textSize = 17f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_text)) })
            sessionText.addView(TextView(a).apply { text = "Adaptive 10-Minuten-Session · passend zu deinem Lernstand"; textSize = 12f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0, a.dp(2), 0, 0) })
            sessionBox.addView(sessionText, LinearLayout.LayoutParams(0, -2, 1f))
            sessionBox.addView(a.button("Start").apply { setOnClickListener { showGuidedSession() } }, LinearLayout.LayoutParams(a.dp(86), a.dp(44)))
            sessionCard.addView(sessionBox); content.addView(sessionCard); addGap(10)
            val streak = prefs.getInt("learn_streak", 0)
            val hero = roundedCard()
            val heroBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(16), a.dp(15), a.dp(16), a.dp(15)) }
            heroBox.addView(TextView(a).apply { text = if (streak > 0) "🔥 $streak Tage Lernserie" else "Heute ist ein guter Tag zum Üben"; textSize = 19f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_copper)) })
            heroBox.addView(TextView(a).apply { tag = "learnToday"; textSize = 13f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0, a.dp(4), 0, a.dp(8)) })
            heroBox.addView(ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply { tag = "learnTodayProgress"; max = 5 }, LinearLayout.LayoutParams(-1, a.dp(10)))
            hero.addView(heroBox); content.addView(hero); addGap(8)

            val stats = LinearLayout(a).apply { tag = "learnStats"; orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(a.dp(4), a.dp(2), a.dp(4), a.dp(2)) }
            val statsCard = roundedCard(); statsCard.addView(stats); content.addView(statsCard); addGap(10)

            val weekCard = roundedCard()
            val weekBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(14), a.dp(13), a.dp(14), a.dp(13)) }
            val weekLabel = TextView(a).apply {
                text = (weekSeconds / 60).coerceAtMost(60).toString() + "/60 Minuten · " + if (weekSeconds >= weekGoal) "Ziel erreicht 🎉" else ((weekGoal - weekSeconds).coerceAtLeast(0) / 60).toString() + " Min. übrig"
                textSize = 12f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0, a.dp(3), 0, a.dp(7))
            }
            weekBox.addView(TextView(a).apply { text = "📅 Wochenziel"; textSize = 17f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_text)) })
            weekBox.addView(weekLabel)
            weekBox.addView(ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progress = ((weekSeconds.toFloat() / weekGoal).coerceIn(0f, 1f) * 100).toInt() }, LinearLayout.LayoutParams(-1, a.dp(10)))
            weekBox.addView(a.body("60 Minuten pro Woche · kleine Einheiten zählen genauso.", 11f))
            weekCard.addView(weekBox); content.addView(weekCard); addGap(10)

            val skillCard = roundedCard()
            val skillBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(14), a.dp(13), a.dp(14), a.dp(13)) }
            skillBox.addView(TextView(a).apply { text = "🏆 Deine Skills"; textSize = 17f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_text)) })
            skillBox.addView(a.body("Jede Trainingseinheit stärkt deinen persönlichen Lernpfad.", 12f))
            fun skillRow(name: String, value: Int, detail: String) {
                val row = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(0, a.dp(5), 0, a.dp(3)) }
                val head = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
                head.addView(TextView(a).apply { text = name; textSize = 13f; setTextColor(a.getColor(R.color.sw_text)) }, LinearLayout.LayoutParams(0, -2, 1f))
                head.addView(TextView(a).apply { text = "Level " + value; textSize = 12f; setTextColor(a.getColor(R.color.sw_copper)) })
                row.addView(head)
                row.addView(TextView(a).apply { text = detail; textSize = 10f; setTextColor(a.getColor(R.color.sw_muted)) })
                skillBox.addView(row)
            }
            val chordLevel = (1 + prefs.getInt("learn_quiz_correct", 0) / 5).coerceAtMost(5)
            val changeLevel = (1 + prefs.getInt("learn_skill_changes", 0) / 3).coerceAtMost(5)
            val rhythmLevel = (1 + prefs.getInt("learn_skill_rhythm", 0) / 3).coerceAtMost(5)
            val strumLevel = (1 + prefs.getInt("learn_strum_best_score", 0) / 300).coerceAtMost(5)
            skillRow("Akkorde", chordLevel, "Treffer: " + prefs.getInt("learn_quiz_correct", 0))
            skillRow("Akkordwechsel", changeLevel, "Trainerstarts: " + prefs.getInt("learn_skill_changes", 0))
            skillRow("Rhythmus", rhythmLevel, "Metronom-Sessions: " + prefs.getInt("learn_skill_rhythm", 0))
            skillRow("Schlagmuster", strumLevel, "Bestscore: " + prefs.getInt("learn_strum_best_score", 0))
            skillCard.addView(skillBox); content.addView(skillCard); addGap(10)

            // Kleine, nachvollziehbare Meilensteine motivieren ohne künstliche Trainerstarts zu belohnen.
            val quizAttempts = prefs.getInt("learn_quiz_total", 0)
            val quizHits = prefs.getInt("learn_quiz_correct", 0)
            val quizAccuracy = if (quizAttempts > 0) quizHits * 100 / quizAttempts else 0
            val sessions = prefs.getInt("learn_sessions", 0)
            val strumBest = prefs.getInt("learn_strum_best_score", 0)
            val achievements = listOf(
                Triple("Erster Schritt", sessions >= 1, "Erste Übungszeit gesammelt"),
                Triple("Dranbleiber", sessions >= 10, "$sessions von 10 Übungseinheiten"),
                Triple("Wochenprofi", weekSeconds >= weekGoal, (weekSeconds / 60).coerceAtMost(60).toString() + " von 60 Wochenminuten"),
                Triple("Lernserie", prefs.getInt("learn_streak", 0) >= 5, prefs.getInt("learn_streak", 0).toString() + " von 5 Tagen in Folge"),
                Triple("Akkord-Sicherheit", quizAttempts >= 10 && quizAccuracy >= 80, quizAccuracy.toString() + "% Treffer · mindestens 80% bei 10 Fragen"),
                Triple("Timing-Meister", strumBest >= 500, strumBest.toString() + " von 500 Schlagmuster-Punkten")
            )
            val earned = achievements.count { it.second }
            val achievementCard = roundedCard()
            val achievementBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(14), a.dp(13), a.dp(14), a.dp(13)) }
            achievementBox.addView(TextView(a).apply {
                text = "🏅 Erfolge · $earned/${achievements.size}"
                textSize = 17f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_text))
            })
            achievementBox.addView(a.body("Echte Lernfortschritte schalten diese Meilensteine frei.", 11f))
            val achievementGrid = GridLayout(a).apply { columnCount = 2; useDefaultMargins = false }
            achievements.forEach { achievement ->
                val cell = LinearLayout(a).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(a.dp(8), a.dp(8), a.dp(6), a.dp(8))
                    background = android.graphics.drawable.GradientDrawable().apply {
                        setColor(a.getColor(if (achievement.second) R.color.sw_surface else R.color.sw_surface))
                        cornerRadius = a.dp(10).toFloat()
                    }
                }
                cell.addView(TextView(a).apply {
                    text = (if (achievement.second) "✓  " else "○  ") + achievement.first
                    textSize = 12f; setTypeface(typeface, 1)
                    setTextColor(a.getColor(if (achievement.second) R.color.sw_copper else R.color.sw_text))
                })
                cell.addView(TextView(a).apply {
                    text = achievement.third; textSize = 10f
                    setTextColor(a.getColor(R.color.sw_muted))
                })
                achievementGrid.addView(cell, GridLayout.LayoutParams().apply {
                    width = 0; height = -2
                    columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                    setMargins(a.dp(3), a.dp(3), a.dp(3), a.dp(3))
                })
            }
            achievementBox.addView(achievementGrid)
            achievementCard.addView(achievementBox); content.addView(achievementCard); addGap(10)

            // Adaptive Tagesfokus: Die Startseite schlägt anhand des bisherigen Lernstands
            // automatisch den sinnvollsten nächsten Schwerpunkt vor.



            val path = roundedCard()
            val pathBox = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(a.dp(14), a.dp(12), a.dp(12), a.dp(12)) }
            val pathText = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            pathText.addView(TextView(a).apply { text = "Dein Lernpfad"; textSize = 17f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_text)) })
            pathText.addView(TextView(a).apply { text = "Lernstufen, persönliches Ziel und langfristiger Fortschritt"; textSize = 12f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0, a.dp(3), 0, 0) })
            pathBox.addView(pathText, LinearLayout.LayoutParams(0, -2, 1f))
            pathBox.addView(a.button("Öffnen").apply { setOnClickListener { a.openSection(6) } }, LinearLayout.LayoutParams(a.dp(92), a.dp(44)))
            path.addView(pathBox); content.addView(path); updatePracticeStats()
        }

        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        overviewAction?.invoke()
        return root
    }

    private fun finishQuizSession() {
        quizCountdownHandler?.removeCallbacksAndMessages(null)
        quizCountdownHandler = null
        val started = quizStartedAt
        quizStartedAt = 0L
        if (started > 0L) onSessionElapsed?.invoke(((android.os.SystemClock.elapsedRealtime() - started) / 1000L).toInt().coerceAtLeast(1))
    }

    private fun stopStrumming() {
        val started = strumStartedAt
        strumStartedAt = 0L
        strumRunning = false
        strumHandler?.removeCallbacksAndMessages(null)
        strumHandler = null
        if (started > 0L) onSessionElapsed?.invoke(((android.os.SystemClock.elapsedRealtime() - started) / 1000L).toInt().coerceAtLeast(1))
        GuitarAudioEngine.stopAll()
    }

    private fun stopRhythm() {
        val started = rhythmStartedAt
        rhythmStartedAt = 0L
        rhythmRunning = false; rhythmHandler?.removeCallbacksAndMessages(null); rhythmHandler = null
        if (started > 0L) onSessionElapsed?.invoke(((android.os.SystemClock.elapsedRealtime() - started) / 1000L).toInt().coerceAtLeast(1))
        GuitarAudioEngine.stopAll()
    }
}
class PathFragment : Fragment() {
    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity; val prefs = a.getSharedPreferences("saitenwerk", 0)
        val root = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        root.addView(a.title("Dein Lernpfad")); root.addView(a.body("Vom ersten Griff bis zum selbstständigen Spielen ganzer Songs. Du bestimmst dein Tempo – dein Fortschritt bleibt auf diesem Gerät gespeichert."))
        val stages = listOf(
            "Erste Akkorde" to "Lerne C, G, D, A, E sowie Am und Em kennen. Ziel: jeden Griff ruhig und einzeln aufsetzen.",
            "Saubere Griffbilder" to "Achte auf gekrümmte Finger, kurze Fingernägel und darauf, dass jede Saite klar klingt.",
            "Flüssige Wechsel" to "Verbinde zwei Akkorde zunächst langsam. Steigere das Tempo erst, wenn der Wechsel sicher sitzt.",
            "Rhythmus festigen" to "Halte einen gleichmäßigen Viertelpuls und übe den Wechsel ohne den Schlagfluss zu unterbrechen.",
            "Erste Songs begleiten" to "Wähle ein einfaches Lied und spiele die Akkordfolge langsam im passenden Takt.",
            "Selbstständig spielen" to "Spiele einen Song vom Anfang bis zum Ende und finde bei Bedarf selbst zurück in den Ablauf."
        )
        val key = "learning_path_done"
        val progressLabel = TextView(a).apply { setTextColor(a.getColor(R.color.sw_copper)); textSize = 17f; setPadding(a.dp(20), a.dp(8), a.dp(20), a.dp(8)) }
        val progress = ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply { max = stages.size }
        root.addView(progressLabel); root.addView(progress, LinearLayout.LayoutParams(-1, a.dp(10)).apply { setMargins(a.dp(20), 0, a.dp(20), a.dp(14)) })
        fun refresh() { val mask = prefs.getInt(key, 0); val count = Integer.bitCount(mask); progress.progress = count; progressLabel.text = "$count von ${stages.size} Lernstufen abgeschlossen · ${count * 100 / stages.size}%" }
        val goalCard = a.card(); val goalBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(16), a.dp(14), a.dp(16), a.dp(14)) }
        goalBox.addView(TextView(a).apply { text = "Mein persönliches Lernziel"; textSize = 19f; setTextColor(a.getColor(R.color.sw_copper)); setTypeface(typeface, 1) })
        val goal = EditText(a).apply { setText(prefs.getString("learning_path_goal", "")); hint = "z. B. In vier Wochen drei Songs begleiten"; setTextColor(a.getColor(R.color.sw_text)); setHintTextColor(a.getColor(R.color.sw_muted)); minLines = 2 }
        goalBox.addView(goal)
        val save = a.button("Lernziel speichern"); save.setOnClickListener { prefs.edit().putString("learning_path_goal", goal.text.toString().trim()).apply(); Toast.makeText(a, "Lernziel gespeichert", Toast.LENGTH_SHORT).show() }
        goalBox.addView(save); goalCard.addView(goalBox); root.addView(goalCard, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(14)) })
        val next = a.body("").apply { textSize = 16f; setTextColor(a.getColor(R.color.sw_text)) }; root.addView(next)
        val checks = mutableListOf<CheckBox>()
        stages.forEachIndexed { index, stage ->
            val card = a.card(); val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(14), a.dp(12), a.dp(14), a.dp(12)) }
            box.addView(TextView(a).apply { text = "${index + 1}. ${stage.first}"; textSize = 18f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_text)) })
            box.addView(a.body(stage.second, 14f))
            val check = CheckBox(a).apply { text = "Lernstufe abgeschlossen"; setTextColor(a.getColor(R.color.sw_text)); isChecked = (prefs.getInt(key, 0) and (1 shl index)) != 0 }; checks.add(check)
            check.setOnCheckedChangeListener { _, checked ->
                var mask = prefs.getInt(key, 0); mask = if (checked) mask or (1 shl index) else mask and (1 shl index).inv(); prefs.edit().putInt(key, mask).apply(); refresh()
                val first = stages.indices.firstOrNull { (mask and (1 shl it)) == 0 }; next.text = if (first == null) "Geschafft! Alle Lernstufen sind abgeschlossen." else "Dein nächster Schritt: ${stages[first].first}"
            }
            box.addView(check); val practice = a.button("Im Lernstudio üben"); practice.setOnClickListener { a.openSection(5) }; box.addView(practice)
            card.addView(box); root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(16), a.dp(5), a.dp(16), a.dp(5)) })
        }
        val reset = a.button("Lernpfad zurücksetzen"); reset.setOnClickListener { prefs.edit().putInt(key, 0).apply(); checks.forEach { it.isChecked = false }; refresh(); next.text = "Dein nächster Schritt: ${stages.first().first}"; Toast.makeText(a, "Lernpfad zurückgesetzt", Toast.LENGTH_SHORT).show() }
        root.addView(reset, LinearLayout.LayoutParams(-1, a.dp(48)).apply { setMargins(a.dp(16), a.dp(12), a.dp(16), a.dp(24)) })
        refresh(); val mask = prefs.getInt(key, 0); val first = stages.indices.firstOrNull { (mask and (1 shl it)) == 0 }; next.text = if (first == null) "Geschafft! Alle Lernstufen sind abgeschlossen." else "Dein nächster Schritt: ${stages[first].first}"
        return ScrollView(a).apply { addView(root) }
    }
}
