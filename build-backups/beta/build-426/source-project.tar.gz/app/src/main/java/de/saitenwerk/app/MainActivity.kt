package de.saitenwerk.app

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.SoundPool
import android.media.AudioAttributes
import android.media.MediaRecorder
import android.media.MediaPlayer
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.card.MaterialCardView
import org.json.JSONArray
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.exp
import kotlin.math.PI

class MainActivity : AppCompatActivity() {
    fun openSong(song: Song) {
        show(SongDetailFragment.newInstance(song))
    }

    private lateinit var appUpdateManager: AppUpdateManager
    private var bottomNav: BottomNavigationView? = null
    private var suppressNavSelection = false
    private var micGrantedAction: (() -> Unit)? = null
    private var contentFrameId: Int = View.NO_ID
    private val requestMic = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) micGrantedAction?.invoke()
        else Toast.makeText(this, "Für das Stimmgerät wird Mikrofonzugriff benötigt.", Toast.LENGTH_LONG).show()
        micGrantedAction = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = getColor(R.color.sw_navy)
        window.navigationBarColor = getColor(R.color.sw_navy)
        // Android 15/Edge-to-Edge: Inhalte sicher unterhalb der Statusleiste halten
        // und die untere Navigation oberhalb der System-Gestenleiste platzieren.
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(buildRoot())
        if (savedInstanceState == null) show(HomeFragment(), addToBackStack = false)
        supportFragmentManager.registerFragmentLifecycleCallbacks(
            object : androidx.fragment.app.FragmentManager.FragmentLifecycleCallbacks() {
                override fun onFragmentViewCreated(
                    fm: androidx.fragment.app.FragmentManager,
                    fragment: Fragment,
                    view: View,
                    savedInstanceState: Bundle?
                ) {
                    super.onFragmentViewCreated(fm, fragment, view, savedInstanceState)
                    applySaitenwerkButtonStyle(view)
                }
            },
            true
        )
        setupBackNavigation()
        // Updates werden ausschließlich auf ausdrücklichen Wunsch in den Einstellungen geprüft.
        appUpdateManager = AppUpdateManager(this)
    }

    override fun onDestroy() {
        if (::appUpdateManager.isInitialized) appUpdateManager.dispose()
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        if (::appUpdateManager.isInitialized) appUpdateManager.resumePendingInstall()
    }

    private fun buildRoot(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.sw_navy))
        }
        val frame = FrameLayout(this).also { contentFrameId = View.generateViewId(); it.id = contentFrameId }
        root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = BottomNavigationView(this).apply {
            // Bewusst dunkler als der Inhaltsbereich: Die Navigation ist klar abgesetzt.
            setBackgroundColor(getColor(R.color.sw_nav_bar))
            elevation = dp(12).toFloat()
            setItemIconSize(dp(24))
            itemPaddingTop = dp(6)
            itemPaddingBottom = dp(6)
            labelVisibilityMode = BottomNavigationView.LABEL_VISIBILITY_LABELED
            setItemIconTintList(android.content.res.ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(getColor(R.color.sw_copper), getColor(R.color.sw_nav_icon))
            ))
            setItemTextColor(android.content.res.ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(getColor(R.color.sw_copper), getColor(R.color.sw_nav_text))
            ))
            setItemTextAppearanceInactive(R.style.SaitenwerkBottomNavLabel)
            setItemTextAppearanceActive(R.style.SaitenwerkBottomNavLabelActive)
            menu.add(0, 1, 0, "Start").setIcon(R.drawable.ic_nav_home)
            menu.add(0, 2, 1, "Stimmen").setIcon(R.drawable.ic_nav_tuner)
            menu.add(0, 3, 2, "Akkorde").setIcon(R.drawable.ic_nav_chords)
            menu.add(0, 5, 4, "Lernstudio").setIcon(R.drawable.ic_nav_learn)
            // BottomNavigationView unterstützt maximal fünf Einträge.
            // Den Lernpfad erreichen Nutzer über das Lernstudio und die Startseite.
            setOnItemSelectedListener { item ->
                if (suppressNavSelection) true else { openSection(item.itemId); true }
            }
        }
        bottomNav = nav
        root.addView(nav, LinearLayout.LayoutParams(-1, dp(76)))
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(0, bars.top, 0, bars.bottom)
            insets
        }
        ViewCompat.requestApplyInsets(root)
        return root
    }

    fun premiumButtonBackground(primary: Boolean = false): android.graphics.drawable.Drawable {
        val shape = android.graphics.drawable.GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(getColor(if (primary) R.color.sw_copper else R.color.sw_surface2))
            if (!primary) setStroke(dp(1), getColor(R.color.sw_outline))
        }
        return android.graphics.drawable.RippleDrawable(
            android.content.res.ColorStateList.valueOf(getColor(R.color.sw_ripple)), shape, null
        )
    }

    fun premiumDropdownItemBackground(): android.graphics.drawable.Drawable {
        val shape = android.graphics.drawable.GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
            setColor(getColor(R.color.sw_surface2))
        }
        return android.graphics.drawable.RippleDrawable(
            android.content.res.ColorStateList.valueOf(getColor(R.color.sw_ripple)), shape, null
        )
    }

    private fun applySaitenwerkButtonStyle(root: View) {
        val density = resources.displayMetrics.density
        fun dp(value: Int) = (value * density + 0.5f).toInt()
        if (root is Button) {
            val primary = root.tag == "saitenwerk-primary"
            root.isAllCaps = false
            root.textSize = 14f
            root.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            root.setTextColor(getColor(if (primary) R.color.sw_on_accent else R.color.sw_copper))
            root.gravity = Gravity.CENTER
            root.textAlignment = View.TEXT_ALIGNMENT_CENTER
            root.includeFontPadding = true
            root.minLines = 1
            root.maxLines = 2
            root.setLineSpacing(dp(2).toFloat(), 1.05f)
            root.setPadding(dp(16), dp(10), dp(16), dp(10))
            root.minHeight = dp(52)
            root.minimumHeight = dp(52)
            root.minimumWidth = 0
            root.stateListAnimator = null
            root.elevation = dp(1).toFloat()
            root.background = premiumButtonBackground(primary)
            val params = root.layoutParams
            if (params != null && params.height > 0 && params.height < dp(52)) {
                params.height = dp(52)
                root.layoutParams = params
            }
        }
        if (root is MaterialCardView) {
            root.radius = dp(20).toFloat()
            root.strokeColor = getColor(R.color.sw_outline)
            root.strokeWidth = dp(1)
            root.cardElevation = dp(2).toFloat()
            root.setCardBackgroundColor(getColor(R.color.sw_surface))
        }
        if (root is Spinner) {
            root.setPopupBackgroundDrawable(android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(getColor(R.color.sw_surface))
                setStroke(dp(1), getColor(R.color.sw_outline))
            })
            root.dropDownVerticalOffset = dp(6)
            root.elevation = dp(1).toFloat()
        }
        if (root is ViewGroup) {
            for (index in 0 until root.childCount) applySaitenwerkButtonStyle(root.getChildAt(index))
        }
    }

    private fun show(fragment: Fragment, addToBackStack: Boolean = true) {
        val tx = supportFragmentManager.beginTransaction().replace(contentFrameId, fragment)
        if (addToBackStack) tx.addToBackStack(null)
        tx.commit()
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (supportFragmentManager.backStackEntryCount > 0) {
                    supportFragmentManager.popBackStack()
                    syncBottomNavigation()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    private fun syncBottomNavigation() {
        val id = when (supportFragmentManager.findFragmentById(contentFrameId)) {
            is HomeFragment -> 1
            is TunerFragment -> 2
            is ChordsFragment -> 3
            is LearnFragment -> 5
            is PathFragment -> 5
            else -> 0
        }
        if (id != 0 && bottomNav?.selectedItemId != id) {
            suppressNavSelection = true
            bottomNav?.selectedItemId = id
            suppressNavSelection = false
        }
    }

    fun openSection(id: Int) {
        val current = supportFragmentManager.findFragmentById(contentFrameId)
        val alreadyOpen = when (id) {
            1 -> current is HomeFragment
            2 -> current is TunerFragment
            3 -> current is ChordsFragment
            5 -> current is LearnFragment
            6 -> current is PathFragment
            else -> false
        }
        if (alreadyOpen) return
        when (id) {
            1 -> show(HomeFragment())
            2 -> show(TunerFragment())
            3 -> show(ChordsFragment())
            5 -> show(LearnFragment())
            6 -> show(PathFragment())
        }
    }

    fun openSettings() {
        show(SettingsFragment())
    }

    fun checkForUpdatesManually() {
        if (::appUpdateManager.isInitialized) appUpdateManager.checkForUpdates()
    }

    fun askMic(onGranted: () -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) onGranted()
        else { micGrantedAction = onGranted; requestMic.launch(Manifest.permission.RECORD_AUDIO) }
    }

    fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()
    fun title(value: String) = TextView(this).apply {
        text = value; setTextColor(getColor(R.color.sw_text)); textSize = 26f
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(dp(20), dp(18), dp(20), dp(8))
        letterSpacing = -0.02f
    }
    fun body(value: String, size: Float = 15f) = TextView(this).apply {
        text = value; textSize = size; setTextColor(getColor(R.color.sw_muted)); setPadding(dp(20), 0, dp(20), dp(14))
        setLineSpacing(dp(2).toFloat(),1f)
    }
    fun card(): MaterialCardView = MaterialCardView(this).apply {
        setCardBackgroundColor(getColor(R.color.sw_surface)); radius = dp(20).toFloat()
        strokeColor = getColor(R.color.sw_outline); strokeWidth = dp(1)
        cardElevation = dp(2).toFloat()
    }
    fun button(value: String) = Button(this).apply {
        text = value
        isAllCaps = false
        setTextColor(getColor(R.color.sw_copper))
        textSize = 14f
        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        gravity = Gravity.CENTER
        textAlignment = View.TEXT_ALIGNMENT_CENTER
        includeFontPadding = true
        minLines = 1
        maxLines = 2
        setLineSpacing(dp(2).toFloat(), 1.05f)
        setPadding(dp(16), dp(10), dp(16), dp(10))
        minHeight = dp(52)
        minimumHeight = dp(52)
        minimumWidth = 0
        stateListAnimator = null
        elevation = dp(1).toFloat()
        background = premiumButtonBackground()
    }

    fun spinnerAdapter(values: List<String>): ArrayAdapter<String> = object : ArrayAdapter<String>(this, R.layout.sw_spinner_item, values) {
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = super.getView(position, convertView, parent) as TextView
            v.setTextColor(getColor(R.color.sw_text))
            v.textSize = 14f
            v.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            v.gravity = Gravity.CENTER_VERTICAL
            v.includeFontPadding = true
            v.maxLines = 2
            v.setPadding(dp(16), dp(8), dp(42), dp(8))
            v.minHeight = dp(52)
            v.background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(getColor(R.color.sw_surface2))
                setStroke(dp(1), getColor(R.color.sw_outline))
            }
            return v
        }
        override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = super.getDropDownView(position, convertView, parent) as TextView
            v.setTextColor(getColor(R.color.sw_text))
            v.textSize = 14f
            v.typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
            v.gravity = Gravity.CENTER_VERTICAL
            v.includeFontPadding = true
            v.maxLines = 2
            v.setPadding(dp(16), dp(12), dp(16), dp(12))
            v.minHeight = dp(52)
            v.background = premiumDropdownItemBackground()
            return v
        }
    }
}

class HomeFragment : Fragment() {
    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a=requireActivity() as MainActivity
        val prefs=a.getSharedPreferences("saitenwerk",0)
        val page=LinearLayout(a).apply { orientation=LinearLayout.VERTICAL; setPadding(a.dp(20),a.dp(14),a.dp(20),a.dp(28)) }
        val top=LinearLayout(a).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        val brand=LinearLayout(a).apply { orientation=LinearLayout.VERTICAL }
        brand.addView(TextView(a).apply { text="SAITENWERK"; textSize=12f; letterSpacing=0.18f; setTypeface(typeface,1); setTextColor(a.getColor(R.color.sw_copper)) })
        brand.addView(TextView(a).apply { text="Dein Sound. Dein Fortschritt."; textSize=13f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0,a.dp(3),0,0) })
        top.addView(brand,LinearLayout.LayoutParams(0,-2,1f))
        top.addView(TextView(a).apply {
            text="⚙"; textSize=22f; gravity=Gravity.CENTER; setTextColor(a.getColor(R.color.sw_text))
            background=android.graphics.drawable.GradientDrawable().apply { shape=android.graphics.drawable.GradientDrawable.OVAL; setColor(a.getColor(R.color.sw_surface2)); setStroke(a.dp(1),a.getColor(R.color.sw_outline)) }
            contentDescription="Einstellungen öffnen"; isClickable=true; isFocusable=true; setOnClickListener { a.openSettings() }
        },LinearLayout.LayoutParams(a.dp(46),a.dp(46)))
        page.addView(top)

        // Persönlicher Tagesüberblick: nutzt ausschließlich vorhandene Lernfortschrittsdaten.
        val todayKey = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.GERMANY).format(java.util.Date())
        val weekCalendar = java.util.Calendar.getInstance()
        val weekKey = weekCalendar.get(java.util.Calendar.YEAR).toString() + "-" + weekCalendar.get(java.util.Calendar.WEEK_OF_YEAR).toString()
        val routineDone = if (prefs.getString("learn_routine_day", "") == todayKey) Integer.bitCount(prefs.getInt("learn_routine_done", 0)) else 0
        val routineTotal = 5
        val dailySeconds = if (prefs.getString("learn_daily_day", "") == todayKey) prefs.getInt("learn_daily_seconds", prefs.getInt("learn_daily_minutes", 0) * 60) else 0
        val weeklySeconds = if (prefs.getString("learn_week_key", "") == weekKey) prefs.getInt("learn_week_seconds", 0) else 0
        val streak = prefs.getInt("learn_streak", 0)
        val pathStages = listOf("Erste Akkorde", "Saubere Griffbilder", "Flüssige Wechsel", "Rhythmus festigen", "Erste Songs begleiten", "Selbstständig spielen")
        val pathMask = prefs.getInt("learning_path_done", 0)
        val nextPathIndex = pathStages.indices.firstOrNull { (pathMask and (1 shl it)) == 0 }
        val nextPath = nextPathIndex?.let { pathStages[it] } ?: "Alle Lernstufen geschafft"

        val todayCard = a.card().apply {
            radius = a.dp(20).toFloat()
            strokeColor = a.getColor(R.color.sw_outline)
            strokeWidth = a.dp(1)
            cardElevation = a.dp(2).toFloat()
        }
        val todayBox = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dp(17), a.dp(16), a.dp(17), a.dp(16))
        }
        val todayHeader = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        todayHeader.addView(TextView(a).apply {
            text = "DEIN HEUTIGES TRAINING"
            textSize = 11f
            letterSpacing = 0.12f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(a.getColor(R.color.sw_copper))
        }, LinearLayout.LayoutParams(0, -2, 1f))
        todayHeader.addView(TextView(a).apply {
            text = if (routineDone == routineTotal) "GESCHAFFT" else "$routineDone / $routineTotal"
            textSize = 12f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(a.getColor(R.color.sw_copper))
        })
        todayBox.addView(todayHeader)
        todayBox.addView(TextView(a).apply {
            text = if (routineDone == routineTotal) "Stark – deine Tagesroutine ist erledigt." else "Ein paar gezielte Minuten bringen dich weiter."
            textSize = 14f
            setTextColor(a.getColor(R.color.sw_text))
            setPadding(0, a.dp(7), 0, a.dp(10))
        })
        val todayProgress = ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = routineTotal
            progress = routineDone
            progressTintList = android.content.res.ColorStateList.valueOf(a.getColor(R.color.sw_copper))
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(a.getColor(R.color.sw_outline))
        }
        todayBox.addView(todayProgress, LinearLayout.LayoutParams(-1, a.dp(7)))
        val metrics = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, a.dp(12), 0, a.dp(12))
        }
        fun metric(value: String, label: String) {
            val item = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
            item.addView(TextView(a).apply {
                text = value
                textSize = 17f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(a.getColor(R.color.sw_text))
                gravity = Gravity.CENTER
            })
            item.addView(TextView(a).apply {
                text = label
                textSize = 10f
                setTextColor(a.getColor(R.color.sw_muted))
                gravity = Gravity.CENTER
                setPadding(0, a.dp(2), 0, 0)
            })
            metrics.addView(item, LinearLayout.LayoutParams(0, -2, 1f))
        }
        metric(String.format(java.util.Locale.GERMANY, "%.0f min", dailySeconds / 60.0), "Heute")
        metric(String.format(java.util.Locale.GERMANY, "%.0f min", weeklySeconds / 60.0), "Diese Woche")
        metric("$streak Tage", "Serie")
        todayBox.addView(metrics)
        todayBox.addView(TextView(a).apply {
            text = "Als Nächstes: $nextPath"
            textSize = 12f
            setTextColor(a.getColor(R.color.sw_muted))
            setPadding(0, 0, 0, a.dp(12))
        })
        val todayActions = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        todayActions.addView(Button(a).apply {
            tag = "saitenwerk-primary"
            text = "Training starten"
            isAllCaps = false
            setOnClickListener { a.openSection(5) }
        }, LinearLayout.LayoutParams(0, a.dp(50), 1f).apply { rightMargin = a.dp(6) })
        todayActions.addView(a.button("Lernpfad").apply {
            setOnClickListener { a.openSection(6) }
        }, LinearLayout.LayoutParams(0, a.dp(50), 1f).apply { leftMargin = a.dp(6) })
        todayBox.addView(todayActions)
        todayCard.addView(todayBox)
        page.addView(todayCard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = a.dp(16) })

        val hero=a.card().apply { radius=a.dp(24).toFloat(); strokeColor=a.getColor(R.color.sw_outline); strokeWidth=a.dp(1); elevation=a.dp(3).toFloat() }
        val box=LinearLayout(a).apply { orientation=LinearLayout.VERTICAL; setPadding(a.dp(20),a.dp(18),a.dp(20),a.dp(18)) }
        box.addView(ImageView(a).apply { setImageResource(R.drawable.saitenwerk_original); contentDescription="Saitenwerk – Dein persönlicher Gitarrenbegleiter"; scaleType=ImageView.ScaleType.FIT_CENTER; adjustViewBounds=true },LinearLayout.LayoutParams(-1,a.dp(180)).apply { bottomMargin=a.dp(12) })
        box.addView(TextView(a).apply { text="DEIN MUSIKALISCHER BEGLEITER"; textSize=10f; letterSpacing=0.16f; setTypeface(typeface,1); setTextColor(a.getColor(R.color.sw_copper)) })
        box.addView(TextView(a).apply { text="Spiel. Lerne. Kling besser."; textSize=25f; setTypeface(typeface,1); setTextColor(a.getColor(R.color.sw_text)); setPadding(0,a.dp(7),0,a.dp(5)) })
        box.addView(TextView(a).apply { text="Alles, was du zum Stimmen, Üben und Weiterkommen brauchst – an einem Ort."; textSize=14f; setLineSpacing(a.dp(2).toFloat(),1f); setTextColor(a.getColor(R.color.sw_muted)) })
        box.addView(Button(a).apply {
            tag = "saitenwerk-primary"
            text="Stimmgerät öffnen   →"; isAllCaps=false; textSize=15f; setTypeface(typeface,1); setTextColor(a.getColor(R.color.sw_on_accent)); minHeight=a.dp(54); stateListAnimator=null
            background=android.graphics.drawable.GradientDrawable().apply { cornerRadius=a.dp(16).toFloat(); setColor(a.getColor(R.color.sw_copper)) }
            setOnClickListener { a.openSection(2) }
        },LinearLayout.LayoutParams(-1,a.dp(54)).apply { topMargin=a.dp(16) })
        hero.addView(box)
        page.addView(hero,LinearLayout.LayoutParams(-1,-2).apply { topMargin=a.dp(20) })
        page.addView(TextView(a).apply { text="DEIN WORKSPACE"; textSize=11f; letterSpacing=0.14f; setTypeface(typeface,1); setTextColor(a.getColor(R.color.sw_muted)); setPadding(a.dp(2),a.dp(24),0,a.dp(10)) })
        fun tile(symbol:String,title:String,detail:String,section:Int) {
            val card=a.card().apply { radius=a.dp(18).toFloat(); strokeColor=a.getColor(R.color.sw_outline); strokeWidth=a.dp(1); isClickable=true; isFocusable=true; setOnClickListener { a.openSection(section) } }
            val row=LinearLayout(a).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(a.dp(15),a.dp(15),a.dp(14),a.dp(15)) }
            row.addView(TextView(a).apply { text=symbol; textSize=23f; gravity=Gravity.CENTER; setTextColor(a.getColor(R.color.sw_copper)); background=android.graphics.drawable.GradientDrawable().apply { cornerRadius=a.dp(13).toFloat(); setColor(a.getColor(R.color.sw_surface2)) } },LinearLayout.LayoutParams(a.dp(48),a.dp(48)))
            val texts=LinearLayout(a).apply { orientation=LinearLayout.VERTICAL }
            texts.addView(TextView(a).apply { text=title; textSize=16f; setTypeface(typeface,1); setTextColor(a.getColor(R.color.sw_text)) })
            texts.addView(TextView(a).apply { text=detail; textSize=12f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0,a.dp(3),0,0) })
            row.addView(texts,LinearLayout.LayoutParams(0,-2,1f).apply { leftMargin=a.dp(13) })
            row.addView(TextView(a).apply { text="›"; textSize=25f; setTextColor(a.getColor(R.color.sw_muted)) })
            card.addView(row); page.addView(card,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=a.dp(10) })
        }
        tile("♬","Akkorde","Griffbilder entdecken und speichern",3)
        tile("✦","Lernstudio","Übungen, Rhythmus und tägliche Routine",5)
        tile("↗","Dein Lernpfad","Deinen Fortschritt Schritt für Schritt verfolgen",6)
        val stats=LinearLayout(a).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(a.dp(2),a.dp(12),a.dp(2),0) }
        stats.addView(TextView(a).apply { text="LERNFORTSCHRITT"; textSize=10f; letterSpacing=0.12f; setTypeface(typeface,1); setTextColor(a.getColor(R.color.sw_muted)) },LinearLayout.LayoutParams(0,-2,1f))
        stats.addView(TextView(a).apply { text=prefs.getInt("learn_quiz_correct",0).toString()+" / "+prefs.getInt("learn_quiz_total",0)+" Quiz-Treffer"; textSize=12f; setTextColor(a.getColor(R.color.sw_copper)) })
        page.addView(stats)
        return ScrollView(a).apply { clipToPadding=false; isFillViewport=true; addView(page) }
    }
}

class SettingsFragment : Fragment() {
    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a=requireActivity() as MainActivity
        val page=LinearLayout(a).apply { orientation=LinearLayout.VERTICAL; setPadding(a.dp(20),a.dp(12),a.dp(20),a.dp(28)) }
        page.addView(TextView(a).apply { text="Einstellungen"; textSize=27f; setTypeface(typeface,1); setTextColor(a.getColor(R.color.sw_text)); setPadding(0,a.dp(8),0,a.dp(4)) })
        page.addView(TextView(a).apply { text="Saitenwerk an deinen Alltag anpassen."; textSize=14f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0,0,0,a.dp(20)) })
        fun section(title:String,description:String,actionLabel:String,action:()->Unit) {
            val card=a.card().apply { radius=a.dp(18).toFloat(); strokeColor=a.getColor(R.color.sw_outline); strokeWidth=a.dp(1) }
            val box=LinearLayout(a).apply { orientation=LinearLayout.VERTICAL; setPadding(a.dp(18),a.dp(17),a.dp(18),a.dp(17)) }
            box.addView(TextView(a).apply { text=title; textSize=17f; setTypeface(typeface,1); setTextColor(a.getColor(R.color.sw_text)) })
            box.addView(TextView(a).apply { text=description; textSize=13f; setLineSpacing(a.dp(2).toFloat(),1f); setTextColor(a.getColor(R.color.sw_muted)); setPadding(0,a.dp(5),0,a.dp(14)) })
            box.addView(a.button(actionLabel).apply { textSize=14f; minHeight=a.dp(48); background=android.graphics.drawable.GradientDrawable().apply { cornerRadius=a.dp(14).toFloat(); setColor(a.getColor(R.color.sw_surface2)); setStroke(a.dp(1),a.getColor(R.color.sw_copper)) }; setOnClickListener { action() } },LinearLayout.LayoutParams(-1,a.dp(48)))
            card.addView(box); page.addView(card,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=a.dp(13) })
        }
        section("App-Updates","Prüfe manuell, ob eine neue Saitenwerk-Version verfügbar ist. Deine installierte Version bleibt erhalten, bis du das Update bestätigst.","Nach Updates suchen") { a.checkForUpdatesManually() }
        val info=a.packageManager.getPackageInfo(a.packageName,0)
        val version=info.versionName ?: "unbekannt"; val code=info.versionCode
        section("Lernfortschritt","Setze sämtliche gespeicherten Lernzeiten, Punkte, XP, Serien, Quizwerte und Lernpfad-Fortschritte auf diesem Gerät zurück. Trainings-Einstellungen wie Akkordauswahl, Tempo und Taktart bleiben erhalten.","Alles zurücksetzen") {
            androidx.appcompat.app.AlertDialog.Builder(a, R.style.ThemeOverlay_Saitenwerk_Dialog)
                .setTitle("Gesamten Lernfortschritt zurücksetzen?")
                .setMessage("Dabei werden alle Lernstudio- und Lernpfad-Werte gelöscht: Übungsminuten, Tages- und Wochenzeiten, XP, Level, Serien, Quizpunkte, Bestwerte, geführte Sessions, Schlagmuster-, Rhythmus-, Griffbrett- und Akkordwechsel-Statistiken sowie abgeschlossene Lernstufen. Deine App-Einstellungen, Akkordauswahl, Tempi, Taktarten und Song-Arrangements bleiben erhalten.")
                .setNegativeButton("Abbrechen", null)
                .setPositiveButton("Alles zurücksetzen") { _, _ ->
                    a.getSharedPreferences("saitenwerk", 0).edit()
                        // Lernstudio: Zeit, Serien, XP, Quiz und Routine
                        .remove("learn_daily_day")
                        .remove("learn_daily_seconds")
                        .remove("learn_daily_minutes")
                        .remove("learn_last_session_day")
                        .remove("learn_week_key")
                        .remove("learn_week_seconds")
                        .remove("learn_sessions")
                        .remove("learn_streak")
                        .remove("learn_xp")
                        .remove("learn_quiz_correct")
                        .remove("learn_quiz_total")
                        .remove("learn_best_quiz_streak")
                        .remove("learn_routine_day")
                        .remove("learn_routine_done")
                        .remove("learn_guided_day")
                        .remove("learn_guided_done")
                        // Lernpfad / Kompetenzwerte
                        .remove("learning_path_done")
                        .remove("learn_skill_changes")
                        .remove("learn_skill_rhythm")
                        .remove("learn_skill_strum")
                        // Rhythmus- und Schlagmuster-Bestwerte
                        .remove("learn_strum_best_score")
                        .remove("learn_strum_best_rounds")
                        .remove("learn_strum_best_combo")
                        // Akkordwechsel-Training
                        .remove("chord_training_best_streak")
                        .remove("chord_training_sessions")
                        .remove("chord_training_mastered")
                        // Griffbrett-Notentrainer
                        .remove("learn_fretboard_best_streak")
                        .remove("learn_fretboard_best_score")
                        .apply()
                    Toast.makeText(a, "Gesamter Lernfortschritt wurde zurückgesetzt", Toast.LENGTH_SHORT).show()
                }
                .show()
        }

        val aboutText = "Saitenwerk ist mehr als nur eine Gitarren-App – es ist ein Experiment.\n\n" +
            "Die Idee hinter diesem Projekt war von Anfang an eine ganz bestimmte: Ich wollte zeigen, dass man keine Programmierkenntnisse oder jahrelange Erfahrung in der Softwareentwicklung benötigt, um eine eigene App auf die Beine zu stellen.\n\n" +
            "Mit Neugier, Ausdauer und der Unterstützung künstlicher Intelligenz ist Saitenwerk entstanden – von der ersten Idee bis hin zu einer eigenständigen Android-App.\n\n" +
            "Man muss nicht alles können, um etwas Eigenes zu erschaffen. Man muss nur anfangen."
        val aboutCard = a.card().apply { radius = a.dp(18).toFloat(); strokeColor = a.getColor(R.color.sw_outline); strokeWidth = a.dp(1) }
        val aboutBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(18), a.dp(17), a.dp(18), a.dp(17)) }
        aboutBox.addView(TextView(a).apply {
            text = "Über Saitenwerk"
            textSize = 17f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(a.getColor(R.color.sw_copper))
        })
        aboutBox.addView(TextView(a).apply {
            text = aboutText
            textSize = 14f
            setLineSpacing(a.dp(2).toFloat(), 1f)
            setTextColor(a.getColor(R.color.sw_muted))
            setPadding(0, a.dp(7), 0, 0)
        })
        aboutCard.addView(aboutBox)
        page.addView(aboutCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = a.dp(13) })

        val buildNumber = version.substringAfterLast(".")
        val appInfoCard = a.card().apply { radius = a.dp(18).toFloat(); strokeColor = a.getColor(R.color.sw_outline); strokeWidth = a.dp(1) }
        val appInfoBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(18), a.dp(17), a.dp(18), a.dp(17)) }
        appInfoBox.addView(TextView(a).apply {
            text = "App-Informationen"
            textSize = 17f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(a.getColor(R.color.sw_copper))
        })
        fun infoRow(label: String, value: String) {
            val line = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, a.dp(8), 0, a.dp(4)) }
            line.addView(TextView(a).apply {
                text = label
                textSize = 13f
                setTextColor(a.getColor(R.color.sw_muted))
            }, LinearLayout.LayoutParams(0, -2, 1f))
            line.addView(TextView(a).apply {
                text = value
                textSize = 13f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(a.getColor(R.color.sw_text))
                gravity = Gravity.END
            })
            appInfoBox.addView(line)
        }
        infoRow("Version", version)
        infoRow("Build-Nummer", buildNumber)
        infoRow("Version-Code", code.toString())
        infoRow("Release-Kanal", "Beta")
        infoRow("Plattform", "Android")
        infoRow("Paket-ID", a.packageName)
        infoRow("Mindestversion", "Android 8.0 (API 26)")
        appInfoBox.addView(TextView(a).apply {
            text = "Changelog"
            textSize = 16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(a.getColor(R.color.sw_copper))
            setPadding(0, a.dp(16), 0, a.dp(4))
        })
        val changes = listOf(
            "19.11.2026 · Build $buildNumber" to "Akkordwechsel-Training: Akkordauswahl-Dialog überarbeitet, damit Übernehmen auch bei langen Listen sichtbar bleibt. Schlagmuster-Trainer: Mehrfachauswahl von Gitarrenakkorden und Taktarten 3/4, 4/4 und 6/8; Akkordwechsel pro Takt. Bedienoberfläche vereinfacht: Muster-vorhören-Button, Takte-Button sowie Abschlag- und Aufschlag-Buttons entfernt. Schlag-Eingabe durch vertikale Wischgesten direkt auf den Schlagpfeilen ersetzt und mit Tonwiedergabe sowie Timing-Auswertung verbunden. Verwaiste Vorschau- und Taktanzahl-Zustände entfernt, erster Taktschlag korrigiert und Akkordreihenfolge dauerhaft geordnet gespeichert. Startbutton heißt jetzt Training starten. Redundante Pattern-Textzeile entfernt und Schlagpfeile vergrößert.",
            "18.11.2026 · Build 399" to "Vollständiger Lernfortschritt-Reset unter Einstellungen → Lernfortschritt. Übungszeiten, Tages- und Wochenwerte, XP, Level, Serien, Quizstatistiken, Lernpfad-Fortschritt und Trainings-Bestwerte werden gemeinsam zurückgesetzt. Persönliche App-Einstellungen und Trainingskonfigurationen bleiben erhalten.",
            "18.11.2026 · Build 394" to "Interaktiver Griffbrett-Notentrainer mit sechs Saiten und zwölf Bünden, zufälligen Notenaufgaben, Gitarrenton-Wiedergabe, direkter Richtig/Falsch-Rückmeldung und 10-Runden-Training. Bestserie und persönliche Bestleistung werden gespeichert.",
            "18.11.2026 · Build 392" to "Intelligenter Schlagmuster-Trainer mit acht Rhythmen in vier Schwierigkeitsstufen. Muster können vorgehört und anschließend selbst gespielt werden. Timing-Fenster, Rückmeldung und persönliche Bestwerte unterstützen das Training.",
            "18.11.2026 · Build 390" to "Persönliches Heute-üben-Dashboard im Lernstudio mit Schnellstart, Wochenübersicht und direktem Einstieg in die Trainingseinheiten.",
            "18.11.2026 · Build 387" to "Ausgangsbasis für die anschließenden Lernstudio-, Trainings- und Fortschrittsverbesserungen."
        )
        changes.forEach { (date, description) ->
            val entry = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(0, a.dp(8), 0, a.dp(8)) }
            entry.addView(TextView(a).apply {
                text = date
                textSize = 13f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(a.getColor(R.color.sw_text))
            })
            entry.addView(TextView(a).apply {
                text = description
                textSize = 13f
                setLineSpacing(a.dp(1).toFloat(), 1f)
                setTextColor(a.getColor(R.color.sw_muted))
                setPadding(0, a.dp(3), 0, 0)
            })
            appInfoBox.addView(entry)
        }
        appInfoCard.addView(appInfoBox)
        page.addView(appInfoCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = a.dp(13) })

        return ScrollView(a).apply { clipToPadding=false; addView(page) }
    }
}

class TunerFragment : Fragment() {
    @Volatile private var active = false
    private var recorder: AudioRecord? = null
    private var worker: Thread? = null
    private var noteView: TextView? = null
    private var hzView: TextView? = null
    private var centsView: TextView? = null
    private var targetView: TextView? = null
    private var statusView: TextView? = null
    private var gauge: TunerGaugeView? = null
    private var startButton: Button? = null
    private var instrumentSpinner: Spinner? = null
    private var alternativeSpinner: TextView? = null
    private var selectedAlternative = AlternativeTuning("Standard E", listOf("E2", "A2", "D3", "G3", "B3", "E4"))
    private var availableTunings = listOf(selectedAlternative)
    private var selectedMode = TuningMode.GUITAR
    private var referenceA4 = 440.0
    private var stringPanel: LinearLayout? = null
    private var selectedReferenceName: String? = null

    private enum class TuningMode(val label: String) {
        GUITAR("Gitarre · Standard · E–A–D–G–B–E"),
        CHROMATIC("Chromatisch · alle Töne"),
        BASS("Bass · Standard · E–A–D–G"),
        UKULELE("Ukulele · C-Stimmung · G–C–E–A"),
        VIOLIN("Violine · Standard · G–D–A–E"),
        VIOLA("Bratsche · Standard · C–G–D–A"),
        CELLO("Cello · Standard · C–G–D–A")
    }

    private data class Target(val name: String, val hz: Double)

    private data class AlternativeTuning(val label: String, val notes: List<String>)
    private fun tuningsFor(mode: TuningMode): List<AlternativeTuning> = when (mode) {
        TuningMode.GUITAR -> listOf(
            AlternativeTuning("Standard E", listOf("E2","A2","D3","G3","B3","E4")),
            AlternativeTuning("Drop D", listOf("D2","A2","D3","G3","B3","E4")),
            AlternativeTuning("Drop C", listOf("C2","G2","C3","F3","A3","D4")),
            AlternativeTuning("Double Drop D", listOf("D2","A2","D3","G3","B3","D4")),
            AlternativeTuning("DADGAD", listOf("D2","A2","D3","G3","A3","D4")),
            AlternativeTuning("Nashville", listOf("E3","A3","D4","G4","B3","E4")),
            AlternativeTuning("Open E", listOf("E2","B2","E3","G#3","B3","E4")),
            AlternativeTuning("Open G", listOf("D2","G2","D3","G3","B3","D4")),
            AlternativeTuning("Nick Drake · CGCFCE", listOf("C2","G2","C3","F3","C4","E4")),
            AlternativeTuning("Rain Song · DGCGCD", listOf("D2","G2","C3","G3","C4","D4"))
        )
        TuningMode.BASS -> listOf(
            AlternativeTuning("4-Saiter · E–A–D–G", listOf("E1","A1","D2","G2")),
            AlternativeTuning("4-Saiter · Drop D", listOf("D1","A1","D2","G2")),
            AlternativeTuning("4-Saiter · Drop C", listOf("C1","G1","C2","F2")),
            AlternativeTuning("5-Saiter · B–E–A–D–G", listOf("B0","E1","A1","D2","G2")),
            AlternativeTuning("6-Saiter · B–E–A–D–G–C", listOf("B0","E1","A1","D2","G2","C3"))
        )
        TuningMode.UKULELE -> listOf(
            AlternativeTuning("C-Stimmung · High G", listOf("G4","C4","E4","A4")),
            AlternativeTuning("C-Stimmung · Low G", listOf("G3","C4","E4","A4")),
            AlternativeTuning("D-Stimmung · A–D–F#–B", listOf("A4","D4","F#4","B4")),
            AlternativeTuning("Bariton · D–G–B–E", listOf("D3","G3","B3","E4"))
        )
        TuningMode.VIOLIN -> listOf(
            AlternativeTuning("Standard · G–D–A–E", listOf("G3","D4","A4","E5")),
            AlternativeTuning("Cross · A–E–A–E", listOf("A3","E4","A4","E5")),
            AlternativeTuning("GDGD", listOf("G3","D4","G4","D5"))
        )
        TuningMode.VIOLA -> listOf(
            AlternativeTuning("Standard · C–G–D–A", listOf("C3","G3","D4","A4")),
            AlternativeTuning("D-Stimmung · D–A–E–B", listOf("D3","A3","E4","B4"))
        )
        TuningMode.CELLO -> listOf(
            AlternativeTuning("Standard · C–G–D–A", listOf("C2","G2","D3","A3")),
            AlternativeTuning("D-Stimmung · D–A–D–A", listOf("D2","A2","D3","A3")),
            AlternativeTuning("Drop G · C–G–D–G", listOf("C2","G2","D3","G3"))
        )
        TuningMode.CHROMATIC -> emptyList()
    }














    override fun onResume() {
        super.onResume()
        requireActivity().window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }













































































































    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity
        val root = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        root.addView(a.title("Stimmgerät"))
        root.addView(a.body("Schnell und präzise stimmen · A4 = 440 Hz"))

        val selectorCard = a.card()
        val selector = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dp(16), a.dp(14), a.dp(16), a.dp(14))
        }
        selector.addView(TextView(a).apply {
            text = "INSTRUMENT"
            textSize = 13f
            setTextColor(a.getColor(R.color.sw_muted))
            setPadding(0, 0, 0, a.dp(6))
        })
        instrumentSpinner = Spinner(a).apply {
            val labels = TuningMode.values().map { it.label }
            adapter = object : ArrayAdapter<String>(a, R.layout.sw_spinner_item, labels) {
                private fun styled(position: Int, dropdown: Boolean): TextView = TextView(a).apply {
                    text = getItem(position).orEmpty()
                    setTextColor(a.getColor(R.color.sw_text))
                    textSize = if (dropdown) 14f else 15f
                    setTypeface(typeface, android.graphics.Typeface.BOLD)
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(a.dp(14), a.dp(if (dropdown) 12 else 10), a.dp(42), a.dp(if (dropdown) 12 else 10))
                    includeFontPadding = true
                    maxLines = 2
                    if (dropdown) {
                        background = a.premiumDropdownItemBackground()
                        minHeight = a.dp(52)
                    } else {
                        setBackground(android.graphics.drawable.GradientDrawable().apply {
                            setColor(a.getColor(R.color.sw_surface2))
                            cornerRadius = a.dp(14).toFloat()
                            setStroke(a.dp(1), a.getColor(R.color.sw_outline))
                        })
                        minHeight = a.dp(52)
                    }
                }
                override fun getView(position: Int, convertView: View?, parent: ViewGroup): View = styled(position, false)
                override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View = styled(position, true)
            }
            setSelection(TuningMode.values().indexOf(selectedMode))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) = Unit
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    selectedMode = TuningMode.values()[position]
                    configureAlternativeTunings()
                    targetView?.text = targetHint()
                    rebuildStringButtons()
                }
            }
        }
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        instrumentSpinner?.contentDescription = "Instrument auswählen"
        selector.addView(instrumentSpinner, LinearLayout.LayoutParams(-1, a.dp(52)))

        val alternativeTitle = TextView(a).apply {
            text = "STIMMUNG"
            textSize = 13f
            setTextColor(a.getColor(R.color.sw_muted))
            setPadding(0, a.dp(10), 0, a.dp(4))
        }
        selector.addView(alternativeTitle)
        alternativeSpinner = TextView(a).apply {
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(a.getColor(R.color.sw_text))
            gravity = Gravity.CENTER_VERTICAL
            setPadding(a.dp(14), a.dp(10), a.dp(42), a.dp(10))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(a.getColor(R.color.sw_surface2))
                cornerRadius = a.dp(12).toFloat()
                setStroke(a.dp(1), a.getColor(R.color.sw_copper))
            }
            minHeight = a.dp(52)
            isClickable = true
            isFocusable = true
            contentDescription = "Stimmung auswählen"
            setOnClickListener {
                val options = availableTunings
                if (options.isEmpty()) return@setOnClickListener
                androidx.appcompat.app.AlertDialog.Builder(a, R.style.ThemeOverlay_Saitenwerk_Dialog)
                    .setTitle("Alternative Stimmung wählen")
                    .setItems(options.map { it.label }.toTypedArray()) { _, which ->
                        val chosen = options.getOrNull(which) ?: return@setItems
                        selectedAlternative = chosen
                        text = chosen.label
                        targetView?.text = targetHint()
                        rebuildStringButtons()
                    }
                    .setNegativeButton("Abbrechen", null)
                    .show()
            }
        }
        selector.addView(alternativeSpinner, LinearLayout.LayoutParams(-1, a.dp(52)))
        configureAlternativeTunings()

        stringPanel = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, a.dp(6), 0, 0)
        }
        selector.addView(stringPanel, LinearLayout.LayoutParams(-1, a.dp(60)))
        selectorCard.addView(selector)

        val displayCard = a.card()
        val display = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(a.dp(14), a.dp(10), a.dp(14), a.dp(16))
        }

        targetView = TextView(a).apply {
            text = targetHint()
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(a.getColor(R.color.sw_muted))
        }
        display.addView(targetView, LinearLayout.LayoutParams(-1, a.dp(30)))

        noteView = TextView(a).apply {
            text = "—"
            textSize = 68f
            gravity = Gravity.CENTER
            setTextColor(a.getColor(R.color.sw_text))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            contentDescription = "Erkannter Ton"
        }
        display.addView(noteView, LinearLayout.LayoutParams(-1, a.dp(78)))

        gauge = TunerGaugeView(a).apply {
            contentDescription = "Stimmungsanzeige: links zu tief, Mitte gestimmt, rechts zu hoch"
        }
        display.addView(gauge, LinearLayout.LayoutParams(-1, a.dp(190)))

        centsView = TextView(a).apply {
            text = "0 Cent · möglichst nahe an 0 stimmen"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(a.getColor(R.color.sw_muted))
        }
        display.addView(centsView, LinearLayout.LayoutParams(-1, a.dp(32)))

        hzView = TextView(a).apply {
            text = "— Hz"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(a.getColor(R.color.sw_muted))
        }
        display.addView(hzView, LinearLayout.LayoutParams(-1, a.dp(32)))

        statusView = TextView(a).apply {
            text = "BEREIT · SAITE ANSCHLAGEN"
            textSize = 15f
            gravity = Gravity.CENTER
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(a.getColor(R.color.sw_copper))
        }
        display.addView(statusView, LinearLayout.LayoutParams(-1, a.dp(34)))

        startButton = a.button("Stimmen starten").also {
            it.setOnClickListener { if (active) stopTuner() else a.askMic { startTuner() } }
        }
        display.addView(startButton, LinearLayout.LayoutParams(-1, a.dp(52)).apply { topMargin = a.dp(8) })
        displayCard.addView(display)
        root.addView(displayCard, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(14)) })
        root.addView(selectorCard, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(10)) })

        rebuildStringButtons()
        return ScrollView(a).apply { addView(root) }
    }

    private fun configureAlternativeTunings() {
        val options = tuningsFor(selectedMode)
        availableTunings = options
        val chosen = options.firstOrNull()
        selectedAlternative = chosen ?: AlternativeTuning("Chromatisch", emptyList())
        val selector = alternativeSpinner ?: return
        selector.text = chosen?.label ?: "Keine alternative Stimmung"
        selector.isEnabled = options.isNotEmpty()
        selector.alpha = if (options.isNotEmpty()) 1f else 0.5f
    }

    private fun targetHint(): String =
        if (selectedMode == TuningMode.CHROMATIC) "Chromatisch: jeder Ton wird erkannt"
        else "Zielsaiten: " + targets().joinToString(" · ") { it.name }

    private fun noteFrequency(note: String): Double {
        val match = Regex("^([A-G])(#?)(-?\\d+)$").matchEntire(note)
            ?: return 440.0
        val base = mapOf("C" to 0, "D" to 2, "E" to 4, "F" to 5, "G" to 7, "A" to 9, "B" to 11)
        val midi = (match.groupValues[3].toInt() + 1) * 12 + base.getValue(match.groupValues[1]) + if (match.groupValues[2] == "#") 1 else 0
        return referenceA4 * 2.0.pow((midi - 69) / 12.0)
    }

    private fun targets(): List<Target> {
        if (selectedMode == TuningMode.CHROMATIC) return emptyList()
        return selectedAlternative.notes.mapIndexed { index, note ->
            Target((selectedAlternative.notes.size - index).toString() + note.replace(Regex("[0-9]"), ""), noteFrequency(note))
        }
    }

    private fun rebuildStringButtons() {
        val panel = stringPanel ?: return
        panel.removeAllViews()
        val list = targets()
        if (list.isEmpty()) {
            panel.addView(TextView(requireContext()).apply {
                text = "Chromatisch · keine Zielsaiten"; textSize = 12f
                gravity = Gravity.CENTER; setTextColor(requireContext().getColor(R.color.sw_muted))
            })
            return
        }
        list.forEach { target ->
            val selected = selectedReferenceName == target.name
            val button = TextView(requireContext()).apply {
                text = target.name + "\n" + "%.1f".format(target.hz) + " Hz"
                textSize = 11.5f; gravity = Gravity.CENTER; includeFontPadding = false
                setLineSpacing(0f, 1.05f); setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(if (selected) android.graphics.Color.WHITE else requireContext().getColor(R.color.sw_text))
                minHeight = (54 * resources.displayMetrics.density).toInt()
                isClickable = true; isFocusable = true
                contentDescription = "Referenzton Saite " + target.name + ", " + "%.1f".format(target.hz) + " Hertz abspielen"
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                    cornerRadius = 11f * resources.displayMetrics.density
                    setColor(if (selected) requireContext().getColor(R.color.sw_copper) else requireContext().getColor(R.color.sw_surface2))
                    setStroke(((if (selected) 2f else 1f) * resources.displayMetrics.density).toInt(),
                        if (selected) requireContext().getColor(R.color.sw_copper) else requireContext().getColor(R.color.sw_outline))
                }
                setPadding(2, 5, 2, 5)
                setOnClickListener {
                    selectedReferenceName = target.name
                    targetView?.text = "Referenzton · " + target.name + " · " + "%.1f".format(target.hz) + " Hz"
                    rebuildStringButtons()
                    playReferenceTone(target.hz)
                }
            }
            panel.addView(button, LinearLayout.LayoutParams(0, -1, 1f).apply {
                val m = (3f * resources.displayMetrics.density).roundToInt()
                setMargins(m, 0, m, 0)
            })
        }
    }

    /** Spielt eine echte, aufgenommene Gitarrensaite aus dem CC0-Samplepaket. */
    private fun playReferenceTone(frequency: Double = referenceA4) {
        if (!frequency.isFinite() || frequency !in 20.0..2000.0) return
        val stringNumber = selectedReferenceName?.take(1)?.toIntOrNull() ?: return
        GuitarAudioEngine.playTunedString(requireContext(), stringNumber, frequency, 0.88f)
    }

    private fun stopReferenceTone() {
        GuitarAudioEngine.stopAll()
    }

    private fun startTuner() {
        if (active) return
        val rate = 44100
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) { Toast.makeText(requireContext(), "Audioaufnahme wird von diesem Gerät nicht unterstützt.", Toast.LENGTH_LONG).show(); return }
        try {
            val size = maxOf(min, 8192)
            val audio = AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size)
            check(audio.state == AudioRecord.STATE_INITIALIZED) { "AudioRecord konnte nicht initialisiert werden" }
            recorder = audio; audio.startRecording(); active = true
            startButton?.text = "Stimmen stoppen"
            statusView?.text = "ICH HÖRE ZU …"
            worker = Thread {
                val samples = ShortArray(4096)
                var stablePitch = -1.0
                var stableFrames = 0
                var silentFrames = 0
                while (active) {
                    val n = audio.read(samples, 0, samples.size)
                    if (n > 2048) {
                        val hz = estimatePitch(samples, n, rate)
                        if (hz in 35.0..1100.0) {
                            silentFrames = 0
                            if (stablePitch > 0.0 && kotlin.math.abs(hz - stablePitch) / stablePitch < 0.035) {
                                stablePitch = stablePitch * 0.65 + hz * 0.35
                                stableFrames++
                            } else {
                                stablePitch = hz
                                stableFrames = 1
                            }
                            if (stableFrames >= 2) updatePitch(stablePitch)
                        } else {
                            stableFrames = 0
                            stablePitch = -1.0
                            silentFrames++
                            if (silentFrames == 5) resetPitchDisplay()
                        }
                    }
                }
            }.apply { name = "Saitenwerk-Tuner"; start() }
        } catch (e: Exception) {
            active = false; releaseRecorder(); startButton?.text = "Erneut versuchen"
            Toast.makeText(requireContext(), "Mikrofonfehler: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun updatePitch(hz: Double) {
        val result = if (selectedMode == TuningMode.CHROMATIC) {
            val midi = (69 + 12 * ln(hz / 440.0) / ln(2.0)).roundToInt()
            val target = 440.0 * 2.0.pow((midi - 69) / 12.0)
            val names = arrayOf("C", "C♯", "D", "D♯", "E", "F", "F♯", "G", "G♯", "A", "A♯", "B")
            val note = names[(midi % 12 + 12) % 12] + (midi / 12 - 1)
            note to target
        } else {
            val t = targets().minByOrNull { kotlin.math.abs(1200.0 * ln(hz / it.hz) / ln(2.0)) } ?: Target("—", 440.0)
            t.name to t.hz
        }
        val cents = (1200 * ln(hz / result.second) / ln(2.0)).roundToInt()
        val status = when {
            cents < -5 -> "ZU TIEF"
            cents > 5 -> "ZU HOCH"
            else -> "GESTIMMT"
        }
        activity?.runOnUiThread {
            if (!active) return@runOnUiThread
            noteView?.text = result.first
            hzView?.text = "%.1f Hz".format(hz)
            centsView?.text = when {
                cents > 0 -> "+$cents Cent"
                else -> "$cents Cent"
            }
            statusView?.text = status
            val tone = when {
                cents < -5 -> -1
                cents > 5 -> 1
                else -> 0
            }
            val statusColor = when (tone) {
                -1 -> android.graphics.Color.rgb(218, 174, 76)
                1 -> android.graphics.Color.rgb(210, 105, 98)
                else -> android.graphics.Color.rgb(92, 175, 142)
            }
            statusView?.setTextColor(statusColor)
            noteView?.setTextColor(if (tone == 0) statusColor else requireContext().getColor(R.color.sw_text))
            gauge?.setCents(cents)
        }
    }

    private fun estimatePitch(x: ShortArray, n: Int, sr: Int): Double {
        if (n < 2048) return -1.0
        var mean = 0.0
        for (i in 0 until n) mean += x[i].toDouble()
        mean /= n.toDouble()
        var energy = 0.0
        var peak = 0.0
        for (i in 0 until n) {
            val v = x[i].toDouble() - mean
            energy += v * v
            peak = maxOf(peak, kotlin.math.abs(v))
        }
        val rms = kotlin.math.sqrt(energy / n.toDouble())
        if (rms < 220.0 || peak < 550.0) return -1.0

        val minLag = maxOf(2, sr / 1100)
        val maxLag = minOf(sr / 32, n / 3)
        val difference = DoubleArray(maxLag + 1)
        val usable = n - maxLag
        for (lag in minLag..maxLag) {
            var sum = 0.0
            for (i in 0 until usable step 2) {
                val a = x[i].toDouble() - mean
                val b = x[i + lag].toDouble() - mean
                val d = a - b
                sum += d * d
            }
            difference[lag] = sum
        }

        // Cumulative Mean Normalized Difference (YIN).
        var running = 0.0
        for (lag in minLag..maxLag) {
            running += difference[lag]
            difference[lag] = if (running > 0.0) difference[lag] * (lag - minLag + 1) / running else 1.0
        }

        // Pick the first sufficiently good local minimum to reduce octave errors.
        var chosen = -1
        var lag = minLag
        while (lag < maxLag - 1) {
            if (difference[lag] < 0.16) {
                while (lag + 1 <= maxLag && difference[lag + 1] < difference[lag]) lag++
                chosen = lag
                break
            }
            lag++
        }
        if (chosen < 0) {
            var best = minLag
            for (candidate in minLag + 1..maxLag) {
                if (difference[candidate] < difference[best]) best = candidate
            }
            if (difference[best] > 0.28) return -1.0
            chosen = best
        }

        // Parabolic interpolation gives sub-sample period resolution.
        val refined = if (chosen > minLag && chosen < maxLag) {
            val left = difference[chosen - 1]
            val center = difference[chosen]
            val right = difference[chosen + 1]
            val denominator = left - 2.0 * center + right
            val offset = if (kotlin.math.abs(denominator) > 1e-12)
                (0.5 * (left - right) / denominator).coerceIn(-0.5, 0.5)
            else 0.0
            chosen.toDouble() + offset
        } else chosen.toDouble()

        val hz = sr.toDouble() / refined
        return if (hz in 30.0..1100.0) hz else -1.0
    }

    private fun resetPitchDisplay() {
        activity?.runOnUiThread {
            if (!active) return@runOnUiThread
            noteView?.text = "—"
            hzView?.text = "— Hz"
            centsView?.text = "— Cent"
            statusView?.text = "BEREIT · SAITE ANSCHLAGEN"
            gauge?.setCents(0)
        }
    }

    private fun releaseRecorder() {
        try { recorder?.stop() } catch (_: Exception) { }
        try { recorder?.release() } catch (_: Exception) { }
        recorder = null; worker = null
    }
    private fun stopTuner() {
        active = false
        releaseRecorder()
        stopReferenceTone()
        startButton?.text = "Stimmen starten"
        statusView?.text = "BEREIT · SAITE ANSCHLAGEN"
    }
    override fun onPause() { stopTuner(); requireActivity().window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        super.onPause() }
    override fun onDestroyView() { stopTuner(); noteView = null; hzView = null; centsView = null; targetView = null; statusView = null; gauge = null; startButton = null; instrumentSpinner = null; alternativeSpinner = null; super.onDestroyView() }
}
class TunerGaugeView(context: android.content.Context) : View(context) {
    private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    private val rect = android.graphics.RectF()
    private var cents = 0

    fun setCents(value: Int) {
        cents = value.coerceIn(-50, 50)
        invalidate()
    }

    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h * 0.78f
        val radius = minOf(w * 0.42f, h * 0.67f)
        rect.set(cx - radius, cy - radius, cx + radius, cy + radius)

        // Große, gut lesbare Halbkreis-Anzeige wie bei einem klassischen Hardware-Tuner.
        val segments = 31
        for (i in 0 until segments) {
            val start = 200f + i * (140f / segments)
            val center = i - (segments - 1) / 2f
            paint.style = android.graphics.Paint.Style.STROKE
            paint.strokeWidth = dp(8f)
            paint.strokeCap = android.graphics.Paint.Cap.BUTT
            paint.color = when {
                kotlin.math.abs(center) <= 2 -> android.graphics.Color.rgb(92, 155, 135)
                center < 0 -> android.graphics.Color.rgb(218, 174, 76)
                else -> android.graphics.Color.rgb(190, 88, 82)
            }
            canvas.drawArc(rect, start, 140f / segments - 2.2f, false, paint)
        }

        val angle = 270f + (cents / 50f) * 70f
        val rad = Math.toRadians(angle.toDouble())
        val x1 = cx + kotlin.math.cos(rad).toFloat() * radius * 0.18f
        val y1 = cy + kotlin.math.sin(rad).toFloat() * radius * 0.18f
        val x2 = cx + kotlin.math.cos(rad).toFloat() * radius * 0.91f
        val y2 = cy + kotlin.math.sin(rad).toFloat() * radius * 0.91f
        paint.color = android.graphics.Color.WHITE
        paint.strokeWidth = dp(4f)
        paint.strokeCap = android.graphics.Paint.Cap.ROUND
        canvas.drawLine(x1, y1, x2, y2, paint)

        paint.style = android.graphics.Paint.Style.FILL
        paint.color = android.graphics.Color.WHITE
        canvas.drawCircle(cx, cy, dp(7f), paint)

        paint.textAlign = android.graphics.Paint.Align.CENTER
        paint.typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
        paint.textSize = dp(13f)
        paint.color = android.graphics.Color.LTGRAY
        canvas.drawText("−50", cx - radius * 0.82f, cy + dp(24f), paint)
        canvas.drawText("0", cx, cy - radius * 0.91f, paint)
        canvas.drawText("+50", cx + radius * 0.82f, cy + dp(24f), paint)
    }

    private fun dp(v: Float) = v * resources.displayMetrics.density
}

data class ChordShape(val name: String, val quality: String, val frets: IntArray, val baseFret: Int = 1, val note: String = "", val fingers: IntArray = IntArray(6))
object ChordLibrary {
    val all = listOf(
        ChordShape("C", "Dur", intArrayOf(-1,3,2,0,1,0), note="Offener C-Dur-Griff", fingers=intArrayOf(0,3,2,0,1,0)),
        ChordShape("G", "Dur", intArrayOf(3,2,0,0,0,3), note="Offener G-Dur-Griff", fingers=intArrayOf(2,1,0,0,0,3)),
        ChordShape("D", "Dur", intArrayOf(-1,-1,0,2,3,2), note="Offener D-Dur-Griff", fingers=intArrayOf(0,0,0,1,3,2)),
        ChordShape("A", "Dur", intArrayOf(-1,0,2,2,2,0), note="Offener A-Dur-Griff", fingers=intArrayOf(0,0,1,2,3,0)),
        ChordShape("E", "Dur", intArrayOf(0,2,2,1,0,0), note="Offener E-Dur-Griff", fingers=intArrayOf(0,2,3,1,0,0)),
        ChordShape("F", "Dur", intArrayOf(1,3,3,2,1,1), note="Barré-Griff im 1. Bund", fingers=intArrayOf(1,3,4,2,1,1)),
        ChordShape("Am", "Moll", intArrayOf(-1,0,2,2,1,0), fingers=intArrayOf(0,0,2,3,1,0)),
        ChordShape("Em", "Moll", intArrayOf(0,2,2,0,0,0), fingers=intArrayOf(0,2,3,0,0,0)),
        ChordShape("Dm", "Moll", intArrayOf(-1,-1,0,2,3,1), fingers=intArrayOf(0,0,0,2,3,1)),
        ChordShape("Hm", "Moll", intArrayOf(-1,2,4,4,3,2), 2, note="Deutscher H-Moll-Barrégriff", fingers=intArrayOf(0,1,3,4,2,1)),
        ChordShape("C7", "Septakkord", intArrayOf(-1,3,2,3,1,0), fingers=intArrayOf(0,3,2,4,1,0)),
        ChordShape("D7", "Septakkord", intArrayOf(-1,-1,0,2,1,2), fingers=intArrayOf(0,0,0,2,1,3)),
        ChordShape("E7", "Septakkord", intArrayOf(0,2,0,1,0,0), fingers=intArrayOf(0,2,0,1,0,0)),
        ChordShape("G7", "Septakkord", intArrayOf(3,2,0,0,0,1), fingers=intArrayOf(3,2,0,0,0,1)),
        ChordShape("Am7", "Septakkord", intArrayOf(-1,0,2,0,1,0), fingers=intArrayOf(0,0,2,0,1,0)),
        ChordShape("Em7", "Septakkord", intArrayOf(0,2,0,0,0,0), fingers=intArrayOf(0,2,0,0,0,0)),
        ChordShape("Dsus2", "Sus-Akkord", intArrayOf(-1,-1,0,2,3,0), fingers=intArrayOf(0,0,0,1,3,0)),
        ChordShape("Dsus4", "Sus-Akkord", intArrayOf(-1,-1,0,2,3,3), fingers=intArrayOf(0,0,0,1,3,4)),
        ChordShape("Asus2", "Sus-Akkord", intArrayOf(-1,0,2,2,0,0), fingers=intArrayOf(0,0,2,3,0,0)),
        ChordShape("Asus4", "Sus-Akkord", intArrayOf(-1,0,2,2,3,0), fingers=intArrayOf(0,0,1,2,3,0)),
        ChordShape("H", "Dur", intArrayOf(-1,2,4,4,4,2), 2, note="H-Dur-Barrégriff", fingers=intArrayOf(0,1,3,3,3,1)),
        ChordShape("H7", "Septakkord", intArrayOf(-1,2,1,2,0,2), note="H-Dominantseptakkord", fingers=intArrayOf(0,2,1,3,0,4)),
        ChordShape("Hmaj7", "Septakkord", intArrayOf(-1,2,4,3,4,2), 2, note="H-Dur mit großer Septime", fingers=intArrayOf(0,1,3,2,4,1)),
        ChordShape("Hm7", "Septakkord", intArrayOf(-1,2,0,2,0,2), note="H-Mollseptakkord", fingers=intArrayOf(0,2,0,3,0,4)),
        ChordShape("Hsus2", "Sus-Akkord", intArrayOf(-1,2,4,4,2,2), 2, note="H-Sus2-Barrégriff", fingers=intArrayOf(0,1,3,4,1,1)),
        ChordShape("Hsus4", "Sus-Akkord", intArrayOf(-1,2,4,4,5,2), 2, note="H-Sus4-Barrégriff", fingers=intArrayOf(0,1,3,3,4,1)),
        ChordShape("Hadd9", "Add-Akkord", intArrayOf(-1,2,1,4,2,2), note="Hadd9-Barrégriff", fingers=intArrayOf(0,2,1,4,3,3)),
        ChordShape("H5", "Power-Akkord", intArrayOf(-1,2,4,4,-1,-1), 2, note="H-Powerchord", fingers=intArrayOf(0,1,3,4,0,0)),
        ChordShape("Bbm", "Moll", intArrayOf(-1,1,3,3,2,1), note="B-Moll-Barrégriff", fingers=intArrayOf(0,1,3,4,2,1)),
        ChordShape("Bbmaj7", "Septakkord", intArrayOf(-1,1,3,2,3,1), note="B-Dur mit großer Septime", fingers=intArrayOf(0,1,4,2,3,1)),
        ChordShape("Bbm7", "Septakkord", intArrayOf(-1,1,3,1,2,1), note="B-Mollseptakkord", fingers=intArrayOf(0,1,3,1,2,1)),
        ChordShape("Bbsus4", "Sus-Akkord", intArrayOf(-1,1,3,3,4,1), note="B-Sus4-Barrégriff", fingers=intArrayOf(0,1,3,3,4,1)),
        ChordShape("Bb5", "Power-Akkord", intArrayOf(-1,1,3,-1,-1,-1), note="B-Powerchord", fingers=intArrayOf(0,1,3,0,0,0)),
        ChordShape("Amaj7", "Septakkord", intArrayOf(-1,0,2,1,2,0), note="A-Dur mit großer Septime", fingers=intArrayOf(0,0,2,1,3,0)),
        ChordShape("Aadd9", "Add-Akkord", intArrayOf(-1,0,2,4,2,0), note="Offener Aadd9-Klang", fingers=intArrayOf(0,0,1,3,2,0)),
        ChordShape("Cm", "Moll", intArrayOf(-1,3,5,5,4,3), 3, note="C-Moll-Barrégriff", fingers=intArrayOf(0,1,3,4,2,1)),
        ChordShape("Cm7", "Septakkord", intArrayOf(-1,3,5,3,4,3), 3, note="C-Mollseptakkord", fingers=intArrayOf(0,1,3,1,2,1)),
        ChordShape("Csus4", "Sus-Akkord", intArrayOf(-1,3,3,0,1,1), note="C-Sus4", fingers=intArrayOf(0,3,4,0,1,1)),
        ChordShape("C5", "Power-Akkord", intArrayOf(-1,3,5,5,-1,-1), 3, note="C-Powerchord", fingers=intArrayOf(0,1,3,4,0,0)),
        ChordShape("Dadd9", "Add-Akkord", intArrayOf(-1,-1,0,2,3,0), note="Offener Dadd9-Klang", fingers=intArrayOf(0,0,0,1,3,0)),
        ChordShape("D5", "Power-Akkord", intArrayOf(-1,-1,0,2,3,-1), note="D-Powerchord", fingers=intArrayOf(0,0,0,1,3,0)),
        ChordShape("Emaj7", "Septakkord", intArrayOf(0,2,1,1,0,0), note="E-Dur mit großer Septime", fingers=intArrayOf(0,2,1,3,0,0)),
        ChordShape("Esus2", "Sus-Akkord", intArrayOf(0,2,4,4,0,0), note="E-Sus2", fingers=intArrayOf(0,1,3,4,0,0)),
        ChordShape("Esus4", "Sus-Akkord", intArrayOf(0,2,2,2,0,0), note="E-Sus4", fingers=intArrayOf(0,1,2,3,0,0)),
        ChordShape("Fm", "Moll", intArrayOf(1,3,3,1,1,1), note="F-Moll-Barrégriff", fingers=intArrayOf(1,3,4,1,1,1)),
        ChordShape("F7", "Septakkord", intArrayOf(1,3,1,2,1,1), note="F-Dominantseptakkord", fingers=intArrayOf(1,3,1,2,1,1)),
        ChordShape("Fmaj7", "Septakkord", intArrayOf(-1,-1,3,2,1,0), note="F-Dur mit großer Septime", fingers=intArrayOf(0,0,3,2,1,0)),
        ChordShape("Fm7", "Septakkord", intArrayOf(1,3,1,1,1,1), note="F-Mollseptakkord", fingers=intArrayOf(1,3,1,1,1,1)),
        ChordShape("Fsus4", "Sus-Akkord", intArrayOf(1,3,3,3,1,1), note="F-Sus4-Barrégriff", fingers=intArrayOf(1,3,3,3,1,1)),
        ChordShape("F5", "Power-Akkord", intArrayOf(1,3,3,-1,-1,-1), note="F-Powerchord", fingers=intArrayOf(1,3,4,0,0,0)),
        ChordShape("Gm", "Moll", intArrayOf(3,5,5,3,3,3), 3, note="G-Moll-Barrégriff", fingers=intArrayOf(1,3,4,1,1,1)),
        ChordShape("Gmaj7", "Septakkord", intArrayOf(3,2,0,0,0,2), note="Offener G-Durseptakkord", fingers=intArrayOf(2,1,0,0,0,3)),
        ChordShape("Gm7", "Septakkord", intArrayOf(3,5,3,3,3,3), 3, note="G-Mollseptakkord", fingers=intArrayOf(1,3,1,1,1,1)),
        ChordShape("Gsus2", "Sus-Akkord", intArrayOf(3,0,0,0,3,3), note="Offener G-Sus2-Klang", fingers=intArrayOf(2,0,0,0,3,4)),
        ChordShape("G5", "Power-Akkord", intArrayOf(3,5,5,-1,-1,-1), 3, note="G-Powerchord", fingers=intArrayOf(1,3,4,0,0,0)),
        ChordShape("B", "Dur", intArrayOf(-1,1,3,3,3,1), note="Deutscher B-Dur-Griff (international Bb)", fingers=intArrayOf(0,1,3,3,3,1)),
        ChordShape("Bb", "Dur", intArrayOf(-1,1,3,3,3,1), note="Barré-Durgriff", fingers=intArrayOf(0,1,3,3,3,1)),
        ChordShape("F#m", "Moll", intArrayOf(2,4,4,2,2,2), 2, note="Barré-Mollgriff", fingers=intArrayOf(1,3,4,1,1,1)),
        ChordShape("C#m", "Moll", intArrayOf(-1,4,6,6,5,4), 4, note="Barré-Mollgriff", fingers=intArrayOf(0,1,3,4,2,1)),
        ChordShape("B7", "Septakkord", intArrayOf(-1,1,3,1,3,1), note="Deutscher B7 (international Bb7)", fingers=intArrayOf(0,1,3,1,4,1)),
        ChordShape("A7", "Septakkord", intArrayOf(-1,0,2,0,2,0), note="Offener Septakkord", fingers=intArrayOf(0,0,1,0,2,0)),
        ChordShape("Dmaj7", "Septakkord", intArrayOf(-1,-1,0,2,2,2), note="Dur-Septakkord", fingers=intArrayOf(0,0,0,1,2,3)),
        ChordShape("Cmaj7", "Septakkord", intArrayOf(-1,3,2,0,0,0), note="Offener Dur-Septakkord", fingers=intArrayOf(0,3,2,0,0,0)),
        ChordShape("Dm7", "Septakkord", intArrayOf(-1,-1,0,2,1,1), note="Moll-Septakkord", fingers=intArrayOf(0,0,0,2,1,1)),
        ChordShape("Cadd9", "Add-Akkord", intArrayOf(-1,3,2,0,3,0), note="Offener Add9-Klang", fingers=intArrayOf(0,2,1,0,3,0)),
        ChordShape("Gsus4", "Sus-Akkord", intArrayOf(3,3,0,0,1,3), note="Sus4-Klang", fingers=intArrayOf(2,3,0,0,1,4)),
        ChordShape("E5", "Power-Akkord", intArrayOf(0,2,2,-1,-1,-1), note="Powerchord", fingers=intArrayOf(0,1,3,0,0,0)),
        ChordShape("A5", "Power-Akkord", intArrayOf(-1,0,2,2,-1,-1), note="Powerchord", fingers=intArrayOf(0,0,1,3,0,0))
    )
}





























/** Gemeinsame Sample-Engine für authentische Gitarrenklänge in der gesamten App. */
object GuitarAudioEngine {
    private val handler = Handler(Looper.getMainLooper())
    private var pool: SoundPool? = null
    private val sampleIds = IntArray(6)
    private val loadedIds = mutableSetOf<Int>()
    private val activeStreams = mutableSetOf<Int>()
    private val scheduled = mutableSetOf<Runnable>()
    private val pendingActions = mutableListOf<() -> Unit>()
    private var progressionTask: Runnable? = null
    private val openFrequencies = doubleArrayOf(82.4069, 110.0, 146.832, 196.0, 246.942, 329.628)

    @Synchronized
    private fun initialize(context: android.content.Context) {
        if (pool != null) return
        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        val created = SoundPool.Builder().setMaxStreams(16).setAudioAttributes(attributes).build()
        pool = created
        created.setOnLoadCompleteListener { _, sampleId, status ->
            if (status == 0) loadedIds.add(sampleId)
            if (loadedIds.size == 6) {
                val ready = pendingActions.toList()
                pendingActions.clear()
                ready.forEach { it.invoke() }
            }
        }
        val resources = intArrayOf(
            R.raw.guitar_string_6e, R.raw.guitar_string_5a, R.raw.guitar_string_4d,
            R.raw.guitar_string_3g, R.raw.guitar_string_2b, R.raw.guitar_string_1e
        )
        resources.forEachIndexed { index, resourceId ->
            sampleIds[index] = created.load(context.applicationContext, resourceId, 1)
        }
    }

    private fun whenReady(context: android.content.Context, action: () -> Unit) {
        initialize(context)
        if (loadedIds.size == 6) action() else pendingActions.add(action)
    }

    private fun playStringNow(index: Int, fret: Int, volume: Float, fadeMs: Long = 0L): Int {
        val player = pool ?: return 0
        if (index !in 0..5) return 0
        val rate = (2.0.pow(fret.coerceIn(0, 24) / 12.0)).coerceIn(0.5, 2.0).toFloat()
        val safeVolume = volume.coerceIn(0f, 1f)
        val stream = player.play(sampleIds[index], safeVolume, safeVolume, 1, 0, rate)
        if (stream != 0) {
            activeStreams.add(stream)
            if (activeStreams.size > 64) activeStreams.clear()
            if (fadeMs > 0L) {
                val steps = 5
                for (step in 1..steps) {
                    lateinit var task: Runnable
                    task = Runnable {
                        val level = safeVolume * (1f - step.toFloat() / steps)
                        try {
                            player.setVolume(stream, level, level)
                            if (step == steps) {
                                player.stop(stream)
                                activeStreams.remove(stream)
                            }
                        } catch (_: Exception) { }
                        scheduled.remove(task)
                    }
                    scheduled.add(task)
                    handler.postDelayed(task, fadeMs * step / steps)
                }
            }
        }
        return stream
    }

    fun playTunedString(context: android.content.Context, stringNumber: Int, frequency: Double, volume: Float = 0.86f) {
        if (stringNumber !in 1..6 || !frequency.isFinite() || frequency !in 20.0..2000.0) return
        val index = 6 - stringNumber
        val rate = (frequency / openFrequencies[index]).coerceIn(0.5, 2.0).toFloat()
        whenReady(context) {
            stopAll()
            val player = pool ?: return@whenReady
            val stream = player.play(sampleIds[index], volume.coerceIn(0f, 1f), volume.coerceIn(0f, 1f), 2, 0, rate)
            if (stream != 0) activeStreams.add(stream)
        }
    }

    fun playString(context: android.content.Context, index: Int, fret: Int = 0, volume: Float = 0.6f, fadeMs: Long = 0L) {
        whenReady(context) { playStringNow(index, fret, volume, fadeMs) }
    }

    /** Kurzer, echter Saitenanschlag als musikalischer Metronom-Puls. */
    fun playTick(context: android.content.Context, accented: Boolean) {
        playString(context, if (accented) 0 else 5, 0, if (accented) 0.62f else 0.38f, 145L)
    }

    /** Zupft die Saiten eines Akkords mit leicht versetztem Anschlag. */
    fun playChord(
        context: android.content.Context,
        shape: ChordShape,
        downstroke: Boolean = true,
        volume: Float = 0.72f,
        replace: Boolean = false
    ) {
        if (replace) stopAll()
        whenReady(context) {
            val order = if (downstroke) (0..5).toList() else (5 downTo 0).toList()
            order.forEachIndexed { position, stringIndex ->
                val fret = shape.frets.getOrNull(stringIndex) ?: -1
                if (fret >= 0) {
                    lateinit var task: Runnable
                    task = Runnable {
                        playStringNow(stringIndex, fret, volume * if (stringIndex == 0 || stringIndex == 5) 0.88f else 1f)
                        scheduled.remove(task)
                    }
                    scheduled.add(task)
                    handler.postDelayed(task, position * 15L)
                }
            }
        }
    }

    /** Spielt eine Song-Akkordfolge mit vier gleichmäßigen Schlägen pro Akkord. */
    fun playProgression(context: android.content.Context, chordNames: List<String>, bpm: Int = 80, onFinished: (() -> Unit)? = null) {
        val shapes = chordNames.mapNotNull { name -> ChordLibrary.all.firstOrNull { it.name == name.trim() } }
        if (shapes.isEmpty()) return
        stopAll()
        whenReady(context) {
            var index = 0
            val interval = (240000L / bpm.coerceIn(40, 180)).coerceAtLeast(500L)
            val task = object : Runnable {
                override fun run() {
                    if (index >= shapes.size) {
                        progressionTask = null
                        onFinished?.invoke()
                        return
                    }
                    playChord(context, shapes[index], downstroke = true, volume = 0.78f)
                    index++
                    handler.postDelayed(this, interval)
                }
            }
            progressionTask = task
            handler.post(task)
        }
    }

    fun stopAll() {
        progressionTask?.let { handler.removeCallbacks(it) }
        progressionTask = null
        scheduled.toList().forEach { handler.removeCallbacks(it) }
        scheduled.clear()
        pendingActions.clear()
        val player = pool
        activeStreams.toList().forEach { stream ->
            try { player?.stop(stream) } catch (_: Exception) { }
        }
        activeStreams.clear()
    }
}

open class ChordDiagramView(context: android.content.Context, initialShape: ChordShape? = null) : View(context) {
    private var shape: ChordShape? = initialShape
    private val gridPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(142, 151, 163)
        strokeWidth = dp(1.35f)
        style = android.graphics.Paint.Style.STROKE
    }
    private val nutPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(224, 226, 229)
        strokeWidth = dp(4f)
        strokeCap = android.graphics.Paint.Cap.ROUND
    }
    private val dotPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(217, 154, 112)
        style = android.graphics.Paint.Style.FILL
    }
    private val fingerPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.WHITE
        textAlign = android.graphics.Paint.Align.CENTER
        textSize = dp(10f)
        typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
    }
    private val labelPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.LTGRAY
        textAlign = android.graphics.Paint.Align.CENTER
        textSize = dp(11f)
        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
    }
    private val titlePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(217, 154, 112)
        textAlign = android.graphics.Paint.Align.LEFT
        textSize = dp(11f)
        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
    }

    fun setChord(value: ChordShape?) {
        shape = value
        contentDescription = value?.let { "Akkord ${it.name}, sechs Saiten, Griffbild mit Fingerzahlen und Barré" } ?: "Gitarrengriffbild"
        invalidate()
    }

    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val chord = shape ?: return
        val left = dp(51f)
        val right = width - dp(13f)
        val top = dp(39f)
        val bottom = height - dp(31f)
        if (right <= left || bottom <= top) return
        val fretWidth = (right - left) / 4f
        val stringGap = (bottom - top) / 5f
        val radius = dp(8.5f)
        val strings = arrayOf("E", "A", "D", "G", "H", "e")

        canvas.drawText(if (chord.baseFret <= 1) "Sattel" else "Bund ${chord.baseFret}", left, dp(15f), titlePaint)
        // Sechs waagerechte Saiten, von der tiefen E- bis zur hohen e-Saite.
        for (i in 0..5) {
            val y = bottom - i * stringGap
            gridPaint.strokeWidth = dp(if (i == 0 || i == 5) 1.8f else 1.25f)
            canvas.drawLine(left, y, right, y, gridPaint)
            canvas.drawText(strings[i], dp(10f), y + dp(4f), labelPaint)
        }
        // Senkrechte Bundlinien; am ersten Bund ersetzt der kräftige Sattel die Linie.
        for (i in 0..4) {
            val x = left + i * fretWidth
            gridPaint.strokeWidth = dp(1.25f)
            canvas.drawLine(x, top, x, bottom, gridPaint)
        }
        if (chord.baseFret <= 1) canvas.drawLine(left, top, left, bottom, nutPaint)
        else {
            for (i in 0..3) {
                val x = left + (i + .5f) * fretWidth
                labelPaint.textSize = dp(9f)
                canvas.drawText((chord.baseFret + i).toString(), x, dp(28f), labelPaint)
            }
            labelPaint.textSize = dp(11f)
        }

        // Gleicher Finger auf gleichem Bund über mehrere Saiten = Barré.
        val fingerGroups = (0..5).mapNotNull { string ->
            val fret = chord.frets.getOrElse(string) { -1 }
            val finger = chord.fingers.getOrElse(string) { 0 }
            if (fret > 0 && finger in 1..4) Triple(string, fret, finger) else null
        }.groupBy { Pair(it.second, it.third) }
        fingerGroups.values.filter { it.size > 1 }.forEach { group ->
            val fret = group.first().second
            val relative = fret - chord.baseFret
            if (relative in 0..3) {
                val x = left + (relative + .5f) * fretWidth
                val firstY = bottom - group.maxOf { it.first } * stringGap
                val lastY = bottom - group.minOf { it.first } * stringGap
                val barrePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                    color = dotPaint.color
                    strokeWidth = dp(16f)
                    strokeCap = android.graphics.Paint.Cap.ROUND
                }
                canvas.drawLine(x, firstY, x, lastY, barrePaint)
            }
        }

        for (i in 0..5) {
            val y = bottom - i * stringGap
            val fret = chord.frets.getOrElse(i) { -1 }
            val finger = chord.fingers.getOrElse(i) { 0 }
            when {
                fret < 0 -> canvas.drawText("×", dp(32f), y + dp(4f), labelPaint)
                fret == 0 -> canvas.drawText("○", dp(32f), y + dp(4f), labelPaint)
                else -> {
                    val relative = fret - chord.baseFret
                    if (relative in 0..3) {
                        val x = left + (relative + .5f) * fretWidth
                        canvas.drawCircle(x, y, radius, dotPaint)
                        if (finger in 1..4) {
                            val baseline = y - (fingerPaint.ascent() + fingerPaint.descent()) / 2f
                            canvas.drawText(finger.toString(), x, baseline, fingerPaint)
                        }
                    }
                }
            }
        }
        labelPaint.textSize = dp(9f)
        canvas.drawText("1 Zeige  ·  2 Mitte  ·  3 Ring  ·  4 Klein", width / 2f, height - dp(7f), labelPaint)
        labelPaint.textSize = dp(11f)
    }

    private fun dp(value: Float) = value * resources.displayMetrics.density
}
/** Spielt den ausgewählten Griff als kurze, gezupfte Gitarrenprobe. */
object ChordPreviewPlayer {
    fun play(shape: ChordShape, context: android.content.Context) {
        GuitarAudioEngine.playChord(context, shape, downstroke = true, volume = 0.88f, replace = true)
    }
    fun stop() = GuitarAudioEngine.stopAll()
}

class ChordsFragment : Fragment() {
    private var training: ChordTrainingPanel? = null

    override fun onDestroyView() {
        training?.stop()
        training = null
        super.onDestroyView()
    }

    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity
        val root = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        root.addView(a.title("Akkorde"))
        root.addView(a.body("Griffbilder · Akkordwissen · Wechseltraining"))
        val scroll = ScrollView(a).apply { clipToPadding = false }
        val content = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dp(12), a.dp(8), a.dp(12), a.dp(24))
        }
        val chooserCard = a.card()
        val chooser = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dp(14), a.dp(14), a.dp(14), a.dp(14))
        }
        chooser.addView(TextView(a).apply {
            text = "Akkord auswählen"
            textSize = 18f
            setTypeface(typeface, 1)
            setTextColor(a.getColor(R.color.sw_text))
        })
        chooser.addView(a.body("Wähle einen Buchstaben und anschließend den gewünschten Akkord."))
        var showChordSelection: ((ChordShape) -> Unit)? = null
        val letterGrid = GridLayout(a).apply {
            columnCount = 4
            useDefaultMargins = false
            setPadding(0, a.dp(10), 0, 0)
        }
        listOf("A", "B", "C", "D", "E", "F", "G", "H").forEach { letter ->
            val chords = ChordLibrary.all
                .filter { it.name.startsWith(letter, ignoreCase = true) }
                .sortedBy { it.name }
            val button = a.button("$letter  ▾").apply {
                textSize = 14f
                isEnabled = chords.isNotEmpty()
                alpha = if (chords.isNotEmpty()) 1f else .4f
                setTextColor(a.getColor(R.color.sw_copper))
                typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                background = android.graphics.drawable.GradientDrawable().apply {
                    cornerRadius = a.dp(13).toFloat()
                    setColor(a.getColor(R.color.sw_surface2))
                    setStroke(a.dp(1), a.getColor(R.color.sw_copper))
                }
            }
            button.setOnClickListener { anchor ->
                val dropdown = LinearLayout(a).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(a.dp(5), a.dp(5), a.dp(5), a.dp(5))
                    background = android.graphics.drawable.GradientDrawable().apply {
                        cornerRadius = a.dp(16).toFloat()
                        setColor(a.getColor(R.color.sw_surface))
                        setStroke(a.dp(1), a.getColor(R.color.sw_copper))
                    }
                }
                val scrollMenu = ScrollView(a).apply {
                    isFillViewport = false
                    isVerticalScrollBarEnabled = chords.size > 6
                    addView(dropdown)
                }
                lateinit var dropdownPopup: android.widget.PopupWindow
                chords.forEachIndexed { index, chord ->
                    val item = TextView(a).apply {
                        text = chord.name
                        textSize = 14f
                        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                        setTextColor(a.getColor(R.color.sw_text))
                        gravity = Gravity.CENTER_VERTICAL
                        includeFontPadding = true
                        setPadding(a.dp(16), a.dp(8), a.dp(16), a.dp(8))
                        minHeight = a.dp(52)
                        isClickable = true
                        isFocusable = true
                        background = a.premiumDropdownItemBackground()
                    }
                    item.setOnClickListener {
                        dropdownPopup.dismiss()
                        showChordSelection?.invoke(chord)
                    }
                    dropdown.addView(item, LinearLayout.LayoutParams(-1, a.dp(52)).apply {
                        if (index > 0) topMargin = a.dp(3)
                    })
                }
                dropdownPopup = android.widget.PopupWindow(
                    scrollMenu,
                    maxOf(anchor.width, a.dp(132)),
                    minOf(chords.size * a.dp(55) + a.dp(10), a.dp(360)),
                    true
                ).apply {
                    setBackgroundDrawable(android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT))
                    isOutsideTouchable = true
                    elevation = a.dp(12).toFloat()
                    animationStyle = android.R.style.Animation_Dialog
                }
                dropdownPopup.showAsDropDown(anchor, 0, a.dp(4))
            }
            letterGrid.addView(button, GridLayout.LayoutParams().apply {
                width = 0
                height = a.dp(46)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(a.dp(3), a.dp(3), a.dp(3), a.dp(3))
            })
        }
        chooser.addView(letterGrid)
        chooserCard.addView(chooser)
        content.addView(chooserCard)

        val detailCard = a.card().apply { visibility = View.GONE }
        val detail = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dp(16), a.dp(14), a.dp(16), a.dp(16))
        }
        detailCard.addView(detail)

        showChordSelection = { ch ->
            detail.removeAllViews()
            detail.addView(TextView(a).apply {
                text = ch.name
                textSize = 29f
                setTextColor(a.getColor(R.color.sw_copper))
                setTypeface(typeface, 1)
            })
            detail.addView(TextView(a).apply {
                text = ch.quality + " · " + ch.note
                setTextColor(a.getColor(R.color.sw_muted))
            })
            detail.addView(ChordDiagramView(a, ch), LinearLayout.LayoutParams(-1, a.dp(270)))
            detail.addView(TextView(a).apply {
                text = "× = nicht anschlagen · ○ = leere Saite"
                setTextColor(a.getColor(R.color.sw_muted))
                textSize = 13f
            })
            val preview = a.button("▶ Akkord anhören")
            preview.setOnClickListener { ChordPreviewPlayer.play(ch, a) }
            detail.addView(preview, LinearLayout.LayoutParams(-1, a.dp(48)).apply {
                topMargin = a.dp(8)
            })
            val prefs = a.getSharedPreferences("saitenwerk", 0)
            val key = "fav_chords"
            val saved = prefs.getStringSet(key, emptySet())?.toMutableSet() ?: mutableSetOf()
            val favorite = a.button(if (ch.name in saved) "★ Favorit entfernen" else "☆ Als Favorit speichern")
            favorite.setOnClickListener {
                val now = prefs.getStringSet(key, emptySet())?.toMutableSet() ?: mutableSetOf()
                if (!now.add(ch.name)) now.remove(ch.name)
                prefs.edit().putStringSet(key, now).apply()
                favorite.text = if (ch.name in now) "★ Favorit entfernen" else "☆ Als Favorit speichern"
            }
            detail.addView(favorite, LinearLayout.LayoutParams(-1, a.dp(46)).apply {
                topMargin = a.dp(8)
            })
            detailCard.visibility = View.VISIBLE
        }

        content.addView(detailCard, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = a.dp(12)
        })
        training = ChordTrainingPanel(a)
        content.addView(training, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = a.dp(14)
        })
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        return root
    }
}

class GuitarFretboardView(context: android.content.Context) : View(context) {
    private var chord: ChordShape? = null
    private val line = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(145, 153, 164)
        strokeWidth = dp(1.25f)
    }
    private val nut = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(224, 224, 218)
        strokeWidth = dp(4f)
    }
    private val marker = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(217, 154, 112)
        style = android.graphics.Paint.Style.FILL
    }
    private val markerText = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.WHITE
        textSize = dp(11f)
        textAlign = android.graphics.Paint.Align.CENTER
        typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    private val labels = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.LTGRAY
        textSize = dp(10f)
        textAlign = android.graphics.Paint.Align.CENTER
    }

    fun setChord(value: ChordShape?) {
        chord = value
        contentDescription = value?.let { "Gitarrengriffbrett für Akkord ${it.name}" } ?: "Gitarrengriffbrett"
        invalidate()
    }

    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val shape = chord ?: return
        val left = dp(35f)
        val right = width - dp(12f)
        val top = dp(22f)
        val bottom = height - dp(18f)
        if (right <= left || bottom <= top) return
        val fretWidth = (right - left) / 5f
        val stringGap = (bottom - top) / 5f
        val stringNames = arrayOf("E", "A", "D", "G", "H", "e")

        // Griffbrett: tiefe E-Saite unten, hohe e-Saite oben.
        for (i in 0..5) {
            val y = bottom - i * stringGap
            line.strokeWidth = dp(if (i == 0 || i == 5) 1.8f else 1.2f)
            canvas.drawLine(left, y, right, y, line)
            canvas.drawText(stringNames[i], dp(15f), y + dp(3.5f), labels)
        }
        for (fret in 0..5) {
            val x = left + fret * fretWidth
            canvas.drawLine(x, top, x, bottom, if (fret == 0 && shape.baseFret == 1) nut else line)
        }

        if (shape.baseFret > 1) {
            canvas.drawText("${shape.baseFret}. Bund", left + dp(34f), dp(12f), labels)
        } else {
            canvas.drawText("Sattel", left + dp(18f), dp(12f), labels)
        }

        shape.frets.forEachIndexed { stringIndex, fret ->
            val y = bottom - stringIndex * stringGap
            when {
                fret < 0 -> canvas.drawText("×", left - dp(13f), y + dp(4f), markerText)
                fret == 0 -> canvas.drawText("○", left - dp(13f), y + dp(4f), markerText)
                else -> {
                    val relative = fret - shape.baseFret
                    if (relative in 0..4) {
                        val x = left + (relative + .5f) * fretWidth
                        canvas.drawCircle(x, y, dp(7f), marker)
                    }
                }
            }
        }
    }

    private fun dp(value: Float) = value * resources.displayMetrics.density
}

class ChordTrainingPanel(private val host: MainActivity) : LinearLayout(host) {
    private val handler = Handler(Looper.getMainLooper())
    private val prefs = host.getSharedPreferences("saitenwerk", 0)
    private val defaultSequence = listOf("C", "G", "Am", "F")
    private val availableChords = ChordLibrary.all.map { it.name.trim() }.filter { it.isNotEmpty() }.distinct().sorted().ifEmpty { defaultSequence }
    private var sequence = loadSequence()
    private var bpm = prefs.getInt("chord_training_bpm", 72).coerceIn(50, 160)
    private val meters = listOf("2/4", "3/4", "4/4", "6/8")
    private var meter = prefs.getString("chord_training_meter", "4/4")?.takeIf { it in meters } ?: "4/4"
    private val beatsPerBar: Int get() = meter.substringBefore("/").toInt()
    private var beat = 0
    private var changes = 0
    private var bars = 0
    private var streak = 0
    private var bestStreak = prefs.getInt("chord_training_best_streak", 0)
    private var sessionSeconds = 0
    private var running = false

    private val current = TextView(host)
    private val next = TextView(host)
    private val fretboard = ChordDiagramView(host)
    private val status = TextView(host)
    private val sequenceLabel = TextView(host)
    private val chooseChords = host.button("Akkorde auswählen")
    private val meterButton = host.button("Taktart · 4/4")
    private val randomize = host.button("↻ Reihenfolge mischen")
    private val start = host.button("Training starten")
    private val tempo = SeekBar(host)
    private val tempoLabel = TextView(host)
    private val stats = TextView(host)
    private val progress = ProgressBar(host, null, android.R.attr.progressBarStyleHorizontal)
    private val sessionTimer = TextView(host)

    private fun loadSequence(): List<String> {
        val validNames = ChordLibrary.all.map { it.name }.toSet()
        val saved = prefs.getStringSet("chord_training_selected_chords", null)
        val valid = saved?.filter { it in validNames } ?: emptyList()
        return if (valid.size >= 2) valid.sorted() else defaultSequence
    }

    private fun refreshSequenceLabel() {
        sequenceLabel.text = "Trainingsakkorde · " + sequence.joinToString(" · ")
        current.text = sequence.firstOrNull() ?: "—"
        next.text = if (sequence.size > 1)
            "Als Nächstes · " + sequence[1]
        else ""
        fretboard.setChord(ChordLibrary.all.firstOrNull { it.name == current.text.toString() })
    }

    private fun openChordPicker() {
        if (running) {
            Toast.makeText(host, "Bitte stoppe das Training zuerst, um die Akkorde zu ändern.", Toast.LENGTH_SHORT).show()
            return
        }
        // Eigene scrollbare Checkbox-Liste: Auswahl wird explizit übernommen.
        // Begrenzte Listenhöhe hält die Dialogaktionen dauerhaft sichtbar.
        val pickerHeightDp = (host.resources.displayMetrics.heightPixels /
            host.resources.displayMetrics.density * 0.48f).toInt().coerceIn(220, 380)
        val scroll = android.widget.ScrollView(host).apply {
            isFillViewport = true
            layoutParams = android.view.ViewGroup.LayoutParams(-1, host.dp(pickerHeightDp))
            setPadding(host.dp(20), host.dp(4), host.dp(20), host.dp(4))
        }
        val list = LinearLayout(host).apply { orientation = VERTICAL }
        val checks = linkedMapOf<String, android.widget.CheckBox>()
        availableChords.forEach { chordName ->
            val check = android.widget.CheckBox(host).apply {
                text = ""
                contentDescription = chordName
                isChecked = chordName in sequence
                minWidth = host.dp(44)
                minHeight = host.dp(44)
                buttonTintList = android.content.res.ColorStateList.valueOf(host.getColor(R.color.sw_copper))
            }
            val label = TextView(host).apply {
                text = chordName
                textSize = 18f
                setTextColor(host.getColor(R.color.sw_copper))
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER_VERTICAL
                includeFontPadding = true
                setPadding(host.dp(10), 0, host.dp(8), 0)
                isClickable = false
            }
            val row = LinearLayout(host).apply {
                orientation = HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                minimumHeight = host.dp(54)
                setPadding(host.dp(4), host.dp(2), host.dp(4), host.dp(2))
                isClickable = true
                setOnClickListener { check.isChecked = !check.isChecked }
            }
            row.addView(check, LayoutParams(host.dp(48), host.dp(54)))
            row.addView(label, LayoutParams(0, -1, 1f))
            checks[chordName] = check
            list.addView(row, LayoutParams(-1, host.dp(54)))
        }
        scroll.addView(list)
        val dialog = androidx.appcompat.app.AlertDialog.Builder(host, R.style.ThemeOverlay_Saitenwerk_Dialog)
            .setTitle("Trainingsakkorde auswählen")
            .setMessage("Markiere mindestens zwei Akkorde und tippe anschließend auf Übernehmen.")
            .setView(scroll)
            .setPositiveButton("Übernehmen", null)
            .setNegativeButton("Abbrechen", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val selected = checks.filterValues { it.isChecked }.keys.toList()
                if (selected.size < 2) {
                    Toast.makeText(host, "Wähle mindestens zwei Akkorde aus.", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                sequence = selected
                prefs.edit().putStringSet("chord_training_selected_chords", selected.toSet()).apply()
                resetSession()
                refreshSequenceLabel()
                status.text = selected.size.toString() + " Akkorde gespeichert. Bereit zum Start."
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun openMeterPicker() {
        if (running) return
        val selectedIndex = meters.indexOf(meter).coerceAtLeast(0)
        androidx.appcompat.app.AlertDialog.Builder(host, R.style.ThemeOverlay_Saitenwerk_Dialog)
            .setTitle("Taktart auswählen")
            .setSingleChoiceItems(meters.toTypedArray(), selectedIndex) { dialog, which ->
                meter = meters[which]
                prefs.edit().putString("chord_training_meter", meter).apply()
                meterButton.text = "Taktart · " + meter
                resetSession()
                status.text = "Taktart " + meter + " gewählt · " + beatsPerBar + " Schläge pro Takt."
                dialog.dismiss()
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun shuffleSequence() {
        if (running) return
        sequence = sequence.shuffled()
        resetSession()
        refreshSequenceLabel()
        status.text = "Neue Reihenfolge bereit."
    }

    private fun resetSession() {
        stop()
        beat = 0
        changes = 0
        bars = 0
        streak = 0
        sessionSeconds = 0
        progress.progress = 0
        stats.text = "0 Wechsel · 0 Takte · Beste Serie " + bestStreak
        sessionTimer.text = "00:00"
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val beatInBar = beat % beatsPerBar
            val isBarStart = beatInBar == 0
            if (isBarStart) {
                val index = changes % sequence.size
                current.text = sequence[index]
                fretboard.setChord(ChordLibrary.all.firstOrNull { it.name == sequence[index] })
                next.text = "Als Nächstes · " + sequence[(index + 1) % sequence.size]
                if (changes > 0) streak++
                changes++
                bars++
                bestStreak = maxOf(bestStreak, streak)
                prefs.edit().putInt("chord_training_best_streak", bestStreak).apply()
                stats.text = changes.toString() + " Wechsel · " + bars + " Takte · Serie " +
                    streak + " · Bestwert " + bestStreak
                progress.progress = (changes % 16) * 100 / 16
            }

            val activeShape = ChordLibrary.all.firstOrNull { it.name == current.text.toString() }
            if (activeShape != null) {
                GuitarAudioEngine.playChord(
                    host, activeShape, downstroke = beatInBar % 2 == 0,
                    volume = if (isBarStart) 0.80f else 0.52f
                )
            }

            beat++
            handler.postDelayed(this, (60000L / bpm).coerceAtLeast(100L))
        }
    }

    private val timerTick = object : Runnable {
        override fun run() {
            if (!running) return
            sessionSeconds++
            sessionTimer.text = String.format("%02d:%02d", sessionSeconds / 60, sessionSeconds % 60)
            handler.postDelayed(this, 1000L)
        }
    }

    init {
        orientation = VERTICAL
        setPadding(host.dp(18), host.dp(18), host.dp(18), host.dp(18))
        background = android.graphics.drawable.GradientDrawable().apply {
            cornerRadius = host.dp(22).toFloat()
            setColor(host.getColor(R.color.sw_surface))
            setStroke(host.dp(1), host.getColor(R.color.sw_outline))
        }
        elevation = host.dp(2).toFloat()

        addView(TextView(host).apply {
            text = "Akkordwechsel-Training"
            textSize = 21f
            setTextColor(host.getColor(R.color.sw_copper))
            setTypeface(typeface, 1)
        })
        addView(TextView(host).apply {
            text = "Wechsle sauber im Takt. Geschwindigkeit kommt erst danach."
            textSize = 13f
            setTextColor(host.getColor(R.color.sw_muted))
            setPadding(0, host.dp(4), 0, host.dp(12))
        })

        sequenceLabel.apply {
            setTextColor(host.getColor(R.color.sw_text))
            textSize = 13f
        }
        addView(sequenceLabel, LayoutParams(-1, -2))

        // Die Auswahlflächen brauchen mehr Höhe als die frühere 44-dp-Zeile:
        // Das Premium-Button-Design zeichnet einen 52-dp-Rahmen samt Rundungen.
        val controls = LinearLayout(host).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            clipChildren = false
            clipToPadding = false
            setPadding(0, host.dp(3), 0, host.dp(3))
        }
        chooseChords.setOnClickListener { openChordPicker() }
        randomize.setOnClickListener { shuffleSequence() }
        chooseChords.clipToOutline = false
        randomize.clipToOutline = false
        chooseChords.clipToOutline = false
        randomize.clipToOutline = false
        chooseChords.clipToOutline = false
        randomize.clipToOutline = false
        chooseChords.clipToOutline = false
        randomize.clipToOutline = false
        chooseChords.clipToOutline = false
        randomize.clipToOutline = false
        chooseChords.clipToOutline = false
        randomize.clipToOutline = false
        chooseChords.clipToOutline = false
        randomize.clipToOutline = false
        chooseChords.clipToOutline = false
        randomize.clipToOutline = false
        chooseChords.clipToOutline = false
        randomize.clipToOutline = false
        chooseChords.clipToOutline = false
        randomize.clipToOutline = false
        chooseChords.clipToOutline = false
        randomize.clipToOutline = false
        chooseChords.clipToOutline = false
        randomize.clipToOutline = false
        chooseChords.clipToOutline = false
        randomize.clipToOutline = false
        controls.addView(chooseChords, LayoutParams(0, host.dp(56), 1f))
        controls.addView(randomize, LayoutParams(0, host.dp(56), 1f).apply {
            leftMargin = host.dp(8)
        })
        addView(controls, LayoutParams(-1, host.dp(62)).apply {
            bottomMargin = host.dp(10)
        })

        val stage = LinearLayout(host).apply {
            orientation = VERTICAL
            gravity = Gravity.CENTER
            setPadding(host.dp(12), host.dp(10), host.dp(12), host.dp(8))
            background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = host.dp(18).toFloat()
                setColor(host.getColor(R.color.sw_surface2))
            }
        }

        current.apply {
            textSize = 48f
            gravity = Gravity.CENTER
            setTextColor(host.getColor(R.color.sw_text))
            setTypeface(typeface, 1)
        }
        stage.addView(current, LayoutParams(-1, host.dp(66)))

        next.apply {
            textSize = 12f
            setTextColor(host.getColor(R.color.sw_muted))
            gravity = Gravity.CENTER
        }
        stage.addView(next, LayoutParams(-1, host.dp(28)))
        stage.addView(fretboard, LayoutParams(-1, host.dp(210)))
        addView(stage, LayoutParams(-1, -2).apply {
            bottomMargin = host.dp(8)
        })

        val infoRow = LinearLayout(host).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        status.apply {
            textSize = 12f
            setTextColor(host.getColor(R.color.sw_muted))
        }
        infoRow.addView(status, LayoutParams(0, -2, 1f))

        sessionTimer.apply {
            textSize = 12f
            setTextColor(host.getColor(R.color.sw_copper))
            gravity = Gravity.END
        }
        infoRow.addView(sessionTimer, LayoutParams(host.dp(52), -2))
        addView(infoRow, LayoutParams(-1, -2))

        tempoLabel.apply {
            textSize = 13f
            setTextColor(host.getColor(R.color.sw_text))
            setPadding(0, host.dp(8), 0, 0)
        }
        meterButton.text = "Takt · " + meter
        // Text im orangefarbenen Auswahlrahmen vertikal etwas nach oben setzen.
        meterButton.gravity = Gravity.CENTER
        meterButton.includeFontPadding = false
        meterButton.setPadding(
            meterButton.paddingLeft,
            host.dp(0),
            meterButton.paddingRight,
            host.dp(5)
        )
        meterButton.setOnClickListener { openMeterPicker() }
        tempoLabel.gravity = Gravity.CENTER
        tempoLabel.text = "BPM " + bpm
        tempoLabel.isSingleLine = true
        tempoLabel.includeFontPadding = false
        tempoLabel.textSize = 18f
        tempoLabel.setTextColor(android.graphics.Color.WHITE)
        tempoLabel.setPadding(host.dp(12), 0, host.dp(12), host.dp(8))
        tempoLabel.background = null
        // Sichtbare Sliderbahn mit Fortschrittslinie und beweglichem Reglerknopf.
        val bpmSliderTrack = object : View(host) {
            private val rail = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.rgb(83, 94, 111)
                strokeWidth = host.dp(4).toFloat()
                strokeCap = android.graphics.Paint.Cap.ROUND
            }
            private val progress = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.rgb(77, 166, 255)
                strokeWidth = host.dp(4).toFloat()
                strokeCap = android.graphics.Paint.Cap.ROUND
            }
            private val knob = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.rgb(77, 166, 255)
                style = android.graphics.Paint.Style.FILL
            }
            private val knobOutline = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.WHITE
                style = android.graphics.Paint.Style.STROKE
                strokeWidth = host.dp(2).toFloat()
            }
            override fun onDraw(canvas: android.graphics.Canvas) {
                super.onDraw(canvas)
                val left = host.dp(14).toFloat()
                val right = (width - host.dp(14)).toFloat()
                val y = (height - host.dp(9)).toFloat()
                val fraction = ((bpm - 50).toFloat() / 110f).coerceIn(0f, 1f)
                val x = left + (right - left) * fraction
                canvas.drawLine(left, y, right, y, rail)
                canvas.drawLine(left, y, x, y, progress)
                canvas.drawCircle(x, y, host.dp(7).toFloat(), knob)
                canvas.drawCircle(x, y, host.dp(7).toFloat(), knobOutline)
            }
        }
        tempoLabel.contentDescription = "BPM-Regler: " + bpm + ". Horizontal ziehen zum Ändern."
        // Relative Bewegung statt absoluter Fingerposition: feinere, kontrollierbare Schritte.
        var bpmDragStartX = 0f
        var bpmDragStartValue = bpm
        val bpmBubbleText = TextView(host).apply {
            text = "BPM " + bpm
            textSize = 16f
            setTextColor(android.graphics.Color.WHITE)
            setPadding(host.dp(12), host.dp(7), host.dp(12), host.dp(7))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(android.graphics.Color.rgb(35, 42, 54))
                cornerRadius = host.dp(12).toFloat()
                setStroke(host.dp(1), android.graphics.Color.rgb(105, 175, 255))
            }
        }
        val bpmBubble = android.widget.PopupWindow(
            bpmBubbleText, android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
            android.view.ViewGroup.LayoutParams.WRAP_CONTENT, false
        ).apply { isTouchable = false; isClippingEnabled = false }
        fun updateBpmFromDrag(event: android.view.MotionEvent) {
            val density = host.resources.displayMetrics.density
            val deltaDp = (event.rawX - bpmDragStartX) / density
            // 2 dp pro BPM verhindert große Sprünge und erlaubt trotzdem den ganzen Bereich.
            val next = (bpmDragStartValue + (deltaDp / 2f).toInt()).coerceIn(50, 160)
            if (next != bpm) {
                bpm = next
                tempoLabel.text = "BPM " + bpm
                tempoLabel.contentDescription = "BPM-Regler: " + bpm
                bpmBubbleText.text = "BPM " + bpm
                bpmSliderTrack.invalidate()
                prefs.edit().putInt("chord_training_bpm", bpm).apply()
            }
            val x = (event.rawX - host.dp(34)).toInt().coerceAtLeast(0)
            val y = (event.rawY - host.dp(62)).toInt().coerceAtLeast(0)
            if (bpmBubble.isShowing) bpmBubble.update(x, y, -1, -1)
        }
        tempoLabel.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    bpmDragStartX = event.rawX
                    bpmDragStartValue = bpm
                    bpmBubbleText.text = "BPM " + bpm
                    val x = (event.rawX - host.dp(34)).toInt().coerceAtLeast(0)
                    val y = (event.rawY - host.dp(62)).toInt().coerceAtLeast(0)
                    bpmBubble.showAtLocation(view, android.view.Gravity.TOP or android.view.Gravity.START, x, y)
                    true
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    updateBpmFromDrag(event)
                    true
                }
                android.view.MotionEvent.ACTION_UP -> {
                    updateBpmFromDrag(event)
                    if (bpmBubble.isShowing) bpmBubble.dismiss()
                    view.performClick()
                    true
                }
                android.view.MotionEvent.ACTION_CANCEL -> {
                    if (bpmBubble.isShowing) bpmBubble.dismiss()
                    true
                }
                else -> false
            }
        }
        tempoLabel.setOnClickListener { }

        val tempoColumn = android.widget.FrameLayout(host).apply {
            setPadding(host.dp(8), 0, 0, 0)
            clipChildren = false
            clipToPadding = false
        }
        tempoColumn.addView(bpmSliderTrack, android.widget.FrameLayout.LayoutParams(-1, host.dp(56)))
        tempoColumn.addView(tempoLabel, android.widget.FrameLayout.LayoutParams(-1, host.dp(56)))
        val meterTempoRow = LinearLayout(host).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            clipChildren = false
            clipToPadding = false
        }
        // Der BPM-Schriftzug bleibt der Regler; die Sprechblase hält den Wert über dem Finger sichtbar.
        meterTempoRow.addView(meterButton, LayoutParams(0, host.dp(52), 0.68f))
        meterTempoRow.addView(tempoColumn, LayoutParams(0, host.dp(56), 1.32f))
        addView(meterTempoRow, LayoutParams(-1, host.dp(60)).apply {
            bottomMargin = host.dp(4)
        })

        progress.max = 100
        progress.progress = 0
        addView(progress, LayoutParams(-1, host.dp(8)).apply {
            bottomMargin = host.dp(8)
        })

        start.setOnClickListener {
            if (running) stop() else begin()
        }
        addView(start, LayoutParams(-1, host.dp(48)))

        stats.apply {
            textSize = 12f
            setTextColor(host.getColor(R.color.sw_muted))
            setPadding(0, host.dp(8), 0, host.dp(6))
        }
        addView(stats)

        val ratingRow = LinearLayout(host).apply { orientation = HORIZONTAL }
        val mastered = host.button("✓ Sitzt")
        val practice = host.button("↻ Weiter üben")
        mastered.setOnClickListener { saveRating(true) }
        practice.setOnClickListener { saveRating(false) }
        ratingRow.addView(mastered, LayoutParams(0, host.dp(44), 1f))
        ratingRow.addView(practice, LayoutParams(0, host.dp(44), 1f).apply {
            leftMargin = host.dp(6)
        })
        addView(ratingRow)

        refreshSequenceLabel()
        tempoLabel.text = "Tempo · " + bpm + " BPM"
        stats.text = "0 Wechsel · 0 Takte · Beste Serie " + bestStreak
        status.text = "Bereit · " + beatsPerBar + " Schläge pro Takt"
        sessionTimer.text = "00:00"
    }

    private fun begin() {
        if (sequence.size < 2) {
            status.text = "Bitte mindestens zwei Akkorde wählen."
            return
        }

        running = true
        beat = 0
        changes = 0
        bars = 0
        streak = 0
        sessionSeconds = 0

        start.text = "Training stoppen"
        chooseChords.isEnabled = false
        randomize.isEnabled = false
        status.text = "Läuft · jeder Akkord bleibt einen Takt (" + meter + ")"
        progress.progress = 0

        handler.removeCallbacks(tick)
        handler.removeCallbacks(timerTick)
        handler.post(tick)
        handler.post(timerTick)
    }

    fun stop() {
        handler.removeCallbacks(tick)
        handler.removeCallbacks(timerTick)

        if (!running) return

        running = false
        start.text = "Training starten"
        chooseChords.isEnabled = true
        randomize.isEnabled = true
        status.text = "Pause · " + changes + " Wechsel in " + sessionSeconds + "s"

        GuitarAudioEngine.stopAll()
    }

    private fun saveRating(mastered: Boolean) {
        val sessions = prefs.getInt("chord_training_sessions", 0) + 1
        val wins = prefs.getInt("chord_training_mastered", 0) + if (mastered) 1 else 0
        prefs.edit()
            .putInt("chord_training_sessions", sessions)
            .putInt("chord_training_mastered", wins)
            .apply()

        status.text = if (mastered) {
            "Als gemeistert markiert · " + wins + " von " + sessions
        } else {
            "Für weitere Übung vorgemerkt · " + wins + " von " + sessions
        }
    }

    override fun onDetachedFromWindow() {
        stop()
        GuitarAudioEngine.stopAll()
        super.onDetachedFromWindow()
    }
}

data class Song(val title: String, val artist: String = "", val genre: String = "", val custom: Boolean = false)
object SongRepository {
    private const val PREFS = "saitenwerk"
    private fun prefs(a: MainActivity) = a.getSharedPreferences(PREFS, 0)
    fun key(song: Song) = (song.title.trim() + "|" + song.artist.trim()).lowercase()

    fun load(a: MainActivity): MutableList<Song> {
        val base = try {
            val raw = a.assets.open("songs.json").bufferedReader().use { it.readText() }
            val array = JSONArray(raw)
            MutableList(array.length()) { index ->
                val o = array.getJSONObject(index)
                Song(o.optString("title"), o.optString("artist"), o.optString("genre"))
            }
        } catch (_: Exception) { mutableListOf() }
        val custom = try {
            val arr = JSONArray(prefs(a).getString("custom_songs", "[]"))
            MutableList(arr.length()) { i -> arr.getJSONObject(i).let { Song(it.optString("title"), it.optString("artist"), it.optString("genre", "Eigene Songs"), true) } }
        } catch (_: Exception) { mutableListOf() }
        val seen = base.map { key(it) }.toMutableSet()
        base.addAll(custom.filter { seen.add(key(it)) })
        return base
    }

    private fun stringSet(a: MainActivity, name: String) = prefs(a).getStringSet(name, emptySet())?.toMutableSet() ?: mutableSetOf()
    fun isFavorite(a: MainActivity, song: Song) = key(song) in stringSet(a, "song_favorites")
    fun toggleFavorite(a: MainActivity, song: Song): Boolean {
        val set = stringSet(a, "song_favorites"); val k = key(song)
        val now = if (set.remove(k)) false else { set.add(k); true }
        prefs(a).edit().putStringSet("song_favorites", set).apply(); return now
    }
    fun inSetlist(a: MainActivity, song: Song) = key(song) in stringSet(a, "song_setlist")
    fun toggleSetlist(a: MainActivity, song: Song): Boolean {
        val set = stringSet(a, "song_setlist"); val k = key(song)
        val now = if (set.remove(k)) false else { set.add(k); true }
        prefs(a).edit().putStringSet("song_setlist", set).apply(); return now
    }
    fun addRecent(a: MainActivity, song: Song) {
        val old = prefs(a).getString("song_recent", "")!!.split("\n").filter { it.isNotBlank() }.toMutableList()
        old.remove(key(song)); old.add(0, key(song))
        prefs(a).edit().putString("song_recent", old.take(30).joinToString("\n")).apply()
    }
    fun isRecent(a: MainActivity, song: Song) = key(song) in prefs(a).getString("song_recent", "")!!.split("\n")
    fun hasSongSheet(a: MainActivity, song: Song): Boolean {
        val prefix = "song_arrangement_${song.title}|${song.artist}_"
        return listOf("Intro", "Strophe 1", "Strophe 2", "Strophe 3", "Refrain", "Bridge", "Solo", "Outro").any { section ->
            val raw = prefs(a).getString(prefix + section, "{}") ?: "{}"
            try { org.json.JSONObject(raw).optString("content").isNotBlank() || org.json.JSONObject(raw).optString("chords").isNotBlank() }
            catch (_: Exception) { false }
        }
    }
    fun addCustom(a: MainActivity, song: Song) {
        val arr = try { JSONArray(prefs(a).getString("custom_songs", "[]")) } catch (_: Exception) { JSONArray() }
        if (load(a).any { key(it) == key(song) }) return
        arr.put(org.json.JSONObject().put("title", song.title).put("artist", song.artist).put("genre", song.genre.ifBlank { "Eigene Songs" }))
        prefs(a).edit().putString("custom_songs", arr.toString()).apply()
    }
}

class SongsFragment : Fragment() {
    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity
        val root = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        root.addView(a.title("Liederbuch"))
        val songs = SongRepository.load(a)
        val hero = a.card()
        val heroBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(18), a.dp(16), a.dp(18), a.dp(16)) }
        heroBox.addView(TextView(a).apply { text = "🎸  Gemeinfreies Gitarren-Songbook"; textSize = 20f; setTypeface(typeface, android.graphics.Typeface.BOLD); setTextColor(a.getColor(R.color.sw_copper)) })
        heroBox.addView(a.body("Nur freie bzw. traditionelle Werke · komplett mit Liedtext und spielbaren Akkorden · ohne moderne Copyright-Songs."))
        heroBox.addView(TextView(a).apply { text = "${songs.size} kuratierte Songs · bereit zum Spielen"; textSize = 13f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0, a.dp(8), 0, 0) })
        hero.addView(heroBox)
        root.addView(hero, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(16), a.dp(6), a.dp(16), a.dp(10)) })
        val count = a.body("${songs.size} Songtitel · vollständige Songblätter mit Text und Akkorden")
        root.addView(count)
        val search = EditText(a).apply {
            hint = "Titel, Künstler oder Genre suchen"; setSingleLine()
            setTextColor(a.getColor(R.color.sw_text)); setHintTextColor(a.getColor(R.color.sw_muted))
            setPadding(a.dp(16), 0, a.dp(16), 0)
            background = android.graphics.drawable.GradientDrawable().apply { setColor(a.getColor(R.color.sw_surface)); cornerRadius = a.dp(14).toFloat(); setStroke(a.dp(1), a.getColor(R.color.sw_surface2)) }
        }
        root.addView(search, LinearLayout.LayoutParams(-1, a.dp(50)).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(8)) })

        val genreValues = listOf("Alle Genres") + songs.map { it.genre }.filter { it.isNotBlank() }.distinct().sorted()
        val genre = Spinner(a).apply { adapter = a.spinnerAdapter(genreValues) }
        val sort = Spinner(a).apply { adapter = a.spinnerAdapter(listOf("Titel A–Z", "Künstler A–Z", "Genre")) }
        val controls = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        controls.addView(genre, LinearLayout.LayoutParams(0, a.dp(48), 1f).apply { setMargins(a.dp(12), 0, a.dp(4), 0) })
        controls.addView(sort, LinearLayout.LayoutParams(0, a.dp(48), 1f).apply { setMargins(a.dp(4), 0, a.dp(12), 0) })
        root.addView(controls)

        var filter = "Alle"
        var refreshList: (() -> Unit)? = null
        val filters = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        val buttons = linkedMapOf<String, Button>()
        listOf("Alle", "★ Favoriten", "♫ Setlist", "Zuletzt").forEach { label ->
            val b = a.button(label).apply { textSize = 12f; minWidth = 0; setPadding(a.dp(8), 0, a.dp(8), 0) }
            buttons[label] = b
            filters.addView(b, LinearLayout.LayoutParams(0, a.dp(42), 1f).apply { setMargins(a.dp(3), a.dp(8), a.dp(3), a.dp(8)) })
            b.setOnClickListener { filter = label; refreshList?.invoke() }
        }
        root.addView(filters)

        val list = RecyclerView(a).apply { layoutManager = LinearLayoutManager(a); setPadding(0, 0, 0, a.dp(8)); clipToPadding = false }
        val adapter = SongAdapter(songs, a) { song -> SongRepository.addRecent(a, song); a.openSong(song) }
        list.adapter = adapter
        fun refresh() {
            val term = search.text.toString().trim().lowercase()
            val selectedGenre = genre.selectedItem?.toString() ?: "Alle Genres"
            val filtered = songs.filter { song ->
                (term.isEmpty() || song.title.lowercase().contains(term) || song.artist.lowercase().contains(term) || song.genre.lowercase().contains(term)) &&
                (selectedGenre == "Alle Genres" || song.genre == selectedGenre) && when (filter) {
                    "★ Favoriten" -> SongRepository.isFavorite(a, song)
                    "♫ Setlist" -> SongRepository.inSetlist(a, song)
                    "Zuletzt" -> SongRepository.isRecent(a, song)
                    else -> true
                }
            }.let { result -> when (sort.selectedItemPosition) {
                1 -> result.sortedBy { it.artist.lowercase() + it.title.lowercase() }
                2 -> result.sortedBy { it.genre.lowercase() + it.title.lowercase() }
                else -> result.sortedBy { it.title.lowercase() }
            } }
            adapter.submit(filtered)
            count.text = "${filtered.size} angezeigt · ${songs.size} Songtitel insgesamt"
            buttons.forEach { (name, b) -> b.alpha = if ((name == "★ Favoriten" && filter == name) || (name == "♫ Setlist" && filter == name) || (name == filter)) 1f else .68f }
        }
        refreshList = { refresh() }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, before: Int, count: Int) { refresh() }
            override fun afterTextChanged(e: Editable?) {}
        })
        genre.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { refresh() }
        }
        sort.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { refresh() }
        }
        val add = a.button("＋ Eigenen Song hinzufügen")
        add.setOnClickListener {
            val panel = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(20), a.dp(8), a.dp(20), 0) }
            val title = EditText(a).apply { hint = "Songtitel" }
            val artist = EditText(a).apply { hint = "Künstler (optional)" }
            val category = EditText(a).apply { hint = "Genre (optional)" }
            panel.addView(title); panel.addView(artist); panel.addView(category)
            androidx.appcompat.app.AlertDialog.Builder(a, R.style.ThemeOverlay_Saitenwerk_Dialog).setTitle("Eigenen Song anlegen").setView(panel)
                .setNegativeButton("Abbrechen", null).setPositiveButton("Speichern") { _, _ ->
                    val name = title.text.toString().trim()
                    if (name.isBlank()) Toast.makeText(a, "Bitte einen Songtitel eingeben.", Toast.LENGTH_SHORT).show()
                    else {
                        val song = Song(name, artist.text.toString().trim(), category.text.toString().trim().ifBlank { "Eigene Songs" }, true)
                        if (songs.any { SongRepository.key(it) == SongRepository.key(song) }) Toast.makeText(a, "Dieser Song ist bereits vorhanden.", Toast.LENGTH_SHORT).show()
                        else { SongRepository.addCustom(a, song); songs.add(song); refresh(); Toast.makeText(a, "Song gespeichert", Toast.LENGTH_SHORT).show() }
                    }
                }.show()
        }
        root.addView(add, LinearLayout.LayoutParams(-1, a.dp(46)).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(6)) })
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        refresh()
        return root
    }
}

class SongAdapter(private val all: List<Song>, private val host: MainActivity, private val onClick: (Song) -> Unit) : RecyclerView.Adapter<SongAdapter.Holder>() {
    private var data = all.toList()
    class Holder(v: View) : RecyclerView.ViewHolder(v)
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val card = MaterialCardView(host).apply {
            setCardBackgroundColor(host.getColor(R.color.sw_surface)); radius = host.dp(14).toFloat()
            strokeColor = host.getColor(R.color.sw_surface2); strokeWidth = host.dp(1)
            val text = LinearLayout(host).apply { orientation = LinearLayout.VERTICAL; setPadding(host.dp(16), host.dp(12), host.dp(16), host.dp(12)) }
            addView(text); tag = text
        }
        return Holder(card)
    }
    override fun getItemCount() = data.size
    override fun onBindViewHolder(holder: Holder, position: Int) {
        val song = data[position]; val card = holder.itemView as MaterialCardView
        val text = card.tag as LinearLayout; text.removeAllViews()
        text.addView(TextView(host).apply { this.text = (if (SongRepository.isFavorite(host, song)) "★  " else "♫  ") + song.title; setTextColor(host.getColor(R.color.sw_text)); textSize = 16f; setTypeface(typeface, android.graphics.Typeface.BOLD) })
        val meta = listOf(song.artist.ifBlank { "Künstler unbekannt" }, song.genre.takeIf { it.isNotBlank() }, if (SongRepository.inSetlist(host, song)) "Setlist" else null, if (SongRepository.hasSongSheet(host, song)) "Songblatt vorhanden" else "Songblatt noch offen").filterNotNull().joinToString("   ·   ")
        text.addView(TextView(host).apply { this.text = meta; setTextColor(host.getColor(R.color.sw_muted)); textSize = 12f; setPadding(0, host.dp(4), 0, 0) })
        card.setOnClickListener { onClick(song) }
        card.layoutParams = RecyclerView.LayoutParams(-1, -2).apply {
            setMargins(host.dp(12), host.dp(4), host.dp(12), host.dp(4))
        }
    }
    fun submit(items: List<Song>) { data = items; notifyDataSetChanged() }
}

class SongDetailFragment : Fragment() {
    companion object {
        fun newInstance(song: Song) = SongDetailFragment().apply {
            arguments = Bundle().apply {
                putString("title", song.title)
                putString("artist", song.artist)
                putString("genre", song.genre)
            }
        }
    }

    private data class SongLine(val parts: List<Pair<String, String>>, val plainText: String)
    private data class PlayerChordEvent(
        val chord: String,
        val startMs: Long,
        val endMs: Long,
        val view: TextView
    )

    private data class PlayerNote(val midi: Int, val startMs: Long, val durationMs: Long, val velocity: Float = 0.72f)

    private class GuitarPlayerEngine(private val context: android.content.Context) {
        private val sampleRate = 22_050
        private val chunkFrames = 512
        private var audioTrack: AudioTrack? = null
        private var renderThread: Thread? = null
        @Volatile private var cancelled = false
        @Volatile private var running = false
        @Volatile private var paused = false
        private var totalDurationMs = 0

        fun stop() {
            cancelled = true
            running = false
            paused = false
            renderThread?.interrupt()
            renderThread = null
            audioTrack?.let {
                try { it.stop() } catch (_: Exception) {}
                try { it.release() } catch (_: Exception) {}
            }
            audioTrack = null
        }

        fun pause() {
            audioTrack?.pause()
            paused = true
            running = false
        }

        fun resume() {
            audioTrack?.play()
            paused = false
            running = true
        }

        fun position(): Int {
            val track = audioTrack ?: return 0
            val frames = track.playbackHeadPosition.toLong() and 0xffffffffL
            return ((frames * 1000L) / sampleRate).toInt().coerceIn(0, totalDurationMs)
        }

        fun duration(): Int = totalDurationMs

        fun play(
            chords: List<Pair<String, Long>>,
            melody: List<PlayerNote>,
            tempoBpm: Int,
            onReady: (Int) -> Unit,
            onCompleted: () -> Unit,
            onError: (Throwable) -> Unit
        ) {
            stop()
            cancelled = false
            val beatMs = 60_000.0 / tempoBpm.coerceIn(40, 180)
            val lastChordEnd = chords.maxOfOrNull { it.second } ?: 0L
            val lastNoteEnd = melody.maxOfOrNull { it.startMs + it.durationMs } ?: 0L
            totalDurationMs = maxOf(lastChordEnd + (beatMs * 2.0).toLong(), lastNoteEnd + 450L).toInt().coerceAtLeast(1000)

            try {
                val minBuffer = AudioTrack.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                ).coerceAtLeast(chunkFrames * 2 * 4)
                val track = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build())
                    .setAudioFormat(AudioFormat.Builder()
                        .setSampleRate(sampleRate)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build())
                    .setBufferSizeInBytes(minBuffer)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
                audioTrack = track

                // Start playback immediately. The audio is rendered in small chunks while it plays,
                // so there is no multi-second WAV generation delay before the first note.
                track.play()
                running = true
                onReady(totalDurationMs)

                val chordEvents = chords.mapIndexed { index, pair ->
                    val end = chords.getOrNull(index + 1)?.second ?: totalDurationMs.toLong()
                    Triple(pair.first, pair.second, end)
                }
                renderThread = Thread {
                    try {
                        val buffer = ShortArray(chunkFrames)
                        var frameCursor = 0L
                        var chordIndex = 0
                        var melodyIndex = 0
                        while (!cancelled && frameCursor < (totalDurationMs * sampleRate / 1000L)) {
                            while (paused && !cancelled) Thread.sleep(8L)
                            if (cancelled) break
                            var count = 0
                            while (count < chunkFrames && frameCursor < (totalDurationMs * sampleRate / 1000L)) {
                                val ms = frameCursor * 1000L / sampleRate
                                while (chordIndex + 1 < chordEvents.size && ms >= chordEvents[chordIndex].third) chordIndex++
                                while (melodyIndex + 1 < melody.size && ms >= melody[melodyIndex].startMs + melody[melodyIndex].durationMs) melodyIndex++

                                var sample = 0.0
                                if (chordIndex in chordEvents.indices) {
                                    val ev = chordEvents[chordIndex]
                                    if (ms >= ev.second && ms < ev.third) {
                                        val local = (ms - ev.second) / 1000.0
                                        val notes = chordToMidi(ev.first)
                                        notes.forEachIndexed { idx, midi ->
                                            sample += guitarPluck(midi, local, if (idx == 0) 0.31 else 0.24, 0.95 - idx * 0.08)
                                        }
                                        if (local < beatMs / 1000.0) {
                                            val bass = notes.firstOrNull()?.minus(12) ?: 48
                                            sample += guitarPluck(bass, local, 0.20, 0.78)
                                        }
                                    }
                                }

                                if (melodyIndex in melody.indices) {
                                    val note = melody[melodyIndex]
                                    if (ms >= note.startMs && ms < note.startMs + note.durationMs) {
                                        val local = (ms - note.startMs) / 1000.0
                                        sample += guitarPluck(note.midi, local, note.velocity.toDouble() * 0.64, 1.08)
                                    }
                                }

                                // Very subtle room/body resonance. It is deliberately quiet so the
                                // sound remains guitar-like instead of turning into an electronic pad.
                                sample += sin(2.0 * PI * 110.0 * (ms / 1000.0)) * 0.0015
                                val shaped = (sample * 0.92).coerceIn(-0.92, 0.92)
                                buffer[count] = (shaped * 32767.0).roundToInt().toShort()
                                count++
                                frameCursor++
                            }
                            var written = 0
                            while (written < count && !cancelled) {
                                val n = track.write(buffer, written, count - written, AudioTrack.WRITE_BLOCKING)
                                if (n <= 0) break
                                written += n
                            }
                        }
                        if (!cancelled) {
                            running = false
                            try { track.stop() } catch (_: Exception) {}
                            onCompleted()
                        }
                    } catch (t: Throwable) {
                        if (!cancelled) onError(t)
                    }
                }.also { it.start() }
            } catch (t: Throwable) {
                onError(t)
            }
        }

        private fun guitarPluck(midi: Int, t: Double, velocity: Double, brightness: Double): Double {
            if (t < 0.0) return 0.0
            val f = midiToHz(midi)
            // Inharmonische Teiltöne + kurzer Anschlag + schneller Verlust der hohen
            // Frequenzen. Das vermeidet den "Game-Sound" eines reinen Oszillators.
            val attack = (t / 0.0038).coerceAtMost(1.0)
            val fundamentalDecay = exp(-t * (2.35 + f / 2300.0))
            val phase = 2.0 * PI * f * t
            val p2 = 2.0 * PI * (f * 2.006) * t
            val p3 = 2.0 * PI * (f * 3.011) * t
            val p4 = 2.0 * PI * (f * 4.018) * t
            val p5 = 2.0 * PI * (f * 5.027) * t
            val body = sin(phase) * 0.56 +
                sin(p2 + 0.08) * (0.25 * brightness) * exp(-t * 4.7) +
                sin(p3 + 0.17) * (0.115 * brightness) * exp(-t * 7.2) +
                sin(p4 + 0.29) * (0.052 * brightness) * exp(-t * 10.0) +
                sin(p5 + 0.41) * (0.018 * brightness) * exp(-t * 13.5)
            val pickNoise = (sin(phase * 31.0 + 0.7) + sin(phase * 47.0 + 2.1)) * exp(-t * 150.0) * 0.010
            val wood = sin(2.0 * PI * (f * 0.497) * t + 0.9) * exp(-t * 18.0) * 0.010
            return (body * fundamentalDecay + pickNoise + wood) * attack * velocity
        }

        private fun midiToHz(midi: Int): Double = 440.0 * 2.0.pow((midi - 69) / 12.0)

        private fun chordToMidi(chord: String): List<Int> {
            val clean = chord.replace('♯', '#').replace('♭', 'b')
            val m = Regex("^([A-G](?:#|b)?)([^/]*)(?:/([A-G](?:#|b)?))?").find(clean) ?: return listOf(60)
            val root = noteIndex(m.groupValues[1]) ?: 0
            val suffix = m.groupValues[2].lowercase()
            val intervals = when {
                suffix.contains("dim") -> listOf(0, 3, 6)
                suffix.contains("sus4") -> listOf(0, 5, 7)
                suffix.contains("sus2") -> listOf(0, 2, 7)
                suffix.contains("7") -> listOf(0, 4, 7, 10)
                suffix.contains("m") && !suffix.contains("maj") -> listOf(0, 3, 7)
                else -> listOf(0, 4, 7)
            }
            return intervals.map { 48 + ((root + it) % 12) }.take(3)
        }

        private fun noteIndex(note: String): Int? = when (note) {
            "C" -> 0; "C#", "Db" -> 1; "D" -> 2; "D#", "Eb" -> 3; "E" -> 4; "F" -> 5
            "F#", "Gb" -> 6; "G" -> 7; "G#", "Ab" -> 8; "A" -> 9; "A#", "Bb" -> 10; "B" -> 11; else -> null
        }
    }

    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity
        val song = arguments?.let {
            Song(it.getString("title").orEmpty(), it.getString("artist").orEmpty(), it.getString("genre").orEmpty())
        } ?: Song("Unbekannter Titel")
        val prefs = a.getSharedPreferences("saitenwerk", 0)
        val storageKey = "song_arrangement_${song.title}|${song.artist}"
        val sections = listOf("Gesamter Song", "Intro", "Strophe 1", "Strophe 2", "Strophe 3", "Refrain", "Bridge", "Solo", "Outro")
        var selectedSection = "Gesamter Song"

        val bundledSheet = try {
            val raw = a.assets.open("public_domain_sheets.json").bufferedReader().use { it.readText() }
            val arr = JSONArray(raw)
            (0 until arr.length()).asSequence()
                .map { arr.getJSONObject(it) }
                .firstOrNull { it.optString("title") == song.title && it.optString("artist") == song.artist }
                ?: org.json.JSONObject()
        } catch (_: Exception) { org.json.JSONObject() }

        fun loadSection(name: String): org.json.JSONObject {
            val saved = try {
                org.json.JSONObject(prefs.getString("${storageKey}_$name", "{}") ?: "{}")
            } catch (_: Exception) { org.json.JSONObject() }
            if (saved.optString("content").isNotBlank()) return saved
            if (name == "Gesamter Song" && bundledSheet.optString("content").isNotBlank()) {
                return org.json.JSONObject().put("content", bundledSheet.optString("content"))
                    .put("capo", bundledSheet.optInt("capo", 0))
                    .put("transpose", bundledSheet.optInt("transpose", 0))
                    .put("formatVersion", 4)
            }
            return saved
        }

        val root = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, a.dp(20))
        }
        val back = a.button("‹  Zurück zum Liederbuch")
        back.setOnClickListener { a.openSection(4) }
        root.addView(back, LinearLayout.LayoutParams(-1, a.dp(48)).apply { setMargins(a.dp(16), a.dp(10), a.dp(16), a.dp(8)) })
        root.addView(a.title(song.title))
        root.addView(TextView(a).apply {
            text = listOf(song.artist, song.genre).filter { it.isNotBlank() }.joinToString(" · ")
            textSize = 14f
            setTextColor(a.getColor(R.color.sw_copper))
            setPadding(a.dp(20), 0, a.dp(20), a.dp(10))
        })

        val actions = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
        val favorite = a.button(if (SongRepository.isFavorite(a, song)) "★ Favorit" else "☆ Favorit")
        favorite.textSize = 12f
        favorite.setOnClickListener {
            val now = SongRepository.toggleFavorite(a, song)
            favorite.text = if (now) "★ Favorit" else "☆ Favorit"
        }
        val setlist = a.button(if (SongRepository.inSetlist(a, song)) "✓ Setlist" else "＋ Setlist")
        setlist.textSize = 12f
        setlist.setOnClickListener {
            val now = SongRepository.toggleSetlist(a, song)
            setlist.text = if (now) "✓ Setlist" else "＋ Setlist"
        }
        actions.addView(favorite, LinearLayout.LayoutParams(0, a.dp(44), 1f).apply { setMargins(a.dp(16), 0, a.dp(5), 0) })
        actions.addView(setlist, LinearLayout.LayoutParams(0, a.dp(44), 1f).apply { setMargins(a.dp(5), 0, a.dp(16), 0) })
        root.addView(actions)

        val editorCard = a.card()
        val editor = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dp(16), a.dp(16), a.dp(16), a.dp(16))
        }
        editor.addView(TextView(a).apply {
            text = "Songblatt & Arrangement"
            textSize = 21f
            setTextColor(a.getColor(R.color.sw_copper))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        editor.addView(a.body("Liedtext und Akkorde werden zeilenweise gemeinsam gespeichert. Verwende Akkordmarkierungen direkt im Text, zum Beispiel: [C]Hier beginnt die Zeile [G]und hier wechselt der Akkord."))

        editor.addView(TextView(a).apply {
            text = "Abschnitt"
            setTextColor(a.getColor(R.color.sw_text))
            setPadding(0, a.dp(12), 0, a.dp(4))
        })
        val section = Spinner(a).apply {
            adapter = a.spinnerAdapter(sections)
            setSelection(0)
        }
        editor.addView(section, LinearLayout.LayoutParams(-1, a.dp(48)))

        var suppressPersistence = true
        val contentInput = EditText(a).apply {
            hint = "[C]Liedtext beginnt hier [G]Akkordwechsel\n[Am]Nächste Textzeile [F]mit weiterem Wechsel"
            setText(loadSection(selectedSection).optString("content", ""))
            setTextColor(a.getColor(R.color.sw_text))
            setHintTextColor(a.getColor(R.color.sw_muted))
            minLines = 7
            gravity = Gravity.TOP
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setPadding(a.dp(12), a.dp(12), a.dp(12), a.dp(12))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(a.getColor(R.color.sw_surface))
                cornerRadius = a.dp(12).toFloat()
                setStroke(a.dp(1), a.getColor(R.color.sw_surface2))
            }
        }
        editor.addView(TextView(a).apply {
            text = "Liedtext mit Akkorden"
            setTextColor(a.getColor(R.color.sw_text))
            setPadding(0, a.dp(12), 0, a.dp(5))
        })
        editor.addView(contentInput, LinearLayout.LayoutParams(-1, a.dp(190)))

        val capoLabel = TextView(a).apply { setTextColor(a.getColor(R.color.sw_text)); setPadding(0, a.dp(12), 0, 0) }
        val capo = SeekBar(a).apply { max = 12; progress = loadSection(selectedSection).optInt("capo", 0).coerceIn(0, 12) }
        val transposeLabel = TextView(a).apply { setTextColor(a.getColor(R.color.sw_text)); setPadding(0, a.dp(8), 0, 0) }
        val transpose = SeekBar(a).apply { max = 12; progress = (loadSection(selectedSection).optInt("transpose", 0) + 6).coerceIn(0, 12) }
        editor.addView(capoLabel); editor.addView(capo, LinearLayout.LayoutParams(-1, a.dp(40)))
        editor.addView(transposeLabel); editor.addView(transpose, LinearLayout.LayoutParams(-1, a.dp(40)))

        fun persistCurrentSection() {
            val data = org.json.JSONObject().apply {
                put("section", selectedSection)
                put("content", contentInput.text.toString())
                put("capo", capo.progress)
                put("transpose", transpose.progress - 6)
                put("updatedAt", System.currentTimeMillis())
                put("formatVersion", 3)
            }
            prefs.edit().putString("${storageKey}_$selectedSection", data.toString()).apply()
        }

        fun isChordSymbol(token: String): Boolean {
            // Accept common chord qualities and slash bass notes without mistaking ordinary bracketed text for chords.
            val pattern = Regex("^[A-G](?:#|b|♯|♭)?(?:maj|min|m|mi|sus|dim|aug|add|M|Δ|°|ø|[0-9]|\\+|-|\\(|\\)|#|b|♯|♭|,)*(?:/[A-G](?:#|b|♯|♭)?)?$")
            return token.isNotBlank() && pattern.matches(token)
        }

        fun parseLines(raw: String): List<SongLine> {
            val marker = Regex("\\[([^]\\r\\n]{1,16})\\]")
            return raw.lines().map { line ->
                val matches = marker.findAll(line).filter { isChordSymbol(it.groupValues[1].trim()) }.toList()
                if (matches.isEmpty()) SongLine(listOf("" to line), line)
                else {
                    val parts = mutableListOf<Pair<String, String>>()
                    var cursor = 0
                    matches.forEach { match ->
                        val before = line.substring(cursor, match.range.first)
                        if (before.isNotEmpty() && parts.isEmpty()) parts.add("" to before)
                        val nextStart = match.range.last + 1
                        val nextMatch = matches.firstOrNull { it.range.first > match.range.first }
                        val end = nextMatch?.range?.first ?: line.length
                        val lyric = line.substring(nextStart, end)
                        parts.add(match.groupValues[1] to lyric)
                        cursor = end
                    }
                    val plain = parts.joinToString("") { it.second }
                    SongLine(parts, plain)
                }
            }
        }

        fun transposeChord(token: String, semitones: Int): String {
            if (semitones == 0 || token.isBlank()) return token
            val names = listOf("C", "C♯", "D", "D♯", "E", "F", "F♯", "G", "G♯", "A", "A♯", "B")
            fun noteIndex(note: String): Int? = when (note.replace('♯', '#').replace('♭', 'b')) {
                "C" -> 0; "C#", "Db" -> 1; "D" -> 2; "D#", "Eb" -> 3
                "E", "Fb" -> 4; "F", "E#" -> 5; "F#", "Gb" -> 6
                "G" -> 7; "G#", "Ab" -> 8; "A" -> 9; "A#", "Bb" -> 10
                "B", "Cb" -> 11; else -> null
            }
            val match = Regex("^([A-G](?:#|b|♯|♭)?)([^/]*)(?:/([A-G](?:#|b|♯|♭)?))?$").matchEntire(token) ?: return token
            val root = noteIndex(match.groupValues[1]) ?: return token
            val suffix = match.groupValues[2]
            val bassToken = match.groupValues[3]
            val shiftedRoot = names[(root + semitones % 12 + 12) % 12]
            val shiftedBass = if (bassToken.isNotEmpty()) {
                val bass = noteIndex(bassToken) ?: return token
                "/" + names[(bass + semitones % 12 + 12) % 12]
            } else ""
            return shiftedRoot + suffix + shiftedBass
        }

        // Professioneller Lesemodus + Player: der Song wird als synchronisierte
        // Gitarren-Begleitung abgespielt. Die sichtbaren Akkorde folgen der Audiozeit.
        var autoScroll: Boolean = false
        var scrollRunnable: Runnable? = null
        val scrollHandler = Handler(Looper.getMainLooper())
        var lastScrollTime: Long = 0L
        var scrollRemainder: Float = 0f
        var resumeAfterTouch: Boolean = false
        val readerScroll = ScrollView(a).apply {
            setFillViewport(true)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(a.getColor(R.color.sw_surface)); cornerRadius = a.dp(14).toFloat()
            }
        }
        val readerContent = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dp(18), a.dp(18), a.dp(18), a.dp(28))
        }
        readerScroll.addView(readerContent)
        val playerEngine = GuitarPlayerEngine(a)
        var playerPlaying = false
        var playerPrepared = false
        var playerDuration = 0
        var playerTempo = bundledSheet.optInt("tempo", 72).coerceIn(40, 160)
        var playerProgressRunnable: Runnable? = null
        var chordEvents = emptyList<PlayerChordEvent>()
        var activeChordIndex = -1

        fun stopAutoScroll() {
            autoScroll = false
            scrollRunnable?.let { scrollHandler.removeCallbacks(it) }
            scrollRunnable = null
            lastScrollTime = 0L
            scrollRemainder = 0f
        }

        fun highlightChord(index: Int) {
            if (index == activeChordIndex) return
            if (activeChordIndex in chordEvents.indices) {
                chordEvents[activeChordIndex].view.setTextColor(a.getColor(R.color.sw_copper))
                chordEvents[activeChordIndex].view.setBackgroundColor(android.graphics.Color.TRANSPARENT)
                chordEvents[activeChordIndex].view.setPadding(a.dp(4), a.dp(3), a.dp(4), a.dp(3))
            }
            activeChordIndex = index
            if (index in chordEvents.indices) {
                val v = chordEvents[index].view
                v.setTextColor(a.getColor(R.color.sw_navy))
                v.setBackgroundColor(a.getColor(R.color.sw_copper))
                v.setPadding(a.dp(7), a.dp(4), a.dp(7), a.dp(4))
                v.post { readerScroll.smoothScrollTo(0, (v.top - readerScroll.height / 3).coerceAtLeast(0)) }
            }
        }

        fun resetChordHighlight() {
            if (activeChordIndex in chordEvents.indices) {
                val v = chordEvents[activeChordIndex].view
                v.setTextColor(a.getColor(R.color.sw_copper))
                v.setBackgroundColor(android.graphics.Color.TRANSPARENT)
                v.setPadding(a.dp(4), a.dp(3), a.dp(4), a.dp(3))
            }
            activeChordIndex = -1
        }

        fun stopPlayer() {
            playerEngine.stop()
            playerPlaying = false
            playerPrepared = false
            playerProgressRunnable?.let { scrollHandler.removeCallbacks(it) }
            playerProgressRunnable = null
            resetChordHighlight()
        }

        fun startAutoScroll() {
            stopAutoScroll()
            autoScroll = true
            lastScrollTime = android.os.SystemClock.uptimeMillis()
            scrollRemainder = 0f
            scrollRunnable = object : Runnable {
                override fun run() {
                    if (!autoScroll) return
                    if (playerPrepared && playerPlaying) {
                        // Der Player ist die Master-Zeitbasis. Der Reader folgt exakt der Audiozeit,
                        // statt mit einer eigenen Scrollgeschwindigkeit langsam auseinanderzulaufen.
                        val duration = playerDuration.coerceAtLeast(1)
                        val pos = playerEngine.position().coerceIn(0, duration)
                        val maxY = ((readerContent.height - readerScroll.height).coerceAtLeast(0))
                        val target = if (maxY == 0) 0 else ((pos.toDouble() / duration) * maxY).roundToInt()
                        val current = readerScroll.scrollY
                        val step = ((target - current) * 0.34f).roundToInt()
                        readerScroll.scrollTo(0, if (step == 0) target else current + step)
                        if (pos >= duration - 120L) {
                            readerScroll.scrollTo(0, maxY)
                            return
                        }
                    } else {
                        stopAutoScroll()
                        return
                    }
                    scrollHandler.postDelayed(this, 16L)
                }
            }
            scrollHandler.post(scrollRunnable!!)
        }

        fun melodyForSong(title: String, chordTimeline: List<Pair<String, Long>>, tempoBpm: Int): List<PlayerNote> {
            val t = title.lowercase()
            val beat = 60_000L / tempoBpm
            val known: Map<String, List<Int>> = mapOf(
                "alle meine entchen" to listOf(0,1,2,3,4,4,4,4,3,3,3,3,2,2,2,2,1,1,1,1,0,0,0,0),
                "hänschen klein" to listOf(0,1,2,3,4,4,4,1,3,3,3,3,1,2,2,2,0,1,2,3,4,4,4,1),
                "jingle bells" to listOf(2,2,2,2,2,2,2,4,0,1,2,3,3,3,3,3,2,2,2,2,2,1,1,2,1,4),
                "silent night" to listOf(0,1,0,4,3,0,1,0,4,3,0,6,4,3,1,0,4,3,0,1,0,4,3),
                "o tannenbaum" to listOf(0,1,2,3,4,4,4,4,5,5,4,3,2,1,0,1,2,3,4,4,3,2,1,0),
                "amazing grace" to listOf(0,3,5,3,5,4,3,1,0,3,5,3,5,4,3,1,0,3,5,6,5,4,3,1),
                "joy to the world" to listOf(4,3,2,1,0,1,2,3,4,4,4,3,2,1,0,1,2,3,4,4,4,3,2,1),
                "auld lang syne" to listOf(0,0,0,3,4,3,4,6,5,5,4,3,4,1,0,0,3,4,3,4,6,5,5,4,3,4),
                "scarborough fair" to listOf(2,3,4,2,1,0,1,2,3,4,6,4,3,2,0,1,2,3,4,2,1,0),
                "greensleeves" to listOf(2,3,4,6,5,4,2,1,0,1,2,4,3,2,0,1,2,4,5,4,3,2)
            )
            val degrees = known.entries.firstOrNull { t.contains(it.key) }?.value
            val notes = mutableListOf<PlayerNote>()
            if (degrees != null) {
                val minor = t.contains("greensleeves") || t.contains("scarborough fair")
                val scale = if (minor) listOf(0,2,3,5,7,8,10) else listOf(0,2,4,5,7,9,11)
                val base = when {
                    t.contains("jingle bells") -> 64
                    t.contains("amazing grace") -> 67
                    t.contains("greensleeves") || t.contains("scarborough fair") -> 64
                    else -> 60
                }
                degrees.forEachIndexed { i, degree ->
                    val octave = if (i % 16 >= 12) 12 else 0
                    val midi = base + scale[degree.coerceIn(0, 6)] + octave
                    val duration = (beat * if (i % 8 == 7) 1.35 else 0.76).toLong()
                    notes.add(PlayerNote(midi, i * beat, duration, if (i % 8 == 0) 0.82f else 0.70f))
                }
            } else {
                chordTimeline.forEachIndexed { i, pair ->
                    val root = Regex("^([A-G](?:#|b)?)").find(pair.first)?.groupValues?.get(1) ?: "C"
                    val idx = when (root) { "C"->0;"C#"->1;"Db"->1;"D"->2;"D#"->3;"Eb"->3;"E"->4;"F"->5;"F#"->6;"Gb"->6;"G"->7;"G#"->8;"Ab"->8;"A"->9;"A#"->10;"Bb"->10;"B"->11;else->0 }
                    notes.add(PlayerNote(60 + idx, pair.second, (beat * 0.68).toLong(), 0.48f))
                    notes.add(PlayerNote(60 + ((idx + 4) % 12), pair.second + beat, (beat * 0.55).toLong(), 0.34f))
                }
            }
            return notes
        }

        fun buildPlayerTimeline(raw: String): Pair<List<Pair<String, Long>>, List<PlayerNote>> {
            val beat = 60_000L / playerTempo
            var cursor = 0L
            val timeline = mutableListOf<Pair<String, Long>>()
            parseLines(raw).forEach { line ->
                val chords = line.parts.map { it.first }.filter { it.isNotBlank() }
                if (chords.isEmpty()) cursor += beat * 2
                else {
                    val perChord = (beat * 2).coerceAtLeast(beat)
                    chords.forEach { chord -> timeline.add(chord to cursor); cursor += perChord }
                }
            }
            return timeline to melodyForSong(song.title, timeline, playerTempo)
        }

        fun playSong(raw: String, playButton: Button, status: TextView, progress: ProgressBar) {
            if (raw.isBlank()) {
                Toast.makeText(a, "Dieser Song hat noch keinen Inhalt.", Toast.LENGTH_SHORT).show()
                return
            }
            stopPlayer()
            val (timeline, melody) = buildPlayerTimeline(raw)
            val bpm = playerTempo
            status.text = "⏳  Gitarren-Player wird vorbereitet …"
            playButton.isEnabled = false
            progress.setProgress(0)

            playerEngine.play(
                chords = timeline,
                melody = melody,
                tempoBpm = bpm,
                onReady = { duration ->
                    playerPrepared = true
                    playerPlaying = true
                    playerDuration = duration
                    a.runOnUiThread {
                        readerScroll.scrollTo(0, 0)
                        resetChordHighlight()
                        playButton.isEnabled = true
                        playButton.text = "Start"
                        status.text = "🎸  Spielt · ${bpm} BPM · synchron"
                        startAutoScroll()

                        playerProgressRunnable?.let { scrollHandler.removeCallbacks(it) }
                        playerProgressRunnable = object : Runnable {
                            override fun run() {
                                if (!playerPrepared) return
                                val position = playerEngine.position()
                                val durationMs = playerDuration.coerceAtLeast(1)
                                progress.setProgress((position * 100 / durationMs).coerceIn(0, 100))

                                val active = chordEvents.indexOfFirst { position >= it.startMs && position < it.endMs }
                                highlightChord(active)

                                if (playerPlaying) {
                                    scrollHandler.postDelayed(this, 50L)
                                }
                            }
                        }
                        scrollHandler.post(playerProgressRunnable!!)
                    }
                },
                onCompleted = {
                    a.runOnUiThread {
                        playerPlaying = false
                        playerPrepared = false
                        progress.setProgress(100)
                        highlightChord(-1)
                        playButton.isEnabled = true
                        playButton.text = "Start"
                        status.text = "✓  Song beendet"
                        playerProgressRunnable?.let { scrollHandler.removeCallbacks(it) }
                        playerProgressRunnable = null
                    }
                },
                onError = { error ->
                    a.runOnUiThread {
                        playerPlaying = false
                        playerPrepared = false
                        playButton.isEnabled = true
                        playButton.text = "Start"
                        status.text = "Fehler beim Abspielen"
                        progress.setProgress(0)
                        resetChordHighlight()
                        Toast.makeText(a, "Player-Fehler: ${error.message ?: "Unbekannter Fehler"}", Toast.LENGTH_LONG).show()
                    }
                }
            )
        }

        fun renderReader() {
            readerContent.removeAllViews(); chordEvents = emptyList(); activeChordIndex = -1
            val raw = contentInput.text.toString(); val semitones = transpose.progress - 6
            if (raw.isBlank()) { readerContent.addView(a.body("Noch kein Songblatt hinterlegt.")); return }
            val events = mutableListOf<PlayerChordEvent>()
            var fakeTime = 0L
            parseLines(raw).forEach { line ->
                if (line.plainText.isBlank() && line.parts.all { it.first.isBlank() }) {
                    readerContent.addView(TextView(a).apply { text = " "; textSize = 8f }); fakeTime += (60_000L / playerTempo) * 2L
                } else {
                    val row = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
                    val chordCount = line.parts.count { it.first.isNotBlank() }.coerceAtLeast(1)
                    val durationPerChord = (60_000L / playerTempo) * 2L
                    line.parts.forEach { (chord, lyric) ->
                        val segment = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
                        if (chord.isNotBlank()) {
                            val chordView = TextView(a).apply {
                                text = transposeChord(chord, semitones); textSize = 18f
                                setTypeface(typeface, android.graphics.Typeface.BOLD); setTextColor(a.getColor(R.color.sw_copper))
                                setPadding(a.dp(4), a.dp(3), a.dp(4), a.dp(3))
                            }
                            segment.addView(chordView)
                            events.add(PlayerChordEvent(chord, fakeTime, fakeTime + durationPerChord, chordView))
                            fakeTime += durationPerChord
                        }
                        segment.addView(TextView(a).apply {
                            text = if (lyric.isEmpty() && chord.isNotBlank()) " " else lyric
                            textSize = 19f; setTextColor(a.getColor(R.color.sw_text)); setPadding(0, 0, a.dp(5), a.dp(8))
                        })
                        row.addView(segment)
                    }
                    if (chordCount == 0) fakeTime += durationPerChord
                    readerContent.addView(row)
                }
            }
            chordEvents = events
        }
        contentInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                renderReader(); if (!suppressPersistence) persistCurrentSection()
            }
            override fun afterTextChanged(s: Editable?) {}
        })
        capo.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { renderReader(); persistCurrentSection() }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        transpose.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { renderReader(); persistCurrentSection() }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        section.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (sections[position] == selectedSection && contentInput.text.isNotBlank()) return
                persistCurrentSection()
                selectedSection = sections[position]
                val saved = loadSection(selectedSection)
                suppressPersistence = true
                contentInput.setText(saved.optString("content", ""))
                capo.progress = saved.optInt("capo", 0).coerceIn(0, 12)
                transpose.progress = (saved.optInt("transpose", 0) + 6).coerceIn(0, 12)
                suppressPersistence = false
                renderReader()
                stopAutoScroll()
            }
        }
        val save = a.button("Songabschnitt speichern")
        save.setOnClickListener {
            persistCurrentSection()
            Toast.makeText(a, "$selectedSection gespeichert", Toast.LENGTH_SHORT).show()
        }
        editor.addView(save, LinearLayout.LayoutParams(-1, a.dp(48)).apply { topMargin = a.dp(12) })
        editorCard.addView(editor)
        root.addView(editorCard, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(16), a.dp(14), a.dp(16), a.dp(12)) })

        val readerCard = a.card()
        val reader = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(16), a.dp(16), a.dp(16), a.dp(16)) }
        reader.addView(TextView(a).apply {
            text = "🎸  Song Player"
            textSize = 21f; setTextColor(a.getColor(R.color.sw_copper)); setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        reader.addView(a.body("Die Melodie läuft mit einer weichen Gitarrenbegleitung. Der aktuelle Akkord leuchtet exakt an seiner Spielposition auf."))
        val playerStatus = TextView(a).apply { text = "Bereit · Originaltempo ${playerTempo} BPM"; textSize = 13f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0, a.dp(8), 0, a.dp(5)) }
        reader.addView(playerStatus)
        val playerProgress = ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; setProgress(0) }
        reader.addView(playerProgress, LinearLayout.LayoutParams(-1, a.dp(8)))
        val startButton = a.button("Start").apply {
            textSize = 16f
            minHeight = a.dp(52)
        }
        reader.addView(startButton, LinearLayout.LayoutParams(-1, a.dp(52)).apply { topMargin = a.dp(8) })

        startButton.setOnClickListener {
            if (playerPlaying) {
                playerEngine.pause()
                playerPlaying = false
                playerStatus.text = "Ⅱ  Pausiert · ${playerTempo} BPM"
            } else if (playerPrepared) {
                playerEngine.resume()
                playerPlaying = true
                playerStatus.text = "🎸  Spielt · ${playerTempo} BPM · synchron"
                startAutoScroll()
            } else {
                playSong(contentInput.text.toString(), startButton, playerStatus, playerProgress)
            }
        }

        readerScroll.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> { resumeAfterTouch = autoScroll; if (autoScroll) stopAutoScroll() }
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> if (resumeAfterTouch) { resumeAfterTouch = false; if (playerPlaying) startAutoScroll() }
            }
            false
        }
        reader.addView(readerScroll, LinearLayout.LayoutParams(-1, a.dp(420)).apply { topMargin = a.dp(8) })
        readerCard.addView(reader)
        root.addView(readerCard, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(24)) })
        suppressPersistence = false
        renderReader()
        a.lifecycle.addObserver(object : androidx.lifecycle.DefaultLifecycleObserver {
            override fun onDestroy(owner: androidx.lifecycle.LifecycleOwner) {
                stopAutoScroll(); stopPlayer()
            }
        })
        return ScrollView(a).apply { addView(root) }
    }
}

/** Interaktives Griffbrett für das Finden einzelner Töne. */
class FretboardNoteView(context: android.content.Context) : View(context) {
    private val grid = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(92, 104, 120); strokeWidth = dp(1f)
        style = android.graphics.Paint.Style.STROKE
    }
    private val stringPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(205, 209, 214); strokeWidth = dp(1.6f)
    }
    private val accent = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(217, 154, 112); style = android.graphics.Paint.Style.FILL
    }
    private val text = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.rgb(224, 226, 229); textAlign = android.graphics.Paint.Align.CENTER
        textSize = dp(10f); typeface = android.graphics.Typeface.create("sans-serif-medium", 0)
    }
    var onNoteTap: ((Int, Int) -> Unit)? = null
    var highlighted: Pair<Int, Int>? = null
        set(value) { field = value; invalidate() }

    private val strings = arrayOf("E", "A", "D", "G", "H", "e")
    private val frets = 12

    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val left = dp(34f); val right = width - dp(12f)
        val top = dp(30f); val bottom = height - dp(34f)
        if (right <= left || bottom <= top) return
        val fw = (right - left) / frets.toFloat()
        val sg = (bottom - top) / 5f
        for (fret in 0..frets) {
            val x = left + fret * fw
            grid.strokeWidth = dp(if (fret == 0) 4f else 1.15f)
            canvas.drawLine(x, top, x, bottom, grid)
        }
        for (string in 0..5) {
            val y = bottom - string * sg
            stringPaint.strokeWidth = dp(1.25f + string * .16f)
            canvas.drawLine(left, y, right, y, stringPaint)
            canvas.drawText(strings[string], dp(15f), y + dp(4f), text)
        }
        for (fret in 1..frets) {
            val x = left + (fret - .5f) * fw
            if (fret == 3 || fret == 5 || fret == 7 || fret == 9) canvas.drawCircle(x, (top + bottom) / 2f, dp(4f), accent)
            if (fret == 12) {
                canvas.drawCircle(x, top + (bottom-top)*.34f, dp(4f), accent)
                canvas.drawCircle(x, top + (bottom-top)*.66f, dp(4f), accent)
            }
            canvas.drawText(fret.toString(), x, height - dp(12f), text)
        }
        highlighted?.let { (string, fret) ->
            val x = left + (fret.coerceIn(0, frets) + .5f) * fw
            val y = bottom - string.coerceIn(0, 5) * sg
            canvas.drawCircle(x, y, dp(10f), accent)
        }
    }

    override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
        if (event.action != android.view.MotionEvent.ACTION_UP) return true
        val left = dp(34f); val right = width - dp(12f)
        val top = dp(30f); val bottom = height - dp(34f)
        if (right <= left || bottom <= top) return true
        val fw = (right - left) / frets.toFloat()
        val sg = (bottom - top) / 5f
        val string = ((bottom - event.y) / sg).toInt().coerceIn(0, 5)
        val fret = ((event.x - left) / fw).toInt().coerceIn(0, frets)
        onNoteTap?.invoke(string, fret)
        performClick()
        return true
    }
    override fun performClick(): Boolean { super.performClick(); return true }
    private fun dp(v: Float) = v * resources.displayMetrics.density
}

class LearnFragment : Fragment() {
    private var chordTraining: ChordTrainingPanel? = null
    private var rhythmHandler: Handler? = null
    private var rhythmRunning = false
    private var rhythmBeat = 0
    private var rhythmBpm = 80
    private var rhythmMeter = "4/4"
    private var rhythmStartedAt = 0L
    private var quizStartedAt = 0L
    private var onSessionElapsed: ((Int) -> Unit)? = null
    private var strumHandler: Handler? = null
    private var strumRunning = false
    private var strumStartedAt = 0L

    override fun onDestroyView() {
        chordTraining?.stop()
        chordTraining = null
        finishQuizSession()
        stopRhythm()
        stopStrumming()
        onSessionElapsed = null
        super.onDestroyView()
    }

    override fun onResume() {
        super.onResume()
        requireActivity().window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onPause() {
        requireActivity().window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        super.onPause()
    }

    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity
        val prefs = a.getSharedPreferences("saitenwerk", 0)
        val root = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(a.dp(16), a.dp(8), a.dp(16), a.dp(24))
        }
        val scroll = ScrollView(a).apply { clipToPadding = false; isFillViewport = true }
        val content = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, a.dp(20)) }
        scroll.addView(content)

        fun roundedCard(): MaterialCardView = a.card().apply {
            radius = a.dp(20).toFloat()
            strokeColor = a.getColor(R.color.sw_outline)
            strokeWidth = a.dp(1)
            cardElevation = a.dp(2).toFloat()
        }
        fun addGap(dp: Int = 10) { content.addView(Space(a), LinearLayout.LayoutParams(1, a.dp(dp))) }

        fun updatePracticeStats() {
            val correct = prefs.getInt("learn_quiz_correct", 0)
            val total = prefs.getInt("learn_quiz_total", 0)
            val best = prefs.getInt("learn_best_quiz_streak", 0)
            val day = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.GERMANY).format(java.util.Date())
            val dailySeconds = if (prefs.getString("learn_daily_day", "") == day) prefs.getInt("learn_daily_seconds", prefs.getInt("learn_daily_minutes", 0) * 60) else 0
            val minutes = String.format(java.util.Locale.GERMANY, "%.1f min", dailySeconds / 60.0)
            val routineDone = if (prefs.getString("learn_routine_day", "") == day) Integer.bitCount(prefs.getInt("learn_routine_done", 0)) else 0
            val routineTotal = 5
            val rate = if (total > 0) correct * 100 / total else 0
            val stats = content.findViewWithTag<LinearLayout>("learnStats")
            stats?.let {
                it.removeAllViews()
                fun stat(value: String, label: String) {
                    val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
                    box.addView(TextView(a).apply { text = value; textSize = 21f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_copper)); gravity = Gravity.CENTER })
                    box.addView(TextView(a).apply { text = label; textSize = 10f; setTextColor(a.getColor(R.color.sw_muted)); gravity = Gravity.CENTER; setPadding(0, a.dp(2), 0, 0) })
                    it.addView(box, LinearLayout.LayoutParams(0, a.dp(58), 1f))
                }
                stat("$routineDone/$routineTotal", "Heute")
                stat(minutes, "Übungszeit")
                stat("$rate%", "Quiz-Treffer")
                stat("$best", "Beste Serie")
            }
            content.findViewWithTag<TextView>("learnToday")?.text =
                if (routineDone == routineTotal) "Heute geschafft · starke Arbeit!" else "Heute: $routineDone von $routineTotal Einheiten"
            content.findViewWithTag<ProgressBar>("learnTodayProgress")?.apply { max = routineTotal; progress = routineDone }
        }

        fun recordPracticeDay() {
            val day = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.GERMANY).format(java.util.Date())
            val last = prefs.getString("learn_last_session_day", "")
            val streak = prefs.getInt("learn_streak", 0)
            val yesterday = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.GERMANY).format(java.util.Date(System.currentTimeMillis() - 86400000L))
            if (last != day) {
                prefs.edit().putString("learn_last_session_day", day).putInt("learn_streak", if (last == yesterday) streak + 1 else 1).apply()
            }
        }

        fun recordSession(seconds: Int) {
            val day = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.GERMANY).format(java.util.Date())
            recordPracticeDay()
            val oldSeconds = if (prefs.getString("learn_daily_day", "") == day) prefs.getInt("learn_daily_seconds", prefs.getInt("learn_daily_minutes", 0) * 60) else 0
            val totalSeconds = oldSeconds + seconds.coerceAtLeast(1)
            val cal = java.util.Calendar.getInstance()
            val weekKey = cal.get(java.util.Calendar.YEAR).toString() + "-" + cal.get(java.util.Calendar.WEEK_OF_YEAR).toString()
            val oldWeekSeconds = if (prefs.getString("learn_week_key", "") == weekKey) prefs.getInt("learn_week_seconds", 0) else 0
            prefs.edit().putString("learn_daily_day", day).putInt("learn_daily_seconds", totalSeconds)
                .putInt("learn_daily_minutes", totalSeconds / 60)
                .putString("learn_week_key", weekKey)
                .putInt("learn_week_seconds", oldWeekSeconds + seconds.coerceAtLeast(1))
                .putInt("learn_sessions", prefs.getInt("learn_sessions", 0) + 1).apply()
            updatePracticeStats()
        }
        onSessionElapsed = { seconds -> recordSession(seconds) }

        fun finishQuizSession() { this@LearnFragment.finishQuizSession() }

        var overviewAction: (() -> Unit)? = null

        fun panel(heading: String, description: String): Pair<MaterialCardView, LinearLayout> {
            val card = roundedCard()
            val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(16), a.dp(15), a.dp(16), a.dp(16)) }
            box.addView(TextView(a).apply { text = heading; textSize = 19f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_copper)) })
            box.addView(a.body(description, 13f))
            card.addView(box)
            return card to box
        }

        fun showQuiz() {
            finishQuizSession(); chordTraining?.stop(); chordTraining = null; stopRhythm(); stopStrumming(); content.removeAllViews()
            quizStartedAt = android.os.SystemClock.elapsedRealtime()
            val (card, box) = panel("Akkord-Blitztrainer", "Erkenne Griffbilder. Die Serie steigt nur bei richtigen Antworten – so siehst du sofort, wie sicher du bist.")
            val header = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val score = TextView(a).apply { textSize = 13f; setTextColor(a.getColor(R.color.sw_muted)) }
            val streak = TextView(a).apply { textSize = 13f; setTextColor(a.getColor(R.color.sw_copper)); gravity = Gravity.END }
            header.addView(score, LinearLayout.LayoutParams(0, -2, 1f)); header.addView(streak, LinearLayout.LayoutParams(0, -2, 1f))
            box.addView(header)
            val diagram = FrameLayout(a); box.addView(diagram, LinearLayout.LayoutParams(-1, a.dp(210)))
            val choices = GridLayout(a).apply { columnCount = 2 }; box.addView(choices)
            val feedback = TextView(a).apply { text = "Wähle den passenden Akkord."; gravity = Gravity.CENTER; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0, a.dp(10), 0, a.dp(6)) }
            box.addView(feedback)
            val actions = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
            val next = a.button("Nächster Akkord"); val finish = a.button("Fertig")
            actions.addView(next, LinearLayout.LayoutParams(0, a.dp(46), 1f))
            actions.addView(finish, LinearLayout.LayoutParams(0, a.dp(46), 1f).apply { leftMargin = a.dp(6) })
            box.addView(actions)
            var answer = ""; var locked = false; var localStreak = 0

            fun updateHeader() {
                val total = prefs.getInt("learn_quiz_total", 0); val correct = prefs.getInt("learn_quiz_correct", 0)
                val rate = if (total > 0) correct * 100 / total else 0
                score.text = "Gesamt: $correct/$total · $rate%"; streak.text = "Serie: $localStreak"
            }
            fun newQuestion() {
                val pool = ChordLibrary.all.filter { it.name in listOf("C", "G", "D", "A", "E", "F", "Am", "Em", "Dm") }
                if (pool.size < 4) return
                val shape = pool.random(); answer = shape.name; locked = false
                feedback.text = "Welcher Akkord ist auf dem Griffbild zu sehen?"; feedback.setTextColor(a.getColor(R.color.sw_muted))
                diagram.removeAllViews(); diagram.addView(ChordDiagramView(a, shape), FrameLayout.LayoutParams(-1, -1)); choices.removeAllViews()
                val options = (listOf(answer) + pool.filter { it.name != answer }.shuffled().take(3).map { it.name }).shuffled()
                options.forEach { option ->
                    val b = a.button(option)
                    b.setOnClickListener {
                        if (locked) return@setOnClickListener
                        locked = true
                        val correctAnswer = option == answer
                        if (correctAnswer) localStreak++ else localStreak = 0
                        val total = prefs.getInt("learn_quiz_total", 0) + 1
                        val correct = prefs.getInt("learn_quiz_correct", 0) + if (correctAnswer) 1 else 0
                        val best = maxOf(prefs.getInt("learn_best_quiz_streak", 0), localStreak)
                        prefs.edit().putInt("learn_quiz_total", total).putInt("learn_quiz_correct", correct).putInt("learn_best_quiz_streak", best)
                            .putInt("learn_xp", prefs.getInt("learn_xp", 0) + if (correctAnswer) 10 else 3).apply()
                        feedback.text = if (correctAnswer) "Richtig! Serie $localStreak." else "Noch nicht ganz – gesucht war $answer."
                        feedback.setTextColor(a.getColor(if (correctAnswer) R.color.sw_copper else R.color.sw_muted))
                        for (j in 0 until choices.childCount) choices.getChildAt(j).isEnabled = false
                        updateHeader(); updatePracticeStats()
                    }
                    choices.addView(b, GridLayout.LayoutParams().apply { width = 0; height = a.dp(46); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(a.dp(3), a.dp(3), a.dp(3), a.dp(3)) })
                }
                updateHeader()
            }
            next.setOnClickListener { newQuestion() }
            finish.setOnClickListener { finishQuizSession(); overviewAction?.invoke() }
            newQuestion(); content.addView(card)
        }

        fun showChanges() {
            prefs.edit().putInt("learn_skill_changes", prefs.getInt("learn_skill_changes", 0) + 1).apply()
            finishQuizSession(); stopRhythm(); content.removeAllViews()
            content.addView(a.body("Dein Haupttraining für saubere Akkordwechsel. Wähle Akkorde, Takt und Tempo direkt im Trainer und steigere dich erst, wenn die Wechsel sicher sitzen."))
            chordTraining = ChordTrainingPanel(a); content.addView(chordTraining, LinearLayout.LayoutParams(-1, -2))
        }

        fun showRhythm() {
            prefs.edit().putInt("learn_skill_rhythm", prefs.getInt("learn_skill_rhythm", 0) + 1).apply()
            finishQuizSession(); chordTraining?.stop(); chordTraining = null; stopRhythm(); content.removeAllViews()
            val (card, box) = panel("Rhythmus & Timing", "Trainiere Puls, Taktgefühl und Geschwindigkeit. Im 6/8-Takt hörst du zwei große Pulse pro Takt.")
            rhythmBpm = prefs.getInt("learn_rhythm_bpm", 80).coerceIn(50, 160)
            rhythmMeter = prefs.getString("learn_rhythm_meter", "4/4") ?: "4/4"
            val tempoLabel = TextView(a).apply { text = "BPM $rhythmBpm"; textSize = 18f; setTextColor(a.getColor(R.color.sw_text)); gravity = Gravity.CENTER }
            box.addView(tempoLabel, LinearLayout.LayoutParams(-1, a.dp(36)))
            val slider = SeekBar(a).apply { max = 110; progress = rhythmBpm - 50 }
            slider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(v: SeekBar?, p: Int, from: Boolean) { rhythmBpm = 50 + p; tempoLabel.text = "BPM $rhythmBpm"; prefs.edit().putInt("learn_rhythm_bpm", rhythmBpm).apply() }
                override fun onStartTrackingTouch(v: SeekBar?) {}
                override fun onStopTrackingTouch(v: SeekBar?) {}
            })
            box.addView(slider, LinearLayout.LayoutParams(-1, a.dp(42)))
            val meterRow = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            meterRow.addView(TextView(a).apply { text = "Takt"; textSize = 13f; setTextColor(a.getColor(R.color.sw_muted)) }, LinearLayout.LayoutParams(0, a.dp(46), 1f))
            val meterButton = a.button(rhythmMeter); meterRow.addView(meterButton, LinearLayout.LayoutParams(a.dp(100), a.dp(46))); box.addView(meterRow)
            val meterHint = TextView(a).apply { text = if (rhythmMeter == "6/8") "Zwei große Pulse pro Takt (1–2), jeweils über drei Achtel." else "Ein Puls pro Zählzeit."; textSize = 12f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0, 0, 0, a.dp(4)) }
            box.addView(meterHint)
            meterButton.setOnClickListener {
                val meters = arrayOf("2/4", "3/4", "4/4", "6/8")
                androidx.appcompat.app.AlertDialog.Builder(a, R.style.ThemeOverlay_Saitenwerk_Dialog).setTitle("Taktart").setSingleChoiceItems(meters, meters.indexOf(rhythmMeter).coerceAtLeast(0)) { d, which ->
                    rhythmMeter = meters[which]; meterButton.text = rhythmMeter
                    meterHint.text = if (rhythmMeter == "6/8") "Zwei große Pulse pro Takt (1–2), jeweils über drei Achtel." else "Ein Puls pro Zählzeit."
                    prefs.edit().putString("learn_rhythm_meter", rhythmMeter).apply(); d.dismiss()
                }.setNegativeButton("Abbrechen", null).show()
            }
            val beat = TextView(a).apply { text = "Bereit"; textSize = 30f; gravity = Gravity.CENTER; setTextColor(a.getColor(R.color.sw_copper)); setPadding(0, a.dp(12), 0, a.dp(8)) }
            box.addView(beat, LinearLayout.LayoutParams(-1, a.dp(72)))
            val start = a.button("Metronom starten"); box.addView(start, LinearLayout.LayoutParams(-1, a.dp(48)))
            start.setOnClickListener {
                if (rhythmRunning) { stopRhythm(); start.text = "Metronom starten"; beat.text = "Pausiert" }
                else {
                    rhythmRunning = true; rhythmStartedAt = android.os.SystemClock.elapsedRealtime(); rhythmBeat = 0; rhythmHandler = Handler(Looper.getMainLooper()); start.text = "Metronom stoppen"
                    val compoundSixEight = rhythmMeter == "6/8"
                    val beatsPerBar = if (compoundSixEight) 2 else rhythmMeter.substringBefore("/").toIntOrNull() ?: 4
                    val pulseInterval = if (compoundSixEight) 90000L / rhythmBpm else 60000L / rhythmBpm
                    val task = object : Runnable {
                        override fun run() {
                            if (!rhythmRunning) return
                            val beatInBar = rhythmBeat % beatsPerBar
                            val strong = beatInBar == 0
                            GuitarAudioEngine.playTick(a, strong)
                            beat.text = if (strong) "1 · TAKT" else "${beatInBar + 1}"
                            rhythmBeat++; rhythmHandler?.postDelayed(this, pulseInterval.coerceAtLeast(100L))
                        }
                    }
                    rhythmHandler?.post(task)
                }
            }
            content.addView(card)
        }

        fun showStrumming() {
            prefs.edit().remove("learn_strum_bars")
                .putInt("learn_skill_strum", prefs.getInt("learn_skill_strum", 0) + 1).apply()
            finishQuizSession(); chordTraining?.stop(); chordTraining = null; stopRhythm(); stopStrumming(); content.removeAllViews()
            val (card, box) = panel("Schlagmuster-Trainer", "Wähle ein Muster und übe den Rhythmus. Timing, Richtung und Serien werden direkt ausgewertet.")

            val patterns = linkedMapOf(
                "Anfänger · ↓ ↓ ↓ ↓" to listOf("↓","↓","↓","↓"),
                "Grundlagen · ↓ ↑ ↓ ↑" to listOf("↓","↑","↓","↑"),
                "Pop · ↓ ↓ ↑ ↑ ↓ ↑" to listOf("↓","↓","↑","↑","↓","↑"),
                "Achtel · ↓ ↑ ↓ ↑ ↓ ↑ ↓ ↑" to listOf("↓","↑","↓","↑","↓","↑","↓","↑"),
                "Akustik · ↓ ↓ ↑ ↓ ↑" to listOf("↓","↓","↑","↓","↑"),
                "Flow · ↓ ↑ ↑ ↓ ↑ ↓" to listOf("↓","↑","↑","↓","↑","↓"),
                "Offbeat · ↓ ↑ · ↑ ↓ ↑ · ↑" to listOf("↓","↑","·","↑","↓","↑","·","↑"),
                "Profi · ↓ · ↑ ↑ · ↑ ↓ ↑" to listOf("↓","·","↑","↑","·","↑","↓","↑")
            )
            val levels = linkedMapOf(
                "Anfänger" to Triple(60, 420L, 3),
                "Grundlagen" to Triple(75, 330L, 4),
                "Fortgeschritten" to Triple(95, 240L, 5),
                "Profi" to Triple(115, 150L, 6)
            )

            var selectedName = prefs.getString("learn_strum_pattern", patterns.keys.first()) ?: patterns.keys.first()
            var selected = patterns[selectedName] ?: patterns.values.first()
            val orderedChordJson = prefs.getString("learn_strum_chords_ordered", null)
            val savedChordNames = if (!orderedChordJson.isNullOrBlank()) {
                runCatching {
                    val array = org.json.JSONArray(orderedChordJson)
                    (0 until array.length()).map { array.getString(it) }
                }.getOrElse { prefs.getStringSet("learn_strum_chords", null)?.toList().orEmpty() }
            } else {
                prefs.getStringSet("learn_strum_chords", null)?.toList()
                    ?: listOf(prefs.getString("learn_strum_chord", "G") ?: "G")
            }
            val selectedChordNames = savedChordNames.distinct()
                .filter { name -> ChordLibrary.all.any { it.name == name } }
                .ifEmpty { listOf(ChordLibrary.all.first().name) }.toMutableList()
            var selectedChords = selectedChordNames.mapNotNull { name -> ChordLibrary.all.firstOrNull { it.name == name } }
            var selectedMeter = prefs.getString("learn_strum_meter", "4/4") ?: "4/4"
            if (selectedMeter !in listOf("3/4", "4/4", "6/8")) selectedMeter = "4/4"
            var difficulty = prefs.getString("learn_strum_difficulty", "Grundlagen") ?: "Grundlagen"
            if (!levels.containsKey(difficulty)) difficulty = "Grundlagen"
            var bpm = prefs.getInt("learn_strum_bpm", levels[difficulty]!!.first).coerceIn(50, 160)

            var phase = "ready"
            var step = 0
            var round = 0
            var hits = 0
            var misses = 0
            var score = 0
            var combo = 0
            var bestCombo = 0
            var expectedAt = 0L
            var answered = true
            var sessionBest = prefs.getInt("learn_strum_best_score", 0)
            var roundBest = prefs.getInt("learn_strum_best_rounds", 0)

            val patternButton = a.button(selectedName)
            val chordButton = a.button("Gitarrenklang · " + selectedChordNames.joinToString(" – "))
            val meterButton = a.button("Taktart · " + selectedMeter)
            val levelButton = a.button("Stufe · " + difficulty)
            val status = TextView(a).apply {
                text = "Bereit · Training starten"
                textSize = 13f
                gravity = Gravity.CENTER
                setTextColor(a.getColor(R.color.sw_muted))
                setPadding(0, a.dp(7), 0, a.dp(8))
            }
            val beatRow = LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                isClickable = true
                isFocusable = true
            }
            val gestureHint = TextView(a).apply {
                text = "Im Training auf den Schlagpfeilen wischen: ↓ Abschlag · ↑ Aufschlag"
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(a.getColor(R.color.sw_muted))
                setPadding(a.dp(4), a.dp(2), a.dp(4), a.dp(6))
            }
            val tempoLabel = TextView(a).apply {
                text = "Tempo: " + bpm + " BPM"
                textSize = 14f
                setTextColor(a.getColor(R.color.sw_text))
            }
            val slider = SeekBar(a).apply { max = 110; progress = bpm - 50 }
            val stats = TextView(a).apply {
                text = "Punkte: 0 · Genauigkeit: 0% · Serie: 0"
                textSize = 12f
                setTextColor(a.getColor(R.color.sw_muted))
                gravity = Gravity.CENTER
            }
            val roundLabel = TextView(a).apply {
                text = "Runde 0 · Bestwert " + sessionBest
                textSize = 12f
                setTextColor(a.getColor(R.color.sw_muted))
                gravity = Gravity.CENTER
            }
            val timing = TextView(a).apply {
                text = "Timing-Fenster · ±" + levels[difficulty]!!.second + " ms"
                textSize = 12f
                setTextColor(a.getColor(R.color.sw_muted))
                gravity = Gravity.CENTER
            }
            val start = a.button("Training starten")

            box.addView(levelButton, LinearLayout.LayoutParams(-1, a.dp(44)).apply { bottomMargin = a.dp(5) })
            box.addView(chordButton, LinearLayout.LayoutParams(-1, a.dp(44)).apply { bottomMargin = a.dp(5) })
            box.addView(meterButton, LinearLayout.LayoutParams(-1, a.dp(42)).apply { bottomMargin = a.dp(4) })
            box.addView(patternButton, LinearLayout.LayoutParams(-1, a.dp(46)))
            box.addView(beatRow, LinearLayout.LayoutParams(-1, a.dp(76)))
            box.addView(gestureHint)
            box.addView(status)
            box.addView(roundLabel)
            box.addView(tempoLabel)
            box.addView(slider, LinearLayout.LayoutParams(-1, a.dp(42)))
            box.addView(timing)
            box.addView(stats)
            box.addView(start, LinearLayout.LayoutParams(-1, a.dp(48)).apply { topMargin = a.dp(4) })

            fun rebuildBeats() {
                beatRow.removeAllViews()
                selected.forEachIndexed { index, dir ->
                    beatRow.addView(TextView(a).apply {
                        text = dir
                        textSize = 22f
                        gravity = Gravity.CENTER
                        setTypeface(typeface, android.graphics.Typeface.BOLD)
                        setTextColor(a.getColor(R.color.sw_muted))
                        contentDescription = "Schlag " + (index + 1) + ": " + dir
                    }, LinearLayout.LayoutParams(0, a.dp(68), 1f))
                }
            }
            fun markBeat(active: Int = step) {
                for (i in 0 until beatRow.childCount) {
                    val v = beatRow.getChildAt(i) as TextView
                    val isActive = i == active
                    v.setTextColor(a.getColor(if (isActive) R.color.sw_copper else R.color.sw_muted))
                    v.textSize = if (isActive) 38f else 30f
                }
            }
            fun refreshStats() {
                val attempts = hits + misses
                val accuracy = if (attempts > 0) hits * 100 / attempts else 0
                stats.text = "Punkte: " + score + " · Genauigkeit: " + accuracy + "% · Serie: " + combo + " · Bestserie: " + bestCombo
                roundLabel.text = "Runde " + round + " · Bestwert " + sessionBest
            }
            fun updateTimingLabel() {
                timing.text = "Timing-Fenster · ±" + levels[difficulty]!!.second + " ms · Zieltempo " + levels[difficulty]!!.first + " BPM"
            }

            chordButton.setOnClickListener {
                if (phase == "play") return@setOnClickListener
                val names = ChordLibrary.all.map { it.name }.toTypedArray()
                val checked = BooleanArray(names.size) { names[it] in selectedChordNames }
                val selectionOrder = selectedChordNames.toMutableList()
                androidx.appcompat.app.AlertDialog.Builder(a, R.style.ThemeOverlay_Saitenwerk_Dialog)
                    .setTitle("Akkordfolge für den Gitarrenklang")
                    .setMultiChoiceItems(names, checked) { _, which, isChecked ->
                        checked[which] = isChecked
                        if (isChecked) {
                            if (names[which] !in selectionOrder) selectionOrder.add(names[which])
                        } else {
                            selectionOrder.remove(names[which])
                        }
                    }
                    .setPositiveButton("Übernehmen") { dialog, _ ->
                        val chosen = selectionOrder.filter { name ->
                            val index = names.indexOf(name)
                            index >= 0 && checked[index]
                        }
                        if (chosen.isNotEmpty()) {
                            selectedChordNames.clear()
                            selectedChordNames.addAll(chosen)
                            selectedChords = selectedChordNames.mapNotNull { name -> ChordLibrary.all.firstOrNull { it.name == name } }
                            prefs.edit()
                                .putString("learn_strum_chords_ordered", org.json.JSONArray(selectedChordNames).toString())
                                .putStringSet("learn_strum_chords", selectedChordNames.toSet())
                                .putString("learn_strum_chord", selectedChordNames.first())
                                .apply()
                            chordButton.text = "Gitarrenklang · " + selectedChordNames.joinToString(" – ")
                            status.text = selectedChordNames.size.toString() + " Akkorde ausgewählt · ein Akkord pro Takt"
                        } else {
                            android.widget.Toast.makeText(a, "Bitte mindestens einen Akkord auswählen.", android.widget.Toast.LENGTH_SHORT).show()
                        }
                        dialog.dismiss()
                    }.setNegativeButton("Abbrechen", null).show()
            }
            meterButton.setOnClickListener {
                if (phase == "play") return@setOnClickListener
                val meters = arrayOf("3/4", "4/4", "6/8")
                androidx.appcompat.app.AlertDialog.Builder(a, R.style.ThemeOverlay_Saitenwerk_Dialog)
                    .setTitle("Taktart auswählen")
                    .setSingleChoiceItems(meters, meters.indexOf(selectedMeter).coerceAtLeast(0)) { dialog, which ->
                        selectedMeter = meters[which]
                        meterButton.text = "Taktart · " + selectedMeter
                        prefs.edit().putString("learn_strum_meter", selectedMeter).apply()
                        dialog.dismiss()
                    }.setNegativeButton("Abbrechen", null).show()
            }
            levelButton.setOnClickListener {
                if (phase == "play") return@setOnClickListener
                val names = levels.keys.toTypedArray()
                androidx.appcompat.app.AlertDialog.Builder(a, R.style.ThemeOverlay_Saitenwerk_Dialog)
                    .setTitle("Trainingsstufe")
                    .setSingleChoiceItems(names, names.indexOf(difficulty).coerceAtLeast(0)) { dialog, which ->
                        difficulty = names[which]
                        bpm = levels[difficulty]!!.first
                        slider.progress = bpm - 50
                        levelButton.text = "Stufe · " + difficulty
                        prefs.edit().putString("learn_strum_difficulty", difficulty).putInt("learn_strum_bpm", bpm).apply()
                        updateTimingLabel()
                        status.text = "Stufe gesetzt · " + difficulty
                        dialog.dismiss()
                    }.setNegativeButton("Abbrechen", null).show()
            }
            patternButton.setOnClickListener {
                if (phase == "play") return@setOnClickListener
                val names = patterns.keys.toTypedArray()
                androidx.appcompat.app.AlertDialog.Builder(a, R.style.ThemeOverlay_Saitenwerk_Dialog)
                    .setTitle("Schlagmuster auswählen")
                    .setSingleChoiceItems(names, names.indexOf(selectedName).coerceAtLeast(0)) { dialog, which ->
                        selectedName = names[which]
                        selected = patterns[selectedName] ?: selected
                        step = 0
                        patternButton.text = selectedName
                        status.text = "Muster gewählt · bereit zum Training"
                        rebuildBeats(); markBeat()
                        dialog.dismiss()
                    }.setNegativeButton("Abbrechen", null).show()
            }
            slider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(v: SeekBar?, p: Int, from: Boolean) {
                    bpm = 50 + p
                    tempoLabel.text = "Tempo: " + bpm + " BPM"
                    prefs.edit().putInt("learn_strum_bpm", bpm).apply()
                }
                override fun onStartTrackingTouch(v: SeekBar?) {}
                override fun onStopTrackingTouch(v: SeekBar?) {}
            })

            fun userHit(direction: String) {
                if (phase != "play" || selected.isEmpty() || answered) return
                val expected = selected[step % selected.size]
                if (expected == "·") {
                    misses++; combo = 0; status.text = "✕ Pause · hier nicht anschlagen"; refreshStats(); answered = true; return
                }
                val delta = kotlin.math.abs(android.os.SystemClock.elapsedRealtime() - expectedAt)
                val window = levels[difficulty]!!.second
                answered = true
                if (direction == expected && delta <= window) {
                    hits++; combo++; bestCombo = maxOf(bestCombo, combo)
                    when {
                        delta <= window / 4 -> { score += 100 + combo.coerceAtMost(20) * 3; status.text = "✓ Perfekt · " + delta + " ms" }
                        delta <= window / 2 -> { score += 80 + combo.coerceAtMost(20) * 2; status.text = "✓ Sehr gut · " + delta + " ms" }
                        else -> { score += 60; status.text = "✓ Im Timing · " + delta + " ms" }
                    }
                } else {
                    misses++; combo = 0
                    status.text = if (direction != expected) "✕ " + direction + " · erwartet " + expected else "◷ Zu spät/früh · " + delta + " ms"
                }
                refreshStats()
            }

            var gestureStartX = 0f
            var gestureStartY = 0f
            beatRow.setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    android.view.MotionEvent.ACTION_DOWN -> {
                        gestureStartX = event.x
                        gestureStartY = event.y
                        true
                    }
                    android.view.MotionEvent.ACTION_UP -> {
                        val deltaX = event.x - gestureStartX
                        val deltaY = event.y - gestureStartY
                        if (phase == "play" &&
                            kotlin.math.abs(deltaY) >= a.dp(28).toFloat() &&
                            kotlin.math.abs(deltaY) > kotlin.math.abs(deltaX)) {
                            val direction = if (deltaY > 0f) "↓" else "↑"
                            val chord = selectedChords[round.coerceAtLeast(0) % selectedChords.size]
                            GuitarAudioEngine.playChord(
                                a, chord, downstroke = direction == "↓", volume = 0.84f
                            )
                            userHit(direction)
                        }
                        true
                    }
                    android.view.MotionEvent.ACTION_CANCEL -> true
                    else -> true
                }
            }

            start.setOnClickListener {
                if (phase == "play") {
                    prefs.edit()
                        .putInt("learn_strum_best_score", maxOf(sessionBest, score))
                        .putInt("learn_strum_best_rounds", maxOf(roundBest, round))
                        .putInt("learn_strum_best_combo", maxOf(prefs.getInt("learn_strum_best_combo", 0), bestCombo))
                        .apply()
                    sessionBest = maxOf(sessionBest, score)
                    roundBest = maxOf(roundBest, round)
                    stopStrumming()
                    phase = "ready"
                    start.text = "Training starten"
                    status.text = "Pausiert · " + score + " Punkte"
                    return@setOnClickListener
                }

                phase = "play"
                start.text = "Training stoppen"
                step = -1; hits = 0; misses = 0; score = 0; combo = 0; bestCombo = 0; round = 0; answered = false
                strumRunning = true
                strumStartedAt = android.os.SystemClock.elapsedRealtime()
                strumHandler = Handler(Looper.getMainLooper())
                val interval = (60000L / bpm / 2).coerceAtLeast(100L)
                val task = object : Runnable {
                    override fun run() {
                        if (!strumRunning || phase != "play") return
                        val beatsPerBar = when (selectedMeter) { "3/4" -> 3; "6/8" -> 6; else -> 4 }
                        val stepsPerBar = if (selected.size >= 6) beatsPerBar * 2 else beatsPerBar
                        step += 1
                        if (step >= stepsPerBar) {
                            step = 0
                            round++
                        }
                        answered = false
                        expectedAt = android.os.SystemClock.elapsedRealtime()
                        markBeat(step % selected.size)
                        val patternIndex = step % selected.size
                        val dir = selected[patternIndex]
                        val chord = selectedChords[round % selectedChords.size]
                        if (dir != "·") {
                            GuitarAudioEngine.playChord(a, chord, downstroke = dir == "↓", volume = if (patternIndex == 0) 0.78f else 0.56f)
                        } else {
                            status.text = "• Pause · nächster Schlag vorbereitet"
                        }
                        refreshStats()
                        strumHandler?.postDelayed(this, interval)
                    }
                }
                status.text = "Spiele passend zur Markierung"
                strumHandler?.post(task)
            }

            updateTimingLabel()
            rebuildBeats()
            markBeat(0)
            refreshStats()
            content.addView(card)
        }

        fun showFretboard() {
            finishQuizSession(); chordTraining?.stop(); chordTraining = null; stopRhythm(); stopStrumming()
            content.removeAllViews()
            val card = roundedCard()
            val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(14), a.dp(14), a.dp(14), a.dp(14)) }
            box.addView(TextView(a).apply {
                text = "🎸 Griffbrett entdecken"; textSize = 21f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_text))
            })
            box.addView(a.body("Finde den gesuchten Ton auf dem Griffbrett. Spiele ihn direkt an und trainiere Orientierung, Gehör und Notennamen.", 13f))
            val target = TextView(a).apply {
                textSize = 25f; setTypeface(typeface, 1); gravity = Gravity.CENTER
                setTextColor(a.getColor(R.color.sw_copper)); setPadding(0, a.dp(10), 0, a.dp(8))
            }
            box.addView(target)
            val feedback = TextView(a).apply {
                textSize = 13f; gravity = Gravity.CENTER; setTextColor(a.getColor(R.color.sw_muted)); minLines = 2
            }
            box.addView(feedback)
            val stats = TextView(a).apply { textSize = 12f; gravity = Gravity.CENTER; setTextColor(a.getColor(R.color.sw_text)); setPadding(0, a.dp(4), 0, a.dp(8)) }
            box.addView(stats)
            val fretboard = FretboardNoteView(a).apply { contentDescription = "Interaktives Gitarrengriffbrett, zwölf Bünde" }
            box.addView(fretboard, LinearLayout.LayoutParams(-1, a.dp(230)).apply { topMargin = a.dp(4) })
            val progress = ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply { max = 10 }
            box.addView(progress, LinearLayout.LayoutParams(-1, a.dp(8)).apply { topMargin = a.dp(8) })
            val next = a.button("Nächsten Ton anzeigen").apply { tag = "saitenwerk-primary" }
            box.addView(next, LinearLayout.LayoutParams(-1, a.dp(52)).apply { topMargin = a.dp(10) })
            val reset = a.button("Runde neu starten")
            box.addView(reset, LinearLayout.LayoutParams(-1, a.dp(48)).apply { topMargin = a.dp(6) })
            card.addView(box); content.addView(card)

            val natural = arrayOf("C", "D", "E", "F", "G", "A", "H")
            val semitones = arrayOf("C", "Cis", "D", "Dis", "E", "F", "Fis", "G", "Gis", "A", "B", "H")
            val openMidi = intArrayOf(40, 45, 50, 55, 59, 64)
            val random = java.util.Random()
            var targetName = natural[random.nextInt(natural.size)]
            var round = 0; var correct = 0; var streak = 0
            var best = prefs.getInt("learn_fretboard_best_streak", 0)

            fun noteAt(string: Int, fret: Int) = semitones[(openMidi[string] + fret) % 12]
            fun update() {
                target.text = "Gesucht:  $targetName"
                stats.text = "Runde $round/10   ·   Treffer $correct   ·   Serie $streak   ·   Bestwert $best"
                progress.progress = round.coerceAtMost(10)
            }
            fun newTarget() {
                targetName = natural[random.nextInt(natural.size)]
                fretboard.highlighted = null
                feedback.text = "Tippe eine Saite und einen Bund an."
                update()
            }
            fun finishRound() {
                best = maxOf(best, streak, prefs.getInt("learn_fretboard_best_streak", 0))
                prefs.edit().putInt("learn_fretboard_best_streak", best).putInt("learn_fretboard_best_score", correct).apply()
                feedback.text = "Runde geschafft · $correct/10 Treffer · beste Serie $best"
                next.text = "Neue Runde starten"; progress.progress = 10
            }
            fretboard.onNoteTap = { string, fret ->
                if (round < 10) {
                    val found = noteAt(string, fret)
                    GuitarAudioEngine.playString(a, string, fret, 0.68f)
                    if (found == targetName) {
                        correct++; streak++; best = maxOf(best, streak); round++
                        fretboard.highlighted = Pair(string, fret)
                        feedback.text = "✓ Richtig · " + found + " auf Saite " + (string + 1) + ", Bund " + fret
                        if (round >= 10) finishRound() else newTarget()
                    } else {
                        streak = 0; fretboard.highlighted = Pair(string, fret)
                        feedback.text = "Noch nicht · du hast " + found + " getroffen. Gesucht ist " + targetName + "."
                        update()
                    }
                }
            }
            next.setOnClickListener {
                if (round >= 10) { round = 0; correct = 0; streak = 0; next.text = "Nächsten Ton anzeigen"; newTarget() }
                else newTarget()
            }
            reset.setOnClickListener {
                round = 0; correct = 0; streak = 0; next.text = "Nächsten Ton anzeigen"; newTarget()
                Toast.makeText(a, "Griffbrett-Training zurückgesetzt", Toast.LENGTH_SHORT).show()
            }
            update(); newTarget()
        }

        fun showSongPractice() {
            finishQuizSession(); chordTraining?.stop(); chordTraining = null; stopRhythm(); stopStrumming()
            content.removeAllViews()
            val (card, box) = panel("Song-Praxis", "Übe typische Song-Akkordfolgen im eigenen Tempo. Wähle eine Folge und trainiere anschließend Wechsel, Rhythmus und Anschlag.")
            val selected = TextView(a).apply {
                text = "Aktuelle Folge: " + (prefs.getString("learn_song_progression", "G – D – Em – C") ?: "G – D – Em – C")
                textSize = 16f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_copper))
                setPadding(0, a.dp(10), 0, a.dp(8))
            }
            box.addView(selected)
            val playProgression = a.button("▶ Akkordfolge anhören").apply {
                gravity = Gravity.CENTER
                textAlignment = View.TEXT_ALIGNMENT_CENTER
                includeFontPadding = true
                minLines = 1
                maxLines = 1
                setPadding(a.dp(16), a.dp(14), a.dp(16), a.dp(14))
                minHeight = a.dp(60)
                minimumHeight = a.dp(60)
            }
            box.addView(playProgression, LinearLayout.LayoutParams(-1, a.dp(60)).apply { topMargin = a.dp(8) })
            var progressionPlaying = false
            playProgression.setOnClickListener {
                if (progressionPlaying) {
                    GuitarAudioEngine.stopAll()
                    progressionPlaying = false
                    playProgression.text = "▶ Akkordfolge anhören"
                } else {
                    val names = selected.text.toString().substringAfter(":").split("–").map { it.trim() }
                    if (names.any { name -> ChordLibrary.all.none { it.name == name } }) {
                        Toast.makeText(a, "Für diese Folge fehlt ein Akkordgriff.", Toast.LENGTH_SHORT).show()
                    } else {
                        progressionPlaying = true
                        playProgression.text = "■ Wiedergabe stoppen"
                        GuitarAudioEngine.playProgression(a, names, 80) {
                            progressionPlaying = false
                            playProgression.text = "▶ Akkordfolge anhören"
                        }
                    }
                }
            }
            val progressions = listOf("G – D – Em – C", "C – Am – F – G", "Am – F – C – G", "Em – C – G – D")
            progressions.forEach { progression ->
                box.addView(a.button(progression).apply {
                    isAllCaps = false
                    setOnClickListener {
                        GuitarAudioEngine.stopAll()
                        progressionPlaying = false
                        playProgression.text = "▶ Akkordfolge anhören"
                        prefs.edit().putString("learn_song_progression", progression).apply()
                        selected.text = "Aktuelle Folge: $progression"
                    }
                }, LinearLayout.LayoutParams(-1, a.dp(44)).apply { topMargin = a.dp(5) })
            }
            box.addView(a.body("Tipp: Spiele jeden Akkord zunächst vier gleichmäßige Schläge. Wenn der Wechsel sicher sitzt, erhöhe das Tempo schrittweise.", 12f).apply {
                setPadding(0, a.dp(10), 0, a.dp(8))
            })
            content.addView(card)
            val actions = roundedCard()
            val actionBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(14), a.dp(12), a.dp(14), a.dp(12)) }
            actionBox.addView(a.button("↔ Akkordwechsel trainieren").apply { setOnClickListener { showChanges() } },
                LinearLayout.LayoutParams(-1, a.dp(46)).apply { bottomMargin = a.dp(8) })
            actionBox.addView(a.button("🎸 Griffbrett entdecken").apply { setOnClickListener { showFretboard() } },
                LinearLayout.LayoutParams(-1, a.dp(46)).apply { bottomMargin = a.dp(8) })
            actionBox.addView(a.button("↘ Schlagmuster trainieren").apply { setOnClickListener { showStrumming() } },
                LinearLayout.LayoutParams(-1, a.dp(46)).apply { bottomMargin = a.dp(8) })
            actionBox.addView(a.button("♩ Rhythmus und Tempo üben").apply { setOnClickListener { showRhythm() } },
                LinearLayout.LayoutParams(-1, a.dp(46)))
            actionBox.addView(a.button("Zur Lernstudio-Übersicht").apply { setOnClickListener { overviewAction?.invoke() } },
                LinearLayout.LayoutParams(-1, a.dp(44)).apply { topMargin = a.dp(12) })
            actions.addView(actionBox)
            content.addView(actions)
        }

        fun showGuidedSession() {
            finishQuizSession(); chordTraining?.stop(); chordTraining = null; stopRhythm(); stopStrumming(); content.removeAllViews()
            val (card, box) = panel("🎯 Geführte 10-Minuten-Session", "Eine kompakte, adaptive Trainingseinheit. Die Reihenfolge passt sich deinem bisherigen Lernstand an.")
            val day = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.GERMANY).format(java.util.Date())
            val doneKey = "learn_guided_day"; val doneCountKey = "learn_guided_done"
            val already = if (prefs.getString(doneKey, "") == day) prefs.getInt(doneCountKey, 0) else 0
            val tasks = listOf(
                Triple("Akkorde", "2 Min · C – G – Am – F sauber greifen", 2),
                Triple("Wechsel", "3 Min · langsame, gleichmäßige Wechsel", 3),
                Triple("Rhythmus", "2 Min · Metronom und gleichmäßiger Puls", 2),
                Triple("Schlagmuster", "2 Min · Anschlag mit Timing-Fenster", 2),
                Triple("Freies Spielen", "1 Min · das Gelernte in einem Song anwenden", 1)
            )
            val progressLabel = TextView(a).apply { textSize = 13f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0, 0, 0, a.dp(8)) }
            val progress = ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply { max = 10; this.progress = already.coerceIn(0, 10) }
            box.addView(progressLabel); box.addView(progress, LinearLayout.LayoutParams(-1, a.dp(10)).apply { bottomMargin = a.dp(10) })
            fun updateGuided() {
                val n = if (prefs.getString(doneKey, "") == day) prefs.getInt(doneCountKey, 0) else 0
                progress.progress = n.coerceIn(0, 10)
                progressLabel.text = if (n >= 10) "Heute abgeschlossen · +10 XP" else n.toString() + "/10 Minuten abgeschlossen"
            }
            tasks.forEach { task ->
                val row = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, a.dp(5), 0, a.dp(5)) }
                val textBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
                textBox.addView(TextView(a).apply { text = task.first; textSize = 15f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_text)) })
                textBox.addView(TextView(a).apply { text = task.second; textSize = 12f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0, a.dp(2), 0, 0) })
                row.addView(textBox, LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(a.button("Start").apply {
                    minWidth = a.dp(74)
                    setOnClickListener {
                        val current = if (prefs.getString(doneKey, "") == day) prefs.getInt(doneCountKey, 0) else 0
                        val next = (current + task.third).coerceAtMost(10)
                        prefs.edit().putString(doneKey, day).putInt(doneCountKey, next).putInt("learn_xp", prefs.getInt("learn_xp", 0) + task.third * 10).apply()
                        updateGuided()
                        (it as Button).text = "✓"; it.isEnabled = false
                        recordSession(task.third * 60)
                    }
                })
                box.addView(row)
            }
            box.addView(a.button("Schlagmuster direkt trainieren").apply { setOnClickListener { showStrumming() } }, LinearLayout.LayoutParams(-1, a.dp(46)).apply { topMargin = a.dp(8) })
            updateGuided()
            content.addView(card)
        }

        fun showRoutine() {
            finishQuizSession(); chordTraining?.stop(); chordTraining = null; stopRhythm(); content.removeAllViews()
            val (card, box) = panel("Deine tägliche 10-Minuten-Routine", "Fünf kurze Einheiten statt einer langen Session. Hake ab, was du heute erledigt hast.")
            val day = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.GERMANY).format(java.util.Date())
            if (prefs.getString("learn_routine_day", "") != day) prefs.edit().putString("learn_routine_day", day).putInt("learn_routine_done", 0).apply()
            val tasks = listOf("2 Min. Akkordgriffe sauber aufsetzen", "3 Min. C – G – Am – F wechseln", "2 Min. Rhythmus mit Metronom", "2 Min. einen Song begleiten", "1 Min. freies Spielen")
            val progressLabel = TextView(a).apply { setTextColor(a.getColor(R.color.sw_text)); textSize = 14f }
            val progress = ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply { max = tasks.size }
            box.addView(progressLabel); box.addView(progress, LinearLayout.LayoutParams(-1, a.dp(10)).apply { bottomMargin = a.dp(8) })
            fun update(mask: Int) {
                val n = Integer.bitCount(mask); progress.progress = n
                progressLabel.text = if (n == tasks.size) "Heute komplett · 10 Minuten geschafft" else "Heute erledigt: $n von ${tasks.size}"
                prefs.edit().putInt("learn_routine_done", mask).apply(); updatePracticeStats()
            }
            tasks.forEachIndexed { index, task ->
                val cb = CheckBox(a).apply { text = task; textSize = 14f; setTextColor(a.getColor(R.color.sw_text)); isChecked = (prefs.getInt("learn_routine_done", 0) and (1 shl index)) != 0 }
                cb.setOnCheckedChangeListener { _, checked ->
                    val previous = prefs.getInt("learn_routine_done", 0)
                    var mask = previous; mask = if (checked) mask or (1 shl index) else mask and (1 shl index).inv()
                    if (checked && previous == 0) recordPracticeDay()
                    update(mask)
                }
                box.addView(cb)
            }
            update(prefs.getInt("learn_routine_done", 0))
            box.addView(a.button("Lernpfad öffnen").apply { setOnClickListener { a.openSection(6) } }, LinearLayout.LayoutParams(-1, a.dp(46)).apply { topMargin = a.dp(8) })
            content.addView(card)
        }

        overviewAction = {
            finishQuizSession(); chordTraining?.stop(); chordTraining = null; stopRhythm(); content.removeAllViews()
            content.addView(a.title("Lernstudio"))
            content.addView(a.body("Dein persönlicher Trainingsbereich für Akkorde, Rhythmus, Timing, Schlagmuster und Songs."))

            val cal = java.util.Calendar.getInstance()
            val weekKey = cal.get(java.util.Calendar.YEAR).toString() + "-" + cal.get(java.util.Calendar.WEEK_OF_YEAR).toString()
            val weekSeconds = if (prefs.getString("learn_week_key", "") == weekKey) prefs.getInt("learn_week_seconds", 0) else 0
            val weekGoal = 60 * 60
            val quick = roundedCard()
            val quickBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(14), a.dp(14), a.dp(14), a.dp(14)) }
            quickBox.addView(TextView(a).apply { text = "Schnellstart"; textSize = 18f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_text)) })
            quickBox.addView(TextView(a).apply { text = "Wähle nach deinem aktuellen Ziel."; textSize = 12f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0, a.dp(3), 0, a.dp(8)) })
            val row1 = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }; val row2 = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
            fun quickButton(text: String, action: () -> Unit): Button = a.button(text).apply { textSize = 12f; minHeight = a.dp(48); setOnClickListener { action() } }
            row1.addView(quickButton("⚡ Akkorde erkennen") { showQuiz() }, LinearLayout.LayoutParams(0, a.dp(48), 1f).apply { rightMargin = a.dp(5) })
            row1.addView(quickButton("↔ Wechsel üben") { showChanges() }, LinearLayout.LayoutParams(0, a.dp(48), 1f).apply { leftMargin = a.dp(5) })
            row2.addView(quickButton("♩ Rhythmus") { showRhythm() }, LinearLayout.LayoutParams(0, a.dp(48), 1f).apply { rightMargin = a.dp(5); topMargin = a.dp(8) })
            row2.addView(quickButton("✓ Tagesroutine") { showRoutine() }, LinearLayout.LayoutParams(0, a.dp(48), 1f).apply { leftMargin = a.dp(5); topMargin = a.dp(8) })
            val row3 = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
            row3.addView(quickButton("↘ Schlagmuster") { showStrumming() }, LinearLayout.LayoutParams(0, a.dp(48), 1f).apply { rightMargin = a.dp(5); topMargin = a.dp(8) })
            row3.addView(quickButton("♬ Song-Praxis") { showSongPractice() }, LinearLayout.LayoutParams(0, a.dp(48), 1f).apply { leftMargin = a.dp(5); topMargin = a.dp(8) })
            val row4 = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
            row4.addView(quickButton("🎯 10-Min-Session") { showGuidedSession() }, LinearLayout.LayoutParams(-1, a.dp(48)).apply { topMargin = a.dp(8) })
            quickBox.addView(row1); quickBox.addView(row2); quickBox.addView(row3); quick.addView(quickBox); content.addView(quick); addGap(10)


            val focusCard = roundedCard()
            val focusBox = LinearLayout(a).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(a.dp(14), a.dp(13), a.dp(14), a.dp(13))
            }
            val focusTitle = TextView(a).apply {
                text = "🎯 Dein Fokus heute"
                textSize = 17f
                setTypeface(typeface, 1)
                setTextColor(a.getColor(R.color.sw_text))
            }
            val focusText = TextView(a).apply {
                textSize = 13f
                setTextColor(a.getColor(R.color.sw_muted))
                setPadding(0, a.dp(3), 0, a.dp(8))
            }
            val focusButton = a.button("Jetzt trainieren").apply { minHeight = a.dp(44) }
            val quizTotal = prefs.getInt("learn_quiz_total", 0)
            val quizCorrect = prefs.getInt("learn_quiz_correct", 0)
            val quizRate = if (quizTotal > 0) quizCorrect * 100 / quizTotal else 0
            val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.GERMANY).format(java.util.Date())
            val minutesToday = if (prefs.getString("learn_daily_day", "") == today) prefs.getInt("learn_daily_minutes", 0) else 0
            val focusAction: () -> Unit = when {
                quizTotal < 5 -> {
                    focusText.text = "Starte mit dem Akkord-Blitztrainer und sammle deine ersten sicheren Treffer."
                    { showQuiz() }
                }
                quizRate < 70 -> {
                    focusText.text = "Deine Akkorderkennung ist noch ausbaufähig. Kurze, häufige Wiederholungen bringen dich weiter."
                    { showQuiz() }
                }
                prefs.getString("learn_daily_day", "") != today || minutesToday < 5 -> {
                    focusText.text = "Du hast heute noch wenig Übungszeit gesammelt. Ein kurzer Wechselblock reicht."
                    { showChanges() }
                }
                prefs.getInt("learn_strum_best_score", 0) < 250 -> {
                    focusText.text = "Dein Schlagmuster-Score ist noch ausbaufähig. Trainiere Timing und Anschlag mit kurzen, präzisen Serien."
                    { showStrumming() }
                }
                weekSeconds < 20 * 60 -> {
                    focusText.text = "Dein Wochenziel ist noch nicht halb voll. Ein kurzer Wechsel- oder Rhythmusblock bringt dich direkt weiter."
                    { showChanges() }
                }
                else -> {
                    focusText.text = "Deine Basis sitzt. Trainiere jetzt Timing und Anschlag mit einem Schlagmuster."
                    { showStrumming() }
                }
            }
            focusButton.setOnClickListener { focusAction() }
            focusBox.addView(focusTitle)
            focusBox.addView(focusText)
            focusBox.addView(focusButton, LinearLayout.LayoutParams(-1, a.dp(44)))
            focusCard.addView(focusBox)
            content.addView(focusCard)
            addGap(10)



            val xp = prefs.getInt("learn_xp", 0)
            val level = (xp / 100) + 1
            val levelXp = xp % 100
            val levelCard = roundedCard()
            val levelBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(16), a.dp(15), a.dp(16), a.dp(15)) }
            levelBox.addView(TextView(a).apply { text = "⭐ Level " + level; textSize = 22f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_copper)) })
            levelBox.addView(TextView(a).apply { text = xp.toString() + " XP · " + (100 - levelXp) + " XP bis Level " + (level + 1); textSize = 12f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0, a.dp(3), 0, a.dp(8)) })
            levelBox.addView(ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progress = levelXp }, LinearLayout.LayoutParams(-1, a.dp(10)))
            levelCard.addView(levelBox); content.addView(levelCard); addGap(8)

            val sessionCard = roundedCard()
            val sessionBox = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(a.dp(14), a.dp(12), a.dp(14), a.dp(12)) }
            val sessionText = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            sessionText.addView(TextView(a).apply { text = "🎯 Heute trainieren"; textSize = 17f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_text)) })
            sessionText.addView(TextView(a).apply { text = "Adaptive 10-Minuten-Session · passend zu deinem Lernstand"; textSize = 12f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0, a.dp(2), 0, 0) })
            sessionBox.addView(sessionText, LinearLayout.LayoutParams(0, -2, 1f))
            sessionBox.addView(a.button("Start").apply { setOnClickListener { showGuidedSession() } }, LinearLayout.LayoutParams(a.dp(86), a.dp(44)))
            sessionCard.addView(sessionBox); content.addView(sessionCard); addGap(10)
            val streak = prefs.getInt("learn_streak", 0)
            val hero = roundedCard()
            val heroBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(16), a.dp(15), a.dp(16), a.dp(15)) }
            heroBox.addView(TextView(a).apply { text = if (streak > 0) "🔥 $streak Tage Lernserie" else "Heute ist ein guter Tag zum Üben"; textSize = 19f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_copper)) })
            heroBox.addView(TextView(a).apply { tag = "learnToday"; textSize = 13f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0, a.dp(4), 0, a.dp(8)) })
            heroBox.addView(ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply { tag = "learnTodayProgress"; max = 5 }, LinearLayout.LayoutParams(-1, a.dp(10)))
            hero.addView(heroBox); content.addView(hero); addGap(8)

            val stats = LinearLayout(a).apply { tag = "learnStats"; orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(a.dp(4), a.dp(2), a.dp(4), a.dp(2)) }
            val statsCard = roundedCard(); statsCard.addView(stats); content.addView(statsCard); addGap(10)

            val weekCard = roundedCard()
            val weekBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(14), a.dp(13), a.dp(14), a.dp(13)) }
            val weekLabel = TextView(a).apply {
                text = (weekSeconds / 60).coerceAtMost(60).toString() + "/60 Minuten · " + if (weekSeconds >= weekGoal) "Ziel erreicht 🎉" else ((weekGoal - weekSeconds).coerceAtLeast(0) / 60).toString() + " Min. übrig"
                textSize = 12f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0, a.dp(3), 0, a.dp(7))
            }
            weekBox.addView(TextView(a).apply { text = "📅 Wochenziel"; textSize = 17f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_text)) })
            weekBox.addView(weekLabel)
            weekBox.addView(ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progress = ((weekSeconds.toFloat() / weekGoal).coerceIn(0f, 1f) * 100).toInt() }, LinearLayout.LayoutParams(-1, a.dp(10)))
            weekBox.addView(a.body("60 Minuten pro Woche · kleine Einheiten zählen genauso.", 11f))
            weekCard.addView(weekBox); content.addView(weekCard); addGap(10)

            val skillCard = roundedCard()
            val skillBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(14), a.dp(13), a.dp(14), a.dp(13)) }
            skillBox.addView(TextView(a).apply { text = "🏆 Deine Skills"; textSize = 17f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_text)) })
            skillBox.addView(a.body("Jede Trainingseinheit stärkt deinen persönlichen Lernpfad.", 12f))
            fun skillRow(name: String, value: Int, detail: String) {
                val row = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(0, a.dp(5), 0, a.dp(3)) }
                val head = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
                head.addView(TextView(a).apply { text = name; textSize = 13f; setTextColor(a.getColor(R.color.sw_text)) }, LinearLayout.LayoutParams(0, -2, 1f))
                head.addView(TextView(a).apply { text = "Level " + value; textSize = 12f; setTextColor(a.getColor(R.color.sw_copper)) })
                row.addView(head)
                row.addView(TextView(a).apply { text = detail; textSize = 10f; setTextColor(a.getColor(R.color.sw_muted)) })
                skillBox.addView(row)
            }
            val chordLevel = (1 + prefs.getInt("learn_quiz_correct", 0) / 5).coerceAtMost(5)
            val changeLevel = (1 + prefs.getInt("learn_skill_changes", 0) / 3).coerceAtMost(5)
            val rhythmLevel = (1 + prefs.getInt("learn_skill_rhythm", 0) / 3).coerceAtMost(5)
            val strumLevel = (1 + prefs.getInt("learn_strum_best_score", 0) / 300).coerceAtMost(5)
            skillRow("Akkorde", chordLevel, "Treffer: " + prefs.getInt("learn_quiz_correct", 0))
            skillRow("Akkordwechsel", changeLevel, "Trainerstarts: " + prefs.getInt("learn_skill_changes", 0))
            skillRow("Rhythmus", rhythmLevel, "Metronom-Sessions: " + prefs.getInt("learn_skill_rhythm", 0))
            skillRow("Schlagmuster", strumLevel, "Bestscore: " + prefs.getInt("learn_strum_best_score", 0))
            skillCard.addView(skillBox); content.addView(skillCard); addGap(10)

            // Kleine, nachvollziehbare Meilensteine motivieren ohne künstliche Trainerstarts zu belohnen.
            val quizAttempts = prefs.getInt("learn_quiz_total", 0)
            val quizHits = prefs.getInt("learn_quiz_correct", 0)
            val quizAccuracy = if (quizAttempts > 0) quizHits * 100 / quizAttempts else 0
            val sessions = prefs.getInt("learn_sessions", 0)
            val strumBest = prefs.getInt("learn_strum_best_score", 0)
            val achievements = listOf(
                Triple("Erster Schritt", sessions >= 1, "Erste Übungszeit gesammelt"),
                Triple("Dranbleiber", sessions >= 10, "$sessions von 10 Übungseinheiten"),
                Triple("Wochenprofi", weekSeconds >= weekGoal, (weekSeconds / 60).coerceAtMost(60).toString() + " von 60 Wochenminuten"),
                Triple("Lernserie", prefs.getInt("learn_streak", 0) >= 5, prefs.getInt("learn_streak", 0).toString() + " von 5 Tagen in Folge"),
                Triple("Akkord-Sicherheit", quizAttempts >= 10 && quizAccuracy >= 80, quizAccuracy.toString() + "% Treffer · mindestens 80% bei 10 Fragen"),
                Triple("Timing-Meister", strumBest >= 500, strumBest.toString() + " von 500 Schlagmuster-Punkten")
            )
            val earned = achievements.count { it.second }
            val achievementCard = roundedCard()
            val achievementBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(14), a.dp(13), a.dp(14), a.dp(13)) }
            achievementBox.addView(TextView(a).apply {
                text = "🏅 Erfolge · $earned/${achievements.size}"
                textSize = 17f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_text))
            })
            achievementBox.addView(a.body("Echte Lernfortschritte schalten diese Meilensteine frei.", 11f))
            val achievementGrid = GridLayout(a).apply { columnCount = 2; useDefaultMargins = false }
            achievements.forEach { achievement ->
                val cell = LinearLayout(a).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(a.dp(8), a.dp(8), a.dp(6), a.dp(8))
                    background = android.graphics.drawable.GradientDrawable().apply {
                        setColor(a.getColor(if (achievement.second) R.color.sw_surface else R.color.sw_surface))
                        cornerRadius = a.dp(10).toFloat()
                    }
                }
                cell.addView(TextView(a).apply {
                    text = (if (achievement.second) "✓  " else "○  ") + achievement.first
                    textSize = 12f; setTypeface(typeface, 1)
                    setTextColor(a.getColor(if (achievement.second) R.color.sw_copper else R.color.sw_text))
                })
                cell.addView(TextView(a).apply {
                    text = achievement.third; textSize = 10f
                    setTextColor(a.getColor(R.color.sw_muted))
                })
                achievementGrid.addView(cell, GridLayout.LayoutParams().apply {
                    width = 0; height = -2
                    columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                    setMargins(a.dp(3), a.dp(3), a.dp(3), a.dp(3))
                })
            }
            achievementBox.addView(achievementGrid)
            achievementCard.addView(achievementBox); content.addView(achievementCard); addGap(10)

            // Adaptive Tagesfokus: Die Startseite schlägt anhand des bisherigen Lernstands
            // automatisch den sinnvollsten nächsten Schwerpunkt vor.



            val path = roundedCard()
            val pathBox = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(a.dp(14), a.dp(12), a.dp(12), a.dp(12)) }
            val pathText = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
            pathText.addView(TextView(a).apply { text = "Dein Lernpfad"; textSize = 17f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_text)) })
            pathText.addView(TextView(a).apply { text = "Lernstufen, persönliches Ziel und langfristiger Fortschritt"; textSize = 12f; setTextColor(a.getColor(R.color.sw_muted)); setPadding(0, a.dp(3), 0, 0) })
            pathBox.addView(pathText, LinearLayout.LayoutParams(0, -2, 1f))
            pathBox.addView(a.button("Öffnen").apply { setOnClickListener { a.openSection(6) } }, LinearLayout.LayoutParams(a.dp(92), a.dp(44)))
            path.addView(pathBox); content.addView(path); updatePracticeStats()
        }

        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        overviewAction?.invoke()
        return root
    }

    private fun finishQuizSession() {
        val started = quizStartedAt
        quizStartedAt = 0L
        if (started > 0L) onSessionElapsed?.invoke(((android.os.SystemClock.elapsedRealtime() - started) / 1000L).toInt().coerceAtLeast(1))
    }

    private fun stopStrumming() {
        val started = strumStartedAt
        strumStartedAt = 0L
        strumRunning = false
        strumHandler?.removeCallbacksAndMessages(null)
        strumHandler = null
        if (started > 0L) onSessionElapsed?.invoke(((android.os.SystemClock.elapsedRealtime() - started) / 1000L).toInt().coerceAtLeast(1))
        GuitarAudioEngine.stopAll()
    }

    private fun stopRhythm() {
        val started = rhythmStartedAt
        rhythmStartedAt = 0L
        rhythmRunning = false; rhythmHandler?.removeCallbacksAndMessages(null); rhythmHandler = null
        if (started > 0L) onSessionElapsed?.invoke(((android.os.SystemClock.elapsedRealtime() - started) / 1000L).toInt().coerceAtLeast(1))
        GuitarAudioEngine.stopAll()
    }
}
class PathFragment : Fragment() {
    override fun onCreateView(i: android.view.LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        val a = requireActivity() as MainActivity; val prefs = a.getSharedPreferences("saitenwerk", 0)
        val root = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        root.addView(a.title("Dein Lernpfad")); root.addView(a.body("Vom ersten Griff bis zum selbstständigen Spielen ganzer Songs. Du bestimmst dein Tempo – dein Fortschritt bleibt auf diesem Gerät gespeichert."))
        val stages = listOf(
            "Erste Akkorde" to "Lerne C, G, D, A, E sowie Am und Em kennen. Ziel: jeden Griff ruhig und einzeln aufsetzen.",
            "Saubere Griffbilder" to "Achte auf gekrümmte Finger, kurze Fingernägel und darauf, dass jede Saite klar klingt.",
            "Flüssige Wechsel" to "Verbinde zwei Akkorde zunächst langsam. Steigere das Tempo erst, wenn der Wechsel sicher sitzt.",
            "Rhythmus festigen" to "Halte einen gleichmäßigen Viertelpuls und übe den Wechsel ohne den Schlagfluss zu unterbrechen.",
            "Erste Songs begleiten" to "Wähle ein einfaches Lied und spiele die Akkordfolge langsam im passenden Takt.",
            "Selbstständig spielen" to "Spiele einen Song vom Anfang bis zum Ende und finde bei Bedarf selbst zurück in den Ablauf."
        )
        val key = "learning_path_done"
        val progressLabel = TextView(a).apply { setTextColor(a.getColor(R.color.sw_copper)); textSize = 17f; setPadding(a.dp(20), a.dp(8), a.dp(20), a.dp(8)) }
        val progress = ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply { max = stages.size }
        root.addView(progressLabel); root.addView(progress, LinearLayout.LayoutParams(-1, a.dp(10)).apply { setMargins(a.dp(20), 0, a.dp(20), a.dp(14)) })
        fun refresh() { val mask = prefs.getInt(key, 0); val count = Integer.bitCount(mask); progress.progress = count; progressLabel.text = "$count von ${stages.size} Lernstufen abgeschlossen · ${count * 100 / stages.size}%" }
        val goalCard = a.card(); val goalBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(16), a.dp(14), a.dp(16), a.dp(14)) }
        goalBox.addView(TextView(a).apply { text = "Mein persönliches Lernziel"; textSize = 19f; setTextColor(a.getColor(R.color.sw_copper)); setTypeface(typeface, 1) })
        val goal = EditText(a).apply { setText(prefs.getString("learning_path_goal", "")); hint = "z. B. In vier Wochen drei Songs begleiten"; setTextColor(a.getColor(R.color.sw_text)); setHintTextColor(a.getColor(R.color.sw_muted)); minLines = 2 }
        goalBox.addView(goal)
        val save = a.button("Lernziel speichern"); save.setOnClickListener { prefs.edit().putString("learning_path_goal", goal.text.toString().trim()).apply(); Toast.makeText(a, "Lernziel gespeichert", Toast.LENGTH_SHORT).show() }
        goalBox.addView(save); goalCard.addView(goalBox); root.addView(goalCard, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(16), 0, a.dp(16), a.dp(14)) })
        val next = a.body("").apply { textSize = 16f; setTextColor(a.getColor(R.color.sw_text)) }; root.addView(next)
        val checks = mutableListOf<CheckBox>()
        stages.forEachIndexed { index, stage ->
            val card = a.card(); val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(a.dp(14), a.dp(12), a.dp(14), a.dp(12)) }
            box.addView(TextView(a).apply { text = "${index + 1}. ${stage.first}"; textSize = 18f; setTypeface(typeface, 1); setTextColor(a.getColor(R.color.sw_text)) })
            box.addView(a.body(stage.second, 14f))
            val check = CheckBox(a).apply { text = "Lernstufe abgeschlossen"; setTextColor(a.getColor(R.color.sw_text)); isChecked = (prefs.getInt(key, 0) and (1 shl index)) != 0 }; checks.add(check)
            check.setOnCheckedChangeListener { _, checked ->
                var mask = prefs.getInt(key, 0); mask = if (checked) mask or (1 shl index) else mask and (1 shl index).inv(); prefs.edit().putInt(key, mask).apply(); refresh()
                val first = stages.indices.firstOrNull { (mask and (1 shl it)) == 0 }; next.text = if (first == null) "Geschafft! Alle Lernstufen sind abgeschlossen." else "Dein nächster Schritt: ${stages[first].first}"
            }
            box.addView(check); val practice = a.button("Im Lernstudio üben"); practice.setOnClickListener { a.openSection(5) }; box.addView(practice)
            card.addView(box); root.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(a.dp(16), a.dp(5), a.dp(16), a.dp(5)) })
        }
        val reset = a.button("Lernpfad zurücksetzen"); reset.setOnClickListener { prefs.edit().putInt(key, 0).apply(); checks.forEach { it.isChecked = false }; refresh(); next.text = "Dein nächster Schritt: ${stages.first().first}"; Toast.makeText(a, "Lernpfad zurückgesetzt", Toast.LENGTH_SHORT).show() }
        root.addView(reset, LinearLayout.LayoutParams(-1, a.dp(48)).apply { setMargins(a.dp(16), a.dp(12), a.dp(16), a.dp(24)) })
        refresh(); val mask = prefs.getInt(key, 0); val first = stages.indices.firstOrNull { (mask and (1 shl it)) == 0 }; next.text = if (first == null) "Geschafft! Alle Lernstufen sind abgeschlossen." else "Dein nächster Schritt: ${stages[first].first}"
        return ScrollView(a).apply { addView(root) }
    }
}
