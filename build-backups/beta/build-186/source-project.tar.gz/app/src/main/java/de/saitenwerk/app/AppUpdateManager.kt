package de.saitenwerk.app

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.appcompat.app.AlertDialog
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/** Checks the current Beta release and offers an Android-approved APK install. */
class AppUpdateManager(private val activity: MainActivity) {
    private val prefs = activity.getSharedPreferences("saitenwerk_updates", Context.MODE_PRIVATE)
    private val executor = Executors.newSingleThreadExecutor()
    private var receiverRegistered = false

    fun checkForUpdates() {
        executor.execute {
            try {
                val release = fetchBetaRelease()
                    ?: throw IllegalStateException("Kein veröffentlichter Beta-Release gefunden")

                val body = release.optString("body")
                val remoteCode = Regex("""(?m)^versionCode\s*=\s*(\d+)\s*$""")
                    .find(body)?.groupValues?.get(1)?.toLongOrNull()
                    ?: release.optLong("target_commitish", -1L).takeIf { it >= 0L }
                    ?: throw IllegalStateException("Release enthält keine verwertbare Versionsnummer")

                val currentCode = installedVersionCode()
                if (remoteCode <= currentCode) {
                    showMessage("Saitenwerk ist aktuell", "Du verwendest bereits die neueste verfügbare Version.")
                    return@execute
                }

                val assets = release.optJSONArray("assets") ?: throw IllegalStateException("Release enthält keine APK")
                var apkUrl: String? = null
                var apkName: String? = null
                for (i in 0 until assets.length()) {
                    val item = assets.optJSONObject(i) ?: continue
                    val name = item.optString("name")
                    if (name == APK_NAME || name.endsWith(".apk", ignoreCase = true)) {
                        apkUrl = item.optString("browser_download_url").takeIf { it.isNotBlank() }
                        apkName = name
                        if (name == APK_NAME) break
                    }
                }
                val url = apkUrl ?: throw IllegalStateException("Keine APK im Release gefunden")
                val versionName = Regex("""(?m)^versionName=(.+)$""").find(body)?.groupValues?.get(1)?.trim()
                    .orEmpty().ifBlank { release.optString("name") }

                activity.runOnUiThread {
                    if (!activity.isFinishing && !activity.isDestroyed) {
                        AlertDialog.Builder(activity)
                            .setTitle("Saitenwerk-Update verfügbar")
                            .setMessage("Eine neue Version${if (versionName.isNotBlank()) " ($versionName)" else ""} ist verfügbar. Möchtest du sie jetzt herunterladen?")
                            .setNegativeButton("Später", null)
                            .setPositiveButton("Jetzt aktualisieren") { _, _ -> download(url, apkName ?: APK_NAME) }
                            .show()
                    }
                }
            } catch (e: Exception) {
                showMessage(
                    "Update-Prüfung nicht möglich",
                    "Das Update konnte nicht geprüft werden. ${e.message ?: "Bitte prüfe deine Internetverbindung und versuche es erneut."}"
                )
            }
        }
    }

    private fun fetchBetaRelease(): JSONObject? {
        val connection = (URL(RELEASES_API).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 15000
            instanceFollowRedirects = true
            requestMethod = "GET"
            setRequestProperty("Accept", "application/vnd.github+json")
            setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
            setRequestProperty("User-Agent", "Saitenwerk-Android-App")
            setRequestProperty("Cache-Control", "no-cache")
        }
        return try {
            val code = connection.responseCode
            if (code !in 200..299) {
                val detail = connection.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                val suffix = if (detail.isNotBlank()) ": $detail" else ""
                throw IllegalStateException("GitHub antwortet mit HTTP $code$suffix")
            }
            val release = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
            if (release.optString("tag_name") != RELEASE_TAG || release.optBoolean("draft", false)) null else release
        } finally { connection.disconnect() }
    }

    private fun showMessage(title: String, message: String) {
        activity.runOnUiThread {
            if (!activity.isFinishing && !activity.isDestroyed) {
                AlertDialog.Builder(activity)
                    .setTitle(title)
                    .setMessage(message)
                    .setPositiveButton("OK", null)
                    .show()
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun installedVersionCode(): Long {
        val info = activity.packageManager.getPackageInfo(activity.packageName, 0)
        return if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
    }

    private fun download(url: String, fileName: String = APK_NAME) {
        try {
            val request = DownloadManager.Request(Uri.parse(url))
                .setTitle("Saitenwerk wird aktualisiert")
                .setDescription("Neue Beta-Version wird heruntergeladen")
                .setMimeType("application/vnd.android.package-archive")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalFilesDir(activity, Environment.DIRECTORY_DOWNLOADS, fileName)
            val manager = activity.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val id = manager.enqueue(request)
            prefs.edit().putLong(KEY_DOWNLOAD_ID, id).putString(KEY_DOWNLOAD_FILE, fileName).apply()
            registerReceiver()
            AlertDialog.Builder(activity).setTitle("Download gestartet")
                .setMessage("Saitenwerk lädt das Update herunter. Nach Abschluss öffnet sich der Android-Installationsdialog.")
                .setPositiveButton("OK", null).show()
        } catch (_: Exception) {
            AlertDialog.Builder(activity).setMessage("Das Update konnte nicht gestartet werden. Bitte prüfe deine Internetverbindung.")
                .setPositiveButton("OK", null).show()
        }
    }

    @Suppress("DEPRECATION")
    private fun registerReceiver() {
        if (receiverRegistered) return
        val filter = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
        if (Build.VERSION.SDK_INT >= 33) activity.registerReceiver(downloadReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else activity.registerReceiver(downloadReceiver, filter)
        receiverRegistered = true
    }

    private val downloadReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val id = intent?.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L) ?: -1L
            if (id != prefs.getLong(KEY_DOWNLOAD_ID, -2L)) return
            completeDownloadIfReady(id)
        }
    }

    fun resumePendingInstall() {
        if (prefs.getString(KEY_PENDING_APK, null) != null) {
            installIfAllowed()
            return
        }
        val id = prefs.getLong(KEY_DOWNLOAD_ID, -1L)
        if (id >= 0L) {
            val manager = activity.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.query(DownloadManager.Query().setFilterById(id)).use { cursor ->
                if (cursor.moveToFirst() && cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) == DownloadManager.STATUS_SUCCESSFUL) {
                    completeDownloadIfReady(id)
                }
            }
        }
    }

    private fun completeDownloadIfReady(id: Long) {
        if (id != prefs.getLong(KEY_DOWNLOAD_ID, -2L)) return
        val fileName = prefs.getString(KEY_DOWNLOAD_FILE, APK_NAME) ?: APK_NAME
        val file = File(activity.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), fileName)
        if (file.exists() && file.length() > 0L) {
            val consumed = prefs.edit()
                .putString(KEY_PENDING_APK, file.absolutePath)
                .remove(KEY_DOWNLOAD_ID)
                .remove(KEY_DOWNLOAD_FILE)
                .commit()
            if (consumed) installIfAllowed()
        }
    }

    fun dispose() {
        if (receiverRegistered) {
            try { activity.unregisterReceiver(downloadReceiver) } catch (_: Exception) { }
            receiverRegistered = false
        }
        executor.shutdown()
    }

    private fun installIfAllowed() {
        val path = prefs.getString(KEY_PENDING_APK, null) ?: return
        val file = File(path)
        if (!file.exists()) { prefs.edit().remove(KEY_PENDING_APK).apply(); return }
        if (Build.VERSION.SDK_INT >= 26 && !activity.packageManager.canRequestPackageInstalls()) {
            AlertDialog.Builder(activity)
                .setTitle("Installation erlauben")
                .setMessage("Android benötigt einmalig die Erlaubnis, Updates für Saitenwerk zu installieren. Aktiviere „Aus dieser Quelle zulassen“ und kehre anschließend zu Saitenwerk zurück.")
                .setNegativeButton("Später", null)
                .setPositiveButton("Einstellungen öffnen") { _, _ ->
                    activity.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${activity.packageName}")))
                }.show()
            return
        }
        try {
            val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.fileprovider", file)
            val install = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            // Pending-APK vor dem Installer-Start atomar verbrauchen.
            val consumed = prefs.edit().remove(KEY_PENDING_APK).commit()
            if (!consumed) throw IllegalStateException("Installationsstatus konnte nicht zurückgesetzt werden.")
            try {
                activity.startActivity(install)
            } catch (e: Exception) {
                prefs.edit().putString(KEY_PENDING_APK, file.absolutePath).commit()
                throw e
            }        } catch (_: Exception) {
            AlertDialog.Builder(activity).setMessage("Der Android-Installationsdialog konnte nicht geöffnet werden. Bitte versuche es erneut.")
                .setPositiveButton("OK", null).show()
        }
    }

    companion object {
        private const val RELEASES_API = "https://api.github.com/repos/davelg-cmd/Saitenwerk---Die-native-Android-Gitarrenlern-App/releases/tags/beta-latest"
        private const val RELEASE_TAG = "beta-latest"
        private const val APK_NAME = "saitenwerk-beta.apk"
        private const val KEY_DOWNLOAD_ID = "download_id"
        private const val KEY_DOWNLOAD_FILE = "download_file"
        private const val KEY_PENDING_APK = "pending_apk"
    }
}
