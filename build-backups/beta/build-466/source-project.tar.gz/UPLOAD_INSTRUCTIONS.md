# Saitenwerk – Premium-Songbook

Der Quellstand basiert auf Build 436. Das persönliche PDF wird vollständig auf dem Gerät importiert: 452 Songs, vollständige Songseiten, Text/Akkorde und Original-PDF-Seiten. Die PDF-Datei selbst bleibt absichtlich außerhalb des öffentlichen Repositorys.

Nach Installation: Lieder → Eigenes Songbook-PDF importieren.
