package de.saitenwerk.app

import androidx.appcompat.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.net.Uri
import android.provider.OpenableColumns
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import com.google.android.gms.common.api.Scope
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import androidx.activity.result.IntentSenderRequest
import android.app.Activity
import androidx.fragment.app.Fragment
import org.json.JSONArray
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.util.Locale
import java.util.concurrent.Executors
import java.util.regex.Pattern

data class SongbookSong(
    val id: Long = 0,
    val title: String,
    val artist: String,
    val lyrics: String,
    val chords: List<String>,
    val source: String,
    val youtubeId: String? = null,
    val youtubeConfidence: Int = 0
)

data class ImportedSongbookPdf(
    val uri: String,
    val displayName: String,
    val importedAt: Long,
    val songCount: Int
)

class SongbookDb(context: Context) {
    private val db = context.openOrCreateDatabase("saitenwerk_songbook.db", Context.MODE_PRIVATE, null)
    init {
        db.execSQL("""CREATE TABLE IF NOT EXISTS songs(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            artist TEXT NOT NULL,
            lyrics TEXT NOT NULL,
            chords TEXT NOT NULL,
            source TEXT NOT NULL,
            youtube_id TEXT,
            youtube_confidence INTEGER NOT NULL DEFAULT 0,
            UNIQUE(title, artist)
        )""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS imported_pdfs(
            uri TEXT PRIMARY KEY,
            display_name TEXT NOT NULL,
            imported_at INTEGER NOT NULL,
            song_count INTEGER NOT NULL DEFAULT 0
        )""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS song_pdf_sources(
            song_id INTEGER NOT NULL,
            pdf_uri TEXT NOT NULL,
            PRIMARY KEY(song_id, pdf_uri)
        )""")
        db.execSQL("INSERT OR IGNORE INTO song_pdf_sources(song_id,pdf_uri) SELECT id,source FROM songs WHERE source IS NOT NULL AND source <> ''")
    }
    fun registerPdf(uri: String, displayName: String, songCount: Int) {
        val cv = android.content.ContentValues().apply {
            put("uri", uri); put("display_name", displayName)
            put("imported_at", System.currentTimeMillis()); put("song_count", songCount)
        }
        db.insertWithOnConflict("imported_pdfs", null, cv, android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun replacePdfSongs(uri: String, songs: List<SongbookSong>): Int {
        db.beginTransaction()
        try {
            val oldIds = linkedSetOf<Long>()
            db.rawQuery("SELECT song_id FROM song_pdf_sources WHERE pdf_uri=?", arrayOf(uri)).use { cursor ->
                while (cursor.moveToNext()) oldIds += cursor.getLong(0)
            }
            val newIds = linkedSetOf<Long>()
            songs.forEach { newIds += upsert(it) }
            db.delete("song_pdf_sources", "pdf_uri=?", arrayOf(uri))
            newIds.forEach { id ->
                db.execSQL("INSERT OR IGNORE INTO song_pdf_sources(song_id,pdf_uri) VALUES(?,?)", arrayOf(id, uri))
            }
            (oldIds - newIds).forEach { id ->
                val referenceCount = db.rawQuery(
                    "SELECT COUNT(*) FROM song_pdf_sources WHERE song_id=?",
                    arrayOf(id.toString())
                ).use { cursor -> if (cursor.moveToFirst()) cursor.getInt(0) else 0 }
                if (referenceCount == 0) db.delete("songs", "id=?", arrayOf(id.toString()))
            }
            db.setTransactionSuccessful()
            return newIds.size
        } finally {
            db.endTransaction()
        }
    }

    fun importedPdfs(): List<ImportedSongbookPdf> {
        val out = mutableListOf<ImportedSongbookPdf>()
        db.rawQuery("SELECT uri,display_name,imported_at,song_count FROM imported_pdfs ORDER BY imported_at DESC", null).use { c ->
            while (c.moveToNext()) out += ImportedSongbookPdf(c.getString(0), c.getString(1), c.getLong(2), c.getInt(3))
        }
        return out
    }
    fun removePdf(uri: String): Int {
        db.beginTransaction()
        try {
            db.delete("song_pdf_sources", "pdf_uri=?", arrayOf(uri))
            val removed = db.delete("songs", "id NOT IN (SELECT song_id FROM song_pdf_sources)", null)
            db.delete("imported_pdfs", "uri=?", arrayOf(uri))
            db.setTransactionSuccessful()
            return removed
        } finally { db.endTransaction() }
    }
    fun upsert(song: SongbookSong): Long {
        val cv = android.content.ContentValues().apply {
            put("title", song.title); put("artist", song.artist); put("lyrics", song.lyrics)
            put("chords", JSONArray(song.chords).toString()); put("source", song.source)
            song.youtubeId?.let { put("youtube_id", it); put("youtube_confidence", song.youtubeConfidence) }
        }
        val existing = db.rawQuery("SELECT id FROM songs WHERE lower(title)=lower(?) AND lower(artist)=lower(?)",
            arrayOf(song.title, song.artist))
        val id = if (existing.moveToFirst()) {
            val value = existing.getLong(0); existing.close()
            db.update("songs", cv, "id=?", arrayOf(value.toString())); value
        } else {
            existing.close(); db.insertOrThrow("songs", null, cv)
        }
        db.execSQL("INSERT OR IGNORE INTO song_pdf_sources(song_id,pdf_uri) VALUES(?,?)", arrayOf(id, song.source))
        return id
    }
    fun all(): List<SongbookSong> {
        val out = mutableListOf<SongbookSong>()
        db.rawQuery("SELECT id,title,artist,lyrics,chords,source,youtube_id,youtube_confidence FROM songs ORDER BY title COLLATE NOCASE", null).use { c ->
            while (c.moveToNext()) {
                val chords = mutableListOf<String>()
                runCatching { val a=JSONArray(c.getString(4)); for(i in 0 until a.length()) chords += a.getString(i) }
                out += SongbookSong(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), chords, c.getString(5),
                    if(c.isNull(6)) null else c.getString(6), c.getInt(7))
            }
        }
        return out
    }
}

object SongbookParser {
    private data class TocEntry(val number: Int, val label: String, val page: Int)

    private val tocLinePattern = Regex("""^\s*(\d{1,3})\s*[.)]\s*(.+?)\s*(?:[.·…]\s*){3,}\s*(\d{1,3})\s*$""")
    private val chordPattern = Pattern.compile("""(?<![A-Za-z0-9])([A-Ga-g](?:#|b)?(?:maj(?:7|9|11|13)?|m(?:aj7|7|9|11|13)?|m9|sus[24]?|add9|dim7?|aug|[0-9]{1,2})?(?:/[A-Ga-g](?:#|b)?)?)(?![A-Za-z0-9])""")

    fun parse(text: String, source: String): List<SongbookSong> {
        val normalized = text.replace("\r\n", "\n").replace('\r', '\n').filter { it.code != 0 }.trim()
        if (normalized.isBlank()) return emptyList()
        val pages = splitPages(normalized)
        val indexed = parseFromContents(pages, source)
        if (indexed.isNotEmpty()) return indexed
        return parseHeuristically(normalized, source)
    }

    private fun splitPages(text: String): Map<Int, String> {
        val marker = Regex("""\[\[SAITENWERK_SEITE_(\d+)]]""")
        val matches = marker.findAll(text).toList()
        if (matches.isEmpty()) return mapOf(1 to text)
        val pages = linkedMapOf<Int, String>()
        matches.forEachIndexed { index, match ->
            val start = match.range.last + 1
            val end = matches.getOrNull(index + 1)?.range?.first ?: text.length
            val pageNumber = match.groupValues[1].toIntOrNull() ?: (index + 1)
            pages[pageNumber] = text.substring(start, end).trim()
        }
        return pages
    }

    private fun parseFromContents(pages: Map<Int, String>, source: String): List<SongbookSong> {
        val entries = mutableListOf<TocEntry>()
        var lastContentsPage = 0
        for ((pageNumber, pageText) in pages.toSortedMap()) {
            if (pageNumber > 20) break
            var foundOnPage = false
            for (rawLine in pageText.lines()) {
                val line = rawLine.replace('\u00A0', ' ').trim()
                val match = tocLinePattern.matchEntire(line) ?: continue
                val number = match.groupValues[1].toIntOrNull() ?: continue
                val label = match.groupValues[2].replace(Regex("""\s+"""), " ").trim()
                val songPage = match.groupValues[3].toIntOrNull() ?: continue
                if (number > 0 && songPage > 1 && label.isNotBlank()) {
                    entries += TocEntry(number, label, songPage)
                    foundOnPage = true
                }
            }
            if (foundOnPage) lastContentsPage = pageNumber
        }

        val ordered = entries.sortedBy { it.number }
        if (ordered.size < 3) return emptyList()
        if (ordered.indices.any { ordered[it].number != it + 1 }) return emptyList()
        val lastPdfPage = pages.keys.maxOrNull() ?: return emptyList()
        if (ordered.first().page <= lastContentsPage || ordered.last().page > lastPdfPage) return emptyList()
        if (ordered.zipWithNext().any { it.first.page >= it.second.page }) return emptyList()

        val duplicateCounts = HashMap<String, Int>()
        val result = mutableListOf<SongbookSong>()
        ordered.forEachIndexed { index, entry ->
            val endExclusive = ordered.getOrNull(index + 1)?.page ?: (lastPdfPage + 1)
            val rawBody = (entry.page until endExclusive)
                .mapNotNull { pages[it] }
                .joinToString("\n")
            val body = rawBody.lines()
                .filterNot { isPdfFooter(it) }
                .joinToString("\n")
                .trim()

            val (baseTitle, artist) = splitTitleAndArtist(entry.label)
            val key = baseTitle.lowercase(Locale.ROOT) + "|" + artist.lowercase(Locale.ROOT)
            val occurrence = (duplicateCounts[key] ?: 0) + 1
            duplicateCounts[key] = occurrence
            // Keep every numbered contents entry, including alternate arrangements with duplicate titles.
            val title = if (occurrence == 1) baseTitle else baseTitle + " (Eintrag " + entry.number + ")"
            val lyrics = body.ifBlank { "Inhalt auf PDF-Seite " + entry.page + " konnte nicht ausgelesen werden." }
            result += SongbookSong(
                title = title.take(120),
                artist = artist.take(100),
                lyrics = lyrics,
                chords = extractChords(body),
                source = source
            )
        }
        return result
    }

    private fun splitTitleAndArtist(label: String): Pair<String, String> {
        val clean = label.replace(Regex("""\s+"""), " ").trim()
        val parenthetical = Regex("""^(.*?)\s+\(([^()]*)\)\s*$""").matchEntire(clean)
        if (parenthetical != null && parenthetical.groupValues[1].isNotBlank()) {
            return parenthetical.groupValues[1].trim() to parenthetical.groupValues[2].trim()
        }
        val separator = clean.lastIndexOf(" - ")
        if (separator > 0 && separator < clean.length - 3) {
            return clean.substring(0, separator).trim() to clean.substring(separator + 3).trim()
        }
        return clean to "Unbekannter Künstler"
    }

    private fun isPdfFooter(line: String): Boolean {
        val value = line.trim()
        return value.contains("Songbook vom", ignoreCase = true) ||
            value.contains("Lyricsarchiv.de", ignoreCase = true) ||
            Regex("""(?i)\bseite\s+\d+\s+von\s+\d+\b""").containsMatchIn(value)
    }

    private fun extractChords(block: String): List<String> {
        val chords = linkedSetOf<String>()
        block.lines().forEach { line ->
            if (!looksLikeChordLine(line)) return@forEach
            line.trim().split(Regex("""\s+""")).forEach { token ->
                val cleaned = token.trim(',', ';', ':', '.', '|', '(', ')', '[', ']')
                if (chordPattern.matcher(cleaned).matches()) {
                    val chord = if (cleaned.length == 1 && cleaned[0] in 'a'..'g') {
                        cleaned.uppercase(Locale.ROOT) + "m"
                    } else {
                        cleaned.replaceFirstChar { it.uppercase() }
                    }
                    chords += chord
                }
            }
        }
        return chords.toList()
    }

    private fun looksLikeChordLine(line: String): Boolean {
        val words = line.trim().split(Regex("""\s+""")).filter { it.isNotBlank() }
        if (words.isEmpty() || words.size > 24) return false
        val matches = words.count { token ->
            val cleaned = token.trim(',', ';', ':', '.', '|', '(', ')', '[', ']')
            chordPattern.matcher(cleaned).matches()
        }
        return matches >= maxOf(1, (words.size + 1) / 2)
    }

    private fun parseHeuristically(text: String, source: String): List<SongbookSong> {
        val pages = splitPages(text)
        val blocks = mutableListOf<String>()
        pages.toSortedMap().values.forEach { page ->
            val lines = page.lines()
            val starts = mutableListOf<Int>()
            lines.forEachIndexed { index, raw ->
                val line = raw.trim()
                if (!isTitle(line)) return@forEachIndexed
                val numbered = line.matches(Regex("""(?i)^(?:(?:lied|song)\s*)?\d{1,3}\s*[.)\-:]?\s+\S.*$"""))
                val marked = raw.trimStart().startsWith("#") || line.startsWith("♪") || line.startsWith("♫")
                val upper = line.count { it.isLetter() } >= 3 && line.filter { it.isLetter() }.all { !it.isLowerCase() }
                val before = index == 0 || lines.getOrNull(index - 1).isNullOrBlank() ||
                    lines.getOrNull(index - 1)?.trim()?.matches(Regex("""[-_=*~•·]{3,}""")) == true
                val after = lines.getOrNull(index + 1).isNullOrBlank()
                val score = (if (before) 1 else 0) + (if (after) 1 else 0) +
                    (if (numbered) 3 else 0) + (if (marked) 3 else 0) +
                    (if (upper) 2 else 0) +
                    (if (line.length <= 58 && !line.endsWith(".") && !line.endsWith(",")) 1 else 0)
                val hasBody = lines.drop(index + 1).take(5).any { it.trim().length >= 12 }
                if (score >= 3 && hasBody && (before || numbered || marked || upper)) starts += index
            }
            val boundaries = starts.distinct().sorted()
            if (boundaries.isEmpty()) {
                if (page.trim().length >= 20) blocks += page.trim()
            } else {
                boundaries.forEachIndexed { index, start ->
                    val end = boundaries.getOrNull(index + 1) ?: lines.size
                    val block = lines.subList(start, end).joinToString("\n").trim()
                    if (block.length >= 20) blocks += block
                }
            }
        }

        val result = mutableListOf<SongbookSong>()
        val seen = HashSet<String>()
        blocks.forEach { block ->
            val lines = block.lines().map { it.trim() }.filter { it.isNotBlank() }
            if (lines.isEmpty()) return@forEach
            val title = lines.firstOrNull { isTitle(it) }
                ?.trim('#', '*', '-', '♪', '♫', ' ')?.trim()?.take(120) ?: return@forEach
            val artist = lines.firstOrNull {
                it.startsWith("Von:", true) || it.startsWith("Artist:", true) ||
                    it.startsWith("Interpret:", true) || it.startsWith("Künstler:", true)
            }?.substringAfter(':')?.trim()?.takeIf { it.isNotBlank() } ?: "Unbekannter Künstler"
            val key = title.lowercase(Locale.ROOT) + "|" + artist.lowercase(Locale.ROOT)
            if (seen.add(key)) {
                result += SongbookSong(title=title, artist=artist, lyrics=block, chords=extractChords(block), source=source)
            }
        }
        if (result.isEmpty()) {
            val all = pages.values.joinToString("\n\n").trim()
            if (all.length >= 20) {
                val title = all.lines().firstOrNull { it.isNotBlank() }?.trim()?.take(120) ?: "PDF-Inhalt prüfen"
                result += SongbookSong(title=title, artist="Unbekannter Künstler", lyrics=all, chords=extractChords(all), source=source)
            }
        }
        return result
    }

    private fun isTitle(value: String): Boolean {
        val line = value.trim().trim('#', '*', '♪', '♫', ' ').trim()
        if (line.length !in 2..100 || line.count { it.isLetter() } < 2) return false
        if (line.matches(Regex("""(?i)(seite|page)\s+\d+""")) || line.matches(Regex("""\d{1,4}"""))) return false
        if (line.contains("www.") || line.contains("http://") || line.contains("https://")) return false
        val words = line.split(Regex("""\s+"""))
        val chordWords = words.count { it.matches(Regex("""[A-Ga-g](?:#|b)?(?:m|maj7|7|sus4|sus2|dim|aug)?""")) }
        return !(chordWords >= maxOf(1, (words.size + 1) / 2) && words.size <= 12)
    }
}
class SongbookFragment : Fragment() {
    private lateinit var root: LinearLayout
    private lateinit var db: SongbookDb
    private val executor = Executors.newSingleThreadExecutor()
    private val youtubePrefs by lazy {
        requireContext().getSharedPreferences("saitenwerk_youtube", Context.MODE_PRIVATE)
    }
    private var youtubeAccessToken: String? = null
    private var youtubeConnected = false
    private var youtubeChannelName: String? = null
    private val youtubeAuthLauncher =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
            if (result.resultCode != Activity.RESULT_OK) {
                Toast.makeText(requireContext(), "YouTube-Verbindung abgebrochen.", Toast.LENGTH_SHORT).show()
                return@registerForActivityResult
            }
            try {
                val authorizationResult =
                    Identity.getAuthorizationClient(requireContext())
                        .getAuthorizationResultFromIntent(result.data)
                youtubeAccessToken = authorizationResult.accessToken
                youtubeConnected = !youtubeAccessToken.isNullOrBlank()
                if (!youtubeConnected) {
                    Toast.makeText(requireContext(), "Keine YouTube-Berechtigung erhalten.", Toast.LENGTH_LONG).show()
                    return@registerForActivityResult
                }
                youtubePrefs.edit().putBoolean("connected", true).apply()
                fetchYoutubeChannel()
            } catch (e: ApiException) {
                Toast.makeText(requireContext(), "YouTube-Autorisierung fehlgeschlagen: ${e.statusCode}", Toast.LENGTH_LONG).show()
            } catch (t: Throwable) {
                Toast.makeText(requireContext(), "YouTube-Autorisierung fehlgeschlagen.", Toast.LENGTH_LONG).show()
            }
        }

    private val importPdf = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importPdf(uri)
    }

    override fun onCreateView(inflater: android.view.LayoutInflater, container: ViewGroup?, state: Bundle?): View {
        db = SongbookDb(requireContext())
        youtubeConnected = youtubePrefs.getBoolean("connected", false)
        youtubeChannelName = youtubePrefs.getString("channel_name", null)
        root = LinearLayout(requireContext()).apply {
            orientation=LinearLayout.VERTICAL
            setPadding(dp(18),dp(12),dp(18),dp(24))
            setBackgroundColor(Color.rgb(7,19,30))
        }
        buildHome()
        return root
    }

    private fun buildHome() {
        root.removeAllViews()
        addText("SONGBOOK", 30f, Color.WHITE, 8)
        addText("Deine Songs. Deine Akkorde. Dein Training.", 15f, Color.LTGRAY, 2)
        val stats = db.all()
        val stat = card()
        val row = LinearLayout(requireContext()).apply { orientation=LinearLayout.HORIZONTAL }
        stat.addView(label("MEINE SONGS\n" + stats.size, 18f, Color.WHITE), LinearLayout.LayoutParams(0,dp(72),1f))
        stat.addView(label(stats.sumOf{it.chords.size}.toString() + " AKKORDE\nverknüpft", 18f, Color.WHITE), LinearLayout.LayoutParams(0,dp(72),1f))
        root.addView(stat)
        val import = button("＋  PDF analysieren & Songs importieren")
        import.setOnClickListener { importPdf.launch(arrayOf("application/pdf")) }
        root.addView(import)
        val pdfs = db.importedPdfs()
        if (pdfs.isNotEmpty()) {
            addText("MEINE IMPORTIERTEN PDFS", 13f, Color.rgb(205,145,91), 2)
            pdfs.forEach { pdf ->
                val pdfCard = card()
                pdfCard.addView(label("▤  " + pdf.displayName, 16f, Color.WHITE))
                pdfCard.addView(label(pdf.songCount.toString() + " erkannte Songs", 12f, Color.LTGRAY))
                val remove = button("PDF aus Songbook entfernen")
                remove.setOnClickListener {
                    AlertDialog.Builder(requireContext(), R.style.ThemeOverlay_Saitenwerk_Dialog)
                        .setTitle("Importiertes PDF entfernen?")
                        .setMessage("\"${pdf.displayName}\" und die ausschließlich daraus importierten Songs werden aus SaitenWerk entfernt. Die Originaldatei auf deinem Gerät bleibt erhalten.")
                        .setNegativeButton("Abbrechen", null)
                        .setPositiveButton("Entfernen") { _, _ ->
                            db.removePdf(pdf.uri)
                            runCatching {
                                requireContext().contentResolver.releasePersistableUriPermission(
                                    Uri.parse(pdf.uri), Intent.FLAG_GRANT_READ_URI_PERMISSION
                                )
                            }
                            buildHome()
                            Toast.makeText(requireContext(), "PDF und zugehörige Songs entfernt.", Toast.LENGTH_LONG).show()
                        }.show()
                }
                pdfCard.addView(remove)
                root.addView(pdfCard)
            }
        }
        val youtube = button(if (youtubeConnected) {
            "✓ YouTube verbunden" + (youtubeChannelName?.let { " · $it" } ?: "")
        } else {
            "▶ YouTube verbinden"
        })
        youtube.setOnClickListener {
            if (youtubeConnected) {
                AlertDialog.Builder(requireContext(), R.style.ThemeOverlay_Saitenwerk_Dialog)
                    .setTitle("YouTube verbunden")
                    .setMessage(
                        "Saitenwerk ist für dein YouTube-Konto autorisiert. " +
                        "Die App nutzt die Berechtigung nur für YouTube-Funktionen im Songbook."
                    )
                    .setNegativeButton("Verbindung lokal trennen") {
                        _, _ ->
                        youtubeAccessToken = null
                        youtubeConnected = false
                        youtubeChannelName = null
                        youtubePrefs.edit().clear().apply()
                        buildHome()
                    }
                    .setPositiveButton("OK", null)
                    .show()
            } else {
                authorizeYoutube()
            }
        }
        root.addView(youtube)

        val search = EditText(requireContext()).apply {
            hint="Song oder Künstler suchen"; setSingleLine(); setTextColor(Color.WHITE); setHintTextColor(Color.rgb(189,161,142))
            setPadding(dp(16),0,dp(16),0); inputType=InputType.TYPE_CLASS_TEXT
            setBackgroundColor(Color.rgb(20,43,58))
        }
        root.addView(search, LinearLayout.LayoutParams(-1,dp(52)).apply { topMargin=dp(12); bottomMargin=dp(10) })
        val list = LinearLayout(requireContext()).apply { orientation=LinearLayout.VERTICAL }
        root.addView(list)
        fun refresh(q:String="") {
            list.removeAllViews()
            db.all().filter { q.isBlank() || (it.title + " " + it.artist).contains(q,true) }.take(100).forEach { song ->
                val c=card()
                c.addView(label(song.title,19f,Color.WHITE))
                c.addView(label(song.artist + "  •  " + song.chords.size + " Akkorde",13f,Color.LTGRAY))
                val actions=LinearLayout(requireContext()).apply { orientation=LinearLayout.HORIZONTAL }
                val open=button("Öffnen"); open.setOnClickListener{showSong(song)}
                val yt=button(if(song.youtubeId==null) "YouTube suchen" else "▶ YouTube")
                yt.setOnClickListener { openYoutube(song) }
                actions.addView(open,LinearLayout.LayoutParams(0,dp(48),1f))
                actions.addView(yt,LinearLayout.LayoutParams(0,dp(48),1f))
                c.addView(actions); list.addView(c)
            }
        }
        search.addTextChangedListener(SimpleTextWatcher { refresh(it) })
        refresh()
    }

    private fun showSong(song: SongbookSong) {
        root.removeAllViews()
        val back=button("‹  Songbook"); back.setOnClickListener{buildHome()}; root.addView(back)
        addText(song.title,27f,Color.WHITE,4); addText(song.artist,15f,Color.LTGRAY,8)
        val meta=card()
        meta.addView(label("Akkorde",12f,Color.LTGRAY))
        meta.addView(label(if(song.chords.isEmpty()) "Keine Akkorde erkannt" else song.chords.joinToString("   "),16f,Color.WHITE))
        root.addView(meta)
        if(song.youtubeId!=null) {
            val web=WebView(requireContext()).apply {
                settings.javaScriptEnabled=true; settings.domStorageEnabled=true
                settings.mediaPlaybackRequiresUserGesture=false
                loadDataWithBaseURL("https://www.youtube.com", youtubeHtml(song.youtubeId), "text/html","UTF-8",null)
            }
            root.addView(web,LinearLayout.LayoutParams(-1,dp(230)))
        } else {
            val match=button("YouTube-Verknüpfung suchen"); match.setOnClickListener{openYoutube(song)}; root.addView(match)
        }
        val lyrics=TextView(requireContext()).apply {
            text=song.lyrics; setTextColor(Color.WHITE); textSize=16f; setPadding(dp(12),dp(12),dp(12),dp(40))
        }
        val scroll=ScrollView(requireContext()); scroll.addView(lyrics); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        val sync=button("⏱  Auto-Sync für Lyrics aktivieren")
        sync.setOnClickListener {
            Toast.makeText(requireContext(),"Synchronisation wird über gespeicherte Zeitmarker aufgebaut.",Toast.LENGTH_LONG).show()
        }
        root.addView(sync)
    }

    private fun authorizeYoutube() {
        val requestedScopes = listOf(
            Scope("https://www.googleapis.com/auth/youtube.readonly")
        )
        val request = AuthorizationRequest.builder()
            .setRequestedScopes(requestedScopes)
            .build()

        Identity.getAuthorizationClient(requireContext())
            .authorize(request)
            .addOnSuccessListener { authorizationResult ->
                if (authorizationResult.hasResolution()) {
                    val pendingIntent = authorizationResult.pendingIntent
                    if (pendingIntent == null) {
                        Toast.makeText(requireContext(), "Google konnte den Autorisierungsdialog nicht öffnen.", Toast.LENGTH_LONG).show()
                    } else {
                        youtubeAuthLauncher.launch(
                            IntentSenderRequest.Builder(pendingIntent.intentSender).build()
                        )
                    }
                } else {
                    youtubeAccessToken = authorizationResult.accessToken
                    youtubeConnected = !youtubeAccessToken.isNullOrBlank()
                    if (youtubeConnected) {
                        youtubePrefs.edit().putBoolean("connected", true).apply()
                        fetchYoutubeChannel()
                    } else {
                        Toast.makeText(requireContext(), "YouTube-Berechtigung wurde nicht erteilt.", Toast.LENGTH_LONG).show()
                    }
                }
            }
            .addOnFailureListener {
                Toast.makeText(requireContext(), "YouTube-Autorisierung konnte nicht gestartet werden.", Toast.LENGTH_LONG).show()
            }
    }

    private fun fetchYoutubeChannel() {
        val token = youtubeAccessToken ?: return
        executor.execute {
            try {
                val url = java.net.URL("https://www.googleapis.com/youtube/v3/channels?part=snippet&mine=true")
                val connection = (url.openConnection() as java.net.HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 10000
                    readTimeout = 10000
                    setRequestProperty("Authorization", "Bearer $token")
                    setRequestProperty("Accept", "application/json")
                }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
                connection.disconnect()
                if (code !in 200..299) {
                    requireActivity().runOnUiThread {
                        youtubePrefs.edit().putBoolean("connected", true).apply()
                        Toast.makeText(
                            requireContext(),
                            "YouTube ist verbunden. Kanalinformationen konnten nicht gelesen werden.",
                            Toast.LENGTH_LONG
                        ).show()
                        buildHome()
                    }
                    return@execute
                }
                val items = org.json.JSONObject(body).optJSONArray("items")
                val name = items?.optJSONObject(0)?.optJSONObject("snippet")?.optString("title").orEmpty()
                youtubeChannelName = name.ifBlank { null }
                youtubePrefs.edit().putBoolean("connected", true).apply {
                    if (name.isBlank()) remove("channel_name") else putString("channel_name", name)
                }.apply()
                requireActivity().runOnUiThread {
                    Toast.makeText(
                        requireContext(),
                        if (name.isBlank()) "YouTube erfolgreich verbunden." else "YouTube verbunden mit: $name",
                        Toast.LENGTH_LONG
                    ).show()
                    buildHome()
                }
            } catch (t: Throwable) {
                requireActivity().runOnUiThread {
                    Toast.makeText(requireContext(), "YouTube verbunden, Kanal konnte nicht geladen werden.", Toast.LENGTH_LONG).show()
                    buildHome()
                }
            }
        }
    }

    private fun openYoutube(song: SongbookSong) {
        val query=Uri.encode(song.artist + " " + song.title + " guitar")
        startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://www.youtube.com/results?search_query="+query)))
    }

    private fun youtubeHtml(id:String)= """
        <!doctype html><html><body style="margin:0;background:#000">
        <iframe width="100%" height="100%" src="https://www.youtube.com/embed/$id?enablejsapi=1&playsinline=1"
        title="YouTube Player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
        </body></html>
    """.trimIndent()

    private fun importPdf(uri:Uri) {
        val progress=ProgressBar(requireContext())
        root.addView(progress,0,LinearLayout.LayoutParams(-1,dp(5)))
        executor.execute {
            try {
                val context = requireContext().applicationContext
                runCatching {
                    requireContext().contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                }
                val displayName = queryPdfDisplayName(uri)
                PDFBoxResourceLoader.init(context)
                val extracted = requireContext().contentResolver.openInputStream(uri).use { input ->
                    if(input==null) error("PDF konnte nicht geöffnet werden.")
                    PDDocument.load(input).use { doc ->
                        val pages = mutableListOf<String>()
                        val renderer = runCatching {
                            val descriptor = requireContext().contentResolver.openFileDescriptor(uri, "r")
                                ?: error("PDF-Datei kann nicht für die Texterkennung geöffnet werden.")
                            PdfRenderer(descriptor)
                        }.getOrNull()
                        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                        try {
                            for (pageIndex in 0 until doc.numberOfPages) {
                                val stripper = PDFTextStripper().apply {
                                    sortByPosition = true
                                    lineSeparator = "\n"
                                    startPage = pageIndex + 1
                                    endPage = pageIndex + 1
                                }
                                var pageText = stripper.getText(doc).trim()
                                val usefulChars = pageText.count { it.isLetterOrDigit() }
                                if (usefulChars < 24 && renderer != null && pageIndex < renderer.pageCount) {
                                    val ocrText = renderer.openPage(pageIndex).use { page ->
                                        val bitmap = Bitmap.createBitmap(
                                            (page.width * 2).coerceAtLeast(1),
                                            (page.height * 2).coerceAtLeast(1),
                                            Bitmap.Config.ARGB_8888
                                        )
                                        try {
                                            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                            Tasks.await(recognizer.process(InputImage.fromBitmap(bitmap, 0))).text
                                        } finally { bitmap.recycle() }
                                    }
                                    if (ocrText.isNotBlank()) pageText = ocrText
                                }
                                if (pageText.isNotBlank()) pages += "[[SAITENWERK_SEITE_${pageIndex + 1}]]\n" + pageText
                            }
                        } finally {
                            recognizer.close()
                            renderer?.close()
                        }
                        pages.joinToString("\n\n")
                    }
                }
                val songs = SongbookParser.parse(extracted, uri.toString())
                if (songs.isEmpty()) error("Es konnten keine Songs erkannt werden. Bitte prüfe, ob die PDF lesbaren Text oder gut erkennbare Noten-/Akkordseiten enthält.")
                val savedCount = db.replacePdfSongs(uri.toString(), songs)
                if (savedCount == 0) error("Songs erkannt, aber kein Song konnte gespeichert werden.")
                db.registerPdf(uri.toString(), displayName, savedCount)
                requireActivity().runOnUiThread {
                    if(progress.parent!=null) root.removeView(progress)
                    buildHome()
                    AlertDialog.Builder(requireContext(), R.style.ThemeOverlay_Saitenwerk_Dialog).setTitle("PDF analysiert")
                        .setMessage(savedCount.toString() + " Songs erkannt und gespeichert. Das Songbook wurde aktualisiert.\n\nText-PDFs werden direkt ausgelesen; gescannte Seiten werden zusätzlich per Texterkennung (OCR) verarbeitet.")
                        .setPositiveButton("OK", null).show()
                }
            } catch(t:Throwable) {
                requireActivity().runOnUiThread {
                    if(progress.parent!=null) root.removeView(progress)
                    AlertDialog.Builder(requireContext(), R.style.ThemeOverlay_Saitenwerk_Dialog).setTitle("Import fehlgeschlagen")
                        .setMessage(t.cause?.message ?: t.message ?: "Unbekannter PDF-Fehler").setPositiveButton("OK",null).show()
                }
            }
        }
    }

    private fun queryPdfDisplayName(uri: Uri): String {
        var name = "Songbook-PDF"
        requireContext().contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) name = c.getString(0)?.takeIf { it.isNotBlank() } ?: name
        }
        return name
    }

    private fun card(): LinearLayout = LinearLayout(requireContext()).apply {
        orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(14),dp(16),dp(14))
        setBackgroundColor(Color.rgb(13,32,45))
        val p=LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT)
        p.setMargins(0,dp(7),0,dp(7))
        layoutParams = p
    }
    private fun button(text:String)=Button(requireContext()).apply {
        this.text=text
        setTextColor(Color.rgb(221,162,122))
        setAllCaps(false)
        textSize=14f
        typeface=android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        gravity=android.view.Gravity.CENTER
        includeFontPadding=true
        minLines=1
        maxLines=2
        minHeight=dp(52)
        minimumHeight=dp(52)
        setPadding(dp(16),dp(10),dp(16),dp(10))
        background=android.graphics.drawable.GradientDrawable().apply {
            cornerRadius=dp(16).toFloat()
            setColor(Color.rgb(20,43,58))
            setStroke(dp(1),Color.rgb(41,67,84))
        }
    }
    private fun label(text:String,size:Float,color:Int)=TextView(requireContext()).apply { this.text=text; textSize=size; setTextColor(color); setPadding(0,dp(4),dp(8),dp(4)) }
    private fun addText(text:String,size:Float,color:Int,bottom:Int){ root.addView(label(text,size,color),LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT).apply{bottomMargin=dp(bottom)}) }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
}

private class SimpleTextWatcher(val changed:(String)->Unit): android.text.TextWatcher {
    override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}
    override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){changed(s?.toString()?:"")}
    override fun afterTextChanged(s:android.text.Editable?){}
}
