package de.saitenwerk.app

import androidx.appcompat.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.net.Uri
import android.provider.OpenableColumns
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import com.google.android.gms.common.api.Scope
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import androidx.activity.result.IntentSenderRequest
import android.app.Activity
import androidx.fragment.app.Fragment
import org.json.JSONArray
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.util.Locale
import java.util.concurrent.Executors
import java.util.regex.Pattern

data class SongbookSong(
    val id: Long = 0,
    val title: String,
    val artist: String,
    val lyrics: String,
    val chords: List<String>,
    val source: String,
    val youtubeId: String? = null,
    val youtubeConfidence: Int = 0
)

data class ImportedSongbookPdf(
    val uri: String,
    val displayName: String,
    val importedAt: Long,
    val songCount: Int
)

private object PublicDomainSongCatalog {
    data class Seed(val title:String,val artist:String,val lyrics:String,val chords:List<String>,val youtubeId:String?=null,val confidence:Int=0)
    val songs=listOf(
        Seed("Am Brunnen vor dem Tore","Wilhelm Müller / Franz Schubert","""Am Brunnen vor dem Tore,
Da steht ein Lindenbaum;
Ich träumt' in seinem Schatten
So manchen süßen Traum.
Ich schnitt in seine Rinde
So manches liebe Wort;
Es zog in Freud und Leide
Zu ihm mich immer fort.

Ich musst' auch heute wandern
Vorbei in tiefer Nacht,
Da hab ich noch im Dunkel
Die Augen zugemacht.""",listOf("C","G7","F","C")),
        Seed("Die Gedanken sind frei","Volkslied","""Die Gedanken sind frei,
wer kann sie erraten?
Sie rauschen vorbei
wie nächtliche Schatten.
Kein Mensch kann sie wissen,
kein Jäger erschießen;
es bleibet dabei:
Die Gedanken sind frei.

Und sperrt man mich ein
im finsteren Kerker,
das alles sind rein
vergebliche Werke;
denn meine Gedanken
zerreißen die Schranken
und Mauern entzwei.""",listOf("Am","G","C","E7"),"SsW-6Klbyto",95),
        Seed("Der Mond ist aufgegangen","Matthias Claudius / Johann Abraham Peter Schulz","""Der Mond ist aufgegangen,
die goldnen Sternlein prangen
am Himmel hell und klar.
Der Wald steht schwarz und schweiget,
und aus den Wiesen steiget
der weiße Nebel wunderbar.

Wie ist die Welt so stille
und in der Dämmrung Hülle
so traulich und so hold!
Als eine stille Kammer,
wo ihr des Tages Jammer
verschlafen und vergessen sollt.""",listOf("C","G7","F","C"),"9897OI_VF8E",95),
        Seed("Das Wandern ist des Müllers Lust","Wilhelm Müller / Carl Friedrich Zöllner","""Das Wandern ist des Müllers Lust,
das Wandern ist des Müllers Lust,
das Wandern.
Das muss ein schlechter Müller sein,
dem niemals fiel das Wandern ein,
dem niemals fiel das Wandern ein,
das Wandern.

Vom Wasser haben wir's gelernt,
vom Wasser haben wir's gelernt,
vom Wasser:
Das hat nicht Ruh bei Tag und Nacht,
ist stets auf Wanderschaft bedacht.""",listOf("G","D7","C","G")),
        Seed("Kein schöner Land in dieser Zeit","Anton Wilhelm von Zuccalmaglio","""Kein schöner Land in dieser Zeit
als hier das unsre weit und breit,
wo wir uns finden wohl unter Linden
zur Abendzeit.

Da haben wir so manche Stund'
gesessen da in froher Rund'
und taten singen; die Lieder klingen
im Eichengrund.""",listOf("G","D7","C","G")),
        Seed("Muss i denn zum Städtele hinaus","Volkslied","""Muss i denn, muss i denn
zum Städtele hinaus,
Städtele hinaus,
und du, mein Schatz, bleibst hier?
Wenn i komm, wenn i komm,
wiederum, wiederum,
kehr i ein, mein Schatz, bei dir.

Wie du weinst, wie du weinst,
dass i wandern muss,
wandern muss,
wie wenn d' Lieb jetzt wär vorbei!
Lieber Schatz, i bleib dir treu.""",listOf("G","D7","C","G")),
        Seed("Heidenröslein","Johann Wolfgang von Goethe / Heinrich Werner","""Sah ein Knab ein Röslein stehn,
Röslein auf der Heiden,
war so jung und morgenschön,
lief er schnell, es nah zu sehn,
sah's mit vielen Freuden.
Röslein, Röslein, Röslein rot,
Röslein auf der Heiden.

Knabe sprach: Ich breche dich,
Röslein auf der Heiden!
Röslein sprach: Ich steche dich,
dass du ewig denkst an mich,
und ich will's nicht leiden.""",listOf("G","D7","C","G")),
        Seed("Der Mai ist gekommen","Emanuel Geibel / Justus Wilhelm Lyra","""Der Mai ist gekommen, die Bäume schlagen aus,
da bleibe, wer Lust hat, mit Sorgen zu Haus;
wie die Wolken dort wandern am himmlischen Zelt,
so steht auch mir der Sinn in die weite, weite Welt.

Herr Vater, Frau Mutter, dass Gott euch behüt'!
Wer weiß, wo in der Ferne mein Glück mir noch blüht.
Es gibt so manche Straße, da zieht keiner ein,
die kann uns zwei wohl führen ins blühende Land hinein.""",listOf("G","D","C","G"),"cKo8nifC5X0",95),
        Seed("Bunt sind schon die Wälder","Johann Gaudenz von Salis-Seewis / Johann Friedrich Reichardt","""Bunt sind schon die Wälder,
gelb die Stoppelfelder,
und der Herbst beginnt.
Rote Blätter fallen,
graue Nebel wallen,
kühler weht der Wind.

Wie die volle Traube
aus dem Rebenlaube
purpurfarbig strahlt!
Am Geländer reifen
Pfirsiche mit Streifen,
rot und weiß bemalt.""",listOf("G","D7","C","G")),
        Seed("Ein Jäger aus Kurpfalz","Volkslied","""Ein Jäger aus Kurpfalz,
der reitet durch den grünen Wald,
er schießt das Wild daher,
gleich wie es ihm gefällt.

Juja, juja, gar lustig ist die Jägerei,
allhier auf grüner Heid,
allhier auf grüner Heid.""",listOf("G","D7","C","G"),"GpqEMKDZX6k",95),
        Seed("Im schönsten Wiesengrunde","Volkslied","""Im schönsten Wiesengrunde
ist meiner Heimat Haus;
da zog ich manche Stunde
ins Tal hinaus.

Dich, mein stilles Tal,
grüß ich tausendmal;
da zog ich manche Stunde
ins Tal hinaus.

Müsst aus dem Tal ich scheiden,
wo alles Lust und Klang,
das wär mein herbstes Leiden,
mein letzter Gang.""",listOf("G","D7","C","G"),"qtZi1b0ponM",95),
        Seed("Wem Gott will rechte Gunst erweisen","Joseph von Eichendorff / Friedrich Theodor Fröhlich","""Wem Gott will rechte Gunst erweisen,
den schickt er in die weite Welt,
dem will er seine Wunder weisen
in Berg und Tal und Strom und Feld.

Die Bächlein von den Bergen springen,
die Lerchen schwirren hoch vor Lust;
was sollt ich nicht mit ihnen singen
aus voller Kehl und frischer Brust?""",listOf("C","G7","F","C"),"IVHctD6XwEY",90),
        Seed("Guter Mond, du gehst so stille","Karl Enslin / Volksweise","""Guter Mond, du gehst so stille
durch die Abendwolken hin;
deines Schöpfers weiser Wille
hieß auf jene Bahn dich ziehn.
Leuchte freundlich jedem Müden
in das stille Kämmerlein,
und dein Schimmer gieße Frieden
ins bedrängte Herz hinein.""",listOf("C","G7","F","C")),
        Seed("Horch, was kommt von draußen rein","Volkslied","""Horch, was kommt von draußen rein?
Hollahi, hollaho!
Wird wohl mein Feinsliebchen sein,
hollahi, hollaho!
Geht vorbei und schaut nicht rein,
als wär sie nicht daheim.""",listOf("G","D7","C","G")),
        Seed("Ännchen von Tharau","Simon Dach / Friedrich Silcher","""Ännchen von Tharau ist, die mir gefällt,
Sie ist mein Leben, mein Gut und mein Geld.
Ännchen von Tharau hat wieder ihr Herz
auf mich gerichtet in Lieb und in Schmerz.

Ännchen von Tharau, mein Reichtum, mein Gut,
Du mein Leben, mein ganzes Herzblut!""",listOf("G","D7","C","G"))
    )
}

class SongbookDb(context: Context) {
    private val db = run {
        // One-time cleanup of the legacy Songbook store. From this version onward
        // every installation starts with an empty, user-owned Songbook.
        val prefs = context.getSharedPreferences("saitenwerk_songbook_migration", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("legacy_store_removed_v1", false)) {
            context.deleteDatabase("saitenwerk_songbook.db")
            prefs.edit().putBoolean("legacy_store_removed_v1", true).apply()
        }
        context.openOrCreateDatabase("saitenwerk_songbook_user.db", Context.MODE_PRIVATE, null)
    }
    init {
        db.execSQL("""CREATE TABLE IF NOT EXISTS songs(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            artist TEXT NOT NULL,
            lyrics TEXT NOT NULL,
            chords TEXT NOT NULL,
            source TEXT NOT NULL,
            youtube_id TEXT,
            youtube_confidence INTEGER NOT NULL DEFAULT 0,
            UNIQUE(title, artist)
        )""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS imported_pdfs(
            uri TEXT PRIMARY KEY,
            display_name TEXT NOT NULL,
            imported_at INTEGER NOT NULL,
            song_count INTEGER NOT NULL DEFAULT 0
        )""")
        db.execSQL("""CREATE TABLE IF NOT EXISTS song_pdf_sources(
            song_id INTEGER NOT NULL,
            pdf_uri TEXT NOT NULL,
            PRIMARY KEY(song_id, pdf_uri)
        )""")
        db.execSQL("INSERT OR IGNORE INTO song_pdf_sources(song_id,pdf_uri) SELECT id,source FROM songs WHERE source IS NOT NULL AND source <> ''")

        fun seedPublicDomainSongsIfEmpty() {
            val count = db.rawQuery("SELECT COUNT(*) FROM songs", null).use { c -> if (c.moveToFirst()) c.getInt(0) else 0 }
            if (count > 0) return
            PublicDomainSongCatalog.songs.forEach { song ->
                upsert(SongbookSong(title=song.title, artist=song.artist, lyrics=song.lyrics, chords=song.chords, source="builtin:public-domain", youtubeId=song.youtubeId, youtubeConfidence=song.confidence))
            }
        }
        seedPublicDomainSongsIfEmpty()
    }
    fun registerPdf(uri: String, displayName: String, songCount: Int) {
        val cv = android.content.ContentValues().apply {
            put("uri", uri); put("display_name", displayName)
            put("imported_at", System.currentTimeMillis()); put("song_count", songCount)
        }
        db.insertWithOnConflict("imported_pdfs", null, cv, android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun replacePdfSongs(uri: String, songs: List<SongbookSong>): Int {
        db.beginTransaction()
        try {
            val oldIds = linkedSetOf<Long>()
            db.rawQuery("SELECT song_id FROM song_pdf_sources WHERE pdf_uri=?", arrayOf(uri)).use { cursor ->
                while (cursor.moveToNext()) oldIds += cursor.getLong(0)
            }
            val newIds = linkedSetOf<Long>()
            songs.forEach { newIds += upsert(it) }
            db.delete("song_pdf_sources", "pdf_uri=?", arrayOf(uri))
            newIds.forEach { id ->
                db.execSQL("INSERT OR IGNORE INTO song_pdf_sources(song_id,pdf_uri) VALUES(?,?)", arrayOf(id, uri))
            }
            (oldIds - newIds).forEach { id ->
                val referenceCount = db.rawQuery(
                    "SELECT COUNT(*) FROM song_pdf_sources WHERE song_id=?",
                    arrayOf(id.toString())
                ).use { cursor -> if (cursor.moveToFirst()) cursor.getInt(0) else 0 }
                if (referenceCount == 0) db.delete("songs", "id=?", arrayOf(id.toString()))
            }
            db.setTransactionSuccessful()
            return newIds.size
        } finally {
            db.endTransaction()
        }
    }

    fun importedPdfs(): List<ImportedSongbookPdf> {
        val out = mutableListOf<ImportedSongbookPdf>()
        db.rawQuery("SELECT uri,display_name,imported_at,song_count FROM imported_pdfs ORDER BY imported_at DESC", null).use { c ->
            while (c.moveToNext()) out += ImportedSongbookPdf(c.getString(0), c.getString(1), c.getLong(2), c.getInt(3))
        }
        return out
    }
    fun removePdf(uri: String): Int {
        db.beginTransaction()
        try {
            db.delete("song_pdf_sources", "pdf_uri=?", arrayOf(uri))
            val removed = db.delete("songs", "id NOT IN (SELECT song_id FROM song_pdf_sources)", null)
            db.delete("imported_pdfs", "uri=?", arrayOf(uri))
            db.setTransactionSuccessful()
            return removed
        } finally { db.endTransaction() }
    }
    fun upsert(song: SongbookSong): Long {
        val cv = android.content.ContentValues().apply {
            put("title", song.title); put("artist", song.artist); put("lyrics", song.lyrics)
            put("chords", JSONArray(song.chords).toString()); put("source", song.source)
            song.youtubeId?.let { put("youtube_id", it); put("youtube_confidence", song.youtubeConfidence) }
        }
        val existing = db.rawQuery("SELECT id FROM songs WHERE lower(title)=lower(?) AND lower(artist)=lower(?)",
            arrayOf(song.title, song.artist))
        val id = if (existing.moveToFirst()) {
            val value = existing.getLong(0); existing.close()
            db.update("songs", cv, "id=?", arrayOf(value.toString())); value
        } else {
            existing.close(); db.insertOrThrow("songs", null, cv)
        }
        db.execSQL("INSERT OR IGNORE INTO song_pdf_sources(song_id,pdf_uri) VALUES(?,?)", arrayOf(id, song.source))
        return id
    }
    fun all(): List<SongbookSong> {
        val out = mutableListOf<SongbookSong>()
        db.rawQuery("SELECT id,title,artist,lyrics,chords,source,youtube_id,youtube_confidence FROM songs ORDER BY title COLLATE NOCASE", null).use { c ->
            while (c.moveToNext()) {
                val chords = mutableListOf<String>()
                runCatching { val a=JSONArray(c.getString(4)); for(i in 0 until a.length()) chords += a.getString(i) }
                out += SongbookSong(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), chords, c.getString(5),
                    if(c.isNull(6)) null else c.getString(6), c.getInt(7))
            }
        }
        return out
    }
}

object SongbookParser {
    private data class TocEntry(val number: Int, val label: String, val page: Int)

    private val tocLinePattern = Regex("""^\s*(\d{1,4})\s*[.)]?\s*(.+?)\s*(?:[.·…]{2,}\s*)?(\d{1,4})\s*$""")
    private val chordPattern = Pattern.compile("""(?<![A-Za-z0-9])([A-Ga-g](?:#|b)?(?:maj(?:7|9|11|13)?|m(?:aj7|7|9|11|13)?|m9|sus[24]?|add9|dim7?|aug|[0-9]{1,2})?(?:/[A-Ga-g](?:#|b)?)?)(?![A-Za-z0-9])""")

    fun parse(text: String, source: String): List<SongbookSong> {
        val normalized = text.replace("\r\n", "\n").replace('\r', '\n').filter { it.code != 0 }.trim()
        if (normalized.isBlank()) return emptyList()
        val pages = splitPages(normalized)
        val indexed = parseFromContents(pages, source)
        if (indexed.isNotEmpty()) return indexed
        return parseHeuristically(normalized, source)
    }

    private fun splitPages(text: String): Map<Int, String> {
        val marker = Regex("""\[\[SAITENWERK_SEITE_(\d+)]]""")
        val matches = marker.findAll(text).toList()
        if (matches.isEmpty()) return mapOf(1 to text)
        val pages = linkedMapOf<Int, String>()
        matches.forEachIndexed { index, match ->
            val start = match.range.last + 1
            val end = matches.getOrNull(index + 1)?.range?.first ?: text.length
            val pageNumber = match.groupValues[1].toIntOrNull() ?: (index + 1)
            pages[pageNumber] = text.substring(start, end).trim()
        }
        return pages
    }

    private fun parseFromContents(pages: Map<Int, String>, source: String): List<SongbookSong> {
        val entries = mutableListOf<TocEntry>()
        var lastContentsPage = 0
        var pending: Pair<Int, String>? = null
        for ((pageNumber, pageText) in pages.toSortedMap()) {
            if (pageNumber > 20) break
            var foundOnPage = false
            for (rawLine in pageText.lines()) {
                val line = rawLine.replace('\u00A0', ' ').replace(Regex("""\s+"""), " ").trim()
                if (line.isBlank()) continue
                val match = tocLinePattern.matchEntire(line)
                if (match != null) {
                    val number = match.groupValues[1].toIntOrNull() ?: continue
                    val label = match.groupValues[2].trim().trim('.', '·', '…', ' ')
                    val songPage = match.groupValues[3].toIntOrNull() ?: continue
                    if (number > 0 && songPage > 1 && label.count { it.isLetter() } >= 2) {
                        entries += TocEntry(number, label, songPage)
                        foundOnPage = true
                        pending = null
                        continue
                    }
                }
                // Some PDF extractors put the title and its page number on separate lines.
                val head = Regex("""^(\d{1,4})\s*[.)]\s*(.{2,})$""").matchEntire(line)
                if (head != null) {
                    val number = head.groupValues[1].toIntOrNull()
                    val label = head.groupValues[2].trim().trim('.', '·', '…')
                    if (number != null && label.count { it.isLetter() } >= 2) pending = number to label
                } else if (pending != null && line.matches(Regex("""^\d{1,4}$"""))) {
                    val page = line.toIntOrNull()
                    if (page != null && page > 1) {
                        entries += TocEntry(pending!!.first, pending!!.second, page)
                        foundOnPage = true
                    }
                    pending = null
                }
            }
            if (foundOnPage) lastContentsPage = pageNumber
        }

        val ordered = entries.distinctBy { it.number }.sortedBy { it.number }
        if (ordered.size < 3) return emptyList()
        val lastPdfPage = pages.keys.maxOrNull() ?: return emptyList()
        val contentPages = pages.keys.filter { it <= maxOf(lastContentsPage, 1) }.toSet()

        fun words(value: String): Set<String> =
            Regex("""[\p{L}\p{N}]{3,}""").findAll(value.lowercase(Locale.ROOT))
                .map { it.value }.filterNot { it in setOf("der","die","das","und","von","mit","the","and","for","song","lied") }
                .toSet()

        // Printed page numbers frequently differ from physical PDF page indices.
        // Infer the constant offset from pages whose extracted heading resembles a TOC title.
        val offsets = mutableListOf<Int>()
        for (entry in ordered) {
            val titleWords = words(entry.label)
            if (titleWords.isEmpty()) continue
            var bestPage = -1
            var bestScore = 0.0
            for ((physicalPage, pageText) in pages) {
                if (physicalPage in contentPages) continue
                val pageWords = words(pageText.take(1800))
                val score = titleWords.count { it in pageWords }.toDouble() / titleWords.size
                if (score > bestScore) { bestScore = score; bestPage = physicalPage }
            }
            if (bestPage > 0 && bestScore >= 0.34) offsets += bestPage - entry.page
        }
        val offset = offsets.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key ?: 0
        val mapped = ordered.mapNotNull { entry ->
            val physical = entry.page + offset
            if (physical in pages && physical > lastContentsPage) entry to physical else null
        }
        if (mapped.size < 3) return emptyList()
        val monotonic = mapped.zipWithNext().count { it.first.second <= it.second.second }
        if (monotonic < (mapped.size * 0.75).toInt()) return emptyList()

        val usable = mapped.sortedBy { it.first.number }
        val duplicateCounts = HashMap<String, Int>()
        val result = mutableListOf<SongbookSong>()
        usable.forEachIndexed { index, pair ->
            val entry = pair.first
            val startPage = pair.second
            val nextPage = usable.drop(index + 1).firstOrNull { it.second > startPage }?.second
                ?: (lastPdfPage + 1)
            val rawBody = (startPage until nextPage).mapNotNull { pages[it] }.joinToString("\n")
            val body = rawBody.lines().filterNot { isPdfFooter(it) }.joinToString("\n").trim()
            val (baseTitle, artist) = splitTitleAndArtist(entry.label)
            val key = baseTitle.lowercase(Locale.ROOT) + "|" + artist.lowercase(Locale.ROOT)
            val occurrence = (duplicateCounts[key] ?: 0) + 1
            duplicateCounts[key] = occurrence
            val title = if (occurrence == 1) baseTitle else baseTitle + " (Eintrag " + entry.number + ")"
            if (body.isNotBlank()) {
                result += SongbookSong(
                    title = title.take(120), artist = artist.take(100), lyrics = body,
                    chords = extractChords(body), source = source
                )
            }
        }
        return result.takeIf { it.size >= 3 } ?: emptyList()
    }
    private fun splitTitleAndArtist(label: String): Pair<String, String> {
        val clean = label.replace(Regex("""\s+"""), " ").trim()
        val parenthetical = Regex("""^(.*?)\s+\(([^()]*)\)\s*$""").matchEntire(clean)
        if (parenthetical != null && parenthetical.groupValues[1].isNotBlank()) {
            return parenthetical.groupValues[1].trim() to parenthetical.groupValues[2].trim()
        }
        val separator = clean.lastIndexOf(" - ")
        if (separator > 0 && separator < clean.length - 3) {
            return clean.substring(0, separator).trim() to clean.substring(separator + 3).trim()
        }
        return clean to "Unbekannter Künstler"
    }

    private fun isPdfFooter(line: String): Boolean {
        val value = line.trim()
        return value.contains("Songbook vom", ignoreCase = true) ||
            value.contains("Lyricsarchiv.de", ignoreCase = true) ||
            Regex("""(?i)\bseite\s+\d+\s+von\s+\d+\b""").containsMatchIn(value)
    }

    private fun extractChords(block: String): List<String> {
        val chords = linkedSetOf<String>()
        block.lines().forEach { line ->
            if (!looksLikeChordLine(line)) return@forEach
            line.trim().split(Regex("""\s+""")).forEach { token ->
                val cleaned = token.trim(',', ';', ':', '.', '|', '(', ')', '[', ']')
                if (chordPattern.matcher(cleaned).matches()) {
                    val chord = if (cleaned.length == 1 && cleaned[0] in 'a'..'g') {
                        cleaned.uppercase(Locale.ROOT) + "m"
                    } else {
                        cleaned.replaceFirstChar { it.uppercase() }
                    }
                    chords += chord
                }
            }
        }
        return chords.toList()
    }

    private fun looksLikeChordLine(line: String): Boolean {
        val words = line.trim().split(Regex("""\s+""")).filter { it.isNotBlank() }
        if (words.isEmpty() || words.size > 24) return false
        val matches = words.count { token ->
            val cleaned = token.trim(',', ';', ':', '.', '|', '(', ')', '[', ']')
            chordPattern.matcher(cleaned).matches()
        }
        return matches >= maxOf(1, (words.size + 1) / 2)
    }

    private fun parseHeuristically(text: String, source: String): List<SongbookSong> {
        val pages = splitPages(text)
        val blocks = mutableListOf<String>()
        pages.toSortedMap().values.forEach { page ->
            val lines = page.lines()
            val starts = mutableListOf<Int>()
            lines.forEachIndexed { index, raw ->
                val line = raw.trim()
                if (!isTitle(line)) return@forEachIndexed
                val numbered = line.matches(Regex("""(?i)^(?:(?:lied|song)\s*)?\d{1,3}\s*[.)\-:]?\s+\S.*$"""))
                val marked = raw.trimStart().startsWith("#") || line.startsWith("♪") || line.startsWith("♫")
                val upper = line.count { it.isLetter() } >= 3 && line.filter { it.isLetter() }.all { !it.isLowerCase() }
                val before = index == 0 || lines.getOrNull(index - 1).isNullOrBlank() ||
                    lines.getOrNull(index - 1)?.trim()?.matches(Regex("""[-_=*~•·]{3,}""")) == true
                val after = lines.getOrNull(index + 1).isNullOrBlank()
                val score = (if (before) 1 else 0) + (if (after) 1 else 0) +
                    (if (numbered) 3 else 0) + (if (marked) 3 else 0) +
                    (if (upper) 2 else 0) +
                    (if (line.length <= 58 && !line.endsWith(".") && !line.endsWith(",")) 1 else 0)
                val hasBody = lines.drop(index + 1).take(5).any { it.trim().length >= 12 }
                if (score >= 3 && hasBody && (before || numbered || marked || upper)) starts += index
            }
            val boundaries = starts.distinct().sorted()
            if (boundaries.isEmpty()) {
                if (page.trim().length >= 20) blocks += page.trim()
            } else {
                boundaries.forEachIndexed { index, start ->
                    val end = boundaries.getOrNull(index + 1) ?: lines.size
                    val block = lines.subList(start, end).joinToString("\n").trim()
                    if (block.length >= 20) blocks += block
                }
            }
        }

        val result = mutableListOf<SongbookSong>()
        val seen = HashSet<String>()
        blocks.forEach { block ->
            val lines = block.lines().map { it.trim() }.filter { it.isNotBlank() }
            if (lines.isEmpty()) return@forEach
            val title = lines.firstOrNull { isTitle(it) }
                ?.trim('#', '*', '-', '♪', '♫', ' ')?.trim()?.take(120) ?: return@forEach
            val artist = lines.firstOrNull {
                it.startsWith("Von:", true) || it.startsWith("Artist:", true) ||
                    it.startsWith("Interpret:", true) || it.startsWith("Künstler:", true)
            }?.substringAfter(':')?.trim()?.takeIf { it.isNotBlank() } ?: "Unbekannter Künstler"
            val key = title.lowercase(Locale.ROOT) + "|" + artist.lowercase(Locale.ROOT)
            if (seen.add(key)) {
                result += SongbookSong(title=title, artist=artist, lyrics=block, chords=extractChords(block), source=source)
            }
        }
        if (result.isEmpty()) {
            val all = pages.values.joinToString("\n\n").trim()
            if (all.length >= 20) {
                val title = all.lines().firstOrNull { it.isNotBlank() }?.trim()?.take(120) ?: "PDF-Inhalt prüfen"
                result += SongbookSong(title=title, artist="Unbekannter Künstler", lyrics=all, chords=extractChords(all), source=source)
            }
        }
        return result
    }

    private fun isTitle(value: String): Boolean {
        val line = value.trim().trim('#', '*', '♪', '♫', ' ').trim()
        if (line.length !in 2..100 || line.count { it.isLetter() } < 2) return false
        if (line.matches(Regex("""(?i)(seite|page)\s+\d+""")) || line.matches(Regex("""\d{1,4}"""))) return false
        if (line.contains("www.") || line.contains("http://") || line.contains("https://")) return false
        val words = line.split(Regex("""\s+"""))
        val chordWords = words.count { it.matches(Regex("""[A-Ga-g](?:#|b)?(?:m|maj7|7|sus4|sus2|dim|aug)?""")) }
        return !(chordWords >= maxOf(1, (words.size + 1) / 2) && words.size <= 12)
    }
}

private object YouTubeAutoLinker {
    private val videoBlock = Regex("""\"videoRenderer\":\{\"videoId\":\"([A-Za-z0-9_-]{11})\"(.*?)(?=\"videoRenderer\"|\"continuationItemRenderer\")""", RegexOption.DOT_MATCHES_ALL)
    private val titlePattern = Regex("""\"title\":\{\"runs\":\[\{\"text\":\"([^\"]+)""")
    private val ownerPattern = Regex("""\"ownerText\":\{\"runs\":\[\{\"text\":\"([^\"]+)""")
    private fun words(value:String)=value.lowercase(java.util.Locale.ROOT)
        .replace(Regex("""[^\p{L}\p{N} ]""")," ").split(Regex("""\s+""")).filter{it.length>2}.toSet()
    fun findVideoId(title:String,artist:String):String? {
        val q=java.net.URLEncoder.encode("\"$title\" \"$artist\" Lied", "UTF-8")
        val c=(java.net.URL("https://www.youtube.com/results?search_query=$q").openConnection() as java.net.HttpURLConnection).apply {
            requestMethod="GET";connectTimeout=8000;readTimeout=10000
            setRequestProperty("User-Agent","Mozilla/5.0 (Android) SaitenWerk/1.0")
        }
        return try {
            if(c.responseCode !in 200..299) return null
            val html=c.inputStream.bufferedReader().use{it.readText()}
            val wantedTitle=words(title);val wantedArtist=words(artist)
            videoBlock.findAll(html).mapNotNull { match ->
                val body=match.groupValues[2]
                val foundTitle=titlePattern.find(body)?.groupValues?.get(1) ?: return@mapNotNull null
                val foundArtist=ownerPattern.find(body)?.groupValues?.get(1).orEmpty()
                val titleWords=words(foundTitle);val artistWords=words(foundArtist)
                if(wantedTitle.isEmpty()) return@mapNotNull null
                val titleScore=wantedTitle.count{it in titleWords}.toDouble()/wantedTitle.size
                val artistScore=if(wantedArtist.isEmpty()) 0.0 else wantedArtist.count{it in artistWords}.toDouble()/wantedArtist.size
                val score=titleScore*0.8+artistScore*0.2
                if(titleScore>=0.6 && score>=0.62) match.groupValues[1] to score else null
            }.maxByOrNull{it.second}?.first
        } finally { c.disconnect() }
    }
}

class SongbookFragment : Fragment() {
    private lateinit var root: LinearLayout
    private lateinit var db: SongbookDb
    private val executor = Executors.newSingleThreadExecutor()
    private val youtubePrefs by lazy {
        requireContext().getSharedPreferences("saitenwerk_youtube", Context.MODE_PRIVATE)
    }
    private var youtubeAccessToken: String? = null
    private var youtubeConnected = false
    private var youtubeChannelName: String? = null
    private val youtubeAuthLauncher =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
            if (result.resultCode != Activity.RESULT_OK) {
                Toast.makeText(requireContext(), "YouTube-Verbindung abgebrochen.", Toast.LENGTH_SHORT).show()
                return@registerForActivityResult
            }
            try {
                val authorizationResult =
                    Identity.getAuthorizationClient(requireContext())
                        .getAuthorizationResultFromIntent(result.data)
                youtubeAccessToken = authorizationResult.accessToken
                youtubeConnected = !youtubeAccessToken.isNullOrBlank()
                if (!youtubeConnected) {
                    Toast.makeText(requireContext(), "Keine YouTube-Berechtigung erhalten.", Toast.LENGTH_LONG).show()
                    return@registerForActivityResult
                }
                youtubePrefs.edit().putBoolean("connected", true).apply()
                fetchYoutubeChannel()
            } catch (e: ApiException) {
                Toast.makeText(requireContext(), "YouTube-Autorisierung fehlgeschlagen: ${e.statusCode}", Toast.LENGTH_LONG).show()
            } catch (t: Throwable) {
                Toast.makeText(requireContext(), "YouTube-Autorisierung fehlgeschlagen.", Toast.LENGTH_LONG).show()
            }
        }

    private val importPdf = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importPdf(uri)
    }

    override fun onCreateView(inflater: android.view.LayoutInflater, container: ViewGroup?, state: Bundle?): View {
        db = SongbookDb(requireContext())
        youtubeConnected = youtubePrefs.getBoolean("connected", false)
        youtubeChannelName = youtubePrefs.getString("channel_name", null)
        root = LinearLayout(requireContext()).apply {
            orientation=LinearLayout.VERTICAL
            setPadding(dp(18),dp(12),dp(18),dp(24))
            setBackgroundColor(Color.rgb(7,19,30))
        }
        buildHome()
        return root
    }

    private fun buildHome() {
        root.removeAllViews()
        addText("SONGBOOK", 30f, Color.WHITE, 8)
        addText("Deine Songs. Deine Akkorde. Dein Training.", 15f, Color.LTGRAY, 2)
        addText("Importiere dein eigenes PDF – SaitenWerk analysiert es und legt nur deine Songs hier ab.", 13f, Color.LTGRAY, 1)
        val stats = db.all()
        val stat = card()
        val row = LinearLayout(requireContext()).apply { orientation=LinearLayout.HORIZONTAL }
        stat.addView(label("MEINE SONGS\n" + stats.size, 18f, Color.WHITE), LinearLayout.LayoutParams(0,dp(72),1f))
        stat.addView(label(stats.sumOf{it.chords.size}.toString() + " AKKORDE\nverknüpft", 18f, Color.WHITE), LinearLayout.LayoutParams(0,dp(72),1f))
        root.addView(stat)
        val import = button("＋  PDF analysieren & Songs importieren")
        import.setOnClickListener { importPdf.launch(arrayOf("application/pdf")) }
        root.addView(import)
        val pdfs = db.importedPdfs()
        if (pdfs.isNotEmpty()) {
            addText("MEINE IMPORTIERTEN PDFS", 13f, Color.rgb(205,145,91), 2)
            pdfs.forEach { pdf ->
                val pdfCard = card()
                pdfCard.addView(label("▤  " + pdf.displayName, 16f, Color.WHITE))
                pdfCard.addView(label(pdf.songCount.toString() + " erkannte Songs", 12f, Color.LTGRAY))
                val remove = button("PDF aus Songbook entfernen")
                remove.setOnClickListener {
                    AlertDialog.Builder(requireContext(), R.style.ThemeOverlay_Saitenwerk_Dialog)
                        .setTitle("Importiertes PDF entfernen?")
                        .setMessage("\"${pdf.displayName}\" und die ausschließlich daraus importierten Songs werden aus SaitenWerk entfernt. Die Originaldatei auf deinem Gerät bleibt erhalten.")
                        .setNegativeButton("Abbrechen", null)
                        .setPositiveButton("Entfernen") { _, _ ->
                            db.removePdf(pdf.uri)
                            runCatching {
                                requireContext().contentResolver.releasePersistableUriPermission(
                                    Uri.parse(pdf.uri), Intent.FLAG_GRANT_READ_URI_PERMISSION
                                )
                            }
                            buildHome()
                            Toast.makeText(requireContext(), "PDF und zugehörige Songs entfernt.", Toast.LENGTH_LONG).show()
                        }.show()
                }
                pdfCard.addView(remove)
                root.addView(pdfCard)
            }
        }
        val youtube = button(if (youtubeConnected) {
            "✓ YouTube verbunden" + (youtubeChannelName?.let { " · $it" } ?: "")
        } else {
            "▶ YouTube verbinden"
        })
        youtube.setOnClickListener {
            if (youtubeConnected) {
                AlertDialog.Builder(requireContext(), R.style.ThemeOverlay_Saitenwerk_Dialog)
                    .setTitle("YouTube verbunden")
                    .setMessage(
                        "Saitenwerk ist für dein YouTube-Konto autorisiert. " +
                        "Die App nutzt die Berechtigung nur für YouTube-Funktionen im Songbook."
                    )
                    .setNegativeButton("Verbindung lokal trennen") {
                        _, _ ->
                        youtubeAccessToken = null
                        youtubeConnected = false
                        youtubeChannelName = null
                        youtubePrefs.edit().clear().apply()
                        buildHome()
                    }
                    .setPositiveButton("OK", null)
                    .show()
            } else {
                authorizeYoutube()
            }
        }
        root.addView(youtube)

        val search = EditText(requireContext()).apply {
            hint="Song oder Künstler suchen"; setSingleLine(); setTextColor(Color.WHITE); setHintTextColor(Color.rgb(189,161,142))
            setPadding(dp(16),0,dp(16),0); inputType=InputType.TYPE_CLASS_TEXT
            setBackgroundColor(Color.rgb(20,43,58))
        }
        root.addView(search, LinearLayout.LayoutParams(-1,dp(52)).apply { topMargin=dp(12); bottomMargin=dp(10) })
        val list = LinearLayout(requireContext()).apply { orientation=LinearLayout.VERTICAL }
        val listScroll = ScrollView(requireContext()).apply {
            isFillViewport = false
            isVerticalScrollBarEnabled = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        }
        listScroll.addView(list, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(listScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        fun refresh(q:String="") {
            list.removeAllViews()
            db.all().filter { q.isBlank() || (it.title + " " + it.artist).contains(q,true) }.take(100).forEach { song ->
                val c=card()
                c.addView(label(song.title,19f,Color.WHITE))
                c.addView(label(song.artist + "  •  " + song.chords.size + " Akkorde",13f,Color.LTGRAY))
                val actions=LinearLayout(requireContext()).apply { orientation=LinearLayout.HORIZONTAL }
                val open=button("Öffnen"); open.setOnClickListener{showSong(song)}
                val yt=button(if(song.youtubeId==null) "YouTube suchen" else "▶ YouTube")
                yt.setOnClickListener { openYoutube(song) }
                actions.addView(open,LinearLayout.LayoutParams(0,dp(48),1f))
                actions.addView(yt,LinearLayout.LayoutParams(0,dp(48),1f))
                c.addView(actions); list.addView(c)
            }
        }
        search.addTextChangedListener(SimpleTextWatcher { refresh(it) })
        refresh()
        autoLinkYoutubeSongs()
    }

    private fun autoLinkYoutubeSongs() {
        val candidates = db.all().filter { it.youtubeId.isNullOrBlank() }.take(4)
        if (candidates.isEmpty()) return
        executor.execute {
            candidates.forEach { song ->
                val match = runCatching { YouTubeAutoLinker.findVideoId(song.title, song.artist) }.getOrNull()
                if (!match.isNullOrBlank()) {
                    runCatching { db.upsert(song.copy(youtubeId=match, youtubeConfidence=65)) }
                }
            }
        }
    }

    private fun showSong(song: SongbookSong) {
        root.removeAllViews()
        songbookActiveLine=-1
        val back=button("‹  Songbook");back.setOnClickListener{buildHome()};root.addView(back)
        addText(song.title,27f,Color.WHITE,4);addText(song.artist,15f,Color.LTGRAY,8)
        val prefs=requireContext().getSharedPreferences("songbook_performance_v1",Context.MODE_PRIVATE)
        val timeKey="times_${song.id}";val chordKey="line_chords_${song.id}"
        val times=runCatching{org.json.JSONObject(prefs.getString(timeKey,"{}")?:"{}")}.getOrElse{org.json.JSONObject()}
        val chords=runCatching{org.json.JSONObject(prefs.getString(chordKey,"{}")?:"{}")}.getOrElse{org.json.JSONObject()}
        val lines=song.lyrics.lines().map{it.trim()}.filter{it.isNotBlank()}
        var selectedLine=0
        val lineViews=mutableListOf<View>()
        lateinit var scroll:ScrollView
        var status:TextView?=null
        var web:WebView?=null
        val playerCard=card()
        if(!song.youtubeId.isNullOrBlank()){
            web=WebView(requireContext()).apply{
                settings.javaScriptEnabled=true;settings.domStorageEnabled=true;settings.mediaPlaybackRequiresUserGesture=false
                addJavascriptInterface(object{
                    @android.webkit.JavascriptInterface fun onTime(seconds:Double){requireActivity().runOnUiThread{updateSongbookLine(seconds,times,lines,lineViews,scroll,status)}}
                    @android.webkit.JavascriptInterface fun onReady(duration:Double){requireActivity().runOnUiThread{status?.text="Video bereit · ${times.length()} von ${lines.size} Zeitmarken"}}
                },"SaitenWerk")
                loadDataWithBaseURL("https://www.youtube.com",songbookPlayerHtml(song.youtubeId),"text/html","UTF-8",null)
            }
            playerCard.addView(web,LinearLayout.LayoutParams(-1,dp(210)))
        }else{
            playerCard.addView(label("Noch kein bestätigtes YouTube-Video verknüpft.",14f,Color.LTGRAY))
            val find=button("YouTube-Suche öffnen");find.setOnClickListener{openYoutube(song)};playerCard.addView(find)
        }
        root.addView(playerCard)
        val playback=LinearLayout(requireContext()).apply{orientation=LinearLayout.HORIZONTAL}
        val start=button("▶  Start");start.setOnClickListener{
            web?.evaluateJavascript("if(window.player){player.playVideo();}",null)
            if(times.length()==0)Toast.makeText(requireContext(),"Noch keine Zeitmarken. Spiele das Lied ab, wähle die jeweilige Textzeile und speichere ihre Zeitmarke.",Toast.LENGTH_LONG).show()
        }
        val pause=button("Ⅱ  Pause");pause.setOnClickListener{web?.evaluateJavascript("if(window.player){player.pauseVideo();}",null)}
        playback.addView(start,LinearLayout.LayoutParams(0,dp(48),1f));playback.addView(pause,LinearLayout.LayoutParams(0,dp(48),1f));root.addView(playback)
        status=label("Synchronisierung: ${times.length()} von ${lines.size} Zeilen markiert",13f,Color.LTGRAY);root.addView(status)

        if (!song.youtubeId.isNullOrBlank() && times.length() < lines.size) {
            status?.text = "Suche automatisch nach passenden YouTube-Untertiteln …"
            Thread {
                val aligned = runCatching { autoAlignLyricsFromYoutube(song.youtubeId!!, lines) }.getOrElse { org.json.JSONObject() }
                activity?.runOnUiThread {
                    if (aligned.length() > 0) {
                        val keys = aligned.keys()
                        while (keys.hasNext()) {
                            val key = keys.next()
                            if (!times.has(key)) times.put(key, aligned.optDouble(key))
                        }
                        prefs.edit().putString(timeKey, times.toString()).apply()
                        status?.text = "Automatisch synchronisiert: ${times.length()} von ${lines.size} Zeilen"
                    } else {
                        status?.text = "Keine passenden Untertitel gefunden – manuelle Zeitmarken bleiben verfügbar."
                    }
                }
            }.start()
        }
        val editing=LinearLayout(requireContext()).apply{orientation=LinearLayout.HORIZONTAL}
        val mark=button("Zeitmarke setzen");mark.setOnClickListener{
            val view=web?:return@setOnClickListener
            view.evaluateJavascript("window.player ? String(player.getCurrentTime()) : '0'"){raw->
                val seconds=raw?.trim('"')?.toDoubleOrNull()
                if(seconds!=null){times.put(selectedLine.toString(),seconds);prefs.edit().putString(timeKey,times.toString()).apply();status?.text="Synchronisierung: ${times.length()} von ${lines.size} Zeilen markiert";Toast.makeText(requireContext(),"Zeitmarke für Zeile ${selectedLine+1} gespeichert.",Toast.LENGTH_SHORT).show()}
            }
        }
        val chord=button("Akkord setzen");chord.setOnClickListener{
            val choices=(song.chords+listOf("C","D","Dm","E","Em","F","G","Am","A7","D7","G7","Bm","B7")).distinct().toTypedArray()
            AlertDialog.Builder(requireContext(), R.style.ThemeOverlay_Saitenwerk_Dialog).setTitle("Akkord über Zeile ${selectedLine+1}").setItems(choices){_,which->
                chords.put(selectedLine.toString(),choices[which]);prefs.edit().putString(chordKey,chords.toString()).apply();renderSongbookLines(lines,chords,lineViews,scroll){selectedLine=it}
            }.setNeutralButton("Akkord entfernen"){_,_->chords.remove(selectedLine.toString());prefs.edit().putString(chordKey,chords.toString()).apply();renderSongbookLines(lines,chords,lineViews,scroll){selectedLine=it}}.setNegativeButton("Abbrechen",null).show()
        }
        editing.addView(mark,LinearLayout.LayoutParams(0,dp(48),1.1f));editing.addView(chord,LinearLayout.LayoutParams(0,dp(48),1f));root.addView(editing)
        scroll=ScrollView(requireContext());val lyrics=LinearLayout(requireContext()).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(8),dp(10),dp(8),dp(36))}
        scroll.addView(lyrics);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        renderSongbookLines(lines,chords,lineViews,scroll){selectedLine=it}
    }

    private var songbookActiveLine:Int=-1
    private fun renderSongbookLines(lines:List<String>,chords:org.json.JSONObject,views:MutableList<View>,scroll:ScrollView,select:(Int)->Unit){
        val box=scroll.getChildAt(0) as? LinearLayout ?: return
        box.removeAllViews();views.clear()
        lines.forEachIndexed{index,line->
            val item=LinearLayout(requireContext()).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),dp(7),dp(10),dp(7));setBackgroundColor(if(index==songbookActiveLine)Color.rgb(67,49,35)else Color.rgb(22,24,29))}
            val chord=chords.optString(index.toString(),"");if(chord.isNotBlank())item.addView(label(chord,15f,Color.rgb(218,169,112)))
            item.addView(label(line,17f,Color.WHITE));item.setOnClickListener{select(index);Toast.makeText(requireContext(),"Zeile ${index+1} ausgewählt",Toast.LENGTH_SHORT).show()}
            box.addView(item,LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT).apply{bottomMargin=dp(5)});views.add(item)
        }
    }
    private fun updateSongbookLine(seconds:Double,times:org.json.JSONObject,lines:List<String>,views:List<View>,scroll:ScrollView,status:TextView?){
        var next=-1;var latest=-1.0
        for(i in lines.indices)if(times.has(i.toString())){val t=times.optDouble(i.toString(),-1.0);if(t<=seconds&&t>=latest){latest=t;next=i}}
        if(next>=0&&next!=songbookActiveLine){songbookActiveLine=next;views.forEachIndexed{i,v->v.setBackgroundColor(if(i==next)Color.rgb(67,49,35)else Color.rgb(22,24,29))};if(next<views.size)scroll.smoothScrollTo(0,views[next].top)}
        status?.text="Videoposition ${"%.1f".format(java.util.Locale.US,seconds)} s · ${times.length()} Zeitmarken"
    }

    private fun autoAlignLyricsFromYoutube(videoId:String, lines:List<String>):org.json.JSONObject {
        val result=org.json.JSONObject()
        fun words(value:String)=value.lowercase(java.util.Locale.ROOT)
            .replace(Regex("[^\\p{L}\\p{N} ]")," ")
            .split(Regex("\\s+")).filter{it.length>2}.toSet()
        for (language in listOf("de","en")) {
            val url="https://www.youtube.com/api/timedtext?v="+
                java.net.URLEncoder.encode(videoId,"UTF-8")+
                "&lang="+language+"&kind=asr&fmt=json3"
            val connection=(java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
                connectTimeout=7000;readTimeout=9000
                setRequestProperty("User-Agent","Mozilla/5.0 (Android) SaitenWerk")
            }
            val events=try {
                if(connection.responseCode !in 200..299) continue
                val body=connection.inputStream.bufferedReader().use{it.readText()}
                val array=org.json.JSONObject(body).optJSONArray("events") ?: continue
                val captions=mutableListOf<Pair<Double,String>>()
                for(i in 0 until array.length()) {
                    val event=array.optJSONObject(i) ?: continue
                    val segments=event.optJSONArray("segs") ?: continue
                    val text=buildString {
                        for(j in 0 until segments.length()) append(segments.optJSONObject(j)?.optString("utf8","") ?: "")
                    }.trim()
                    val start=event.optDouble("tStartMs",-1.0)/1000.0
                    if(start>=0 && text.isNotBlank()) captions += start to text
                }
                captions
            } catch (_:Throwable) { emptyList() } finally { connection.disconnect() }
            if(events.isEmpty()) continue

            var cursor=0
            for(lineIndex in lines.indices) {
                val target=words(lines[lineIndex])
                if(target.size<2) continue
                var bestScore=0.0
                var bestStart=-1.0
                var bestEnd=cursor
                for(start in cursor until events.size) {
                    val combined=StringBuilder()
                    for(end in start until minOf(events.size,start+9)) {
                        if(events[end].first-events[start].first>11.0) break
                        combined.append(' ').append(events[end].second)
                        val spoken=words(combined.toString())
                        val score=target.count{it in spoken}.toDouble()/target.size
                        if(score>bestScore) {
                            bestScore=score;bestStart=events[start].first;bestEnd=end+1
                        }
                    }
                    if(bestScore>=0.82) break
                }
                if(bestStart>=0 && bestScore>=0.52) {
                    result.put(lineIndex.toString(),bestStart)
                    cursor=maxOf(cursor,bestEnd)
                }
            }
            if(result.length()>=maxOf(2,lines.size/5)) return result
            result.keys().asSequence().toList().forEach{result.remove(it)}
        }
        return result
    }

    private fun songbookPlayerHtml(id:String)= """
        <!doctype html><html><body style="margin:0;background:#000"><div id="player" style="width:100%;height:210px"></div>
        <script src="https://www.youtube.com/iframe_api"></script><script>var player;
        function onYouTubeIframeAPIReady(){player=new YT.Player('player',{videoId:'$id',playerVars:{playsinline:1,rel:0},events:{onReady:function(e){SaitenWerk.onReady(e.target.getDuration());setInterval(function(){try{SaitenWerk.onTime(player.getCurrentTime());}catch(x){}},250);}}});}
        </script></body></html>
    """.trimIndent()

    private fun authorizeYoutube() {
        val requestedScopes = listOf(
            Scope("https://www.googleapis.com/auth/youtube.readonly")
        )
        val request = AuthorizationRequest.builder()
            .setRequestedScopes(requestedScopes)
            .build()

        Identity.getAuthorizationClient(requireContext())
            .authorize(request)
            .addOnSuccessListener { authorizationResult ->
                if (authorizationResult.hasResolution()) {
                    val pendingIntent = authorizationResult.pendingIntent
                    if (pendingIntent == null) {
                        Toast.makeText(requireContext(), "Google konnte den Autorisierungsdialog nicht öffnen.", Toast.LENGTH_LONG).show()
                    } else {
                        youtubeAuthLauncher.launch(
                            IntentSenderRequest.Builder(pendingIntent.intentSender).build()
                        )
                    }
                } else {
                    youtubeAccessToken = authorizationResult.accessToken
                    youtubeConnected = !youtubeAccessToken.isNullOrBlank()
                    if (youtubeConnected) {
                        youtubePrefs.edit().putBoolean("connected", true).apply()
                        fetchYoutubeChannel()
                    } else {
                        Toast.makeText(requireContext(), "YouTube-Berechtigung wurde nicht erteilt.", Toast.LENGTH_LONG).show()
                    }
                }
            }
            .addOnFailureListener {
                Toast.makeText(requireContext(), "YouTube-Autorisierung konnte nicht gestartet werden.", Toast.LENGTH_LONG).show()
            }
    }

    private fun fetchYoutubeChannel() {
        val token = youtubeAccessToken ?: return
        executor.execute {
            try {
                val url = java.net.URL("https://www.googleapis.com/youtube/v3/channels?part=snippet&mine=true")
                val connection = (url.openConnection() as java.net.HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 10000
                    readTimeout = 10000
                    setRequestProperty("Authorization", "Bearer $token")
                    setRequestProperty("Accept", "application/json")
                }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
                connection.disconnect()
                if (code !in 200..299) {
                    requireActivity().runOnUiThread {
                        youtubePrefs.edit().putBoolean("connected", true).apply()
                        Toast.makeText(
                            requireContext(),
                            "YouTube ist verbunden. Kanalinformationen konnten nicht gelesen werden.",
                            Toast.LENGTH_LONG
                        ).show()
                        buildHome()
                    }
                    return@execute
                }
                val items = org.json.JSONObject(body).optJSONArray("items")
                val name = items?.optJSONObject(0)?.optJSONObject("snippet")?.optString("title").orEmpty()
                youtubeChannelName = name.ifBlank { null }
                youtubePrefs.edit().putBoolean("connected", true).apply {
                    if (name.isBlank()) remove("channel_name") else putString("channel_name", name)
                }.apply()
                requireActivity().runOnUiThread {
                    Toast.makeText(
                        requireContext(),
                        if (name.isBlank()) "YouTube erfolgreich verbunden." else "YouTube verbunden mit: $name",
                        Toast.LENGTH_LONG
                    ).show()
                    buildHome()
                }
            } catch (t: Throwable) {
                requireActivity().runOnUiThread {
                    Toast.makeText(requireContext(), "YouTube verbunden, Kanal konnte nicht geladen werden.", Toast.LENGTH_LONG).show()
                    buildHome()
                }
            }
        }
    }

    private fun openYoutube(song: SongbookSong) {
        val query=Uri.encode(song.artist + " " + song.title + " guitar")
        startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://www.youtube.com/results?search_query="+query)))
    }

    private fun youtubeHtml(id:String)= """
        <!doctype html><html><body style="margin:0;background:#000">
        <iframe width="100%" height="100%" src="https://www.youtube.com/embed/$id?enablejsapi=1&playsinline=1"
        title="YouTube Player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
        </body></html>
    """.trimIndent()

    private fun importPdf(uri:Uri) {
        val progress=ProgressBar(requireContext())
        root.addView(progress,0,LinearLayout.LayoutParams(-1,dp(5)))
        executor.execute {
            try {
                val context = requireContext().applicationContext
                runCatching {
                    requireContext().contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                }
                val displayName = queryPdfDisplayName(uri)
                PDFBoxResourceLoader.init(context)
                val extracted = requireContext().contentResolver.openInputStream(uri).use { input ->
                    if(input==null) error("PDF konnte nicht geöffnet werden.")
                    PDDocument.load(input).use { doc ->
                        val pages = mutableListOf<String>()
                        val renderer = runCatching {
                            val descriptor = requireContext().contentResolver.openFileDescriptor(uri, "r")
                                ?: error("PDF-Datei kann nicht für die Texterkennung geöffnet werden.")
                            PdfRenderer(descriptor)
                        }.getOrNull()
                        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                        try {
                            for (pageIndex in 0 until doc.numberOfPages) {
                                val stripper = PDFTextStripper().apply {
                                    sortByPosition = true
                                    lineSeparator = "\n"
                                    startPage = pageIndex + 1
                                    endPage = pageIndex + 1
                                }
                                var pageText = stripper.getText(doc).trim()
                                val usefulChars = pageText.count { it.isLetterOrDigit() }
                                if (usefulChars < 24 && renderer != null && pageIndex < renderer.pageCount) {
                                    val ocrText = renderer.openPage(pageIndex).use { page ->
                                        val bitmap = Bitmap.createBitmap(
                                            (page.width * 2).coerceAtLeast(1),
                                            (page.height * 2).coerceAtLeast(1),
                                            Bitmap.Config.ARGB_8888
                                        )
                                        try {
                                            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                            Tasks.await(recognizer.process(InputImage.fromBitmap(bitmap, 0))).text
                                        } finally { bitmap.recycle() }
                                    }
                                    if (ocrText.isNotBlank()) pageText = ocrText
                                }
                                if (pageText.isNotBlank()) pages += "[[SAITENWERK_SEITE_${pageIndex + 1}]]\n" + pageText
                            }
                        } finally {
                            recognizer.close()
                            renderer?.close()
                        }
                        pages.joinToString("\n\n")
                    }
                }
                val songs = SongbookParser.parse(extracted, uri.toString())
                if (songs.isEmpty()) error("Es konnten keine Songs erkannt werden. Bitte prüfe, ob die PDF lesbaren Text oder gut erkennbare Noten-/Akkordseiten enthält.")
                val savedCount = db.replacePdfSongs(uri.toString(), songs)
                if (savedCount == 0) error("Songs erkannt, aber kein Song konnte gespeichert werden.")
                db.registerPdf(uri.toString(), displayName, savedCount)
                requireActivity().runOnUiThread {
                    if(progress.parent!=null) root.removeView(progress)
                    buildHome()
                    AlertDialog.Builder(requireContext(), R.style.ThemeOverlay_Saitenwerk_Dialog).setTitle("PDF analysiert")
                        .setMessage(savedCount.toString() + " Songs erkannt und gespeichert. Das Songbook wurde aktualisiert.\n\nText-PDFs werden direkt ausgelesen; gescannte Seiten werden zusätzlich per Texterkennung (OCR) verarbeitet.")
                        .setPositiveButton("OK", null).show()
                }
            } catch(t:Throwable) {
                requireActivity().runOnUiThread {
                    if(progress.parent!=null) root.removeView(progress)
                    AlertDialog.Builder(requireContext(), R.style.ThemeOverlay_Saitenwerk_Dialog).setTitle("Import fehlgeschlagen")
                        .setMessage(t.cause?.message ?: t.message ?: "Unbekannter PDF-Fehler").setPositiveButton("OK",null).show()
                }
            }
        }
    }

    private fun queryPdfDisplayName(uri: Uri): String {
        var name = "Songbook-PDF"
        requireContext().contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) name = c.getString(0)?.takeIf { it.isNotBlank() } ?: name
        }
        return name
    }

    private fun card(): LinearLayout = LinearLayout(requireContext()).apply {
        orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(14),dp(16),dp(14))
        setBackgroundColor(Color.rgb(13,32,45))
        val p=LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT)
        p.setMargins(0,dp(7),0,dp(7))
        layoutParams = p
    }
    private fun button(text:String)=Button(requireContext()).apply {
        this.text=text
        setTextColor(Color.rgb(221,162,122))
        setAllCaps(false)
        textSize=14f
        typeface=android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        gravity=android.view.Gravity.CENTER
        includeFontPadding=true
        minLines=1
        maxLines=2
        minHeight=dp(52)
        minimumHeight=dp(52)
        setPadding(dp(16),dp(10),dp(16),dp(10))
        background=android.graphics.drawable.GradientDrawable().apply {
            cornerRadius=dp(16).toFloat()
            setColor(Color.rgb(20,43,58))
            setStroke(dp(1),Color.rgb(41,67,84))
        }
    }
    private fun label(text:String,size:Float,color:Int)=TextView(requireContext()).apply { this.text=text; textSize=size; setTextColor(color); setPadding(0,dp(4),dp(8),dp(4)) }
    private fun addText(text:String,size:Float,color:Int,bottom:Int){ root.addView(label(text,size,color),LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT).apply{bottomMargin=dp(bottom)}) }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
}

private class SimpleTextWatcher(val changed:(String)->Unit): android.text.TextWatcher {
    override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}
    override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){changed(s?.toString()?:"")}
    override fun afterTextChanged(s:android.text.Editable?){}
}
