# Saitenwerk Native 3.0 – Alpha 2

Native Android project for Saitenwerk – Von David Elger.

## Included
- Native Activity + Fragment navigation (Start, Stimmen, Akkorde, Lieder, Lernstudio, Lernpfad)
- AndroidX configuration and runtime microphone permission declaration
- 500 song titles in the local JSON asset and native songbook search
- Native chord library with 20 chord shapes, finger diagrams, category filters and local favorites
- **New in Alpha 2:** interactive chord-change trainer (C–G–Am–F), adjustable 50–160 BPM metronome, beat accents, live change counter, and locally stored self-assessment (`Sitzt` / `Weiter üben`)
- Legacy HTML retained as a migration reference in `app/src/main/assets/saitenwerk_legacy.html`

## Build
Open the `SaitenwerkNative` folder in Android Studio or push it to GitHub and run the included Actions workflow. The current execution environment has no Gradle installation / Android SDK, so this package has not been built into an APK here. The workflow result is the authoritative build check.

## Notes
- The metronome produces simple timing clicks; it does not claim to synthesize guitar chord audio.
- The tuner screen currently requests microphone permission but still needs the native pitch-detection engine.
- Song title migration is complete at the title level; full song arrangements are being migrated separately.
