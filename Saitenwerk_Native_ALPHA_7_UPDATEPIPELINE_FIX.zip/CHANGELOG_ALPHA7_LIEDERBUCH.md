# Saitenwerk Alpha 7 – Liederbuch-Iteration

## Änderungen
- Automatische Zwischenspeicherung des aktuellen Songabschnitts bei Texteingabe.
- Automatische Speicherung der Kapodaster- und Transponierungseinstellungen.
- Sicherung des bisherigen Abschnitts vor dem Wechsel zu einem anderen Abschnitt.
- Erweiterte Erkennung gängiger Akkordqualitäten und Slash-Akkorde.
- Transponierung verschiebt jetzt sowohl den Akkordgrundton als auch eine vorhandene Bassnote (z. B. `C#m7/G#` → zwei Halbtöne höher → `D♯m7/A♯`).
- Vorhandene Songdaten, Favoriten, Setlist, Navigation und sonstige App-Bereiche wurden nicht absichtlich verändert.

## Prüfung
- ZIP-Archivstruktur geprüft.
- 500 vorhandene Songdatensätze geprüft und erhalten.
- Kotlin-Logik für Akkorderkennung und Transponierung isoliert kompiliert und mit Beispielen geprüft.
- Vollständiger Android-Gradle-Build in dieser Umgebung nicht ausgeführt: Gradle/Android-SDK sind hier nicht eingerichtet.
- Reale Geräteprüfung steht aus.

## Hinweis zu Songinhalten
Die 500 vorhandenen Einträge bleiben Songkatalog-Einträge. Vollständige Liedtexte und Akkordarrangements werden nur ergänzt, wenn sie selbst erstellt, gemeinfrei oder entsprechend lizenziert sind.
